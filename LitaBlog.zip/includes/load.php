<?php
/**
* Bootstrap file
*/
if (!defined('DEBUG') || !DEBUG) {
    ini_set('display_errors', 'Off');
    error_reporting(0);
}
// Define core constant
define('CORE', true);

// Load configuration
require_once dirname(__FILE__) . '/../config.php';


// ==========================
// 1. 获取真实客户端信息（代理兼容）
// ==========================
$http_host = $_SERVER['HTTP_HOST'] ?? '';
$http_host = preg_replace('/:\d+$/', '', $http_host); // 过滤端口号

// 恢复真实客户端 IP
if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
    $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
    $_SERVER['REMOTE_ADDR'] = trim($ips[0]);
}

// ==========================
// 2. HTTPS 识别（多源增强）
// ==========================
$is_secure = false;
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    $is_secure = true;
} elseif (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') {
    $is_secure = true;
} elseif (($_SERVER['HTTP_CF_VISITOR'] ?? '') === '{"scheme":"https"}') {
    // 兼容部分旧版 Cloudflare 环境
    $is_secure = true;
}

// ==========================
// 3. Cookie domain（安全防御调整）
// ==========================
$cookie_domain = ''; 

// 仅当需要处理多级子域名共享，且排除了 eu.org 等公共后缀以及 IP 地址时，才启用以下逻辑：
/*
$parts = explode('.', $http_host);
$is_ip = filter_var($http_host, FILTER_VALIDATE_IP);
// 排除局域网、本地开发及公共后缀域名
if (!$is_ip && count($parts) >= 2 && !preg_match('/\.(eu\.org|com\.cn|org\.cn)$/i', $http_host)) {
    $cookie_domain = '.' . $parts[count($parts) - 2] . '.' . $parts[count($parts) - 1];
}
*/

// ==========================
// 4. Cookie path & Session Name
// ==========================
$cookie_path = '/';
session_name('MYAPPSESSID'); // 自定义 Session Name 避免与宿主服务器冲突

// ==========================
// 5. Session cookie 安全配置
// ==========================
if (session_status() === PHP_SESSION_NONE) {
    // 设置安全、符合现代浏览器标准的 Cookie 参数
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => $cookie_path,
        'domain'   => $cookie_domain, // 留空，由浏览器自动锁定当前精确域名（支持 eu.org 和 IP）
        'secure'   => $is_secure,      // 如果是 HTTPS 则启用 Secure 标记
        'httponly' => true,            // 防范 XSS 劫持 Cookie
        'samesite' => 'Lax'            // 采用安全且兼容性最佳的 Lax 模式
    ]);

    session_start();
}


// 设置安全响应头与移除敏感信息
if (!headers_sent()) {
    header_remove('X-Powered-By'); // 移除 PHP 版本泄露
    header('X-Frame-Options: SAMEORIGIN'); // 防范点击劫持
    header('X-Content-Type-Options: nosniff'); // 防范 MIME 嗅探
    header('Referrer-Policy: strict-origin-when-cross-origin'); // 限制 Referrer 泄漏
    
    // 针对 HTTPS 额外加固
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    }
}


// Load classes
require_once ABSPATH . '/includes/router.php';
require_once ABSPATH . '/includes/permalink.php';

// Load functions
require_once ABSPATH . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'functions.php';
require_once ABSPATH . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'db_wrapper.php';

// --- 设置全局默认时区 ---
$site_timezone = get_option('site_timezone', 'Asia/Shanghai'); // 获取设置，提供默认值
date_default_timezone_set($site_timezone);
// --- 全局时区设置结束 ---

// Start session if not started
//if (session_status() === PHP_SESSION_NONE) {session_start();}

// Initialize database connection
global $db;
$db = get_db();


// --- 新增：Remember Me 自动登录校验 ---

if (!isset($_SESSION['user_id']) && isset($_COOKIE['lita_remember'])) {

$parts = explode(':', $_COOKIE['lita_remember'], 2);

if (count($parts) === 2) {

$selector = $parts[0];

$validator = $parts[1];

$hashed_validator = hash('sha256', $validator);



try {

$db = get_db();

// 一次性查出带有 remember_tokens 的用户数据

$stmt = $db->prepare("SELECT user_id, meta_value FROM usermeta WHERE meta_key = 'remember_tokens'");

$stmt->execute();

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);



$matched_user_id = null;

$matched_tokens = [];

$target_token_index = -1;



foreach ($rows as $row) {

$tokens = unserialize($row['meta_value']);

if (is_array($tokens)) {

foreach ($tokens as $idx => $t) {

if ($t['selector'] === $selector && $t['expires'] > time()) {

if (hash_equals($t['hashed_validator'], $hashed_validator)) {

$matched_user_id = $row['user_id'];

$matched_tokens = $tokens;

$target_token_index = $idx;

break 2;

}

}

}

}

}



if ($matched_user_id) {

$user = get_user($matched_user_id);

if ($user && $user['status'] === 'active') {

// 1. 重建会话

$_SESSION['user_id'] = $user['id'];

$_SESSION['username'] = $user['username'];

$_SESSION['role'] = $user['role'];



// 2. 轮转单次验证令牌以确保安全

$new_validator = bin2hex(random_bytes(24));

$new_hashed_validator = hash('sha256', $new_validator);



$matched_tokens[$target_token_index]['hashed_validator'] = $new_hashed_validator;

update_user_meta($matched_user_id, 'remember_tokens', $matched_tokens);



// 3. 刷新客户端 Cookie 的验证器部分，保持过期时间不变

setcookie(

'lita_remember',

$selector . ':' . $new_validator,

$matched_tokens[$target_token_index]['expires'],

'/',

'',

isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',

true

);

}

}

} catch (Exception $e) {

error_log("Auto login error: " . $e->getMessage());

}

}

}

// --- 结束 ---


// Load active plugins (only once)
if (!defined('PLUGINS_LOADED')) {
define('PLUGINS_LOADED', true);
$active_plugins = get_active_plugins();
foreach ($active_plugins as $plugin) {
$plugin_file = ABSPATH . 'content/plugins/' . $plugin['slug'] . '/' . $plugin['slug'] . '.php';
if (file_exists($plugin_file)) {
require_once $plugin_file;
}
}
}
// Trigger the init hook for plugins
do_action('init');