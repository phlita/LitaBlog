<?php
/**
* 固定链接设置类
*/
class Permalink {
// 固定链接类型
const TYPE_DEFAULT = 'default';     // 默认 ?p=123
const TYPE_NUMERIC = 'numeric';     // 数字式 123.html
const TYPE_POST = 'post';           // 文章式 post/123

/**
* 获取当前固定链接类型
*/
public static function get_type() {
return get_option('permalink_type', self::TYPE_DEFAULT);
}

/**
* 获取文章链接
*/
public static function get_post_link($post_id) {
$type = self::get_type();
$base_url = rtrim(SITE_URL, '/');

switch($type) {
case self::TYPE_NUMERIC:
return $base_url . '/' . $post_id . '.html';
case self::TYPE_POST:
return $base_url . '/post/' . $post_id;
default:
return $base_url . '/?p=' . $post_id;
}
}
}
