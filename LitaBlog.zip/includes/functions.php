<?php
/**
* Core functions
*/

// Database connection
function get_db() {
static $db = null;
if ($db === null) {
try {
// Check if config exists and load it
$config_file = dirname(__FILE__) . '/../config.php';
if (!file_exists($config_file)) {
throw new Exception('Blog is not installed');
}

if (!defined('DB_FILE')) {
require_once $config_file;
}

if (!file_exists(DB_FILE)) {
throw new Exception('Database file not found');
}

$db = new PDO('sqlite:' . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// ========== 新增以下 4 行 SQLite 底层性能调优 ==========
$db->exec('PRAGMA journal_mode = WAL;');       // 开启 WAL 写入日志模式
$db->exec('PRAGMA synchronous = NORMAL;');     // 调整磁盘同步频率为“普通”
$db->exec('PRAGMA busy_timeout = 5000;');      // 设置锁库等待时间为 5 秒
$db->exec('PRAGMA cache_size = -16000;');       // 设置缓存大小为约 16MB
// ===================================================

// Enable foreign key support
$db->exec('PRAGMA foreign_keys=ON;');
} catch (PDOException $e) {
die('Database connection failed: ' . $e->getMessage());
} catch (Exception $e) {
die('Configuration error: ' . $e->getMessage());
}
}
return $db;
}

// Get option value
/*
function get_option($name, $default = '') {
try {
$db = get_db();
$stmt = $db->prepare('SELECT value FROM options WHERE name = ?');
$stmt->execute([$name]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result ? $result['value'] : $default;
} catch (PDOException $e) {
return $default;
}
}
*/

// Get option value (支持内存缓存的优化版)
function get_option($name, $default = '') {
    // 声明一个静态变量。它的特点是：在这一次网页加载（PHP进程生命周期）中，它的值会一直保留
    static $cached_options = null;

    try {
        // 如果是第一次调用该函数，$cached_options 还是空值，此时去查一次数据库
        if ($cached_options === null) {
            $db = get_db();
            // 一次性把 options 表里的所有配置都查出来，不要一条一条查
            $stmt = $db->query('SELECT name, value FROM options');
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $cached_options = [];
            foreach ($results as $row) {
                $cached_options[$row['name']] = $row['value'];
            }
        }

        // 以后再次调用 get_option() 时，直接在 PHP 内存（$cached_options 数组）中查找，不再查数据库
        return isset($cached_options[$name]) ? $cached_options[$name] : $default;

    } catch (PDOException $e) {
        return $default;
    }
}


// Update option value
function update_option($name, $value) {
try {
$db = get_db();
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
return $stmt->execute([$name, $value]);
} catch (PDOException $e) {
return false;
}
}



//--- START OF MODIFICATION - includes/functions.php (Post Meta Functions) ---

/**
* Retrieves a post meta field for a given post ID.
*
* @param int    $post_id     Post ID.
* @param string $meta_key    Optional. The meta key to retrieve. If empty, returns all meta for the post.
* @param bool   $single      Optional. Whether to return a single value. Default true.
*                            If $meta_key is empty, $single is ignored and all meta is returned as an array.
* @return mixed             Value of meta data field if $single is true and $meta_key is specified.
*                           Array of values if $single is false and $meta_key is specified.
*                           Array of all meta key-value pairs if $meta_key is empty.
*                           Empty string or empty array if no meta found.
*/

function get_post_meta($post_id, $meta_key = '', $single = true) {
$db = get_db();
try {
if (empty($meta_key)) { // Get all meta for the post
$stmt = $db->prepare("SELECT meta_key, meta_value FROM postmeta WHERE post_id = :post_id");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$all_meta = array();
foreach ($results as $row) {
$value = @unserialize($row['meta_value']);
if ($value === false && $row['meta_value'] !== 'b:0;') { // Check if it was a non-serialized string
$value = $row['meta_value'];
}
// Handle multiple values for the same key
if (isset($all_meta[$row['meta_key']])) {
if (!is_array($all_meta[$row['meta_key']])) {
$all_meta[$row['meta_key']] = array($all_meta[$row['meta_key']]);
}
$all_meta[$row['meta_key']][] = $value;
} else {
$all_meta[$row['meta_key']] = array($value); // Always store as array initially
}
}
// If a key was expected to have only one value, simplify it
foreach($all_meta as $key => &$values) {
if(count($values) === 1) {
$values = $values[0];
}
}
return $all_meta;
} else { // Get specific meta key
$stmt = $db->prepare("SELECT meta_value FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($results)) {
return $single ? '' : array();
}

$values = array();
foreach ($results as $value) {
$unserialized_value = @unserialize($value);
if ($unserialized_value === false && $value !== 'b:0;') {
$values[] = $value;
} else {
$values[] = $unserialized_value;
}
}

if ($single) {
return $values[0];
}
return $values;
}
} catch (PDOException $e) {
error_log("Error in get_post_meta: " . $e->getMessage());
return $single ? '' : array();
}
}




/**
* Updates a post meta field for a given post ID.
* If the meta field for the post does not exist, it will be added.
*
* @param int    $post_id    Post ID.
* @param string $meta_key   The meta key to update.
* @param mixed  $meta_value The new meta value. Must be serializable if non-scalar.
* @param mixed  $prev_value Optional. If specified, only update existing metadata entry with this value.
*                           Otherwise, update all entries with the new value.
* @return bool              True on success, false on failure.
*/
function update_post_meta($post_id, $meta_key, $meta_value, $prev_value = '') {
$db = get_db();
try {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;

// Check if meta key exists for this post
$current_meta = get_post_meta($post_id, $meta_key, false); // Get all values for this key

if (empty($current_meta)) { // Meta doesn't exist, add it
return add_post_meta($post_id, $meta_key, $meta_value);
} else { // Meta exists, update it
if (!empty($prev_value)) {
$prev_value_serialized = (is_array($prev_value) || is_object($prev_value)) ? serialize($prev_value) : $prev_value;
$stmt = $db->prepare("UPDATE postmeta SET meta_value = :meta_value WHERE post_id = :post_id AND meta_key = :meta_key AND meta_value = :prev_value");
$stmt->bindValue(':prev_value', $prev_value_serialized, PDO::PARAM_STR);
} else {
// If no prev_value, update all matching keys (or first one, depending on desired behavior)
// For simplicity, this will update the first found meta ID with this key.
// A more robust solution might delete all old values and add the new one.
// Or update only one record. Let's delete and add for cleaner update of single values.
delete_post_meta($post_id, $meta_key);
return add_post_meta($post_id, $meta_key, $meta_value);

// Alternative: Update one existing record (less common for update_post_meta if key isn't unique by design)
// $stmt = $db->prepare("UPDATE postmeta SET meta_value = :meta_value WHERE post_id = :post_id AND meta_key = :meta_key LIMIT 1");
}
// $stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
// $stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
// $stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
// return $stmt->execute();
}
} catch (PDOException $e) {
error_log("Error in update_post_meta: " . $e->getMessage());
return false;
}
}



/**
* Adds a new post meta field for a given post ID.
*
* @param int    $post_id    Post ID.
* @param string $meta_key   The meta key to add.
* @param mixed  $meta_value The new meta value. Must be serializable if non-scalar.
* @param bool   $unique     Optional. Whether the meta key should be unique. Default false.
*                           If true and the meta key already exists, the function will not add the new value.
* @return bool|int          Meta ID on success, false on failure.
*/
function add_post_meta($post_id, $meta_key, $meta_value, $unique = false) {
$db = get_db();
try {
if ($unique) {
$existing = get_post_meta($post_id, $meta_key, true); // Check if any value exists for this key
if (!empty($existing) || ($existing === '0' && $meta_value !== 0) ) { // Allow '0' if it's a legit value
return false; // Unique meta already exists
}
}

$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;

$stmt = $db->prepare("INSERT INTO postmeta (post_id, meta_key, meta_value) VALUES (:post_id, :meta_key, :meta_value)");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);

if ($stmt->execute()) {
return $db->lastInsertId();
}
return false;
} catch (PDOException $e) {
error_log("Error in add_post_meta: " . $e->getMessage());
return false;
}
}

/**
* Deletes a post meta field for a given post ID.
*
* @param int    $post_id    Post ID.
* @param string $meta_key   The meta key to delete.
* @param mixed  $meta_value Optional. If specified, only delete rows with this meta_key and meta_value.
* @return bool              True on success, false on failure.
*/
function delete_post_meta($post_id, $meta_key, $meta_value = '') {
$db = get_db();
try {
if (!empty($meta_value)) {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("DELETE FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key AND meta_value = :meta_value");
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
} else {
$stmt = $db->prepare("DELETE FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key");
}
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
} catch (PDOException $e) {
error_log("Error in delete_post_meta: " . $e->getMessage());
return false;
}
}

// --- END OF MODIFICATION - includes/functions.php (Post Meta Functions) ---


// Get user by ID
function get_user($user_id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$user_id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return false;
}
}

// Get username by ID
function get_username($user_id) {
$user = get_user($user_id);
return $user ? $user['username'] : 'Unknown';
}

// --- START OF MODIFICATION - includes/functions.php (User Meta Functions) ---

/**
* Retrieves a user meta field for a given user ID.
*
* @param int    $user_id     User ID.
* @param string $meta_key    Optional. The meta key to retrieve. If empty, returns all meta for the user.
* @param bool   $single      Optional. Whether to return a single value. Default false.
*                            If $meta_key is empty, $single is ignored and all meta is returned as an array of arrays.
* @return mixed             Value of meta data field if $single is true and $meta_key is specified.
*                           Array of values if $single is false and $meta_key is specified (can be multiple rows for same key).
*                           Array of all meta key-value pairs (value as array) if $meta_key is empty.
*                           Empty string or empty array if no meta found.
*/
function get_user_meta($user_id, $meta_key = '', $single = false) {
$db = get_db();
try {
if (empty($meta_key)) { // Get all meta for the user
$stmt = $db->prepare("SELECT meta_key, meta_value FROM usermeta WHERE user_id = :user_id");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$all_meta = array();
foreach ($results as $row) {
$value = @unserialize($row['meta_value']);
if ($value === false && $row['meta_value'] !== 'b:0;') { // Check if it was a non-serialized string
$value = $row['meta_value'];
}
// Always store as an array of values for each key, as a key can have multiple entries
if (!isset($all_meta[$row['meta_key']])) {
$all_meta[$row['meta_key']] = array();
}
$all_meta[$row['meta_key']][] = $value;
}
return $all_meta;
} else { // Get specific meta key
$stmt = $db->prepare("SELECT meta_value FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($results)) {
return $single ? '' : array();
}

$values = array();
foreach ($results as $value) {
$unserialized_value = @unserialize($value);
// Check if unserialization failed for a reason other than it being a non-serialized string (like 'b:0;' for false boolean)
if ($unserialized_value === false && $value !== 'b:0;') {
$values[] = $value; // Treat as a raw string
} else {
$values[] = $unserialized_value; // Use the unserialized value
}
}

if ($single) {
return $values[0]; // Return the first value
}
return $values; // Return all values for that key
}
} catch (PDOException $e) {
error_log("Error in get_user_meta: " . $e->getMessage());
return $single ? '' : array();
}
}

/**
* Adds a new user meta field for a given user ID.
*
* @param int    $user_id    User ID.
* @param string $meta_key   The meta key to add.
* @param mixed  $meta_value The new meta value. Must be serializable if non-scalar.
* @param bool   $unique     Optional. Whether the meta key should be unique for this user. Default false.
*                           If true and the meta key already exists for the user, the function will not add the new value.
* @return int|false         Meta ID on success, false on failure.
*/
function add_user_meta($user_id, $meta_key, $meta_value, $unique = false) {
$db = get_db();
try {
if ($unique) {
$existing = get_user_meta($user_id, $meta_key, true); // Check if any value exists for this key for this user
// Consider '0' and empty string as potentially valid distinct values.
// If $existing is not an empty array OR it's not an empty string (when $single = true)
if ($existing !== '' && !empty($existing)) {
return false; // Unique meta already exists for this user
}
}

$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;

$stmt = $db->prepare("INSERT INTO usermeta (user_id, meta_key, meta_value) VALUES (:user_id, :meta_key, :meta_value)");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);

if ($stmt->execute()) {
return $db->lastInsertId();
}
return false;
} catch (PDOException $e) {
error_log("Error in add_user_meta: " . $e->getMessage());
return false;
}
}

/**
* Updates a user meta field for a given user ID.
* If the meta field for the user does not exist, it will be added.
*
* @param int    $user_id    User ID.
* @param string $meta_key   The meta key to update.
* @param mixed  $meta_value The new meta value. Must be serializable if non-scalar.
* @param mixed  $prev_value Optional. If specified, only update existing metadata entry with this value.
*                           Otherwise, all entries for that user and meta_key are deleted and the new one is added.
*                           This mimics WordPress behavior where update_user_meta usually replaces all instances of a key.
* @return bool              True on success, false on failure.
*/
function update_user_meta($user_id, $meta_key, $meta_value, $prev_value = '') {
$db = get_db();
try {
// Check if meta key exists for this user
$current_meta_values = get_user_meta($user_id, $meta_key, false); // Get all values for this key

if (empty($current_meta_values)) { // Meta doesn't exist, add it
return (bool)add_user_meta($user_id, $meta_key, $meta_value);
} else { // Meta exists
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;

if (!empty($prev_value)) {
$prev_value_serialized = (is_array($prev_value) || is_object($prev_value) || is_bool($prev_value)) ? serialize($prev_value) : $prev_value;
$stmt = $db->prepare("UPDATE usermeta SET meta_value = :meta_value WHERE user_id = :user_id AND meta_key = :meta_key AND meta_value = :prev_value");
$stmt->bindValue(':prev_value', $prev_value_serialized, PDO::PARAM_STR);
} else {
// If no prev_value, WordPress-like behavior: delete all old values for this key and add the new one.
// This ensures only one value (or the new set of values if $meta_value is an array handled by multiple add_user_meta calls) remains for a given key for typical updates.
// If you want to add multiple values for the same key, use add_user_meta repeatedly.
delete_user_meta($user_id, $meta_key); // Delete all existing entries for this user_id and meta_key
return (bool)add_user_meta($user_id, $meta_key, $meta_value); // Add the new value
}
// This part is for the case where $prev_value IS specified
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
}
} catch (PDOException $e) {
error_log("Error in update_user_meta: " . $e->getMessage());
return false;
}
}

/**
* Deletes a user meta field for a given user ID.
*
* @param int    $user_id    User ID.
* @param string $meta_key   The meta key to delete.
* @param mixed  $meta_value Optional. If specified, only delete rows with this meta_key and meta_value.
* @return bool              True on success, false on failure.
*/
function delete_user_meta($user_id, $meta_key, $meta_value = '') {
$db = get_db();
try {
if (!empty($meta_value)) {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("DELETE FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key AND meta_value = :meta_value");
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
} else {
// If no value specified, delete all entries for this user and key
$stmt = $db->prepare("DELETE FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key");
}
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
} catch (PDOException $e) {
error_log("Error in delete_user_meta: " . $e->getMessage());
return false;
}
}

// --- END OF MODIFICATION - includes/functions.php (User Meta Functions) ---

/**
* 根据关键词搜索博客文章（标题和内容）.
*
* @param string $query 搜索关键词.
* @param int    $limit 每页返回的文章数量.
* @param int    $offset 查询的起始位置.
* @return array 包含 'posts' (文章数组) 和 'total_posts' (总数) 的数组.
*/
function search_blog_posts(string $query, int $limit = 10, int $offset = 0): array
{
$results = ['posts' => [], 'total_posts' => 0];
//$query = trim($query);
$query = mb_substr(trim($query), 0, 30, 'UTF-8');// 限制搜索词最多 30 个字符
if (empty($query)) {
return $results;
}

try {
$db = get_db();
$search_term_like = '%' . $query . '%';

// --- 获取总数 ---
// 考虑搜索范围：标题、内容、摘要。未来可扩展到标签、分类名。
$count_sql = "
SELECT COUNT(DISTINCT p.id)
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post'
AND (
p.title LIKE :search_query_like
OR p.content LIKE :search_query_like
OR p.excerpt LIKE :search_query_like
)";
// 如果需要搜索标签/分类，需要 JOIN 相应表并修改 WHERE
// OR EXISTS (SELECT 1 FROM tags t JOIN post_tags pt ON t.id = pt.tag_id WHERE pt.post_id = p.id AND t.name LIKE :search_query_like)
// OR EXISTS (SELECT 1 FROM categories cat JOIN post_categories pc ON cat.id = pc.category_id WHERE pc.post_id = p.id AND cat.name LIKE :search_query_like)

$stmt_count = $db->prepare($count_sql);
$stmt_count->bindValue(':search_query_like', $search_term_like, PDO::PARAM_STR);
$stmt_count->execute();
$results['total_posts'] = (int) $stmt_count->fetchColumn();

if ($results['total_posts'] > 0) {
// --- 获取当前页的文章数据 ---
// 同时获取作者、分类、标签信息，与首页/归档页逻辑保持一致
$posts_sql = "
SELECT
p.*,
u.username AS author_username,
GROUP_CONCAT(DISTINCT c.id || ':' || c.name || ':' || c.slug) AS categories_data,
GROUP_CONCAT(DISTINCT t.id || ':' || t.name || ':' || t.slug) AS tags_data,
-- 添加相关性评分（简单示例，实际中可能更复杂或使用FTS）
(CASE WHEN p.title LIKE :search_query_exact_title THEN 100 ELSE 0 END) +
(CASE WHEN p.title LIKE :search_query_like THEN 50 ELSE 0 END) +
(LENGTH(p.content) - LENGTH(REPLACE(LOWER(p.content), LOWER(:search_query_raw), ''))) / LENGTH(:search_query_raw_len) * 10 AS relevance -- 关键词出现频率
FROM posts p
LEFT JOIN users u ON p.author = u.id
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN categories c ON pc.category_id = c.id
LEFT JOIN post_tags pt ON p.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE p.status = 'publish' AND p.type = 'post'
AND (
p.title LIKE :search_query_like
OR p.content LIKE :search_query_like
OR p.excerpt LIKE :search_query_like
)
GROUP BY p.id
ORDER BY relevance DESC, p.created DESC -- 按相关性排序，然后按创建时间
LIMIT :limit OFFSET :offset
";
$stmt_posts = $db->prepare($posts_sql);
$stmt_posts->bindValue(':search_query_like', $search_term_like, PDO::PARAM_STR);
$stmt_posts->bindValue(':search_query_exact_title', $query, PDO::PARAM_STR); // 用于精确标题匹配的权重
$stmt_posts->bindValue(':search_query_raw', $query, PDO::PARAM_STR);
$stmt_posts->bindValue(':search_query_raw_len', mb_strlen($query, 'UTF-8'), PDO::PARAM_INT); // 用于频率计算的长度
$stmt_posts->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt_posts->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt_posts->execute();
$posts_raw = $stmt_posts->fetchAll(PDO::FETCH_ASSOC);

// 处理 GROUP_CONCAT 的结果 (与 'home' case 相同)
$posts_processed = [];
foreach ($posts_raw as $post_item) {
// 处理分类
$post_item['categories'] = [];
if (!empty($post_item['categories_data'])) {
$cats = explode(',', $post_item['categories_data']);
foreach ($cats as $cat_str) {
$parts = explode(':', $cat_str, 3);
if (count($parts) === 3) {
$post_item['categories'][] = ['id' => (int)$parts[0], 'name' => $parts[1], 'slug' => $parts[2]];
}
}
}
unset($post_item['categories_data']);

// 处理标签
$post_item['tags'] = [];
if (!empty($post_item['tags_data'])) {
$tags_items = explode(',', $post_item['tags_data']); // 避免变量名冲突
foreach ($tags_items as $tag_str) {
$parts = explode(':', $tag_str, 3);
if (count($parts) === 3) {
$post_item['tags'][] = ['id' => (int)$parts[0], 'name' => $parts[1], 'slug' => $parts[2]];
}
}
}
unset($post_item['tags_data']);
$posts_processed[] = $post_item;
}
$results['posts'] = $posts_processed;
}
} catch (PDOException $e) {
error_log("Search blog posts error for query '{$query}': " . $e->getMessage());
}
return $results;
}

// Get post by ID
function get_post($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM posts WHERE id = ?');
$stmt->execute([$post_id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return false;
}
}

// Create new post
function create_post($title, $content, $author_id, $status = 'draft') {
try {
$db = get_db();
$stmt = $db->prepare('
INSERT INTO posts (title, content, author, status, slug)
VALUES (?, ?, ?, ?, ?)
');
$slug = create_slug($title);
return $stmt->execute([$title, $content, $author_id, $status, $slug]);
} catch (PDOException $e) {
return false;
}
}

// Update post
function update_post($post_id, $data) {
try {
$db = get_db();
$fields = [];
$values = [];
foreach ($data as $key => $value) {
$fields[] = "$key = ?";
$values[] = $value;
}
$values[] = $post_id;

$sql = 'UPDATE posts SET ' . implode(', ', $fields) . ' WHERE id = ?';
$stmt = $db->prepare($sql);
return $stmt->execute($values);
} catch (PDOException $e) {
return false;
}
}

// Create URL slug
function create_slug($text) {
$text = preg_replace('~[^\pL\d]+~u', '-', $text);

// 使用 transliterator_transliterate 替代 iconv
if (function_exists('transliterator_transliterate')) {
$text = transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
} else {
$text = str_replace(
array('á','à','ã','â','ª','ä','é','è','ê','ë','í','ì','î','ï','ó','ò','õ','ô','º','ö','ú','ù','û','ü','ý','ÿ','ñ','ç','Á','À','Ã','Â','É','È','Ê','Ë','Í','Ì','Î','Ï','Ó','Ò','Õ','Ô','Ö','Ú','Ù','Û','Ü','Ý','Ñ','Ç'),
array('a','a','a','a','a','a','e','e','e','e','i','i','i','i','o','o','o','o','o','o','u','u','u','u','y','y','n','c','A','A','A','A','E','E','E','E','I','I','I','I','O','O','O','O','O','U','U','U','U','Y','N','C'),
$text
);
}

$text = preg_replace('~[^-\w]+~', '', $text);
$text = trim($text, '-');
$text = preg_replace('~-+~', '-', $text);
$text = strtolower($text);
return $text ?: 'n-a';
}

// Get posts
function get_posts($args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'type' => 'post',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

try {
$db = get_db();
if (!$db) {
return [];
}

$where = [];
$values = [];

if (!empty($args['status'])) {
$where[] = 'status = ?';
$values[] = $args['status'];
}

if (!empty($args['type'])) {
$where[] = 'type = ?';
$values[] = $args['type'];
}

$sql = 'SELECT * FROM posts';
if ($where) {
$sql .= ' WHERE ' . implode(' AND ', $where);
}

// 确保 orderby 字段存在
$allowed_orderby = ['created', 'modified', 'title', 'id'];
if (!in_array($args['orderby'], $allowed_orderby)) {
$args['orderby'] = 'created';
}

// 确保 order 是有效值
$args['order'] = strtoupper($args['order']);
if (!in_array($args['order'], ['ASC', 'DESC'])) {
$args['order'] = 'DESC';
}

$sql .= " ORDER BY {$args['orderby']} {$args['order']}";

if (isset($args['limit']) && (int)$args['limit'] !== -1) {
$args['limit'] = max(1, (int)$args['limit']);
$args['offset'] = max(0, (int)$args['offset']);

$sql .= ' LIMIT ? OFFSET ?';
$values[] = $args['limit'];
$values[] = $args['offset'];
}
$stmt = $db->prepare($sql);
$stmt->execute($values);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

return $results;
} catch (PDOException $e) {
return [];
} catch (Exception $e) {
return [];
}
}

// Check if user is logged in
function is_logged_in() {
return isset($_SESSION['user_id']);
}

// Check if user is admin
function is_admin() {
//return isset($_SESSION['role']) && $_SESSION['role'] === 'administrator';
return current_user_can('manage_options');
}

// Redirect to URL
function redirect($url) {
header("Location: $url");
exit;
}

// Sanitize output
function e($text) {
return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

// --- START OF MODIFICATION - includes/functions.php (Sanitization Helpers) ---
function sanitize_text_field($str) {
return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

function sanitize_textarea_field($str) {
// More complex sanitization might be needed depending on allowed HTML
// For basic text, htmlspecialchars is fine. If allowing some HTML, use a purifier library.
return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

function sanitize_email_field($email) {
return filter_var(trim($email), FILTER_SANITIZE_EMAIL);
}
// ... add more as needed (e.g., sanitize_key, sanitize_title)
// --- END OF MODIFICATION - includes/functions.php (Sanitization Helpers) ---

// Get comments for a post
function get_post_comments($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT c.*, 
COALESCE(u.display_name, u.username, c.author) as author_name,
c.user_id
FROM comments c
LEFT JOIN users u ON c.user_id = u.id
WHERE c.post_id = ? AND c.status = "approved"
ORDER BY c.created DESC
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

// Add a new comment
function add_comment($post_id, $content, $author = null, $email = null) {
// Check if comments are enabled
if (get_option('enable_comments', '1') !== '1') {
return false;
}

try {
$db = get_db();
$user_id = null;

// If user is logged in, use their ID and auto-approve comment
if (is_logged_in()) {
$user_id = $_SESSION['user_id'];
$author = null;
$email = null;
$status = 'approved';
} else {
$status = 'pending';
}

$stmt = $db->prepare('
INSERT INTO comments (post_id, user_id, author, email, content, status) 
VALUES (?, ?, ?, ?, ?, ?)
');

return $stmt->execute([$post_id, $user_id, $author, $email, $content, $status]);
} catch (PDOException $e) {
return false;
}
}

// Delete a comment
function delete_comment($comment_id, $user_id = null) {
try {
$db = get_db();

// Only admin or comment owner can delete
if (!is_admin() && $user_id) {
$stmt = $db->prepare('DELETE FROM comments WHERE id = ? AND user_id = ?');
return $stmt->execute([$comment_id, $user_id]);
} else if (is_admin()) {
$stmt = $db->prepare('DELETE FROM comments WHERE id = ?');
return $stmt->execute([$comment_id]);
}

return false;
} catch (PDOException $e) {
return false;
}
}

// Get post categories
function get_post_categories($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT c.* 
FROM categories c
JOIN post_categories pc ON c.id = pc.category_id
WHERE pc.post_id = ?
ORDER BY c.name
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (PDOException $e) {
return [];
}
}

// Get post tags
function get_post_tags($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT t.* 
FROM tags t
JOIN post_tags pt ON t.id = pt.tag_id
WHERE pt.post_id = ?
ORDER BY t.name
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}


// Get total posts count
function get_total_posts($args = []) {
$defaults = [
'status' => 'publish',
'type' => 'post'
];
$args = array_merge($defaults, $args);

try {
$db = get_db();
$where = [];
$values = [];

if ($args['status']) {
$where[] = 'status = ?';
$values[] = $args['status'];
}

if ($args['type']) {
$where[] = 'type = ?';
$values[] = $args['type'];
}

$sql = 'SELECT COUNT(*) as count FROM posts';
if ($where) {
$sql .= ' WHERE ' . implode(' AND ', $where);
}

$stmt = $db->prepare($sql);
$stmt->execute($values);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

return (int)$result['count'];
} catch (PDOException $e) {
return 0;
}
}



// Generate pagination HTML
function get_pagination($current_page, $total_items, $per_page = 10, $params = []) {
if ($total_items <= 0) return '';

$total_pages = ceil($total_items / $per_page);
if ($total_pages <= 1) return '';

// 合并当前 URL 参数
$current_params = $_GET;
//unset($current_params['page']); // 移除当前页码参数
$params = array_merge($current_params, $params);

$html = '<div class="pagination">';

// 上一页
if ($current_page > 1) {
$prev_params = array_merge($params, ['page' => $current_page - 1]);
$html .= sprintf(
'<a href="?%s" class="prev-page">上一页</a>',
http_build_query($prev_params)
);
}

// 页码
for ($i = 1; $i <= $total_pages; $i++) {
if ($i == $current_page) {
$html .= sprintf('<span class="current-page">%d</span>', $i);
} else {
$page_params = array_merge($params, ['page' => $i]);
$html .= sprintf(
'<a href="?%s" class="page-numbers">%d</a>',
http_build_query($page_params),
$i
);
}
}

// 下一页
if ($current_page < $total_pages) {
$next_params = array_merge($params, ['page' => $current_page + 1]);
$html .= sprintf(
'<a href="?%s" class="next-page">下一页</a>',
http_build_query($next_params)
);
}

$html .= '</div>';
return $html;
}

function get_paginations($current_page, $total_items, $per_page = 10, $base_params = []) { // 重命名 $params 为 $base_params 更清晰
if ($total_items <= 0) return '';
$total_pages = ceil($total_items / $per_page);
if ($total_pages <= 1) return '';

// $base_params 应该包含所有非分页参数，例如 admin slug ('page'), 过滤器等
// $current_page 是当前的分页页码 (例如从 $_GET['paged'] 获取)

$html = '<div class="pagination">';

// 上一页
if ($current_page > 1) {
$link_params = array_merge($base_params, ['paged' => $current_page - 1]); // 使用 paged
$html .= sprintf(
'<a href="?%s" class="prev-page">上一页</a>',
http_build_query($link_params)
);
}

// 页码
// 你可能需要添加 "..." 的逻辑，这里简化
for ($i = 1; $i <= $total_pages; $i++) {
if ($i == $current_page) {
$html .= sprintf('<span class="current-page">%d</span>', $i);
} else {
$link_params = array_merge($base_params, ['paged' => $i]); // 使用 paged
$html .= sprintf(
'<a href="?%s" class="page-numbers">%d</a>',
http_build_query($link_params),
$i
);
}
}

// 下一页
if ($current_page < $total_pages) {
$link_params = array_merge($base_params, ['paged' => $current_page + 1]); // 使用 paged
$html .= sprintf(
'<a href="?%s" class="next-page">下一页</a>',
http_build_query($link_params)
);
}

$html .= '</div>';
return $html;
}



// 判断是否为文章页面
function is_single() {
global $current_post;
return isset($current_post) && !empty($current_post);
}

// 获取当前文章标题
function get_post_title() {
global $current_post;
return is_single() ? $current_post['title'] : '';
}

// 判断是否为分类页面
function is_category() {
global $current_category;
return isset($current_category) && !empty($current_category);
}

// 获取当前分类名称
function get_category_name() {
global $current_category;
return is_category() ? $current_category['name'] : '';
}

// 通过别名获取分类信息
function get_category_by_slug($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM categories WHERE slug = ?');
$stmt->execute([$slug]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

// Get posts by category
function get_posts_by_category($category_slug, $args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

try {
$db = get_db();
$sql = '
SELECT DISTINCT p.*
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = ? AND p.status = ?
ORDER BY p.' . $args['orderby'] . ' ' . $args['order'] . '
LIMIT ? OFFSET ?
';

$stmt = $db->prepare($sql);
$stmt->execute([
$category_slug,
$args['status'],
$args['limit'],
$args['offset']
]);

return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

// Get posts by tag
function get_posts_by_tag($tag_slug, $args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

try {
$db = get_db();
$sql = '
SELECT DISTINCT p.*
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = ? AND p.status = ?
ORDER BY p.' . $args['orderby'] . ' ' . $args['order'] . '
LIMIT ? OFFSET ?
';

$stmt = $db->prepare($sql);
$stmt->execute([
$tag_slug,
$args['status'],
$args['limit'],
$args['offset']
]);

return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

// Get tag by slug
function get_tag_by_slug($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM tags WHERE slug = ?');
$stmt->execute([$slug]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

// Get category posts count
function get_category_posts_count($category_slug) {
try {
$db = get_db();
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = ? AND p.status = "publish"
';
$stmt = $db->prepare($sql);
$stmt->execute([$category_slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int)$result['count'];
} catch (PDOException $e) {
return 0;
}
}

// Get tag posts count
function get_tag_posts_count($tag_slug) {
try {
$db = get_db();
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = ? AND p.status = "publish"
';
$stmt = $db->prepare($sql);
$stmt->execute([$tag_slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int)$result['count'];
} catch (PDOException $e) {
return 0;
}
}

// Plugin related functions
function get_plugins() {
try {
$db = get_db();
$stmt = $db->query('SELECT * FROM plugins ORDER BY name');
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function get_active_plugins() {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM plugins WHERE status = ? ORDER BY name');
$stmt->execute(['active']);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}
/*
function activate_plugin($slug) {
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['active', $slug]);

if ($result) {
// Load and execute plugin activation hook if exists
$plugin_file = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
if (file_exists($plugin_file)) {
include_once $plugin_file;
if (function_exists($slug . '_activate')) {
call_user_func($slug . '_activate');
}
}
return true;
}
return false;
} catch (PDOException $e) {
return false;
}
}*/
//--- START OF MODIFICATION - includes/functions.php (activate_plugin) ---
function activate_plugin($slug) {
error_log('LitaBlog: activate_plugin called for slug: ' . $slug);
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['active', $slug]);

if ($result) {
// Load and execute plugin activation hook if exists
$plugin_file_path_for_hook = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
error_log('LitaBlog: Attempting to include plugin file for hook: ' . $plugin_file_path_for_hook);
// Ensure plugin file is loaded before calling its activation hook
if (file_exists($plugin_file_path_for_hook)) {
// Temporarily include it to make its functions available if not already
// This might be redundant if already loaded, but safe
require_once $plugin_file_path_for_hook;
error_log('LitaBlog: Plugin file included successfully: ' . $plugin_file_path_for_hook);
}
error_log('LitaBlog: Calling do_activation_hook for: ' . $plugin_file_path_for_hook);
do_activation_hook($plugin_file_path_for_hook); // Call the generic hook execution
error_log('LitaBlog: activate_plugin completed successfully for: ' . $slug);
return true;
}
error_log('LitaBlog: activate_plugin DB update failed for: ' . $slug);
return false;
} catch (PDOException $e) {
error_log('LitaBlog: activate_plugin PDOException for ' . $slug . ': ' . $e->getMessage());
return false;
}
}
//--- END OF MODIFICATION - includes/functions.php (activate_plugin) ---

/*
function deactivate_plugin($slug) {
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['inactive', $slug]);

if ($result) {
// Execute plugin deactivation hook if exists
$plugin_file = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
if (file_exists($plugin_file)) {
include_once $plugin_file;
if (function_exists($slug . '_deactivate')) {
call_user_func($slug . '_deactivate');
}
}
return true;
}
return false;
} catch (PDOException $e) {
return false;
}
}*/
//--- START OF MODIFICATION - includes/functions.php (deactivate_plugin) ---
function deactivate_plugin($slug) {
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['inactive', $slug]);

if ($result) {
// Execute plugin deactivation hook if exists
$plugin_file_path_for_hook = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
if (file_exists($plugin_file_path_for_hook)) {
include_once $plugin_file_path_for_hook; // Ensure functions are available
}
do_deactivation_hook($plugin_file_path_for_hook); // Call the generic hook execution
return true;
}
return false;
} catch (PDOException $e) {
return false;
}
}
//--- END OF MODIFICATION - includes/functions.php (deactivate_plugin) ---


function is_plugin_active($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT status FROM plugins WHERE slug = ?');
$stmt->execute([$slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result && $result['status'] === 'active';
} catch (PDOException $e) {
return false;
}
}
/*
// Plugin hooks system
$_plugin_hooks = [];

function register_plugin_hook($hook_name, $callback) {
global $_plugin_hooks;
if (!isset($_plugin_hooks[$hook_name])) {
$_plugin_hooks[$hook_name] = [];
}
// 避免重复注册同一个钩子
if (!in_array($callback, $_plugin_hooks[$hook_name])) {
$_plugin_hooks[$hook_name][] = $callback;
}
}

function do_plugin_action($hook_name, $args = []) {
global $_plugin_hooks;
$result = '';
if (isset($_plugin_hooks[$hook_name])) {
foreach ($_plugin_hooks[$hook_name] as $callback) {
if (is_callable($callback)) {
$result .= call_user_func_array($callback, $args);
}
}
}
return $result;
}*/
//--- START OF MODIFICATION - includes/functions.php ---
/**
* Plugin Hooks System
* Inspired by WordPress
*/

global $wp_actions, $wp_filters, $wp_current_filter;
$wp_actions = array();
$wp_filters = array();
$wp_current_filter = array();

/**
* Adds a callback function to a specific action hook.
*
* @param string   $hook_name     The name of the action to which the $callback is hooked.
* @param callable $callback      The callback to be run when the action is called.
* @param int      $priority      Optional. Used to specify the order in which the functions
*                                associated with a particular action are executed. Default 10.
* @param int      $accepted_args Optional. The number of arguments the function accepts. Default 1.
* @return true Always true.
*/
function add_action($hook_name, $callback, $priority = 10, $accepted_args = 1) {
global $wp_actions;
if (!isset($wp_actions[$hook_name])) {
$wp_actions[$hook_name] = array();
}
if (!isset($wp_actions[$hook_name][$priority])) {
$wp_actions[$hook_name][$priority] = array();
}
$wp_actions[$hook_name][$priority][] = array(
'function' => $callback,
'accepted_args' => $accepted_args
);
// Sort by priority after adding
ksort($wp_actions[$hook_name]);
if ($hook_name === 'admin_menu') { // 只在关注 admin_menu 时打印
error_log('LitaBlog DEBUG (add_action for admin_menu): Callback added. Current $wp_actions[admin_menu]: ' . print_r($wp_actions['admin_menu'], true));
}

return true;
}

/**
* Executes all callback functions hooked to a specific action.
*
* @param string $hook_name The name of the action to be executed.
* @param mixed  ...$args   Optional. Additional arguments which are passed on to the
*                          hooked Sfunctions.
*/
function do_action($hook_name, ...$args) {
global $wp_actions, $wp_current_filter;
if ($hook_name === 'admin_menu') { // 只在关注 admin_menu 时打印
error_log('LitaBlog DEBUG (do_action for admin_menu): Checking $wp_actions[admin_menu]: ' . print_r($wp_actions[$hook_name] ?? "NOT SET", true));
}
// Add hook name to current filter stack
$wp_current_filter[] = $hook_name;

if (isset($wp_actions[$hook_name])) {
foreach ($wp_actions[$hook_name] as $priority_level) {
foreach ($priority_level as $hook) {
if (is_callable($hook['function'])) {
$num_args = $hook['accepted_args'];
$call_args = array_slice($args, 0, $num_args);
call_user_func_array($hook['function'], $call_args);
}
}
}
}
// Remove hook name from current filter stack
array_pop($wp_current_filter);
}

/**
* Adds a callback function to a specific filter hook.
*
* @param string   $hook_name     The name of the filter to which the $callback is hooked.
* @param callable $callback      The callback to be run when the filter is applied.
* @param int      $priority      Optional. Used to specify the order in which the functions
*                                associated with a particular filter are executed. Default 10.
* @param int      $accepted_args Optional. The number of arguments the function accepts. Default 1.
* @return true Always true.
*/
function add_filter($hook_name, $callback, $priority = 10, $accepted_args = 1) {
global $wp_filters;
if (!isset($wp_filters[$hook_name])) {
$wp_filters[$hook_name] = array();
}
if (!isset($wp_filters[$hook_name][$priority])) {
$wp_filters[$hook_name][$priority] = array();
}
$wp_filters[$hook_name][$priority][] = array(
'function' => $callback,
'accepted_args' => $accepted_args
);
// Sort by priority after adding
ksort($wp_filters[$hook_name]);
return true;
}

/**
* Applies all callback functions hooked to a specific filter.
*
* @param string $hook_name The name of the filter to apply.
* @param mixed  $value     The value to filter.
* @param mixed  ...$args   Optional. Additional arguments which are passed on to the
*                          hooked functions.
* @return mixed The filtered value.
*/
function apply_filters($hook_name, $value, ...$args) {
global $wp_filters, $wp_current_filter;

// Add hook name to current filter stack
$wp_current_filter[] = $hook_name;

if (isset($wp_filters[$hook_name])) {
foreach ($wp_filters[$hook_name] as $priority_level) {
foreach ($priority_level as $hook) {
if (is_callable($hook['function'])) {
$num_args = $hook['accepted_args'];
// Prepare arguments: $value is always the first.
$call_args = array_merge(array($value), array_slice($args, 0, $num_args - 1));
$value = call_user_func_array($hook['function'], $call_args);
}
}
}
}
// Remove hook name from current filter stack
array_pop($wp_current_filter);
return $value;
}

// --- END OF MODIFICATION - includes/functions.php ---

function normalize_plugin_path_for_key($plugin_file_path) {
// 1. Normalize directory separators to forward slash
$path = str_replace('\\', '/', $plugin_file_path);
// 2. Normalize ABSPATH to have forward slashes and a trailing slash
$abs_path_normalized = rtrim(str_replace('\\', '/', ABSPATH), '/') . '/';
// 3. Define the base path to remove (content/plugins/)
$base_to_remove = $abs_path_normalized . 'content/plugins/';

if (strpos($path, $base_to_remove) === 0) {
return substr($path, strlen($base_to_remove));
}
// Fallback or error if path doesn't match expected structure
// For now, let's return the original path if it doesn't start with $base_to_remove
// This might indicate an issue with ABSPATH or plugin_file_path structure
// error_log("LitaBlog (normalize_plugin_path_for_key): Path normalization failed for: " . $plugin_file_path . " with base: " . $base_to_remove);
return $plugin_file_path; // Or handle error
}

//--- START OF MODIFICATION - includes/functions.php ---

global $wp_activation_hooks, $wp_deactivation_hooks;
$wp_activation_hooks = array();
$wp_deactivation_hooks = array();

/**
* Registers a plugin activation hook.
*
* @param string   $plugin_file Path to the main plugin file from the plugins directory.
*                              Example: 'my-plugin/my-plugin.php'
* @param callable $callback    The function to call when the plugin is activated.
*/
function register_activation_hook($plugin_file, $callback) {
global $wp_activation_hooks;
if (!is_array($wp_activation_hooks)) $wp_activation_hooks = array(); // Defensive
//$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
//$plugin_file_key = str_replace('\\', '/', $plugin_file_key); // Normalize slashes
$plugin_file_key = normalize_plugin_path_for_key($plugin_file); // USE NORMALIZER

$wp_activation_hooks[$plugin_file_key] = $callback;
error_log('LitaBlog (register_activation_hook): Registered key: [' . $plugin_file_key . '] with callback: [' . print_r($callback, true) . ']');
error_log('LitaBlog (register_activation_hook): $wp_activation_hooks now: ' . print_r($wp_activation_hooks, true));
}

/**
* Registers a plugin deactivation hook.
*
* @param string   $plugin_file Path to the main plugin file from the plugins directory.
* @param callable $callback    The function to call when the plugin is deactivated.
*/
function register_deactivation_hook($plugin_file, $callback) {
global $wp_deactivation_hooks;
if (!is_array($wp_deactivation_hooks)) $wp_deactivation_hooks = array();
//$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
//$plugin_file_key = str_replace('\\', '/', $plugin_file_key);
$plugin_file_key = normalize_plugin_path_for_key($plugin_file); // USE NORMALIZER
$wp_deactivation_hooks[$plugin_file_key] = $callback;
}

/**
* Calls all registered activation hooks for a specific plugin.
*
* @param string $plugin_file Path to the main plugin file.
*//*
function do_activation_hook($plugin_file) {
error_log('LitaBlog: do_activation_hook called for: ' . $plugin_file);
global $wp_activation_hooks;
$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
$plugin_file_key = str_replace('\\', '/', $plugin_file_key);
error_log('LitaBlog: Normalized plugin file key: ' . $plugin_file_key);
if (isset($wp_activation_hooks[$plugin_file_key]) && is_callable($wp_activation_hooks[$plugin_file_key])) {
error_log('LitaBlog: Found and calling activation hook for key: ' . $plugin_file_key);
call_user_func($wp_activation_hooks[$plugin_file_key]);
}
}*/

function do_activation_hook($plugin_file) {
error_log('LitaBlog (do_activation_hook): Called for: ' . $plugin_file);
global $wp_activation_hooks;

// Ensure $wp_activation_hooks is an array
if (!is_array($wp_activation_hooks)) {
error_log('LitaBlog (do_activation_hook): ERROR - $wp_activation_hooks is NOT an array! Value: ' . print_r($wp_activation_hooks, true));
return; // Critical error, stop
}
if (empty($wp_activation_hooks)) {
error_log('LitaBlog (do_activation_hook): $wp_activation_hooks is EMPTY.');
} else {
error_log('LitaBlog (do_activation_hook): $wp_activation_hooks dump: ' . print_r($wp_activation_hooks, true));
}

$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
$plugin_file_key = str_replace('\\', '/', $plugin_file_key);
error_log('LitaBlog (do_activation_hook): Normalized plugin file key: [' . $plugin_file_key . ']');

// Check 1: Is the key set in the hooks array?
if (isset($wp_activation_hooks[$plugin_file_key])) {
error_log('LitaBlog (do_activation_hook): Key [' . $plugin_file_key . '] IS SET in $wp_activation_hooks.');
$callback_to_check = $wp_activation_hooks[$plugin_file_key];
error_log('LitaBlog (do_activation_hook): Callback stored for this key is: [' . print_r($callback_to_check, true) . ']');

// Check 2: Is the stored callback actually callable?
if (is_callable($callback_to_check)) {
error_log('LitaBlog (do_activation_hook): is_callable reports TRUE for [' . print_r($callback_to_check, true) . ']. Calling it now.'); // <<< THIS IS THE LOG YOU WANT TO SEE
call_user_func($callback_to_check);
} else {
error_log('LitaBlog (do_activation_hook): is_callable reports FALSE for [' . print_r($callback_to_check, true) . '].');
// If it's false, let's try to see if the function exists globally *right now*
if (function_exists('litapay_activate')) {
error_log('LitaBlog (do_activation_hook): BUT function_exists("litapay_activate") IS TRUE right now.');
} else {
error_log('LitaBlog (do_activation_hook): AND function_exists("litapay_activate") IS FALSE right now.');
}
}
} else {
error_log('LitaBlog (do_activation_hook): Key [' . $plugin_file_key . '] IS NOT SET in $wp_activation_hooks.');
}
}

/**
* Calls all registered deactivation hooks for a specific plugin.
*
* @param string $plugin_file Path to the main plugin file.
*/
function do_deactivation_hook($plugin_file) {
global $wp_deactivation_hooks;
$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
$plugin_file_key = str_replace('\\', '/', $plugin_file_key);
if (isset($wp_deactivation_hooks[$plugin_file_key]) && is_callable($wp_deactivation_hooks[$plugin_file_key])) {
call_user_func($wp_deactivation_hooks[$plugin_file_key]);
}
}

// --- END OF MODIFICATION - includes/functions.php ---


// --- START OF MODIFICATION - includes/functions.php (Uninstall Hook) ---

global $wp_uninstall_hooks; // WordPress menggunakan variabel global untuk ini
$wp_uninstall_hooks = array();

/**
* Registers a plugin uninstall hook.
* Ini adalah alternatif jika plugin tidak memiliki uninstall.php.
* Fungsi ini akan dipanggil JIKA uninstall.php TIDAK ditemukan.
*
* @param string   $plugin_file Path to the main plugin file.
* @param callable $callback    The function to call when the plugin is uninstalled.
*/
function register_uninstall_hook($plugin_file, $callback) {
global $wp_uninstall_hooks;
if (!is_array($wp_uninstall_hooks)) $wp_uninstall_hooks = array();
//  $plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
//  $plugin_file_key = str_replace('\\', '/', $plugin_file_key);
$plugin_file_key = normalize_plugin_path_for_key($plugin_file); // USE NORMALIZER
$wp_uninstall_hooks[$plugin_file_key] = $callback;
}

/**
* Calls the uninstall procedure for a specific plugin.
* Prioritizes running uninstall.php if it exists.
* Otherwise, calls a registered uninstall hook function.
*
* @param string $plugin_slug The slug of the plugin (directory name).
*/
function do_uninstall_plugin($plugin_slug) {
global $wp_uninstall_hooks;

$plugin_dir = ABSPATH . 'content/plugins/' . $plugin_slug;
$uninstall_file = $plugin_dir . '/uninstall.php';
$plugin_main_file_key = $plugin_slug . '/' . $plugin_slug . '.php'; // Kunci untuk hook terdaftar

// Penting: Definisikan konstanta ini SEBELUM include uninstall.php
// agar uninstall.php tahu bahwa ia dijalankan dalam konteks uninstall.
if (!defined('SBP_UNINSTALL_PLUGIN')) { // Gunakan prefix unik, SBP_ = Small Blog Plugin
define('SBP_UNINSTALL_PLUGIN', true);
}

if (file_exists($uninstall_file)) {
// Jalankan uninstall.php
// Ini berisiko jika uninstall.php tidak aman, tapi ini pendekatan WordPress
include_once $uninstall_file;
} elseif (isset($wp_uninstall_hooks[$plugin_main_file_key]) && is_callable($wp_uninstall_hooks[$plugin_main_file_key])) {
// Jalankan hook yang terdaftar
call_user_func($wp_uninstall_hooks[$plugin_main_file_key]);
} else {
// Tidak ada prosedur uninstall yang ditemukan untuk plugin ini.
// Bisa juga log pesan ini.
}
}

// --- END OF MODIFICATION - includes/functions.php (Uninstall Hook) ---


//--- START OF MODIFICATION - includes/functions.php ---

global $wp_shortcodes;
$wp_shortcodes = array();

/**
* Adds a new shortcode.
*
* @param string   $tag      Shortcode tag to be searched in content.
* @param callable $callback Hook to run when shortcode is found.
*/
function add_shortcode($tag, $callback) {
global $wp_shortcodes;
if (is_callable($callback)) {
$wp_shortcodes[$tag] = $callback;
}
}

/**
* Parses content for shortcodes and executes their callbacks.
*
* @param string $content Content to search for shortcodes.
* @return string Content with shortcodes filtered out.
*/
function do_shortcode($content) {
global $wp_shortcodes;
if (empty($wp_shortcodes) || !is_array($wp_shortcodes)) {
return $content;
}

// Build the regex pattern for all registered shortcodes
// Pattern: \[(\w+)(.*?)\](?:(.*?)\[\/\1\])?
// \1 is the shortcode tag
// \2 is attributes (optional)
// \3 is enclosed content (optional)
$pattern = '/\[(' . implode('|', array_map('preg_quote', array_keys($wp_shortcodes))) . ')([^\]]*)\](?:(.*?)\[\/\1\])?/s';

return preg_replace_callback($pattern, 'do_shortcode_tag', $content);
}

/**
* Callback for preg_replace_callback in do_shortcode().
*
* @param array $matches Matched shortcode.
* @return string Result of shortcode execution.
*/
function do_shortcode_tag($matches) {
global $wp_shortcodes;

// $matches[0] is the entire shortcode, e.g. [tag atts]content[/tag]
// $matches[1] is the shortcode tag, e.g. "tag"
// $matches[2] is the attributes part, e.g. " atts" (note leading space)
// $matches[3] is the enclosed content (if any)

$tag = $matches[1];
$attr_string = trim($matches[2]);
$enclosed_content = isset($matches[3]) ? $matches[3] : null;

// Parse attributes
$atts = array();
if ($attr_string) {
// A simple regex for parsing attributes: key="value" or key='value' or key=value
// More robust parsing might be needed for complex cases
preg_match_all('/([\w-]+)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s\]]+))/s', $attr_string, $attr_matches, PREG_SET_ORDER);
foreach ($attr_matches as $attr_match) {
$key = $attr_match[1];
if (!empty($attr_match[3])) { // Double quotes
$atts[$key] = $attr_match[3];
} elseif (!empty($attr_match[4])) { // Single quotes
$atts[$key] = $attr_match[4];
} else { // Unquoted
$atts[$key] = $attr_match[5];
}
}
}

if (isset($wp_shortcodes[$tag]) && is_callable($wp_shortcodes[$tag])) {
return call_user_func($wp_shortcodes[$tag], $atts, $enclosed_content, $tag);
}
return $matches[0]; // Return original match if no callback found
}

// --- END OF MODIFICATION - includes/functions.php ---


// --- START OF MODIFICATION - includes/functions.php (CSRF Functions) ---

/**
* Generates a CSRF token for a specific form/action.
*
* @param string $action_name A unique name for the action being protected.
* @return string The CSRF token.
*/
function generateCsrfToken($action_name = 'default_form_action') {
if (session_status() == PHP_SESSION_NONE) {
// error_log("Warning: Session not started when generateCsrfToken called for action '{$action_name}'. Starting session.");
session_start();
}
if (empty($_SESSION['csrf_tokens'][$action_name])) {
try {
$_SESSION['csrf_tokens'][$action_name] = bin2hex(random_bytes(32));
} catch (Exception $e) {
// Fallback if random_bytes fails (highly unlikely with modern PHP)
$_SESSION['csrf_tokens'][$action_name] = sha1(uniqid(mt_rand(), true) . CSRF_SALT_FALLBACK); // Define CSRF_SALT_FALLBACK in config.php
}
}
return $_SESSION['csrf_tokens'][$action_name];
}

/**
* Verifies a CSRF token against the one stored in the session.
* For critical actions, consider making tokens one-time use by unsetting after verification.
*
* @param string $token_from_form The token submitted with the form.
* @param string $action_name     The unique name of the action being verified.
* @param bool   $one_time        Whether the token should be invalidated after successful verification.
* @return bool True if the token is valid, false otherwise.
*/
function verifyCsrfToken($token_from_form, $action_name = 'default_form_action', $one_time = true) {
if (session_status() == PHP_SESSION_NONE) {
// error_log("Warning: Session not started when verifyCsrfToken called for action '{$action_name}'. Starting session.");
session_start();
}
if (empty($_SESSION['csrf_tokens'][$action_name]) ||
!is_string($token_from_form) ||
!hash_equals($_SESSION['csrf_tokens'][$action_name], $token_from_form)) {
// For security, don't log the actual tokens in production environments.
// error_log("CSRF token mismatch for action '{$action_name}'. Submitted: '{$token_from_form}', Expected: '{$_SESSION['csrf_tokens'][$action_name]}'");
return false;
}

if ($one_time) {
unset($_SESSION['csrf_tokens'][$action_name]);
}
return true;
}

/**
* Outputs a hidden HTML input field with the CSRF token.
*
* @param string $action_name The unique name for the action.
* @param bool $echo Echo or return the field.
* @return string HTML hidden input field.
*/
function csrf_token_field($action_name = 'default_form_action', $echo = true) {
$token = generateCsrfToken($action_name);
$field = '<input type="hidden" name="csrf_token" value="' . e($token) . '">';
if ($echo) {
echo $field;
}
return $field;
}

// Define a fallback salt in config.php if random_bytes is a concern, though it shouldn't be.
// Example for config.php: define('CSRF_SALT_FALLBACK', 'your_very_secret_random_string_here');

// --- END OF MODIFICATION - includes/functions.php (CSRF Functions) ---


function scan_plugins() {
$plugins_dir = ABSPATH . 'content/plugins';
$plugins = [];

if (!is_dir($plugins_dir)) {
return $plugins;
}

$dirs = scandir($plugins_dir);
foreach ($dirs as $dir) {
if ($dir === '.' || $dir === '..') {
continue;
}

$plugin_dir = $plugins_dir . '/' . $dir;
if (!is_dir($plugin_dir)) {
continue;
}

$main_file = $plugin_dir . '/' . $dir . '.php';
if (!file_exists($main_file)) {
continue;
}

$plugin_data = get_plugin_data($main_file);
if ($plugin_data) {
$plugins[$dir] = $plugin_data;
}
}

return $plugins;
}

function get_plugin_data($plugin_file) {
$default_headers = [
'name' => 'Plugin Name',
'plugin_uri' => 'Plugin URI',
'version' => 'Version',
'description' => 'Description',
'author' => 'Author',
'author_url' => 'Author URI'
];

$plugin_data = [];
$file_contents = file_get_contents($plugin_file);

foreach ($default_headers as $field => $regex) {
if (preg_match('/\s*\*\s*' . preg_quote($regex, '/') . '\s*:\s*(.+)$/mi', $file_contents, $match)) {
$plugin_data[$field] = trim($match[1]);
} else {
$plugin_data[$field] = '';
}
}

return $plugin_data;
}


/**
* 获取侧边栏小部件
*/
function get_sidebar_widgets() {
global $db;
$stmt = $db->query("SELECT * FROM sidebar_widgets ORDER BY `order` ASC");
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
* 更新侧边栏小部件
*/
function update_sidebar_widgets($widgets) {
global $db;
try {
$db->beginTransaction();

// 清空现有小部件
$db->exec("DELETE FROM sidebar_widgets");
// 插入新的小部件
$stmt = $db->prepare("INSERT INTO sidebar_widgets (title, type, content, `order`) VALUES (?, ?, ?, ?)");
foreach ($widgets as $widget) {
$stmt->execute([
$widget['title'],
$widget['type'],
$widget['content'],
$widget['order']
]);
}

$db->commit();
return true;
} catch (Exception $e) {
$db->rollBack();
return false;
}
}

// 改为从数据库获取主题设置
function get_current_theme() {
$db = get_db();
$stmt = $db->prepare('SELECT value FROM options WHERE name = ?');
$stmt->execute(['current_theme']);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result ? $result['value'] : 'default';
}

/**
* 获取导航菜单
*/
function get_nav_menu() {
$db = get_db();
$stmt = $db->prepare('SELECT value FROM options WHERE name = ?');
$stmt->execute(['nav_menu']);
$menu_json = $stmt->fetchColumn();    
return $menu_json ? json_decode($menu_json, true) : [];
}

/**
* 更新导航菜单
*/
function update_nav_menu($menu_items) {
$db = get_db();
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
return $stmt->execute(['nav_menu', json_encode($menu_items)]);
}

// --- START OF MODIFICATION - includes/functions.php (Admin Menu API) ---

global $admin_menu, $admin_submenu;
$admin_menu = array();
$admin_submenu = array();

/**
* Registers a top-level administrative menu page.
*
* @param string   $page_title The text to be displayed in the title tags of the page when the menu is selected.
* @param string   $menu_title The text to be used for the menu.
* @param string   $capability The capability required for this menu to be displayed to the user. (e.g., 'manage_options' for admin)
* @param string   $menu_slug  The slug name to refer to this menu by. Should be unique.
* @param callable|string $function   The function to be called to output the content for this page, or the path to the PHP file.
* @param string   $icon_url   The URL to the icon to be used for this menu. (Optional)
* @param int      $position   The position in the menu order this item should appear. (Optional)
*/
function add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function = '', $icon_url = '', $position = null) {
global $admin_menu;
// Basic capability check (can be expanded)
if ($capability === 'manage_options' && !is_admin()) {
return false;
}

$hookname = 'admin_page_' . $menu_slug; // For potential future use

if (null === $position) {
$position = count($admin_menu) * 10; // Simple auto-positioning
while (isset($admin_menu[$position])) {
$position += 10;
}
}

$admin_menu[$position] = array(
$menu_title,
$capability,
$menu_slug,
$page_title,
$function, // Store function or file path
$icon_url
);
ksort($admin_menu); // Keep sorted by position
return $hookname;
}

/**
* Registers an administrative submenu page.
*
* @param string   $parent_slug The slug name for the parent menu (or the file name of a standard WordPress admin page).
* @param string   $page_title  The text to be displayed in the title tags of the page when the menu is selected.
* @param string   $menu_title  The text to be used for the menu.
* @param string   $capability  The capability required for this menu to be displayed to the user.
* @param string   $menu_slug   The slug name to refer to this menu by. Should be unique.
* @param callable|string $function    The function to be called to output the content for this page, or the path to the PHP file.
* @param int      $position    The position in the menu order this item should appear. (Optional)
*/
function add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function = '', $position = null) {
global $admin_menu, $admin_submenu;

if ($capability === 'manage_options' && !is_admin()) {
return false;
}

// Ensure parent menu exists if adding a submenu (simplified check)
$parent_exists = false;
foreach($admin_menu as $menu_item) {
if ($menu_item[2] === $parent_slug) {
$parent_exists = true;
break;
}
}
// Also allow adding to core pages (like index.php, content.php) by their file names
// This part is a bit tricky without a full WP-like menu system.
// For now, let's assume $parent_slug is a slug registered by add_menu_page.

if (!$parent_exists && !in_array($parent_slug, ['index.php', 'content.php', 'settings.php'])) { // Example core pages
// error_log("Admin submenu: Parent menu '{$parent_slug}' not found.");
// return false; // Or queue it, WordPress style
}


if (!isset($admin_submenu[$parent_slug])) {
$admin_submenu[$parent_slug] = array();
}

if (null === $position) {
$position = count($admin_submenu[$parent_slug]) * 10;
while (isset($admin_submenu[$parent_slug][$position])) {
$position += 10;
}
}

$admin_submenu[$parent_slug][$position] = array(
$menu_title,
$capability,
$menu_slug,
$page_title,
$function
);
ksort($admin_submenu[$parent_slug]);
return 'admin_page_' . $menu_slug;
}

// --- END OF MODIFICATION - includes/functions.php (Admin Menu API) ---


/**
* 获取当前主题URL
* @return string 主题URL
*/
function get_theme_url() {
return SITE_URL . '/content/themes/' . get_current_theme();
}

/**
* 获取当前主题目录路径
* @return string 主题目录物理路径
*/
function get_theme_path() {
return THEME_DIR . '/' . get_current_theme();
}

function switch_theme($theme_name) {
$db = get_db();
// 验证主题是否存在
if (!is_dir(THEME_DIR . '/' . $theme_name)) {
return false;
}

// 更新数据库中的主题设置
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
$stmt->execute(['current_theme', $theme_name]);
return true;
}


// 在 functions.php 文件中添加这个新函数，或者修改现有的计数函数

/**
* 获取指定分类或标签下的已发布文章数量
*
* @param string $term_type 'category' 或 'tag'
* @param string $term_slug 分类或标签的 slug
* @return int 文章数量
*/
function get_term_posts_count(string $term_type, string $term_slug): int
{
try {
$db = get_db();
$sql = "";

if ($term_type === 'category') {
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = :slug AND p.status = "publish" AND p.type = "post"
';
} elseif ($term_type === 'tag') {
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = :slug AND p.status = "publish" AND p.type = "post"
';
} else {
return 0; // 无效的 term 类型
}

$stmt = $db->prepare($sql);
$stmt->bindValue(':slug', $term_slug, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int) ($result['count'] ?? 0); // 返回整数，处理可能的 null
} catch (PDOException $e) {
error_log("Error counting posts for {$term_type} '{$term_slug}': " . $e->getMessage());
return 0;
}
}

/**
* 统一格式化时间
* 
* @param string $datetime 原始时间字符串 (通常来自数据库)
* @param bool $full 是否返回完整的格式化数组
* @return array|string 格式化后的时间数组或字符串
*/
function format_datetime($datetime, $full = true) {
$date_format = get_option('date_format', 'Y-m-d');
$time_format = get_option('time_format', 'H:i');
$timezone_string = get_option('site_timezone', 'Asia/Shanghai');

try {
// 创建时区对象
$site_timezone = new DateTimeZone($timezone_string);

// 假设数据库中的时间是 UTC 时间（根据实际情况修改）
$dt = new DateTime($datetime, new DateTimeZone('UTC'));
// 转换到站点时区
$dt->setTimezone($site_timezone);

// 格式化时间
$result = [
'formatted_datetime' => $dt->format($date_format . ' ' . $time_format),
'formatted_date' => $dt->format($date_format),
'formatted_time' => $dt->format($time_format),
'iso_datetime' => $dt->format('c'),
'timestamp' => $dt->getTimestamp()
];

return $full ? $result : $result['formatted_datetime'];
} catch (Exception $e) {
error_log("Error formatting datetime '{$datetime}': " . $e->getMessage());
// 出错时返回原始时间或基本格式
return $full ? [
'formatted_datetime' => $datetime,
'formatted_date' => substr($datetime, 0, 10),
'formatted_time' => substr($datetime, 11, 5),
'iso_datetime' => $datetime,
'timestamp' => time()
] : $datetime;
}
}

/**
* 根据路由结果准备模板所需的数据数组
*
* @param string $request_type 请求类型 (e.g., 'single', 'home', 'category')
* @param mixed $main_object Router 返回的主要对象 (post, category, tag) 或 null
* @return array 包含模板所需数据的关联数组
*/
function prepare_template_data(string $request_type, $main_object): array
{
$template_data = []; // 初始化数据数组
$current_theme_slug = get_current_theme(); 
// a. 添加基本信息 (总是需要的)
$template_data['request_type'] = $request_type; // 将传入的 request_type 也加入数据，模板可能需要
$template_data['site_title'] = get_option('site_title', 'My Blog');
$template_data['site_description'] = get_option('site_description', '');
$template_data['site_url'] = SITE_URL;
$template_data['theme_url'] = rtrim(SITE_URL, '/') . '/content/themes/' . $current_theme_slug;
$template_data['nav_menu'] = get_nav_menu();
$template_data['widgets'] = get_sidebar_widgets();
$template_data['is_logged_in'] = is_logged_in();
$template_data['is_admin'] = is_admin();


// b. 根据请求类型添加特定数据
switch ($request_type) {

// 在 prepare_template_data 的 switch 语句中
case 'search':
$search_query_raw = $main_object; // 从 Router 获取原始搜索词
$template_data['search_query'] = e($search_query_raw); // 转义后供模板使用
$template_data['archive_title'] = '搜索结果："' . e($search_query_raw) . '"';

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$posts_per_page = (int) get_option('posts_per_page', 10);
$offset = ($page - 1) * $posts_per_page;

// 调用新的搜索函数 (将在下一步定义)
$search_results = search_blog_posts($search_query_raw, $posts_per_page, $offset);

$template_data['posts'] = $search_results['posts']; // 获取文章列表
$template_data['total_posts'] = $search_results['total_posts']; // 获取总数

// 格式化搜索结果文章列表的时间
if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$search_post_item) {
if (isset($search_post_item['created'])) {
$search_post_item = array_merge(
$search_post_item,
format_datetime($search_post_item['created'])
);
}
}
unset($search_post_item);
}

$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;
// 确保分页链接包含搜索参数 's'
$template_data['pagination'] = get_pagination($page, $template_data['total_posts'], $posts_per_page, ['s' => $search_query_raw]);
break;

case 'single':
if ($main_object) {
$template_data['post'] = $main_object;
$template_data['author'] = get_user($main_object['author']);
$template_data['comments'] = get_post_comments($main_object['id']);
$template_data['categories'] = get_post_categories($main_object['id']);
$template_data['tags'] = get_post_tags($main_object['id']);

// --- Apply the_content filter and do_shortcode ---
$post_content = $main_object['content'];
// First, process shortcodes
$post_content = do_shortcode($post_content);
// Then, apply other content filters
$post_content = apply_filters('the_content', $post_content, $main_object['id']);
$template_data['post']['content'] = $post_content; // Use the filtered content

// ---- START: 统一格式化文章时间 ----
if (isset($main_object['created'])) {
// 将格式化的时间信息合并到 post 数组中
$template_data['post'] = array_merge(
$template_data['post'],
format_datetime($main_object['created'])
);
}

// 格式化所有评论的时间
if (!empty($template_data['comments'])) {
$formatted_comments = [];
foreach ($template_data['comments'] as $comment) {
if (isset($comment['created'])) {
// 合并格式化的时间信息到评论数组
$comment = array_merge(
$comment,
format_datetime($comment['created'])
);
}
$formatted_comments[] = $comment;
}
$template_data['comments'] = $formatted_comments;
}
// ---- END: 统一格式化文章时间 ----
$template_data['enable_comments'] = (get_option('enable_comments', '1') === '1');


// ---- START: 添加当前用户信息 (之前可选优化，现在加入) ----
if ($template_data['is_logged_in'] && isset($_SESSION['username'])) {
$template_data['current_user'] = [
'id' => $_SESSION['user_id'] ?? null, // 添加 ID
'username' => $_SESSION['username']
];
} else {
$template_data['current_user'] = null; // 明确未登录
}
// ---- END: 添加当前用户信息 ----

} else {
// 如果 main_object 为空，即使 request_type 是 single，也当作 404 处理
$template_data['request_type'] = '404'; // 覆盖 request_type
$template_data['error_message'] = '文章未找到。'; // 可以添加错误消息
}
break; // <--- 确保 single case 有 break

// --- START OF INSERTED CODE for 'page' type ---
case 'page':
if ($main_object && isset($main_object['type']) && $main_object['type'] === 'page') {
$template_data['post'] = $main_object; // 将页面数据赋值给 'post' 键
// 对于页面，通常不需要评论、分类、标签等，但可以按需添加作者信息
$template_data['author'] = get_user($main_object['author']);
$template_data['comments'] = []; // 页面通常没有评论，或评论功能被禁用
$template_data['categories'] = [];
$template_data['tags'] = [];
$template_data['enable_comments'] = false; // 明确页面不启用评论

// --- Apply the_content filter and do_shortcode ---
$page_content = $main_object['content'];
// First, process shortcodes
$page_content = do_shortcode($page_content);
// Then, apply other content filters
$page_content = apply_filters('the_content', $page_content, $main_object['id']);
$template_data['post']['content'] = $page_content; // Use the filtered content

// 统一格式化页面创建时间
if (isset($main_object['created'])) {
$template_data['post'] = array_merge(
$template_data['post'],
format_datetime($main_object['created'])
);
}

// 添加当前用户信息 (如果登录)
if ($template_data['is_logged_in'] && isset($_SESSION['username'])) {
$template_data['current_user'] = [
'id' => $_SESSION['user_id'] ?? null,
'username' => $_SESSION['username']
];
} else {
$template_data['current_user'] = null;
}

} else {
// 如果 $main_object 无效或类型不对，则视为 404
$template_data['request_type'] = '404'; // 覆盖 request_type
$template_data['error_message'] = '页面未找到。';
}
break;
// --- END OF INSERTED CODE for 'page' type ---

// 继续往下是 case 'category': 和 case 'tag':

case 'category':
case 'tag':
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$posts_per_page = (int) get_option('posts_per_page', 10); // 确保是整数
$offset = ($page - 1) * $posts_per_page;

if ($main_object && isset($main_object['slug'])) { // 确保 $main_object 和 slug 存在
$slug = $main_object['slug'];
$template_data['term'] = $main_object; // 'term' 是 category 或 tag 的通用术语

// ---- START: 修改获取文章列表的逻辑 (应用 JOIN 和 GROUP_CONCAT) ----
try {
$db = get_db();
$sql = ""; // 初始化 SQL 字符串

// 根据类型构建不同的 WHERE 条件和参数绑定
if ($request_type === 'category') {
$template_data['archive_title'] = '分类：' . e($main_object['name']);
$sql = "
SELECT
p.*,
u.username AS author_username,
GROUP_CONCAT(DISTINCT c.id || ':' || c.name || ':' || c.slug) AS categories_data,
GROUP_CONCAT(DISTINCT t.id || ':' || t.name || ':' || t.slug) AS tags_data
FROM posts p
JOIN post_categories pc_filter ON p.id = pc_filter.post_id -- Join for filtering
JOIN categories c_filter ON pc_filter.category_id = c_filter.id
LEFT JOIN users u ON p.author = u.id
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN categories c ON pc.category_id = c.id
LEFT JOIN post_tags pt ON p.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE c_filter.slug = :slug AND p.status = 'publish' AND p.type = 'post'
GROUP BY p.id
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
";
} else { // 'tag'
$template_data['archive_title'] = '标签：' . e($main_object['name']);
$sql = "
SELECT
p.*,
u.username AS author_username,
GROUP_CONCAT(DISTINCT c.id || ':' || c.name || ':' || c.slug) AS categories_data,
GROUP_CONCAT(DISTINCT t.id || ':' || t.name || ':' || t.slug) AS tags_data
FROM posts p
JOIN post_tags pt_filter ON p.id = pt_filter.post_id -- Join for filtering
JOIN tags t_filter ON pt_filter.tag_id = t_filter.id
LEFT JOIN users u ON p.author = u.id
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN categories c ON pc.category_id = c.id
LEFT JOIN post_tags pt ON p.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE t_filter.slug = :slug AND p.status = 'publish' AND p.type = 'post'
GROUP BY p.id
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
";
}

$stmt = $db->prepare($sql);
$stmt->bindValue(':slug', $slug, PDO::PARAM_STR); // 绑定 slug
$stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$posts_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 处理 GROUP_CONCAT 的结果 (与 case 'home' 相同逻辑)
$posts_processed = [];
foreach ($posts_raw as $post) {
// 处理分类
$post['categories'] = [];
if (!empty($post['categories_data'])) {
$cats = explode(',', $post['categories_data']);
foreach ($cats as $cat_str) {
$parts = explode(':', $cat_str, 3);
if (count($parts) === 3) {
$post['categories'][] = ['id' => (int)$parts[0], 'name' => $parts[1], 'slug' => $parts[2]];
}
}
}
unset($post['categories_data']);

// 处理标签
$post['tags'] = [];
if (!empty($post['tags_data'])) {
$tags = explode(',', $post['tags_data']);
foreach ($tags as $tag_str) {
$parts = explode(':', $tag_str, 3);
if (count($parts) === 3) {
$post['tags'][] = ['id' => (int)$parts[0], 'name' => $parts[1], 'slug' => $parts[2]];
}
}
}
unset($post['tags_data']);

$posts_processed[] = $post;
}
$template_data['posts'] = $posts_processed;

// ---- START: 格式化文章列表时间 ----
if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$post) {
if (isset($post['created'])) {
// 合并格式化的时间信息到文章数组
$post = array_merge(
$post,
format_datetime($post['created'])
);
}
}
unset($post); // 防止后续操作影响引用
}
// ---- END: 格式化文章列表时间 ----
} catch (PDOException $e) {
error_log("Database error fetching posts for {$request_type} '{$slug}': " . $e->getMessage());
$template_data['posts'] = [];
}
// ---- END: 修改获取文章列表的逻辑 ----


// ---- START: 修改获取总数的逻辑 ----
// 调用一个统一的函数来获取总数，这个函数需要在 functions.php 中创建或修改
$template_data['total_posts'] = get_term_posts_count($request_type, $slug);
// ---- END: 修改获取总数的逻辑 ----


$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;

// 添加分页 HTML 到数据中
$pagination_params = [$request_type => $slug]; // 使用 $request_type 作为参数名
$template_data['pagination'] = get_pagination($page, $template_data['total_posts'], $posts_per_page, $pagination_params);

} else {
// $main_object 无效或 slug 不存在
$template_data['request_type'] = '404';
$template_data['error_message'] = ($request_type === 'category' ? '分类' : '标签') . '未找到。';
}
break; // <--- 确保 category/tag case 有 break

// 继续往下是 case 'home':


case 'home':

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$posts_per_page = get_option('posts_per_page', 10);
$offset = ($page - 1) * $posts_per_page;

// ---- START: 修改获取文章列表的逻辑 ----
try {
$db = get_db();
$sql = "
SELECT
p.*,
u.username AS author_username,
GROUP_CONCAT(DISTINCT c.id || ':' || c.name || ':' || c.slug) AS categories_data,
GROUP_CONCAT(DISTINCT t.id || ':' || t.name || ':' || t.slug) AS tags_data
FROM posts p
LEFT JOIN users u ON p.author = u.id
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN categories c ON pc.category_id = c.id
LEFT JOIN post_tags pt ON p.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE p.status = 'publish' AND p.type = 'post' -- 确保只获取已发布的文章
GROUP BY p.id -- 按文章 ID 分组以合并分类和标签
ORDER BY CASE WHEN p.sticky_order > 0 THEN 0 ELSE 1 END, p.sticky_order ASC, p.created DESC -- ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
";
$stmt = $db->prepare($sql);
$stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$posts_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 处理 GROUP_CONCAT 的结果
$posts_processed = [];
foreach ($posts_raw as $post) {
// 处理分类
$post['categories'] = [];
if (!empty($post['categories_data'])) {
$cats = explode(',', $post['categories_data']);
foreach ($cats as $cat_str) {
$parts = explode(':', $cat_str, 3); // Limit to 3 parts: id, name, slug
if (count($parts) === 3) {
$post['categories'][] = [
'id' => (int)$parts[0],
'name' => $parts[1],
'slug' => $parts[2]
];
}
}
}
unset($post['categories_data']); // 移除原始的 group_concat 字符串

// 处理标签
$post['tags'] = [];
if (!empty($post['tags_data'])) {
$tags = explode(',', $post['tags_data']);
foreach ($tags as $tag_str) {
$parts = explode(':', $tag_str, 3);
if (count($parts) === 3) {
$post['tags'][] = [
'id' => (int)$parts[0],
'name' => $parts[1],
'slug' => $parts[2]
];
}
}
}
unset($post['tags_data']); // 移除原始的 group_concat 字符串

$posts_processed[] = $post;
}
$template_data['posts'] = $posts_processed;

// ---- START: 格式化文章列表时间 ----
if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$post) {
if (isset($post['created'])) {
// 合并格式化的时间信息到文章数组
$post = array_merge(
$post,
format_datetime($post['created'])
);
}
}
unset($post); // 防止后续操作影响引用
}
// ---- END: 格式化文章列表时间 ----
} catch (PDOException $e) {
// 处理数据库错误，例如记录日志
error_log("Database error fetching posts for home: " . $e->getMessage());
$template_data['posts'] = []; // 出错时返回空数组
}
// ---- END: 修改获取文章列表的逻辑 ----

$template_data['total_posts'] = get_total_posts(['status' => 'publish', 'type' => 'post']); // total count 也要加 type
$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;
$template_data['archive_title'] = '';
$template_data['pagination'] = get_pagination($page, $template_data['total_posts'], $posts_per_page);

break;

case '404':
$template_data['error_message'] = '抱歉，页面未找到。';
break;
}


if ($template_data['request_type'] === '404') {
if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
// 确保模板文件名也是 404
// 这个问题需要由调用者 (index.php) 处理，因为它持有 $template_file_name
}


return $template_data;
}


/**
* 获取缓存的或新扫描的插件文件系统数据
* @param int $cache_ttl 缓存有效期（秒），例如 3600 (1小时)
* @return array 插件数据数组，格式如 ['plugin-slug' => ['name' => ..., 'version' => ...], ...]
*/
function get_cached_plugins_data($cache_ttl = 3600) {
$cache_key_data = 'cached_plugins_filesystem_data';
$cache_key_time = 'cached_plugins_filesystem_timestamp';

$cached_data_json = get_option($cache_key_data, null);
$cache_time = (int) get_option($cache_key_time, 0);

// 检查缓存是否有效
if ($cached_data_json !== null && (time() - $cache_time) < $cache_ttl) {
$cached_data = json_decode($cached_data_json, true);
// 确保解码成功且是数组
if (is_array($cached_data)) {
return $cached_data;
}
// 如果解码失败，则视为缓存无效，继续执行扫描
}

// --- 缓存无效或不存在，执行实际扫描 ---
$plugins_dir = PLUGIN_DIR; // 使用常量
$plugins = [];

if (!is_dir($plugins_dir)) {
// 目录不存在，也缓存一个空结果，避免每次都检查
update_option($cache_key_data, json_encode([]));
update_option($cache_key_time, time());
return [];
}

$dirs = @scandir($plugins_dir); // 使用 @ 抑制潜在错误
if ($dirs === false) {
// 扫描失败，同样缓存空结果
update_option($cache_key_data, json_encode([]));
update_option($cache_key_time, time());
return [];
}

foreach ($dirs as $dir) {
if ($dir === '.' || $dir === '..') continue;

$plugin_dir = $plugins_dir . '/' . $dir;
if (!is_dir($plugin_dir)) continue;

$main_file = $plugin_dir . '/' . $dir . '.php';
if (!file_exists($main_file)) continue;

// 调用原有的元数据获取函数 (假设它还在 functions.php)
$plugin_data = get_plugin_data($main_file); // 这个函数读取文件内容并解析
if ($plugin_data) {
// 简单补充下 slug 和可能的文件路径信息（如果需要）
$plugin_data['slug'] = $dir;
// $plugin_data['path'] = $main_file; // 根据需要添加
$plugins[$dir] = $plugin_data; // 使用 slug 作为 key
}
}
// --- 扫描结束 ---

// 存储到缓存
update_option($cache_key_data, json_encode($plugins));
update_option($cache_key_time, time());

return $plugins;
}


function get_cached_themes_data($cache_ttl = 3600) {
$cache_key_data = 'cached_themes_data';
$cache_key_time = 'cached_themes_timestamp';

$cached_data_json = get_option($cache_key_data, null);
$cache_time = (int) get_option($cache_key_time, 0);

if ($cached_data_json !== null && (time() - $cache_time) < $cache_ttl) {
$cached_data = json_decode($cached_data_json, true);
if (is_array($cached_data)) {
return $cached_data;
}
}

// --- 缓存无效，执行实际扫描 ---
$themes_data = scan_and_get_theme_details(); // 这是你需要封装的扫描函数

// 存储到缓存
update_option($cache_key_data, json_encode($themes_data));
update_option($cache_key_time, time());

return $themes_data;
}



/**
* 扫描主题目录，获取所有主题的详细信息。
* 这个函数执行实际的文件系统操作和元数据解析。
*
* @return array 返回一个以主题目录名（slug）为键，主题信息数组为值的关联数组。
*               每个主题信息数组包含：name, slug, description, version, author, author_uri,
*               theme_uri, screenshot_url, is_valid (bool), missing_files (array)
*/
function scan_and_get_theme_details(): array
{
$themes_data = []; // 初始化结果数组
$themes_dir = THEME_DIR; // 使用已定义的常量

// 检查主题目录是否存在
if (!is_dir($themes_dir)) {
// 可以选择记录错误日志
// error_log("Theme directory not found: " . $themes_dir);
return []; // 返回空数组
}

// 扫描目录
$dirs = @scandir($themes_dir); // 使用 @ 抑制潜在的权限等错误
if ($dirs === false) {
// 记录扫描错误
// error_log("Failed to scan theme directory: " . $themes_dir);
return [];
}

foreach ($dirs as $dir) {
// 跳过 '.' 和 '..' 目录
if ($dir === "." || $dir === "..") {
continue;
}

$theme_path = $themes_dir . "/" . $dir;

// 确保是目录
if (!is_dir($theme_path)) {
continue;
}

// --- 初始化当前主题信息数组 ---
$theme_info = [
'slug' => $dir, // 主题的唯一标识符（目录名）
'name' => $dir, // 默认名称是目录名
'description' => '',
'version' => '',
'author' => '',
'theme_uri' => '',
'author_uri' => '',
'screenshot_url' => '', // 截图的公共URL
'is_valid' => true, // 先假设有效，检查后可能变为 false
'missing_files' => [] // 记录缺失的必要文件
];

// --- 1. 检查必需的模板文件 ---
$required_files = ['index.php', 'single.php']; // 根据你的要求定义
foreach ($required_files as $file) {
if (!file_exists($theme_path . "/" . $file)) {
$theme_info['missing_files'][] = $file;
$theme_info['is_valid'] = false; // 缺少必要文件则无效
}
}

// --- 2. 读取 style.css 获取元数据 ---
$style_file = $theme_path . "/style.css";
if (file_exists($style_file)) {
// 尝试读取文件内容，@抑制读取错误
$style_content = @file_get_contents($style_file);
if ($style_content !== false) {
// 使用正则表达式提取元数据 (更健壮的模式)
// 匹配以 "Key:" 开头，忽略前导空格/星号/注释符，捕获冒号后的内容直到行尾
if (preg_match('/^[ \t\/*#]*Theme Name:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['name'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Description:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['description'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Version:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['version'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Author:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['author'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Theme URI:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['theme_uri'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Author URI:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['author_uri'] = trim($match[1]);
}
// 可以按需添加更多标签，如 Tags, License, License URI 等
} else {
// 文件存在但读取失败
$theme_info['missing_files'][] = 'style.css (无法读取)';
$theme_info['is_valid'] = false;
}
} else {
// style.css 文件不存在，通常认为主题无效
$theme_info['missing_files'][] = 'style.css';
$theme_info['is_valid'] = false;
}

// --- 3. 查找截图文件 ---
$screenshot_found = false;
$screenshot_types = ['png', 'jpg', 'jpeg', 'gif']; // 常见的截图格式
foreach ($screenshot_types as $type) {
$screenshot_filename = "screenshot." . $type;
if (file_exists($theme_path . "/" . $screenshot_filename)) {
// 构建截图的公共访问URL
// 确保 SITE_URL 已定义且末尾没有斜杠 (或统一处理)
$site_url_base = rtrim(SITE_URL, '/');
$theme_info['screenshot_url'] = $site_url_base . '/content/themes/' . $dir . '/' . $screenshot_filename;
$screenshot_found = true;
break; // 找到一个即可
}
}
// 如果没有找到截图，screenshot_url 将保持为空字符串 ''

// --- 将当前主题信息添加到结果数组 ---
$themes_data[$dir] = $theme_info; // 使用目录名作为键
}

// 返回包含所有扫描到的主题信息的数组
return $themes_data;
}


// --- START OF ADDITION - includes/functions.php (Flash Message System) ---

/**
* Sets a flash message to be displayed on the next page load.
* Messages are stored in the session.
*
* @param string $message The message to display.
* @param string $type    Optional. The type of message (e.g., 'success', 'error', 'warning', 'info').
*                        This will be used as a CSS class for styling. Defaults to 'info'.
*/
function set_flash_message($message, $type = 'info') {
if (session_status() == PHP_SESSION_NONE) {
session_start(); // Ensure session is started
}

// Initialize the flash messages array in session if it doesn't exist
if (!isset($_SESSION['flash_messages'])) {
$_SESSION['flash_messages'] = array();
}

// Add the message to the array for the specified type
// This allows multiple messages of the same type if needed, though typically one is fine.
if (!isset($_SESSION['flash_messages'][$type])) {
$_SESSION['flash_messages'][$type] = array();
}
$_SESSION['flash_messages'][$type][] = $message;
}

/**
* Displays and clears any flash messages stored in the session.
* This function should be called in your template files (e.g., header.php or before main content)
* where you want messages to appear.
*
* @param bool $echo Whether to echo the messages directly (true) or return the HTML string (false).
* @return string|void If $echo is false, returns the HTML string for messages, otherwise echoes directly.
*/
function display_flash_message($echo = true) {
if (session_status() == PHP_SESSION_NONE) {
session_start(); // Ensure session is started
}

$output = '';
if (isset($_SESSION['flash_messages']) && !empty($_SESSION['flash_messages'])) {
foreach ($_SESSION['flash_messages'] as $type => $messages) {
// Sanitize type for CSS class, default to 'info' if not a recognized type
$allowed_types = ['success', 'error', 'warning', 'info', 'danger']; // 'danger' for Bootstrap compatibility
$alert_type_class = in_array($type, $allowed_types) ? $type : 'info';
if ($alert_type_class === 'error') $alert_type_class = 'danger'; // Map 'error' to 'danger' for CSS consistency if needed

$output .= '<div class="alert alert-' . htmlspecialchars($alert_type_class) . '" role="alert">'; // Assuming you have CSS for .alert and .alert-type
if (count($messages) > 1) {
$output .= '<ul>';
foreach ($messages as $msg) {
$output .= '<li>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</li>';
}
$output .= '</ul>';
} else {
$output .= htmlspecialchars(reset($messages), ENT_QUOTES, 'UTF-8'); // Display the first (and likely only) message
}
$output .= '</div>';
}
// Clear the flash messages from the session once displayed
unset($_SESSION['flash_messages']);
}

if ($echo) {
echo $output;
} else {
return $output;
}
}

// --- END OF ADDITION - includes/functions.php (Flash Message System) ---


// --- START OF SETTINGS API CODE - functions.php ---

global $wp_settings_sections, $wp_settings_fields;
$wp_settings_sections = array();
$wp_settings_fields = array();

/**
* Registers a settings section.
*
* @param string   $page      The slug-name of the settings page on which to show the section.
* @param string   $id        Slug-like ID for the section.
* @param string   $title     Formatted title of the section.
* @param callable $callback  Function that echos out any content at the top of the section (optional).
*/
function add_settings_section($page, $id, $title, $callback = null) {
global $wp_settings_sections;
if (!isset($wp_settings_sections[$page])) {
$wp_settings_sections[$page] = array();
}
$wp_settings_sections[$page][$id] = array(
'id'       => $id,
'title'    => $title,
'callback' => $callback
);
}

/**
* Registers a settings field for a specific section.
*
* @param string   $page        The slug-name of the settings page.
* @param string   $section_id  The slug-name of the section to which this field belongs.
* @param string   $id          Slug-like ID for the field (this will also be the option_name).
* @param string   $title       Formatted title of the field (label).
* @param callable $callback    Function that echos the HTML for the field.
* @param array    $args        Optional. Arguments to pass to the callback function.
*                              Can include 'description', 'default', 'type', 'options' (for select/radio).
*/
function add_settings_field($page, $section_id, $id, $title, $callback, $args = array()) {
global $wp_settings_fields;
if (!isset($wp_settings_fields[$page])) {
$wp_settings_fields[$page] = array();
}
if (!isset($wp_settings_fields[$page][$section_id])) {
$wp_settings_fields[$page][$section_id] = array();
}
$wp_settings_fields[$page][$section_id][$id] = array(
'id'       => $id, // This ID will be the option_name and the input field's name attribute
'title'    => $title,
'callback' => $callback,
'args'     => $args
);
}

/**
* Prints out all settings sections added for a particular settings page.
*
* @param string $page The slug-name of the settings page.
*/
function do_settings_sections($page) {
global $wp_settings_sections, $wp_settings_fields;

if (!isset($wp_settings_sections[$page])) {
return;
}

foreach ($wp_settings_sections[$page] as $section) {
echo '<div class="settings-section" id="section-' . e($section['id']) . '">'; // Optional wrapper div
if ($section['title']) {
echo '<h2>' . e($section['title']) . '</h2>';
}
if ($section['callback'] && is_callable($section['callback'])) {
call_user_func($section['callback'], $section);
}

// Check if there are fields registered for this section on this page
if (isset($wp_settings_fields[$page][$section['id']])) {
echo '<table class="form-table">'; // Using table for layout like WordPress
do_settings_fields($page, $section['id']);
echo '</table>';
}
echo '</div>'; // End optional wrapper div
}
}

/**
* Prints out the settings fields for a particular section.
*
* @param string $page        The slug-name of the settings page.
* @param string $section_id  The slug-name of the section.
*/
function do_settings_fields($page, $section_id) {
global $wp_settings_fields;

if (!isset($wp_settings_fields[$page][$section_id])) {
return;
}

foreach ($wp_settings_fields[$page][$section_id] as $field) {
echo '<tr valign="top">';
echo '<th scope="row"><label for="' . e($field['id']) . '">' . e($field['title']) . '</label></th>';
echo '<td>';
if ($field['callback'] && is_callable($field['callback'])) {
// Pass field id (option name) and args to callback
call_user_func($field['callback'], array_merge(['id' => $field['id']], $field['args']));
}
// Optional: Add description if provided in args
if (isset($field['args']['description']) && !empty($field['args']['description'])) {
echo '<p class="description">' . $field['args']['description'] . '</p>';
}
echo '</td>';
echo '</tr>';
}
}

/**
* A generic callback function to render standard input fields.
* Plugins can use this or define their own more complex callbacks.
*
* @param array $args Field arguments including 'id', 'type', 'default', 'options', etc.
*/
function render_settings_field_callback($args) {
$option_name = $args['id'];
$type = isset($args['type']) ? $args['type'] : 'text';
$default_value = isset($args['default']) ? $args['default'] : '';
$value = get_option($option_name, $default_value);
$options = isset($args['options']) && is_array($args['options']) ? $args['options'] : [];
$description_id = $option_name . '-description'; // For aria-describedby

switch ($type) {
case 'text':
case 'number':
case 'email':
case 'url':
echo '<input type="' . e($type) . '" id="' . e($option_name) . '" name="' . e($option_name) . '" value="' . e($value) . '" class="regular-text" aria-describedby="' . e($description_id) . '">';
break;
case 'textarea':
echo '<textarea id="' . e($option_name) . '" name="' . e($option_name) . '" rows="5" class="large-text" aria-describedby="' . e($description_id) . '">' . e($value) . '</textarea>';
break;
case 'checkbox':
echo '<input type="checkbox" id="' . e($option_name) . '" name="' . e($option_name) . '" value="1" ' . checked($value, '1', false) . ' aria-describedby="' . e($description_id) . '">';
// Optional: Add a label for the checkbox if 'label' arg is provided
if (isset($args['label'])) {
echo ' <label for="' . e($option_name) . '">' . e($args['label']) . '</label>';
}
break;
case 'select':
echo '<select id="' . e($option_name) . '" name="' . e($option_name) . '" aria-describedby="' . e($description_id) . '">';
foreach ($options as $val => $label) {
echo '<option value="' . e($val) . '" ' . selected($value, $val, false) . '>' . e($label) . '</option>';
}
echo '</select>';
break;
case 'radio':
if (!empty($options)) {
echo '<fieldset>'; // Group radio buttons
foreach ($options as $val => $label) {
echo '<label style="margin-right: 15px;">'; // Add some spacing
echo '<input type="radio" name="' . e($option_name) . '" value="' . e($val) . '" ' . checked($value, $val, false) . '> ';
echo e($label);
echo '</label>';
}
echo '</fieldset>';
}
break;
// Add more types as needed (e.g., color picker, date picker)
default:
echo '<!-- Field type ' . e($type) . ' not implemented by generic renderer -->';
break;
}
// The field-specific description is now handled by do_settings_fields
// if (isset($args['description'])) {
//     echo '<p class="description" id="' . e($description_id) . '">' . $args['description'] . '</p>';
// }
}

/**
* Helper function for checkbox and radio 'checked' attribute.
*/
function checked($checked, $current = true, $echo = true) {
$result = ($checked == $current) ? ' checked="checked"' : '';
if ($echo) {
echo $result;
}
return $result;
}

/**
* Helper function for select option 'selected' attribute.
*/
function selected($selected, $current = true, $echo = true) {
$result = ($selected == $current) ? ' selected="selected"' : '';
if ($echo) {
echo $result;
}
return $result;
}

// --- END OF SETTINGS API CODE - functions.php ---



// --- START OF ADDITION TO includes/functions.php ---

/**
* 生成RSS feed的XML内容字符串.
*
* @return string|false RSS XML字符串，如果失败则返回false.
*/
function generate_rss_feed_content() {
// 从数据库获取RSS所需配置
$feed_title = get_option('site_title', 'My Blog');
$site_url_for_feed = rtrim(SITE_URL, '/'); // 确保没有尾部斜杠
$feed_link = $site_url_for_feed;
$feed_description = get_option('site_description', 'Latest updates from the blog.');
$feed_language = 'zh-CN'; // 或者从选项获取
$feed_items_count = (int) get_option('posts_per_rss', 15);
$feed_ttl = (int) get_option('rss_ttl', 60);

// 使用输出缓冲来捕获XML内容
ob_start();

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:wfw="http://wellformedweb.org/CommentAPI/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:atom="http://www.w3.org/2005/Atom"
xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
>' . "\n";

echo '<channel>' . "\n";
echo '  <title>' . e($feed_title) . '</title>' . "\n";
// atom:link 指向静态的 rss.xml 文件
echo '  <atom:link href="' . e($site_url_for_feed . '/rss.xml') . '" rel="self" type="application/rss+xml" />' . "\n";
echo '  <link>' . e($feed_link) . '</link>' . "\n";
echo '  <description>' . e($feed_description) . '</description>' . "\n";
echo '  <lastBuildDate>' . date(DATE_RFC2822) . '</lastBuildDate>' . "\n";
echo '  <language>' . e($feed_language) . '</language>' . "\n";
echo '  <sy:updatePeriod>hourly</sy:updatePeriod>' . "\n";
echo '  <sy:updateFrequency>1</sy:updateFrequency>' . "\n";
echo '  <ttl>' . $feed_ttl . '</ttl>' . "\n";

try {
$db = get_db();
$stmt = $db->prepare("
SELECT p.*, u.username as author_username
FROM posts p
LEFT JOIN users u ON p.author = u.id
WHERE p.status = 'publish' AND p.type = 'post'
ORDER BY p.created DESC
LIMIT :limit
");
$stmt->bindValue(':limit', $feed_items_count, PDO::PARAM_INT);
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($posts as $post) {
$post_url = Permalink::get_post_link($post['id']);
$post_date_rfc2822 = date(DATE_RFC2822, strtotime($post['created']));

echo '  <item>' . "\n";
echo '    <title>' . e($post['title']) . '</title>' . "\n";
echo '    <link>' . e($post_url) . '</link>' . "\n";
echo '    <pubDate>' . $post_date_rfc2822 . '</pubDate>' . "\n";
echo '    <dc:creator><![CDATA[' . e($post['author_username'] ?? 'Unknown Author') . ']]></dc:creator>' . "\n";
echo '    <guid isPermaLink="true">' . e($post_url) . '</guid>' . "\n";

$description_content = '';
if (!empty($post['excerpt'])) {
$description_content = nl2br(e($post['excerpt']));
} else {
$content_text = strip_tags($post['content']);
$limit = 250;
if (mb_strlen($content_text, 'UTF-8') > $limit) {
$description_content = mb_substr($content_text, 0, $limit, 'UTF-8') . '...';
} else {
$description_content = $content_text;
}
$description_content = nl2br(e($description_content));
}
// **重要: 如果要提供全文RSS，取消下面这行注释**
// echo '    <content:encoded><![CDATA[' . $post['content'] . ']]></content:encoded>' . "\n";
echo '    <description><![CDATA[' . $description_content . ']]></description>' . "\n";

$categories = get_post_categories($post['id']);
if (!empty($categories)) {
foreach ($categories as $category) {
echo '    <category><![CDATA[' . e($category['name']) . ']]></category>' . "\n";
}
}
echo '  </item>' . "\n";
}

} catch (PDOException $e) {
error_log("RSS Feed Content Generation Error: " . $e->getMessage());
// 可以在这里 echo 一个错误 item，或者直接让 ob_get_clean() 返回空内容
// 为了简单，这里我们允许在出错时 feed 内容不完整或为空
}

echo '</channel>' . "\n";
echo '</rss>' . "\n";

$rss_content = ob_get_clean(); // 获取缓冲区内容并清空
return $rss_content;
}

/**
* 将生成的RSS内容写入到 rss.xml 文件.
*
* @return bool 写入成功返回true, 失败返回false.
*/
function write_rss_file() {
$rss_content = generate_rss_feed_content();
if ($rss_content === false || empty(trim($rss_content))) { // 确保内容不是空的
error_log("Failed to generate RSS content, it was empty.");
return false;
}

// rss.xml 文件路径，通常在网站根目录
$rss_file_path = ABSPATH . 'rss.xml';

// 尝试写入文件
if (@file_put_contents($rss_file_path, $rss_content) !== false) {
// （可选）设置文件权限
// @chmod($rss_file_path, 0644);
return true;
} else {
error_log("Failed to write rss.xml file to: " . $rss_file_path . ". Check directory permissions.");
// 可以在后台给管理员提示错误
return false;
}
}

// --- END OF ADDITION TO includes/functions.php ---

//--- START OF MODIFICATION - includes/functions.php (Script/Style Enqueueing) ---
global $wp_scripts_registered, $wp_styles_registered;
global $wp_scripts_enqueued, $wp_styles_enqueued;
global $wp_script_data, $wp_style_data; // For extra data like 'defer', 'async'

$wp_scripts_registered = [];
$wp_styles_registered = [];
$wp_scripts_enqueued = []; // Handles to be printed in footer
$wp_styles_enqueued = [];  // Handles to be printed in head
$wp_script_data = []; // Store extra data for scripts
$wp_style_data = [];  // Store extra data for styles


/**
* 注册脚本
* @param string $handle 脚本的唯一句柄
* @param string $src 脚本的URL
* @param array $deps 依赖的其他脚本句柄数组 (暂未实现依赖解析)
* @param string|bool $ver 版本号 (可选, 用于缓存清除)
* @param bool $in_footer 是否在页脚加载 (true) 或页头 (false)
* @param array $args 附加参数，例如 ['strategy' => 'defer']
*/
function wp_register_script($handle, $src, $deps = [], $ver = false, $in_footer = false, $args = []) {
global $wp_scripts_registered, $wp_script_data;
error_log('LitaBlog DEBUG: wp_register_script for handle: ' . $handle . ' with src: ' . $src); 
$wp_scripts_registered[$handle] = [
'src' => $src,
'ver' => $ver,
'in_footer' => $in_footer,
'deps' => (array) $deps // 暂未实现依赖解析
];
if (!empty($args)) {
$wp_script_data[$handle] = $args;
}
}

/**
* 注册样式
* @param string $handle 样式的唯一句柄
* @param string $src 样式的URL
* @param array $deps 依赖的其他样式句柄数组 (暂未实现依赖解析)
* @param string|bool $ver 版本号 (可选)
* @param string $media 媒体类型 (e.g., 'all', 'screen')
*/
function wp_register_style($handle, $src, $deps = [], $ver = false, $media = 'all') {
global $wp_styles_registered;
error_log('LitaBlog DEBUG: wp_register_style for handle: ' . $handle . ' with src: ' . $src); 
$wp_styles_registered[$handle] = [
'src' => $src,
'ver' => $ver,
'media' => $media,
'deps' => (array) $deps // 暂未实现依赖解析
];
}

/**
* 将已注册的脚本加入加载队列
* @param string $handle
*/
function wp_enqueue_script($handle) {
global $wp_scripts_registered, $wp_scripts_enqueued;
if (isset($wp_scripts_registered[$handle]) && !in_array($handle, $wp_scripts_enqueued)) {
// 简单处理：直接加入队列，未来可以实现依赖排序
$wp_scripts_enqueued[] = $handle;
error_log('LitaBlog DEBUG: wp_enqueue_script - ADDED handle: ' . $handle . ' to $wp_scripts_enqueued. Current queue: ' . print_r($wp_scripts_enqueued, true)); 
}
}

/**
* 将已注册的样式加入加载队列
* @param string $handle
*/
function wp_enqueue_style($handle) {
global $wp_styles_registered, $wp_styles_enqueued;
if (isset($wp_styles_registered[$handle]) && !in_array($handle, $wp_styles_enqueued)) {
$wp_styles_enqueued[] = $handle;
error_log('LitaBlog DEBUG: wp_enqueue_style - ADDED handle: ' . $handle . ' to $wp_styles_enqueued. Current queue: ' . print_r($wp_styles_enqueued, true));
}
}

/**
* 打印页头队列中的样式和脚本
*/
function wp_print_head_scripts_and_styles() {
global $wp_styles_registered, $wp_styles_enqueued;
global $wp_scripts_registered, $wp_scripts_enqueued, $wp_script_data;
error_log('LitaBlog DEBUG: wp_print_head_scripts_and_styles() CALLED.'); // << ADD THIS
error_log('LitaBlog DEBUG: Styles to print: ' . print_r($wp_styles_enqueued, true)); // << ADD THIS
error_log('LitaBlog DEBUG: Head scripts to print: ' . print_r(array_filter($wp_scripts_enqueued, function($h) { global $wp_scripts_registered; return isset($wp_scripts_registered[$h]) && !$wp_scripts_registered[$h]['in_footer']; }), true)); // << ADD THIS



// 打印样式
foreach ($wp_styles_enqueued as $handle) {
if (isset($wp_styles_registered[$handle])) {
$style = $wp_styles_registered[$handle];
$src = $style['src'];
if ($style['ver']) {
$src .= '?ver=' . $style['ver'];
}
echo "<link rel='stylesheet' id='{$handle}-css' href='" . e($src) . "' media='" . e($style['media']) . "' />\n";
}
}

// 打印页头脚本 (in_footer = false)
foreach ($wp_scripts_enqueued as $handle) {
if (isset($wp_scripts_registered[$handle]) && !$wp_scripts_registered[$handle]['in_footer']) {
$script = $wp_scripts_registered[$handle];
$src = $script['src'];
if ($script['ver']) {
$src .= '?ver=' . $script['ver'];
}
$extra_attrs = '';
if (isset($wp_script_data[$handle]) && isset($wp_script_data[$handle]['strategy'])) {
if ($wp_script_data[$handle]['strategy'] === 'defer') $extra_attrs .= ' defer';
if ($wp_script_data[$handle]['strategy'] === 'async') $extra_attrs .= ' async';
}
echo "<script src='" . e($src) . "' id='{$handle}-js'{$extra_attrs}></script>\n";
}
}
}

/**
* 打印页脚队列中的脚本
*/
function wp_print_footer_scripts() {
global $wp_scripts_registered, $wp_scripts_enqueued, $wp_script_data;
error_log('LitaBlog DEBUG: wp_print_footer_scripts() CALLED.'); // << ADD THIS
error_log('LitaBlog DEBUG: Footer scripts to print: ' . print_r(array_filter($wp_scripts_enqueued, function($h) { global $wp_scripts_registered; return isset($wp_scripts_registered[$h]) && $wp_scripts_registered[$h]['in_footer']; }), true)); // << ADD THIS


foreach ($wp_scripts_enqueued as $handle) {
if (isset($wp_scripts_registered[$handle]) && $wp_scripts_registered[$handle]['in_footer']) {
$script = $wp_scripts_registered[$handle];
$src = $script['src'];
if ($script['ver']) {
$src .= '?ver=' . $script['ver'];
}
$extra_attrs = '';
if (isset($wp_script_data[$handle]) && isset($wp_script_data[$handle]['strategy'])) {
if ($wp_script_data[$handle]['strategy'] === 'defer') $extra_attrs .= ' defer';
if ($wp_script_data[$handle]['strategy'] === 'async') $extra_attrs .= ' async';
}
echo "<script src='" . e($src) . "' id='{$handle}-js'{$extra_attrs}></script>\n";
}
}
}


/**
* 辅助函数：获取当前管理页面的 hook_suffix
* 简单实现：基于当前脚本文件名和 GET 参数
* @return string
*/
function get_current_admin_page_hook_suffix() {
$current_script = basename($_SERVER['PHP_SELF']); // e.g., 'content.php'
$page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';

if (!empty($page_slug)) {
return $current_script . '_page_' . $page_slug; // e.g., admin.php_page_my-plugin-settings
} elseif (!empty($type)) {
return $current_script . '_' . $type; // e.g., content.php_post
}
return $current_script; // e.g., index.php (for dashboard)
}

// --- END OF MODIFICATION - includes/functions.php (Script/Style Enqueueing) ---

// --- START OF PERMISSION SYSTEM ADDITION ---

/**
 * 定义系统的角色及其对应的权限.
 * 这是一个集中管理权限的地方.
 *
 * @return array 角色与权限的映射数组.
 */
function get_roles_and_caps() {
    $roles = [
        'administrator' => [
            'read' => true,
            'publish_posts' => true,
            'edit_posts' => true,
            'edit_others_posts' => true,
            'delete_posts' => true,
            'manage_options' => true,
            // 管理员默认拥有所有权限 (在 current_user_can 中有硬编码检查)
        ],
        'user' => [
            'read' => true,
            'publish_posts' => false, // 默认情况下，普通用户不能发帖
            'edit_posts' => true,    // 允许编辑自己的帖子 (需要在 content.php 中检查)
        ],
        // 未来可以添加更多角色，例如 'editor', 'contributor'
    ];

    // 允许插件或主题通过过滤器修改角色和权限
    return apply_filters('get_roles_and_caps', $roles);
}

/**
 * 检查当前登录用户是否拥有指定的权限.
 * 这是新的权限检查核心函数.
 *
 * @param string $capability 要检查的权限名称 (e.g., 'publish_posts').
 * @return bool 用户是否拥有该权限.
 */
function current_user_can($capability) {
    if (!is_logged_in()) {
        return false;
    }

    $user_role = $_SESSION['role'] ?? 'user'; // 如果 session 中没有角色, 默认为 'user'
    
    // 管理员拥有所有权限，这是一个硬编码的最高权限
    if ($user_role === 'administrator') {
        // 允许插件覆盖管理员权限 (极少数情况需要)
        return apply_filters('user_has_cap', true, $capability, $user_role);
    }

    $roles_map = get_roles_and_caps();
    
    // 检查角色是否存在且权限是否被设置为 true
    $has_cap = isset($roles_map[$user_role][$capability]) && $roles_map[$user_role][$capability] === true;

    // 允许插件过滤最终结果
    return apply_filters('user_has_cap', $has_cap, $capability, $user_role);
}

/**
 * 自动根据固定链接结构生成 Web 服务器伪静态重写规则
 *
 * @param string $permalink_type 固定链接类型
 * @return bool 是否成功生成
 */
function litablog_generate_rewrite_rules($permalink_type) {
    $htaccess_file = ABSPATH . '.htaccess';
    $web_config_file = ABSPATH . 'web.config';

    // 获取站点子目录路径 (如 /blog/)
    $sub_dir = parse_url(SITE_URL, PHP_URL_PATH);
    $sub_dir = $sub_dir ? rtrim($sub_dir, '/') . '/' : '/';

    if ($permalink_type === 'default') {
        // 如果是默认链接，尝试恢复干净的默认伪静态或删除，避免干扰
        if (file_exists($htaccess_file) && is_writable($htaccess_file)) {
            @unlink($htaccess_file);
        }
        if (file_exists($web_config_file) && is_writable($web_config_file)) {
            @unlink($web_config_file);
        }
        return true;
    }

    // --- 1. 生成 Apache .htaccess ---
    $htaccess_rules = "# Begin LitaBlog Rewrite Rules\n";
    $htaccess_rules .= "<IfModule mod_rewrite.c>\n";
    $htaccess_rules .= "RewriteEngine On\n";
    $htaccess_rules .= "RewriteBase " . $sub_dir . "\n";
    
    // 如果是数字型 (e.g. 123.html)
    if ($permalink_type === 'numeric') {
        $htaccess_rules .= "RewriteRule ^([0-9]+)\.html$ index.php?p=$1 [L,QSA]\n";
    } 
    // 如果是文章名型 (e.g. post/123)
    elseif ($permalink_type === 'post') {
        $htaccess_rules .= "RewriteRule ^post/([0-9]+)$ index.php?p=$1 [L,QSA]\n";
    }
    
    $htaccess_rules .= "RewriteCond %{REQUEST_FILENAME} !-f\n";
    $htaccess_rules .= "RewriteCond %{REQUEST_FILENAME} !-d\n";
    $htaccess_rules .= "RewriteRule . index.php [L]\n";
    $htaccess_rules .= "</IfModule>\n";
    $htaccess_rules .= "# End LitaBlog Rewrite Rules\n";

    // --- 2. 生成 IIS web.config ---
    $xml_rules = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $xml_rules .= '<configuration>' . "\n";
    $xml_rules .= '  <system.webServer>' . "\n";
    $xml_rules .= '    <rewrite>' . "\n";
    $xml_rules .= '      <rules>' . "\n";
    
    if ($permalink_type === 'numeric') {
        $xml_rules .= '        <rule name="LitaBlog Numeric Rule" stopProcessing="true">' . "\n";
        $xml_rules .= '          <match url="^([0-9]+)\.html$" />' . "\n";
        $xml_rules .= '          <action type="Rewrite" url="index.php?p={R:1}" />' . "\n";
        $xml_rules .= '        </rule>' . "\n";
    } elseif ($permalink_type === 'post') {
        $xml_rules .= '        <rule name="LitaBlog Post Rule" stopProcessing="true">' . "\n";
        $xml_rules .= '          <match url="^post/([0-9]+)$" />' . "\n";
        $xml_rules .= '          <action type="Rewrite" url="index.php?p={R:1}" />' . "\n";
        $xml_rules .= '        </rule>' . "\n";
    }
    
    $xml_rules .= '        <rule name="LitaBlog Index Fallback" stopProcessing="true">' . "\n";
    $xml_rules .= '          <match url="." />' . "\n";
    $xml_rules .= '          <conditions>' . "\n";
    $xml_rules .= '            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />' . "\n";
    $xml_rules .= '            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />' . "\n";
    $xml_rules .= '          </conditions>' . "\n";
    $xml_rules .= '          <action type="Rewrite" url="index.php" />' . "\n";
    $xml_rules .= '        </rule>' . "\n";
    $xml_rules .= '      </rules>' . "\n";
    $xml_rules .= '    </rewrite>' . "\n";
    $xml_rules .= '  </system.webServer>' . "\n";
    $xml_rules .= '</configuration>' . "\n";

    // 写入文件并做好权限和可写性校验
    $htaccess_ok = false;
    if (!file_exists($htaccess_file) || is_writable($htaccess_file)) {
        $htaccess_ok = (file_put_contents($htaccess_file, $htaccess_rules) !== false);
    }
    
    $web_config_ok = false;
    if (!file_exists($web_config_file) || is_writable($web_config_file)) {
        $web_config_ok = (file_put_contents($web_config_file, $xml_rules) !== false);
    }

    return ($htaccess_ok || $web_config_ok);
}


// --- END OF PERMISSION SYSTEM ADDITION ---


/**
 * 基于白名单机制的 HTML 安全净化器 (防止 Stored XSS 漏洞)
 * 采用原生 DOMDocument 解析器，比正则表达式更安全、更难被绕过
 *
 * @param string $html 待净化的原始 HTML 字符串
 * @return string 净化后的安全 HTML 字符串
 */
function litablog_purify_html($html) {
    if (empty($html)) {
        return '';
    }

    // 初始化 DOMDocument 并关闭 libxml 错误输出（防止畸形 HTML 抛出警告）
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);

    // 包装外层容器以确保能正确解析 UTF-8 编码的 HTML 片段
    $html_wrapped = '<div>' . $html . '</div>';
    $dom->loadHTML(mb_convert_encoding($html_wrapped, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    // 允许保留的 HTML 标签白名单
    $allowed_tags = [
        'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'span', 
        'a', 'img', 'ul', 'ol', 'li', 'blockquote', 'pre', 'code', 
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'video', 'audio', 'source',
		'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td' // 新增：允许表格标签通过安全净化器
    ];

    // 绝对禁止且必须连同子元素一起彻底销毁的危险标签黑名单
    $destroy_tags = [
        'script', 'style', 'iframe', 'object', 'embed', 
        'form', 'input', 'textarea', 'button', 'noscript'
    ];

    // 针对特定标签允许保留的属性白名单
    $allowed_attributes = [
        'a'      => ['href', 'title', 'target', 'class', 'style'],
        'img'    => ['src', 'alt', 'title', 'class', 'style', 'width', 'height'],
        'span'   => ['class', 'style'],
        'p'      => ['class', 'style', 'align'],
        'div'    => ['class', 'style'],
        'pre'    => ['class', 'style'],
        'code'   => ['class'],
        'video'  => ['src', 'controls', 'width', 'height', 'poster', 'preload', 'class'],
        'audio'  => ['src', 'controls', 'preload', 'class'],
        'source' => ['src', 'type']
    ];

    // 全局允许保留的无害属性
    $global_allowed_attributes = ['id', 'class', 'style'];

    $root = $dom->getElementsByTagName('div')->item(0);
    if (!$root) {
        return '';
    }

    // 递归净化节点树
    litablog_purify_node($root, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes);

    // 导出处理后的 HTML 片段
    $purified_html = '';
    foreach ($root->childNodes as $child) {
        $purified_html .= $dom->saveHTML($child);
    }

    return $purified_html;
}

/**
 * 递归处理 DOM 节点
 */
function litablog_purify_node($node, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes) {
    if ($node->hasChildNodes()) {
        // 采用倒序循环，因为在循环体中可能会删除不合法的 DOM 节点
        for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
            $child = $node->childNodes->item($i);

            if ($child->nodeType === XML_ELEMENT_NODE) {
                $tag_name = strtolower($child->nodeName);

                // 1. 如果属于高危标签，直接连带子节点整体移除
                if (in_array($tag_name, $destroy_tags)) {
                    $node->removeChild($child);
                    continue;
                }

                // 2. 如果是不在白名单中的无害外层标签 (例如 <section>)，则解包并保留其内部文字和子元素
                if (!in_array($tag_name, $allowed_tags)) {
                    while ($child->hasChildNodes()) {
                        $node->insertBefore($child->firstChild, $child);
                    }
                    $node->removeChild($child);
                    continue;
                }

                // 3. 如果是白名单内的标签，则进一步清洗其属性
                litablog_purify_node_attributes($child, $tag_name, $allowed_attributes, $global_allowed_attributes);

                // 4. 递归处理其子节点
                litablog_purify_node($child, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes);
            }
        }
    }
}

/**
 * 清洗节点属性，过滤 javascript 伪协议和恶意的 CSS 执行
 */
function litablog_purify_node_attributes($element, $tag_name, $allowed_attributes, $global_allowed_attributes) {
    if (!$element->hasAttributes()) {
        return;
    }

    $attrs_to_remove = [];
    $specific_allowed = $allowed_attributes[$tag_name] ?? [];

    foreach ($element->attributes as $attr) {
        $attr_name = strtolower($attr->nodeName);

        // 1. 检查属性是否在允许名单中
        $is_allowed = in_array($attr_name, $global_allowed_attributes) || in_array($attr_name, $specific_allowed);
        if (!$is_allowed) {
            $attrs_to_remove[] = $attr->nodeName;
            continue;
        }

        // 2. 过滤基于协议的属性值，阻断 javascript: 伪协议
        if (in_array($attr_name, ['href', 'src'])) {
            $value = trim($attr->nodeValue);
            
            // 移除非法字符，防止通过折行和空白符绕过检测 (例如: java\nscript:)
            $clean_value = preg_replace('/[\r\n\t]/', '', strtolower($value));
            
            if (preg_match('/^(javascript|vbscript|data|onload|onerror|onmouseover):/i', $clean_value)) {
                $attrs_to_remove[] = $attr->nodeName;
                continue;
            }
        }

        // 3. 严格清洗 style 属性，阻断 CSS 表达式及行为注入
        if ($attr_name === 'style') {
            $style_value = strtolower(trim($attr->nodeValue));
            if (preg_match('/(expression|behavior|url\s*\(|javascript:|mocha:|livescript:)/i', $style_value)) {
                $attrs_to_remove[] = $attr->nodeName;
            }
        }
    }

    // 移除不合规属性
    foreach ($attrs_to_remove as $attr_name) {
        $element->removeAttribute($attr_name);
    }
}


/**
 * 注册 HTML 净化过滤器到 'the_content' 钩子
 * 优先级设为 9，确保在富文本短代码解析或其它渲染逻辑之前净化完毕，保障输出安全
 */
add_filter('the_content', 'litablog_purify_html', 9);






?>