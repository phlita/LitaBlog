<?php

class Router {
/**
* 查询变量
*/
private $query_vars = array();

/**
* 允许的查询参数
*/
private $public_query_vars = array(
'p',           // 文章ID
'page',        // 页码
'category',    // 分类（向后兼容）
'tag',         // 标签（向后兼容）
'author',      // 作者
'year',        // 年份
'month',       // 月份
's'           // 搜索关键词
);

/**
* 是否找到匹配的路由
*/
private $matched = false;

public function __construct() {
$this->parse_request(); // Call parsing logic upon instantiation
}

private function parse_request() {
// 1. 清空旧状态 (Clear old state - good practice if reused)

$this->query_vars = [];
$this->matched = false;
$this->request_type = 'home';
$this->template = 'index.php';
$this->main_object = null;

// 2. 解析 $_GET 和请求路径 (Parse $_GET and Request Path)
//    (Keep the existing logic to populate $this->query_vars based on
//     $_GET parameters and permalink structure)
foreach ($_GET as $key => $value) {
if (in_array($key, $this->public_query_vars)) {
$this->query_vars[$key] = $value;
}
}

// 3. --- NEW: DECISION MAKING LOGIC ---
//    This block replaces the if/else structure in the original index.php

// a. 检查是否是显式 404 (Check for explicit 404)
if ($this->get_query_var('error') === '404') {
$this->request_type = '404';
$this->template = '404.php';
// 设置 404 状态码 (Set 404 Header)
if (!headers_sent()) { // Check if headers are already sent
header('HTTP/1.0 404 Not Found');
}
$this->matched = true; // We explicitly identified it as 404
return; // Stop further processing
}

$search_query = trim($this->get_query_var('s', ''));
if (!empty($search_query)) {
    $this->request_type = 'search';
    $this->main_object = $search_query; // 将搜索词作为主要对象

    // 决定使用哪个模板：优先 search.php，其次 index.php
    $theme_name = get_option('current_theme', 'default');
    $search_template_file = ABSPATH . '/content/themes/' . $theme_name . '/search.php';
    $this->template = file_exists($search_template_file) ? 'search.php' : 'index.php';

    $this->matched = true;
    return; // 搜索请求已匹配，结束路由解析
}

// b. 获取关键查询变量 (Get key query variables)
$post_id = (int) $this->get_query_var('p', 0);
$category_slug = $this->get_query_var('category');
$tag_slug = $this->get_query_var('tag');
// Add other potential vars like 's' (search), 'author', etc. if needed

// c. 判断请求类型并获取数据 (Determine type and fetch data)
if ($post_id > 0) {
// 尝试获取文章 (Try to get post)
$post = get_post($post_id);
if ($post) {
//$this->request_type = 'single';
//$this->template = 'single.php';

        // --- START OF INSERTED CODE ---
        // 根据 $post['type'] 设置请求类型和模板
        if (isset($post['type'])) {
            if ($post['type'] === 'page') {
                $this->request_type = 'page'; // 将请求类型明确为 'page'

                // 检查主题中是否存在 page.php，如果存在则使用，否则回退到 single.php
                // (或者，如果严格要求 page 必须用 page.php，不存在则404，可以调整这里的逻辑)
                $theme_name_for_page_check = get_option('current_theme', 'default');
                $page_template_file_path = ABSPATH . '/content/themes/' . $theme_name_for_page_check . '/page.php';
                if (file_exists($page_template_file_path)) {
                    $this->template = 'page.php';
                } else {
                    // 如果 page.php 不存在，可以选择回退到 single.php，
                    // 或者更严格地抛出错误/显示404（取决于您的设计决策）
                    // 这里我们先回退到 single.php，因为原逻辑就是这样
                    $this->template = 'single.php';
                    // 如果希望 page 类型必须有 page.php，则可以将上面一行改为:
                    // $this->request_type = '404';
                    // $this->template = '404.php';
                    // if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
                    // $this->main_object = null; // 清空 main_object
                }
            } elseif ($post['type'] === 'post') {
                $this->request_type = 'single'; // 'post' 类型对应 'single' 请求
                $this->template = 'single.php';
            } else {
                // 未知类型，可以默认为 'single' 或抛出错误
                $this->request_type = 'single';
                $this->template = 'single.php';
            }
        } else {
            // 如果 $post['type'] 未设置 (理论上不应该发生，除非数据问题)，默认行为
            $this->request_type = 'single';
            $this->template = 'single.php';
        }
        // --- END OF INSERTED CODE ---

$this->main_object = $post;

// 处理 URL 规范化 (Handle Canonical URL)
$permalink_type = get_option('permalink_type', Permalink::TYPE_DEFAULT);
if ($permalink_type !== Permalink::TYPE_DEFAULT) {
$current_url = $_SERVER['REQUEST_URI'];
$correct_url_path = parse_url(Permalink::get_post_link($post_id), PHP_URL_PATH);

// Normalize comparison (ignore trailing slashes)
if (rtrim($current_url, '/') !== rtrim($correct_url_path, '/')) {
if (!headers_sent()) {
header('Location: ' . Permalink::get_post_link($post_id), true, 301);
exit; // Important: Stop script after redirect header
}
}
}
$this->matched = true;
} else {
// 文章 ID 有效但未找到 (Post ID valid but not found) -> 404
$this->request_type = '404';
$this->template = '404.php';
if (!headers_sent()) {
header('HTTP/1.0 404 Not Found');
}
$this->matched = true;
}
} elseif ($category_slug) {
// 尝试获取分类 (Try to get category)
$category = get_category_by_slug($category_slug);
if ($category) {
$this->request_type = 'category';
$this->main_object = $category;
// 检查分类模板是否存在，否则回退 (Check for category template, fallback)
$category_template_path = ABSPATH . '/content/themes/' . get_option('current_theme', 'default') . '/category.php';
$this->template = file_exists($category_template_path) ? 'category.php' : 'index.php';
$this->matched = true;
} else {
// 分类 slug 无效 (Invalid category slug) -> 404
$this->request_type = '404';
$this->template = '404.php';
if (!headers_sent()) {
header('HTTP/1.0 404 Not Found');
}
$this->matched = true;
}
} elseif ($tag_slug) {
// 尝试获取标签 (Try to get tag)
$tag = get_tag_by_slug($tag_slug);
if ($tag) {
$this->request_type = 'tag';
$this->main_object = $tag;
// 检查标签模板是否存在，否则回退 (Check for tag template, fallback)
$tag_template_path = ABSPATH . '/content/themes/' . get_option('current_theme', 'default') . '/tag.php';
$this->template = file_exists($tag_template_path) ? 'tag.php' : 'index.php';
$this->matched = true;
} else {
// 标签 slug 无效 (Invalid tag slug) -> 404
$this->request_type = '404';
$this->template = '404.php';
if (!headers_sent()) {
header('HTTP/1.0 404 Not Found');
}
$this->matched = true;
}
} else {
// --- 核心修复：严格区分“真·首页”和“未匹配的垃圾路径” ---
            
            // 1. 获取用户在浏览器中实际请求的路径 (去除域名)
            $request_uri = $_SERVER['REQUEST_URI'];
            $parsed_url = parse_url($request_uri);
            $path = $parsed_url['path'] ?? '/';

            // 2. 获取当前博客安装所在的子目录路径 (例如 /blog/v6/)
            $site_path = parse_url(SITE_URL, PHP_URL_PATH) ?? '';
            $site_path = rtrim($site_path, '/');

            // 3. 剥离安装目录，算出相对路径
            $relative_path = substr($path, strlen($site_path));
            $relative_path = trim($relative_path, '/');

            // 4. 终极判断：如果相对路径为空、或者是 index.php，说明确实在访问首页
            if ($relative_path === '' || $relative_path === 'index.php') {
                $this->request_type = 'home';
                $this->template = 'index.php';
                $this->matched = true;
            } else {
                // 相对路径里有乱七八糟的目录名，且没有任何重写规则认识它
                // 宣判为死刑 -> 触发真正的 404
                $this->request_type = '404';
                $this->template = '404.php';
                if (!headers_sent()) {
                    header('HTTP/1.0 404 Not Found');
                }
                $this->matched = true;
            }
}

// d. 如果经过所有判断仍然没有匹配 (Final fallback 404 if not matched)
//    (This might be redundant if logic above covers all cases, but safe)
if (!$this->matched) {
$this->request_type = '404';
$this->template = '404.php';
if (!headers_sent()) {
header('HTTP/1.0 404 Not Found');
}
$this->matched = true; // Explicitly handled as 404
}
// --- END DECISION MAKING LOGIC ---
} // End parse_request

// ... get_query_var(), get_query_vars() ...
public function get_query_var($var, $default = '') {
return isset($this->query_vars[$var]) ? $this->query_vars[$var] : $default;
}
// --- NEW GETTER METHODS ---
/**
* 获取请求类型
* @return string
*/
public function get_request_type() {
return $this->request_type;
}

/**
* 获取模板文件名
* @return string
*/
public function get_template() {
return $this->template;
}

/**
* 获取主要数据对象
* @return mixed|null
*/
public function get_main_object() {
return $this->main_object;
}
// --- END NEW GETTER METHODS ---

} // End Class Router