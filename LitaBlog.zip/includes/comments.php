<?php
/**
 * Comment handler (Strictly Web & AJAX)
 */

require_once './../config.php';
require_once './functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$wants_json = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'add_comment')) {
        if ($wants_json) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => '安全验证失败，请刷新页面后重新提交']); exit;
        }
        exit('CSRF Verification Failed');
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if (get_option('enable_comments', '1') !== '1') {
        if ($wants_json) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => '评论功能已关闭']); exit;
        }
        exit('评论功能已关闭');
    }

if (!is_logged_in()) {
    $last_comment_time = $_SESSION['last_comment_time'] ?? 0;
    if (time() - $last_comment_time < 30) { // 限制 30 秒内只能评论一次
        if ($wants_json) {
            http_response_code(429);
            echo json_encode(['success' => false, 'error' => '您说话太快了，请休息 30 秒后再试']); exit;
        }
        exit('发言太快');
    }
    $_SESSION['last_comment_time'] = time();
}
    switch ($action) {
        case 'add':
            $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
            if (!$post_id || !get_post($post_id)) { $error = '文章不存在'; break; }
            $content = isset($_POST['content']) ? trim($_POST['content']) : '';
            if (empty($content)) { $error = '评论不能为空'; break; }

            $db = get_db();
            $user_id = null;
            $author = isset($_POST['author']) ? trim($_POST['author']) : 'Anonymous';
            $email = null;
            $status = 'pending';

            if (is_logged_in()) {
                $user_id = $_SESSION['user_id'];
                $status = 'approved';
                $author = null; // 数据库联表读取真实 username
            }

            try {
                $stmt = $db->prepare('INSERT INTO comments (post_id, user_id, author, email, content, status) VALUES (?, ?, ?, ?, ?, ?)');
                if ($stmt->execute([$post_id, $user_id, $author, $email, $content, $status])) {
                    if ($wants_json) {
                        http_response_code(201); echo json_encode(['success' => true, 'message' => '评论提交成功']); exit;
                    }
                    header('Location: ' . SITE_URL . '/?p=' . $post_id . '#comments'); exit;
                } else { $error = '写入失败'; }
            } catch (Exception $e) { $error = '数据库异常'; }
            break;

        case 'delete':
            if (!is_logged_in() || !is_admin()) { $error = '权限不足'; break; }
            $comment_id = isset($_POST['comment_id']) ? (int)$_POST['comment_id'] : 0;
            if (delete_comment($comment_id)) {
                if ($wants_json) { echo json_encode(['success' => true]); exit; }
                header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? SITE_URL)); exit;
            } else { $error = '删除失败'; }
            break;
    }
}

if (isset($error)) {
    if ($wants_json) {
        http_response_code(400); echo json_encode(['success' => false, 'error' => $error]); exit;
    }
    $redirect_url = $_SERVER['HTTP_REFERER'] ?? SITE_URL;
    $redirect_url .= (strpos($redirect_url, '?') === false ? '?' : '&') . 'error=' . urlencode($error);
    header('Location: ' . $redirect_url); exit;
}
header('Location: ' . SITE_URL); exit;