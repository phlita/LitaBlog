<?php
// --- START OF FILE includes/db_wrapper.php ---
if (!defined('CORE')) {
    die("Direct access not allowed.");
}

class DB {
    private static $pdo_instance = null;
    private $pdo;
    private $stmt;

    public function __construct() {
        if (self::$pdo_instance === null) {
            self::$pdo_instance = get_db(); // 使用现有的 get_db() 获取 PDO 连接
        }
        $this->pdo = self::$pdo_instance;
    }

    /**
     * 准备并执行一个SQL查询
     * @param string $sql SQL 查询语句
     * @param array $params 参数数组
     * @return PDOStatement|false 返回 PDOStatement 对象或失败时返回 false
     */
    private function query($sql, $params = []) {
        try {
            $this->stmt = $this->pdo->prepare($sql);
            $this->stmt->execute($params);
            return $this->stmt;
        } catch (PDOException $e) {
            // 在实际应用中，这里应该记录日志而不是直接 die
            error_log("Database Query Error: " . $e->getMessage() . " SQL: " . $sql . " Params: " . json_encode($params));
            return false;
        }
    }

    /**
     * 获取所有结果行 (关联数组)
     * @param string $sql
     * @param array $params
     * @return array
     */
    public function fetchAll($sql, $params = []) {
        if ($this->query($sql, $params)) {
            return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        return [];
    }

    /**
     * 获取单个结果行 (关联数组)
     * @param string $sql
     * @param array $params
     * @return array|false
     */
    public function fetchOne($sql, $params = []) {
        if ($this->query($sql, $params)) {
            return $this->stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    /**
     * 获取单个结果列的单个值
     * @param string $sql
     * @param array $params
     * @param int $column_number 列号 (0-indexed)
     * @return mixed|false
     */
    public function fetchColumn($sql, $params = [], $column_number = 0) {
        if ($this->query($sql, $params)) {
            return $this->stmt->fetchColumn($column_number);
        }
        return false;
    }

    /**
     * 执行 INSERT, UPDATE, DELETE 语句
     * @param string $sql
     * @param array $params
     * @return int|false 返回受影响的行数或 false
     */
    public function execute($sql, $params = []) {
        if ($this->query($sql, $params)) {
            return $this->stmt->rowCount();
        }
        return false;
    }

    /**
     * 获取最后插入的行的 ID
     * @return string|false
     */
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }

    /**
     * 开始一个事务
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }

    /**
     * 提交一个事务
     */
    public function commit() {
        return $this->pdo->commit();
    }

    /**
     * 回滚一个事务
     */
    public function rollBack() {
        return $this->pdo->rollBack();
    }

    /**
     * 获取底层的 PDOStatement 对象，用于更复杂的操作
     * @return PDOStatement|null
     */
    public function getStatement() {
        return $this->stmt;
    }
}
// --- END OF FILE includes/db_wrapper.php ---