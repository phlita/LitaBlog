<?php
//Configuration Sample for config.php

// Base
define('ABSPATH', __DIR__ . '/' );
define('DB_TYPE', 'sqlite');
define('DB_FILE', ABSPATH . 'content/database/blog.db');

// Site
define('SITE_URL', '');
define('CONTENT_DIR', ABSPATH . 'content');
define('THEME_DIR', CONTENT_DIR . '/themes');
define('PLUGIN_DIR', CONTENT_DIR . '/plugins');
define('UPLOAD_DIR', CONTENT_DIR . '/uploads');

// Security
define('AUTH_KEY', '');
define('SECURE_AUTH_KEY', '');
define('DEBUG', false);
define('CSRF_SALT_FALLBACK', '');