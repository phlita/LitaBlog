<?php
// admin/foot.php
include dirname(__FILE__) . '/views/footer.php';