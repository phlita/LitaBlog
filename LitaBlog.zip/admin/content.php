<?php
// admin/content.php
if (isset($_FILES['image'])) {
header('Content-Type: application/json');
try {
if (!defined('ABSPATH')) {
require_once dirname(__FILE__) . '/../includes/load.php';
}
if (!is_logged_in()) {
throw new Exception('未授权的访问，请先登录。');
}
if (!defined('UPLOAD_DIR') || !defined('SITE_URL')) {
throw new Exception('系统配置常量丢失。');
}

$file = $_FILES['image'];
if ($file['error'] !== UPLOAD_ERR_OK) { 
throw new Exception('文件上传错误: code ' . $file['error']); 
}
if ($file['size'] > 5 * 1024 * 1024) { 
throw new Exception('文件大小超过 5MB 限制。'); 
}
$image_info = getimagesize($file['tmp_name']);
if (!$image_info) { 
throw new Exception('无效的图片文件。'); 
}
$allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($image_info['mime'], $allowed_mime_types)) { 
throw new Exception('无效的图片类型。允许: jpg, png, gif。'); 
}

$year_month = date('Y/m/');
$target_dir = UPLOAD_DIR . '/' . $year_month;

if (!file_exists($target_dir)) {
if (!mkdir($target_dir, 0755, true)) { 
throw new Exception('创建上传目录失败。'); 
}
}
if (!is_writable($target_dir)) { 
throw new Exception('上传目录不可写。'); 
}

// 检测图片物理属性--start image upload
$image_info = getimagesize($file['tmp_name']);
if (!$image_info) { 
    throw new Exception('无效的图片文件。'); 
}

// 安全的 MIME-扩展名 映射白名单
$allowed_extensions = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif'
];

if (!array_key_exists($image_info['mime'], $allowed_extensions)) { 
    throw new Exception('无效的图片类型。允许: jpg, png, gif。'); 
}

// 强制使用服务器转换后的安全后缀，替代客户端声明的后缀
$safe_extension = $allowed_extensions[$image_info['mime']];

$year_month = date('Y/m/');
$target_dir = UPLOAD_DIR . '/' . $year_month;

if (!file_exists($target_dir)) {
    if (!mkdir($target_dir, 0755, true)) { 
        throw new Exception('创建上传目录失败。'); 
    }
}

// 拼接安全文件名--end image upload
$filename = 'img_' . bin2hex(random_bytes(8)) . '.' . $safe_extension;
$target_file = $target_dir . $filename;

if (move_uploaded_file($file['tmp_name'], $target_file)) {
$relative_path = 'content/uploads/' . $year_month . $filename;
$url = rtrim(SITE_URL, '/') . '/' . $relative_path;
echo json_encode(['success' => true, 'url' => $url]);
} else {
throw new Exception('移动上传的文件失败。');
}
} catch (Exception $e) {
error_log("AJAX Image Upload Error: " . $e->getMessage());
echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
exit;
}

require_once 'header.php';

$current_user_id = $_SESSION['user_id'] ?? null;
$is_administrator = is_admin();

if (!$current_user_id) {
header('Location: login.php'); 
exit;
}

function get_all_categories_cached() {
static $categories = null;
if ($categories === null) {
try {
$db = get_db();
$stmt_all_cat = $db->prepare('SELECT id, name FROM categories ORDER BY name');
$stmt_all_cat->execute();
$categories = $stmt_all_cat->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
error_log("Error fetching categories: " . $e->getMessage());
$categories = [];
}
}
return $categories;
}

function get_all_tags_cached() {
static $tags = null;
if ($tags === null) {
try {
$db = get_db();
$stmt_all_tag = $db->prepare('SELECT id, name FROM tags ORDER BY name');
$stmt_all_tag->execute();
$tags = $stmt_all_tag->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
error_log("Error fetching tags: " . $e->getMessage());
$tags = [];
}
}
return $tags;
}

$feedback_message = '';
$feedback_type = '';
$valid_types = ['post', 'page'];
$type = isset($_GET['type']) && in_array($_GET['type'], $valid_types) ? $_GET['type'] : 'post';
if (!$is_administrator && $type === 'page') {
$type = 'post';
}

$content_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
$is_new = empty($content_id);
$action_text = $is_new ? '新增' : '编辑';
$title_prefix = ucfirst($type);

$item_data = [
'id' => $content_id,
'title' => '',
'content' => '',
'excerpt' => '',
'status' => 'draft',
'type' => $type,
'slug' => $content_id ?: '',
'sticky_order' => 0,
];
$all_categories = [];
$all_tags = [];
$selected_category_ids = [];
$selected_tag_ids = [];

if ($is_new && !current_user_can('publish_posts')) {
//$feedback_message = '您没有发布新内容的权限。';$feedback_type = 'error';
header('Location: index.php?type=post&error=adminonly');
exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$is_ajax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') || (isset($_GET['ajax']) && $_GET['ajax'] == '1');
$response = ['success' => false, 'message' => '', 'data' => [], 'redirect' => null];

$item_data['title'] = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
$item_data['content'] = $_POST['content'] ?? '';
$item_data['excerpt'] = filter_input(INPUT_POST, 'excerpt', FILTER_SANITIZE_STRING);
$item_data['status'] = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
if (!in_array($item_data['status'], ['draft', 'publish'])) {
$item_data['status'] = 'draft';
}
if ($is_administrator) {
$item_data['type'] = filter_input(INPUT_POST, 'item_type', FILTER_SANITIZE_STRING);
if (!in_array($item_data['type'], $valid_types)) {
$item_data['type'] = 'post';
}
} else {
$item_data['type'] = 'post';
}

$new_category_ids_input = ($item_data['type'] === 'post' && isset($_POST['categories']) && is_array($_POST['categories'])) ? $_POST['categories'] : [];
$new_tag_ids_input = ($item_data['type'] === 'post' && isset($_POST['tags']) && is_array($_POST['tags'])) ? $_POST['tags'] : [];

$item_data['sticky_order'] = 0;
if ($is_administrator && isset($_POST['sticky_order'])) {
$sticky_order_input = filter_input(INPUT_POST, 'sticky_order', FILTER_SANITIZE_NUMBER_INT);
$item_data['sticky_order'] = max(0, intval($sticky_order_input));
}

if (empty($item_data['title'])) {
$feedback_message = '标题不能为空。';
$feedback_type = 'error';
$selected_category_ids = array_map('intval', $new_category_ids_input);
$selected_tag_ids = array_map('intval', $new_tag_ids_input);
if ($is_ajax) {
$response['message'] = $feedback_message;
echo json_encode($response);
exit;
}
} else {
$db = get_db();
try {
$db->beginTransaction();
do_action('pre_save_post', $item_data, $is_new);
$cleaned_content = litablog_purify_html($item_data['content']);

if ($is_new) {
if (!$is_administrator && $item_data['type'] !== 'post') {
throw new Exception("非管理员用户无权创建 '" . $item_data['type'] . "' 类型的内容。");
}
$temp_slug = 'tempslug-' . bin2hex(random_bytes(8));
$stmt_insert = $db->prepare('
INSERT INTO posts (title, content, excerpt, author, status, type, slug, created, modified, sticky_order)
VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, ?)
');
$executed_insert = $stmt_insert->execute([
$item_data['title'],
$cleaned_content,
$item_data['excerpt'],
$current_user_id,
$item_data['status'],
$item_data['type'],
$temp_slug,
$item_data['sticky_order']
]);

if (!$executed_insert) {
throw new PDOException("Failed to initially insert new {$item_data['type']}.");
}

$content_id = $db->lastInsertId();
$item_data['id'] = $content_id;

$stmt_update_slug = $db->prepare('UPDATE posts SET slug = ? WHERE id = ?');
$executed_update_slug = $stmt_update_slug->execute([(string)$content_id, $content_id]);

if (!$executed_update_slug) {
throw new PDOException("Failed to update slug for new {$item_data['type']} with ID $content_id.");
}
$item_data['slug'] = (string)$content_id;
do_action('save_post', $content_id, $item_data); 
} else {
$stmt_check_owner = $db->prepare('SELECT author, type FROM posts WHERE id = ?');
$stmt_check_owner->execute([$content_id]);
$existing_item_info = $stmt_check_owner->fetch(PDO::FETCH_ASSOC);

if (!$existing_item_info) {
if ($is_ajax) {
$response['message'] = "未找到指定内容";
echo json_encode($response);
exit;
} else {
header('Location: index.php?type=post&error=notfound'); 
exit;
}
}

$existing_author_id = $existing_item_info['author'];
$existing_type = $existing_item_info['type'];

if (!$is_administrator && ($existing_author_id != $current_user_id || $existing_type !== 'post')) {
throw new Exception("您无权编辑此内容。");
}

if (!$is_administrator) {
$item_data['type'] = $existing_type;
}

$stmt_update = $db->prepare('
UPDATE posts
SET title = ?, content = ?, excerpt = ?, status = ?, slug = ?, type = ?, modified = CURRENT_TIMESTAMP, sticky_order = ?
WHERE id = ?
');
$executed_update = $stmt_update->execute([
$item_data['title'],
$cleaned_content,
$item_data['excerpt'],
$item_data['status'],
(string)$content_id,
$item_data['type'],
$item_data['sticky_order'], 
$content_id
]);
if (!$executed_update) {
throw new PDOException("更新 {$item_data['type']} ID 为 $content_id 失败。");
}
$item_data['slug'] = (string)$content_id;
do_action('save_post', $content_id, $item_data); 

if ($item_data['type'] === 'post') {
$stmt_del_cat = $db->prepare('DELETE FROM post_categories WHERE post_id = ?');
$stmt_del_cat->execute([$content_id]);
$stmt_del_tag = $db->prepare('DELETE FROM post_tags WHERE post_id = ?');
$stmt_del_tag->execute([$content_id]);
}
}

if ($item_data['type'] === 'post') {
if (!empty($new_category_ids_input)) {
$cat_placeholders = implode(', ', array_fill(0, count($new_category_ids_input), '(?, ?)'));
$cat_sql = "INSERT INTO post_categories (post_id, category_id) VALUES " . $cat_placeholders;
$cat_values = [];
foreach ($new_category_ids_input as $cat_id) {
$cat_values[] = $content_id;
$cat_values[] = (int)$cat_id;
}
$stmt_add_cat_bulk = $db->prepare($cat_sql);
if (!$stmt_add_cat_bulk->execute($cat_values)) {
throw new PDOException("批量插入关系失败。");
}
}
if (!empty($new_tag_ids_input)) {
$tag_placeholders = implode(', ', array_fill(0, count($new_tag_ids_input), '(?, ?)'));
$tag_sql = "INSERT INTO post_tags (post_id, tag_id) VALUES " . $tag_placeholders;
$tag_values = [];
foreach ($new_tag_ids_input as $tag_id) {
$tag_values[] = $content_id;
$tag_values[] = (int)$tag_id;
}
$stmt_add_tag_bulk = $db->prepare($tag_sql);
if (!$stmt_add_tag_bulk->execute($tag_values)) {
throw new PDOException("批量插入关系失败。");
}
}
}

$db->commit();

if ($is_new) {
$redirect_type = $is_administrator ? $item_data['type'] : 'post';
if ($is_ajax) {
$response['success'] = true;
$response['message'] = "新的" . ucfirst($item_data['type']) . "创建成功";
$response['redirect'] = "index.php?type=" . $redirect_type . "&created=1";
echo json_encode($response);
exit;
} else {
header('Location: index.php?type=' . $redirect_type . '&created=1');
exit;
}
} else {
$feedback_message = ucfirst($item_data['type']) . ' 更新成功。';
$feedback_type = 'success';
if ($is_ajax) {
$response['success'] = true;
$response['message'] = $feedback_message;
echo json_encode($response);
exit;
}
if ($item_data['type'] === 'post') {
$selected_category_ids = array_map('intval', $new_category_ids_input);
$selected_tag_ids = array_map('intval', $new_tag_ids_input);
} else {
$selected_category_ids = [];
$selected_tag_ids = [];
}
}
} catch (Exception $e) {
$db->rollBack();
$error_message = $e->getMessage();
error_log("保存 {$item_data['type']} 错误: " . $error_message);
$feedback_message = ucfirst($item_data['type']) . ' 保存失败: ' . $error_message;
$feedback_type = 'error';
if ($is_ajax) {
$response['success'] = false;
$response['message'] = $feedback_message;
echo json_encode($response);
exit;
}
$selected_category_ids = array_map('intval', $new_category_ids_input);
$selected_tag_ids = array_map('intval', $new_tag_ids_input);
}
}
}

try {
$all_categories = get_all_categories_cached();
$all_tags = get_all_tags_cached();

if (!$is_new) {
$db = get_db();
$stmt_item = $db->prepare('
SELECT p.*,
GROUP_CONCAT(DISTINCT pc.category_id) AS category_ids,
GROUP_CONCAT(DISTINCT pt.tag_id) AS tag_ids
FROM posts p
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN post_tags pt ON p.id = pt.post_id
WHERE p.id = ? AND p.type = ?
GROUP BY p.id
');
$stmt_item->execute([$content_id, $type]);
$loaded_item = $stmt_item->fetch(PDO::FETCH_ASSOC);

if (!$loaded_item) {
header('Location: index.php?type=post&error=notfound');
exit;
}

if (!$is_administrator && ($loaded_item['author'] != $current_user_id || $loaded_item['type'] !== 'post')) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $feedback_type === 'success') {
$item_data = array_merge($item_data, $loaded_item);
$item_data['slug'] = (string)$item_data['id'];
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $feedback_type === 'success') {
$selected_category_ids = [];
if (!empty($loaded_item['category_ids'])) {
$selected_category_ids = array_map('intval', explode(',', trim($loaded_item['category_ids'])));
$selected_category_ids = array_filter($selected_category_ids);
}
$selected_tag_ids = [];
if (!empty($loaded_item['tag_ids'])) {
$selected_tag_ids = array_map('intval', explode(',', trim($loaded_item['tag_ids'])));
$selected_tag_ids = array_filter($selected_tag_ids);
}
}
}
} catch (Exception $e) {
error_log("Error loading content: " . $e->getMessage());
$feedback_message = '加载数据错误: ' . $e->getMessage();
$feedback_type = 'error';
$item_data = ['id' => $content_id, 'title' => '加载错误', 'content' => '', 'excerpt' => '', 'status' => 'draft', 'type' => $type, 'slug' => $content_id ?: 'error'];
}

// 调度加载内容编辑视图
include dirname(__FILE__) . '/views/content.php';
require_once 'foot.php';