<!-- START OF FILE admin/views/tags.php -->
<div class="desktop-header">
    <h1>内容标签</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo e($feedback_message); ?>
    </div>
<?php endif; ?>

<!-- 1. 新增标签卡片 -->
<div class="card" style="margin-bottom: 25px;">
    <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">+ 新建标签</h3>
    <form method="post">
        <input type="hidden" name="action" value="add">
        <div class="form-group">
            <label for="name">标签名称</label>
            <input type="text" id="name" name="name" value="<?php echo e($tag_name_input); ?>" placeholder="例如：生活、科技..." required>
        </div>
        <button type="submit" class="btn btn-primary">添加标签</button>
    </form>
</div>

<!-- 2. 已有标签云卡片 -->
<div class="card">
    <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">🏷️ 已有标签库</h3>
    
    <?php if (empty($tags_data) && $feedback_type !== 'error'): ?>
        <p style="color: #888; font-size: 0.9rem;">还没有添加任何标签。</p>
    <?php elseif (!empty($tags_data)): ?>
        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <?php foreach ($tags_data as $tag): ?>
                <!-- 药丸式标签，内嵌删除按钮 -->
                <div style="display: inline-flex; align-items: center; background: var(--warm-bg); border: 1px solid var(--border-color); border-radius: 20px; padding: 4px 6px 4px 12px; font-size: 0.85rem; color: var(--text-color);">
                    <span><?php echo e($tag['name']); ?></span>
                    <span style="color: #999; margin-left: 4px; font-size: 0.75rem;">(<?php echo $tag['post_count']; ?>)</span>
                    
                    <form method="post" onsubmit="return confirm('确定要删除标签 [<?php echo e($tag['name']); ?>] 吗？');" style="margin: 0; margin-left: 8px;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="tag_id" value="<?php echo $tag['id']; ?>">
                        <button type="submit" title="删除" style="background: rgba(220,53,69,0.1); color: var(--danger-color); border: none; border-radius: 50%; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                            ✕
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<!-- END OF FILE admin/views/tags.php -->