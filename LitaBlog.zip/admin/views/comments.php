<!-- START OF FILE admin/views/comments.php -->
<div class="desktop-header">
    <h1>互动评论</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo e($feedback_message); ?>
    </div>
<?php endif; ?>

<!-- 筛选器卡片 -->
<div class="card" style="margin-bottom: 20px; padding: 15px;">
    <form method="get" style="display:flex; flex-wrap:wrap; gap:10px;">
        <select name="status" onchange="this.form.submit()" style="flex:1; min-width: 100px; padding: 8px;">
            <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>全部状态</option>
            <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>✅ 已通过</option>
            <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>⏳ 待审核</option>
        </select>
        <select name="sort" onchange="this.form.submit()" style="flex:1; min-width: 100px; padding: 8px;">
            <option value="newest" <?php echo $sort_order === 'newest' ? 'selected' : ''; ?>>最新优先</option>
            <option value="oldest" <?php echo $sort_order === 'oldest' ? 'selected' : ''; ?>>最早优先</option>
        </select>
        <input type="hidden" name="page" value="1"> 
    </form>
</div>

<!-- 评论卡片流 -->
<div class="card-list">
    <?php if (empty($comments_data)): ?>
        <div class="card"><p style="text-align:center; color:#888;">没有找到相关评论。</p></div>
    <?php else: ?>
        <?php foreach ($comments_data as $comment): ?>
            <div class="card" style="position: relative; padding: 20px;">
                <!-- 头部：作者与状态 -->
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                    <div>
                        <strong style="font-size: 1.05rem; color: var(--text-color);">
                            👤 <?php echo e($comment['author']); ?>
                            <?php if (!empty($comment['comment_user_username'])): ?>
                                <span style="font-size: 0.8rem; color: #888; font-weight: normal;">(注册用户: <?php echo e($comment['comment_user_username']); ?>)</span>
                            <?php endif; ?>
                        </strong>
                        <div style="font-size: 0.8rem; color: #999; margin-top: 4px;">
                            🕒 <?php echo date('Y-m-d H:i', strtotime($comment['created'])); ?>
                        </div>
                    </div>
                    <!-- 状态标签 -->
                    <?php if ($comment['status'] === 'approved'): ?>
                        <span style="background: #d1fae5; color: #065f46; padding: 3px 8px; border-radius: 20px; font-size: 0.75rem;">已通过</span>
                    <?php else: ?>
                        <span style="background: #fef3c7; color: #92400e; padding: 3px 8px; border-radius: 20px; font-size: 0.75rem;">待审核</span>
                    <?php endif; ?>
                </div>

                <!-- 评论内容体 -->
                <div style="background: var(--warm-bg); padding: 12px; border-radius: var(--radius-sm); margin-bottom: 12px; font-size: 0.95rem; line-height: 1.6; color: var(--text-color);">
                    <?php echo nl2br(e($comment['content'])); ?>
                </div>

                <!-- 来源文章链接 -->
                <div style="font-size: 0.85rem; color: #666; margin-bottom: 15px; border-bottom: 1px dashed var(--border-color); padding-bottom: 10px;">
                    原文：
                    <?php if ($comment['post_title']): ?>
                        <a href="<?php echo Permalink::get_post_link($comment['post_id']); ?>#comment-<?php echo $comment['id']; ?>" target="_blank">
                            <?php echo e($comment['post_title']); ?> 🔗
                        </a>
                    <?php else: ?>
                        (文章已被删除)
                    <?php endif; ?>
                </div>

                <!-- 底部操作按钮 -->
                <div style="display: flex; gap: 10px;">
                    <form method="post" style="flex: 1; margin: 0;">
                        <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                        <?php if ($comment['status'] === 'pending'): ?>
                            <button type="submit" name="action" value="approve" class="btn btn-outline" style="width: 100%; color: var(--primary-green); border-color: var(--primary-green);">✅ 通过</button>
                        <?php else: ?>
                            <button type="submit" name="action" value="unapprove" class="btn btn-outline" style="width: 100%;">⛔ 驳回</button>
                        <?php endif; ?>
                    </form>
                    
                    <form method="post" onsubmit="return confirm('确定彻底删除这条评论吗？');" style="flex: 1; margin: 0;">
                        <input type="hidden" name="comment_id" value="<?php echo $comment['id']; ?>">
                        <button type="submit" name="action" value="delete" class="btn btn-danger" style="width: 100%;">🗑️ 删除</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- 分页 -->
<?php if ($total_pages > 1): ?>
    <div style="display: flex; justify-content: center; gap: 10px; margin-top: 20px;">
        <?php if ($page > 1): ?>
            <a href="?<?php echo http_build_query(array_merge($pagination_params, ['page' => ($page - 1)])); ?>" class="btn btn-outline">上一页</a>
        <?php endif; ?>
        <span class="btn" style="background: #eee;"><?php echo $page; ?> / <?php echo $total_pages; ?></span>
        <?php if ($page < $total_pages): ?>
            <a href="?<?php echo http_build_query(array_merge($pagination_params, ['page' => ($page + 1)])); ?>" class="btn btn-outline">下一页</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<!-- END OF FILE admin/views/comments.php -->