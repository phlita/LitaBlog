<!-- START OF FILE admin/views/header.php -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<title>管理后台 - LitaBlog</title>
<?php wp_print_head_scripts_and_styles(); ?>
<?php echo do_action('admin_head'); ?>
</head>
<body>

<header class="mobile-app-bar">
    <button class="menu-toggle-btn" onclick="toggleSidebar()">☰</button>
    <h1>后台管理</h1>
</header>

<div class="app-layout">
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <aside class="sidebar" id="appSidebar">
        <div class="sidebar-logo">LitaBlog</div>
        <nav class="admin-nav">
<ul>
            <?php
            global $admin_menu, $admin_submenu;
            $core_menus = get_core_admin_menus();
            $plugins_rendered = false; // 标记插件菜单是否已经插队渲染
            
            foreach ($core_menus as $menu_key => $menu_item) {
                
                // 【核心修改：插队机制】
                // 当准备渲染 "账号资料(profile)" 这种底部核心菜单时，先拦截，把插件菜单全部输出！
                if ($menu_key === 'profile' && !$plugins_rendered) {
                    if (!empty($admin_menu)) {
                    
                       
                        
                        foreach ($admin_menu as $menu_item_array) {
                            $menu_title = e($menu_item_array[0]);
                            $capability = $menu_item_array[1];
                            $menu_slug  = e($menu_item_array[2]);
                            $menu_url   = SITE_URL . '/admin/admin.php?page=' . $menu_slug;
                            $icon_url   = !empty($menu_item_array[5]) ? e($menu_item_array[5]) : '';

                            if (!can_user_access_menu($capability)) continue;

                            $active_class = (isset($_GET['page']) && $_GET['page'] == $menu_slug) ? 'active' : '';

                            echo '<li class="'.$active_class.'">';
                            echo '<a href="' . $menu_url . '">';
                            if ($icon_url) {
                                echo '<img src="'.$icon_url.'" alt="" style="width:18px; height:18px; margin-right:8px; vertical-align:middle; border-radius:4px;"> ';
                            }
                            echo $menu_title . '</a>';

                            if (isset($admin_submenu[$menu_slug])) {
                                echo '<ul class="sub-menu" style="padding-left: 20px; font-size: 0.9em; margin: 4px 0;">';
                                foreach ($admin_submenu[$menu_slug] as $submenu_item_array) {
                                    $submenu_title = e($submenu_item_array[0]);
                                    $submenu_capability = $submenu_item_array[1];
                                    $submenu_slug  = e($submenu_item_array[2]);
                                    $submenu_url   = SITE_URL . '/admin/admin.php?page=' . $submenu_slug;

                                    if (!can_user_access_menu($submenu_capability)) continue;

                                    $sub_is_active = (isset($_GET['page']) && $_GET['page'] == $submenu_slug);
                                    $sub_style = $sub_is_active ? 'color: var(--primary-green); font-weight: 600;' : 'color: var(--text-muted);';

                                    echo '<li><a href="' . $submenu_url . '" style="padding: 8px 20px; border-radius: 0; background: transparent; ' . $sub_style . '">- ' . $submenu_title . '</a></li>';
                                }
                                echo '</ul>';
                            }
                            echo '</li>';
                        }
                    }
                    $plugins_rendered = true; // 标记完毕，继续走核心菜单
                }

                // 继续输出原本的核心菜单
                if ($menu_item['type'] === 'separator') { echo '<hr />'; continue; }
                if (!can_user_access_menu($menu_item['capability'])) continue;
                
                $active_class = (basename($_SERVER['PHP_SELF']) == basename(parse_url($menu_item['url'], PHP_URL_PATH)) && !isset($_GET['page'])) ? 'active' : '';
                echo '<li class="'.$active_class.'"><a href="' . e($menu_item['url']) . '">' . e($menu_item['title']) . '</a></li>';
            }
            ?>
            </ul>
        </nav>
		
		
	
		
    </aside>

    <main class="main-content">
<!-- END OF FILE admin/views/header.php -->