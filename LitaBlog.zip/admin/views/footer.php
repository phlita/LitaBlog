<!-- START OF FILE admin/views/footer.php -->
    </main> <!-- end .main-content -->
</div> <!-- end .app-layout -->

<!-- 极简版移动端底部导航 (Bottom Navigation) -->
<nav class="bottom-nav">
    <!-- 将 index.php (无论是否带 type=post) 都作为高亮的“内容”主页 -->
    <a href="<?php echo SITE_URL; ?>/admin/index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' && (!isset($_GET['type']) || $_GET['type'] == 'post' || $_GET['type'] == 'page') ? 'active' : ''; ?>">
        <svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>
        <span>文章</span>
    </a>
  
    <!-- 2. 独立页面 (Page) -->
    <?php if (is_admin()): ?>
    <a href="<?php echo SITE_URL; ?>/admin/index.php?type=page" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' && isset($_GET['type']) && $_GET['type'] == 'page' ? 'active' : ''; ?>">
        <svg viewBox="0 0 24 24"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2h12c1.1 0 2-.9 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/></svg>
        <span>单页</span>
    </a>
    <?php endif; ?>
  
    <a href="<?php echo SITE_URL; ?>/admin/settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
        <svg viewBox="0 0 24 24"><path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.06-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.73,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.06,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.49-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/></svg>
        <span>设置</span>
    </a>
    
    <a href="<?php echo SITE_URL; ?>/" target="_blank">
        <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>
        <span>前台</span>
    </a>
</nav>

<script>
function toggleSidebar() {
    document.getElementById('appSidebar').classList.toggle('active');
    document.querySelector('.sidebar-overlay').classList.toggle('active');
}
</script>

<?php wp_print_footer_scripts(); ?>
<?php echo do_action('admin_footer'); ?>
</body>
</html>
<!-- END OF FILE admin/views/footer.php -->