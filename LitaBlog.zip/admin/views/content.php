<!-- START OF FILE admin/views/content.php -->
<!-- 沉浸式写作专属样式 -->
<style>
    /* 隐藏全局底部导航，为键盘和打字腾出最大空间 */
    .bottom-nav { display: none !important; }
    body { padding-bottom: 20px; } 

    /* 沉浸式标题 */
    .immersive-title-input {
        width: 100%; border: none; background: transparent;
        font-size: 1.8rem; font-weight: bold; padding: 10px 0; margin-bottom: 15px;
        color: var(--text-color); outline: none; border-bottom: 2px solid transparent;
        transition: 0.3s;
    }
    .immersive-title-input:focus { border-bottom-color: var(--primary-green); }
    .immersive-title-input::placeholder { color: #ccc; font-weight: normal; }
</style>

<div class="desktop-header">
    <h1><?php echo e($action_text) . ' ' . e($title_prefix); ?></h1>
    <?php if (!$is_new && $item_data['status'] === 'publish'): ?>
        <a href="<?php echo Permalink::get_post_link($item_data['id']); ?>" target="_blank" class="btn btn-outline">👀 预览</a>
    <?php endif; ?>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo $feedback_message; ?>
    </div>
<?php endif; ?>

<form method="post" id="post-editor-form">
    <!-- 沉浸式标题输入 -->
    <input type="text" id="title" name="title" class="immersive-title-input" value="<?php echo e($item_data['title']); ?>" placeholder="输入出色的标题..." required autocomplete="off" />

    <!-- Quill 容器 (样式已由 admin.css 接管，保证绝对可用) -->
    <div class="editor-wrapper">
        <div id="editor-container"></div>
        <input type="hidden" name="content" id="hiddenContent" value="<?php echo htmlspecialchars($item_data['content'], ENT_QUOTES, 'UTF-8'); ?>" />
    </div>

    <!-- 参数设置卡片 -->
    <div class="card">
        <div class="form-group">
            <label>发布状态</label>
            <div class="pill-group">
                <label class="pill-label">
                    <input type="radio" name="status" value="publish" <?php echo $item_data['status'] === 'publish' ? 'checked' : ''; ?> required>
                    <span class="pill-text">🚀 立即发布</span>
                </label>
                <label class="pill-label">
                    <input type="radio" name="status" value="draft" <?php echo $item_data['status'] === 'draft' ? 'checked' : ''; ?> required>
                    <span class="pill-text">💾 存为草稿</span>
                </label>
            </div>
        </div>

        <?php if ($is_administrator): ?>
        <div class="form-group">
            <label>内容类型</label>
            <div class="pill-group">
                <label class="pill-label">
                    <input type="radio" name="item_type" value="post" <?php echo $item_data['type'] === 'post' ? 'checked' : ''; ?> required>
                    <span class="pill-text">普通文章</span>
                </label>
                <label class="pill-label">
                    <input type="radio" name="item_type" value="page" <?php echo $item_data['type'] === 'page' ? 'checked' : ''; ?> required>
                    <span class="pill-text">独立页面</span>
                </label>
            </div>
        </div>
        <div class="form-group">
            <label for="sticky_order">置顶权重 (数字越小越靠前，0为不置顶)</label>
            <input type="number" id="sticky_order" name="sticky_order" value="<?php echo e($item_data['sticky_order'] ?? 0); ?>" min="0" />
        </div>
        <?php endif; ?>

        <div class="form-group" style="margin-bottom: 0;">
            <label for="excerpt">摘要说明</label>
            <textarea id="excerpt" name="excerpt" rows="2" placeholder="写一段简短的引言..."><?php echo e($item_data['excerpt']); ?></textarea>
        </div>
    </div>

    <?php if ($item_data['type'] === 'post'): ?>
    <div class="card">
        <?php if (!empty($all_categories)): ?>
        <div class="form-group">
            <label>分类归属</label>
            <div class="pill-group">
                <?php foreach ($all_categories as $category): ?>
                <label class="pill-label">
                    <input type="checkbox" name="categories[]" value="<?php echo $category['id']; ?>" <?php echo in_array($category['id'], $selected_category_ids) ? 'checked' : ''; ?>>
                    <span class="pill-text"><?php echo e($category['name']); ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($all_tags)): ?>
        <div class="form-group" style="margin-bottom: 0;">
            <label>添加标签</label>
            <div class="pill-group">
                <?php foreach ($all_tags as $tag): ?>
                <label class="pill-label">
                    <input type="checkbox" name="tags[]" value="<?php echo $tag['id']; ?>" <?php echo in_array($tag['id'], $selected_tag_ids) ? 'checked' : ''; ?>>
                    <span class="pill-text"># <?php echo e($tag['name']); ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php do_action('add_meta_boxes', $item_data['type'], $item_data); ?>
    <?php do_action('do_meta_boxes', $item_data['type'], 'normal', $item_data); ?>

    <!-- 悬浮的保存按钮，保证打长文时随时可保存 -->
    <div style="position: sticky; bottom: 15px; z-index: 100;">
        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px; font-size: 1.1rem; box-shadow: 0 4px 12px var(--shadow-color);">
            <?php echo $is_new ? '✨ 立即创建' : '💾 保存更新'; ?>
        </button>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const hiddenContent = document.getElementById('hiddenContent');
    const form = document.querySelector('form');

    const quill = new Quill('#editor-container', {
        theme: 'snow',
        modules: {
            toolbar: [
                [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                ['bold', 'italic', 'underline', 'blockquote', 'code-block'],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }, { 'indent': '-1'}, { 'indent': '+1' }, { 'align': [] }],
                ['link', 'image', 'video'],
                ['clean']
            ]
        }
    });

    window.quillInstance = quill;
    quill.root.innerHTML = hiddenContent.value;

    form.addEventListener('submit', () => {
        hiddenContent.value = quill.root.innerHTML;
    });

    quill.getModule('toolbar').addHandler('image', () => { selectLocalImage(); });
    quill.clipboard.addMatcher('IMG', (node, delta) => {
        if (node.src.startsWith('data:')) {
            handlePastedImage(node.src);
            return new Quill.import('delta');
        }
        return delta;
    });

    function selectLocalImage() {
        const input = document.createElement('input');
        input.setAttribute('type', 'file'); input.setAttribute('accept', 'image/*'); input.click();
        input.onchange = async () => {
            const file = input.files[0];
            if (file) {
                const range = quill.getSelection(true);
                quill.insertEmbed(range.index, 'text', 'uploading', 'user');
                quill.setSelection(range.index + 1, 0);
                try {
                    const imageUrl = await uploadFile(file);
                    quill.deleteText(range.index, 9);
                    quill.insertEmbed(range.index, 'image', imageUrl);
                } catch (error) {
                    quill.deleteText(range.index, 1);
                    alert(`图片上传失败: ${error.message}`);
                }
            }
        };
    }

    async function handlePastedImage(dataUrl) {
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        const file = new File([blob], "pasted_image.png", { type: blob.type });
        const range = quill.getSelection(true);
        quill.insertEmbed(range.index, 'text', 'uploading', 'user');
        quill.setSelection(range.index + 1, 0);
        try {
            const imageUrl = await uploadFile(file);
            quill.deleteText(range.index, 1);
            quill.insertEmbed(range.index, 'image', imageUrl);
        } catch (error) {
            quill.deleteText(range.index, 1);
            alert(`粘贴图片上传失败: ${error.message}`);
        }
    }

    async function uploadFile(file) {
        const formData = new FormData(); formData.append('image', file);
        const response = await fetch(window.location.href + '?ajax=1', { method: 'POST', body: formData });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        if (data.success && data.url) return data.url;
        throw new Error(data.error || '上传失败');
    }
});
</script>
<!-- END OF FILE admin/views/content.php -->