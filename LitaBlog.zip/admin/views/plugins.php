<!-- START OF FILE admin/views/plugins.php -->
<div class="desktop-header">
<h1>插件管理</h1>
</div>

<?php 
// 统一显示由于 POST 重定向携带过来的系统状态提示 (Flash Message)
display_flash_message(); 
?>

<form method="post" style="margin-bottom: 20px;">
<input type="hidden" name="force_plugin_refresh" value="1">
<button type="submit" class="btn btn-outline" style="width:100%; background: #fff;">🔄 重新扫描插件目录</button>
</form>

<div class="card-list">
<?php if (empty($plugins_display_data)): ?>
<div class="card"><p style="text-align:center; color:#888;">未安装任何插件</p></div>
<?php else: ?>
<?php foreach ($plugins_display_data as $slug => $plugin): ?>
<?php
$is_active = (isset($plugin['status']) && $plugin['status'] === 'active');
$plugin_exists = $plugin['plugin_exists'] ?? true;
?>
<!-- 单个插件卡片 -->
<div class="card" style="border-left: 4px solid <?php echo $is_active ? 'var(--primary-green)' : 'var(--border-color)'; ?>;">
<div style="display:flex; justify-content: space-between; align-items: flex-start;">
<div>
<h3 class="card-title">
<?php if (!empty($plugin['plugin_uri'])): ?>
<a href="<?php echo e($plugin['plugin_uri']); ?>" target="_blank" title="访问插件主页">
<?php echo e($plugin['name'] ?? $slug); ?>
</a>
<?php else: ?>
<?php echo e($plugin['name'] ?? $slug); ?>
<?php endif; ?>
</h3>
<span class="plugin-author" style="font-size:0.8rem; color:#888;">
v<?php echo e($plugin['version'] ?? '未知'); ?> | 作者：
<?php if (!empty($plugin['author_url']) && !empty($plugin['author'])): ?>
<a href="<?php echo e($plugin['author_url']); ?>" target="_blank" title="访问作者主页">
<?php echo e($plugin['author']); ?>
</a>
<?php else: ?>
<?php echo e($plugin['author'] ?? '未知作者'); ?>
<?php endif; ?>
</span>
</div>
<?php if ($is_active): ?>
<span style="background: rgba(74, 159, 107, 0.1); color: var(--primary-green); padding: 3px 8px; border-radius: 20px; font-size: 0.75rem;">已启用</span>
<?php else: ?>
<span style="background: #f1f3f5; color: #666; padding: 3px 8px; border-radius: 20px; font-size: 0.75rem;">未启用</span>
<?php endif; ?>
</div>

<p style="font-size: 0.9rem; color: #555; margin: 15px 0; line-height: 1.5;">
<?php echo e($plugin['description'] ?? '没有提供描述。'); ?>
</p>

<?php if (!$plugin_exists): ?>
<p style="color:var(--danger-color); font-size:0.85rem; margin-bottom:10px;">⚠️ 插件物理文件已丢失！</p>
<?php endif; ?>

<div style="display: flex; gap: 10px; border-top: 1px solid var(--border-color); padding-top: 15px;">
<?php if ($plugin_exists): ?>
<form method="post" style="flex: 1;">
<input type="hidden" name="plugin" value="<?php echo e($slug); ?>">
<input type="hidden" name="action" value="<?php echo $is_active ? 'deactivate' : 'activate'; ?>">
<button type="submit" class="btn <?php echo $is_active ? 'btn-outline' : 'btn-primary'; ?>" style="width: 100%;">
<?php echo $is_active ? '停用' : '启用'; ?>
</button>
</form>

<?php if (!$is_active): ?>
<form method="post" onsubmit="return confirm('彻底删除此插件？');" style="flex: 1;">
<?php echo csrf_token_field('delete_plugin_' . $slug); ?>
<input type="hidden" name="action" value="delete_plugin">
<input type="hidden" name="plugin_slug" value="<?php echo e($slug); ?>">
<button type="submit" class="btn btn-danger" style="width: 100%;">删除</button>
</form>
<?php endif; ?>
<?php endif; ?>
</div>
</div>
<?php endforeach; ?>
<?php endif; ?>
</div>
<!-- END OF FILE admin/views/plugins.php -->