<!-- START OF FILE admin/views/menu.php -->
<div class="desktop-header">
    <h1>导航菜单</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo e($feedback_message); ?>
    </div>
<?php endif; ?>

<div class="card">
    <p style="color: #666; font-size: 0.9rem; margin-bottom: 15px;">在下方添加、修改或删除菜单项。您可以按住左侧的 ☰ 图标拖拽以重新排序。</p>

    <form method="post" id="menu-form">
        <div id="menu-items-container">
            <?php if (empty($current_menu_items)): ?>
                <div id="no-menu-items-placeholder" style="text-align:center; padding: 30px; background: var(--warm-bg); border-radius: var(--radius-sm); color: #888; margin-bottom: 15px;">
                    菜单空空如也，点击下方按钮添加。
                </div>
            <?php endif; ?>
            
            <?php foreach ($current_menu_items as $item): ?>
                <!-- 单个菜单项块 -->
                <div class="menu-item" draggable="true" style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; padding: 15px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--warm-bg); transition: box-shadow 0.2s;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span class="drag-handle" style="cursor: grab; font-size: 1.2rem; color: #999; padding: 0 5px;">☰</span>
                        <input type="text" name="menu_name[]" value="<?php echo e($item['name']); ?>" placeholder="菜单名称 (如：首页)" required style="flex: 1;" />
						        <button type="button" class="btn btn-outline move-up" style="padding: 6px 10px; font-size: 0.8rem;">↑</button>
        <button type="button" class="btn btn-outline move-down" style="padding: 6px 10px; font-size: 0.8rem;">↓</button>
                    </div>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="visibility: hidden; padding: 0 5px;">☰</span> <!-- 占位对齐 -->
                        <input type="text" name="menu_url[]" value="<?php echo e($item['url']); ?>" placeholder="URL链接 (如：/ 或 https://...)" required style="flex: 1;" />
                        <button type="button" class="btn btn-danger remove-item" style="padding: 10px 12px;">✕</button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="button" id="add-item" class="btn btn-outline" style="flex: 1; border-style: dashed;">+ 添加新项</button>
            <button type="submit" class="btn btn-primary" style="flex: 1;">💾 保存菜单</button>
        </div>
    </form>
</div>

<!-- 拖拽与动态添加逻辑 (保留原有JS结构，微调了注入的HTML样式) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('menu-items-container');
    const addBtn = document.getElementById('add-item');
    const placeholder = document.getElementById('no-menu-items-placeholder');

    addBtn.onclick = function() {
        const div = document.createElement('div');
        div.className = 'menu-item';
        div.setAttribute('draggable', 'true');
        div.style.cssText = "display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; padding: 15px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); background: var(--warm-bg);";
        div.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span class="drag-handle" style="cursor: grab; font-size: 1.2rem; color: #999; padding: 0 5px;">☰</span>
                <input type="text" name="menu_name[]" placeholder="菜单名称" required style="flex: 1;" />
				 <button type="button" class="btn btn-outline move-up" style="padding: 6px 10px; font-size: 0.8rem;">↑</button>
        <button type="button" class="btn btn-outline move-down" style="padding: 6px 10px; font-size: 0.8rem;">↓</button>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="visibility: hidden; padding: 0 5px;">☰</span>
                <input type="text" name="menu_url[]" placeholder="URL链接" required style="flex: 1;" />
                <button type="button" class="btn btn-danger remove-item" style="padding: 10px 12px;">✕</button>
            </div>
        `;
        container.appendChild(div);
        if (placeholder) placeholder.style.display = 'none';
    };

    container.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('remove-item')) {
            e.target.closest('.menu-item').remove();
            if (container.querySelectorAll('.menu-item').length === 0 && placeholder) {
                placeholder.style.display = 'block';
            }
        }
		
		
 // 新增：处理上移
    if (e.target && e.target.classList.contains('move-up')) {
        const item = e.target.closest('.menu-item');
        if (item.previousElementSibling && item.previousElementSibling.classList.contains('menu-item')) {
            container.insertBefore(item, item.previousElementSibling);
        }
    }
    // 新增：处理下移
    if (e.target && e.target.classList.contains('move-down')) {
        const item = e.target.closest('.menu-item');
        if (item.nextElementSibling && item.nextElementSibling.classList.contains('menu-item')) {
            container.insertBefore(item.nextElementSibling, item);
        }
    }		
		
		
    });

    let draggedItem = null;
    container.addEventListener('dragstart', e => {
        const item = e.target.closest('.menu-item');
        if (item) { draggedItem = item; e.dataTransfer.effectAllowed = 'move'; setTimeout(() => item.style.opacity = '0.4', 0); }
    });
    container.addEventListener('dragend', e => {
        if (draggedItem) { draggedItem.style.opacity = '1'; draggedItem = null; }
        container.querySelectorAll('.menu-item').forEach(el => el.style.borderTop = '');
    });
    container.addEventListener('dragover', e => {
        e.preventDefault();
        const target = e.target.closest('.menu-item');
        if (target && draggedItem && target !== draggedItem) target.style.borderTop = '2px solid var(--primary-green)';
    });
    container.addEventListener('dragleave', e => {
        const target = e.target.closest('.menu-item');
        if (target) target.style.borderTop = '';
    });
    container.addEventListener('drop', e => {
        e.preventDefault();
        const target = e.target.closest('.menu-item');
        if (draggedItem && target && target !== draggedItem) {
            target.style.borderTop = '';
            const rect = target.getBoundingClientRect();
            if (e.clientY < rect.top + rect.height / 2) container.insertBefore(draggedItem, target);
            else container.insertBefore(draggedItem, target.nextSibling);
        }
    });
});
</script>
<!-- END OF FILE admin/views/menu.php -->