<!-- START OF FILE admin/views/categories.php -->
<div class="desktop-header">
    <h1>文章分类</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo e($feedback_message); ?>
    </div>
<?php endif; ?>

<!-- 1. 新增分类卡片 -->
<div class="card" style="margin-bottom: 25px;">
    <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">+ 新建分类</h3>
    <form method="post">
        <input type="hidden" name="action" value="add">
        <div class="form-group">
            <label for="name">分类名称</label>
            <input type="text" id="name" name="name" value="<?php echo e($category_name_input); ?>" placeholder="例如：随笔、技术..." required>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%;">添加分类</button>
    </form>
</div>

<!-- 2. 已有分类卡片库 -->
<div class="card">
    <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">📁 已有分类库</h3>
    
    <?php if (empty($categories_data) && $feedback_type !== 'error'): ?>
        <p style="color: #888; font-size: 0.9rem; text-align: center; padding: 20px 0;">还没有添加任何分类。</p>
    <?php elseif (!empty($categories_data)): ?>
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <?php foreach ($categories_data as $category): ?>
                <!-- 单个分类长条卡片 -->
                <div style="display: flex; justify-content: space-between; align-items: center; background: var(--warm-bg); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 12px 15px;">
                    <div>
                        <strong style="color: var(--text-color); font-size: 1rem;"><?php echo e($category['name']); ?></strong>
                        <div style="font-size: 0.8rem; color: #888; margin-top: 4px;">
                            路径: /<?php echo e($category['slug']); ?> · 包含 <?php echo $category['post_count']; ?> 篇文章
                        </div>
                    </div>
                    
                    <form method="post" onsubmit="return confirm('警告：删除分类 [<?php echo e($category['name']); ?>] 将会把它从所有相关文章中移除！确定继续吗？');" style="margin: 0;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="category_id" value="<?php echo $category['id']; ?>">
                        <button type="submit" class="btn btn-danger" style="padding: 6px 12px; font-size: 0.85rem;">删除</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<!-- END OF FILE admin/views/categories.php -->