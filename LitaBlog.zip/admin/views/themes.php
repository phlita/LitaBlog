<!-- START OF FILE admin/views/themes.php -->
<div class="desktop-header">
    <h1>外观主题</h1>
</div>

<!-- 移动端隐藏，PC端可以留着这个头部 -->
<form method="post" style="margin-bottom: 20px;">
    <input type="hidden" name="force_theme_refresh" value="1">
    <button type="submit" class="btn btn-outline" style="width: 100%; background: #fff;">🔄 重新扫描主题目录</button>
</form>

<?php if (isset($feedback_message) && !empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo $feedback_message; ?>
    </div>
<?php endif; ?>

<div class="card-list">
    <?php if (empty($themes_data)): ?>
        <div class="card"><p style="text-align:center; color:#888;">未找到任何主题，请检查 themes 目录。</p></div>
    <?php else: ?>
        <?php foreach ($themes_data as $dir => $theme): ?>
            <?php
            $is_current = ($dir === $current_theme_slug);
            $is_valid = $theme['is_valid'] ?? false;
            ?>
            <div class="card" style="padding: 0; overflow: hidden; display: flex; flex-direction: column; border: 2px solid <?php echo $is_current ? 'var(--primary-green)' : 'transparent'; ?>;">
                
                <!-- 主题截图区 -->
                <div style="height: 180px; background: #e5e7eb; display: flex; justify-content: center; align-items: center; position: relative;">
                    <?php if ($is_current): ?>
                        <div style="position: absolute; top: 10px; right: 10px; background: var(--primary-green); color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; z-index: 10;">当前启用</div>
                    <?php endif; ?>

                    <?php if (!empty($theme['screenshot_url'])): ?>
                        <img src="<?php echo e($theme['screenshot_url']); ?>" alt="截图" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php else: ?>
                        <span style="color: #9ca3af; font-size: 0.9rem;">无截图</span>
                    <?php endif; ?>
                </div>

                <!-- 主题信息区 -->
                <div style="padding: 15px; flex: 1; display: flex; flex-direction: column;">
                    <h3 style="font-size: 1.1rem; color: var(--text-color); margin-bottom: 5px;">
                        <?php echo e($theme['name'] ?? $dir); ?> 
                        <span style="font-size: 0.8rem; color: #888; font-weight: normal;">v<?php echo e($theme['version'] ?? '1.0'); ?></span>
                    </h3>
                    <p style="font-size: 0.85rem; color: #666; margin-bottom: 15px; flex: 1;">
                        <?php echo e($theme['description'] ?? '没有提供主题描述。'); ?>
                    </p>

                    <?php if (!$is_valid): ?>
                        <div class="alert alert-danger" style="padding: 8px; font-size: 0.8rem; margin-bottom: 10px;">
                            <strong>无效主题:</strong> 缺少 <?php echo e(implode(', ', $theme['missing_files'] ?? [])); ?>

                        </div>
                    <?php endif; ?>

                    <!-- 操作区 -->
                    <div style="display: flex; gap: 10px; margin-top: auto; border-top: 1px solid var(--border-color); padding-top: 15px;">
                        <?php if ($is_current): ?>
                            <a href="<?php echo e(SITE_URL); ?>/" class="btn btn-outline" target="_blank" style="width: 100%;">👀 去前台看看</a>
                        <?php elseif ($is_valid): ?>
                            <form method="post" style="width: 100%; margin: 0;">
                                <input type="hidden" name="theme_dir" value="<?php echo e($dir); ?>">
                                <button type="submit" name="activate_theme" class="btn btn-primary" style="width: 100%;">✅ 启用此主题</button>
                            </form>
                        <?php else: ?>
                            <button class="btn btn-outline" disabled style="width: 100%; opacity: 0.5;">不可用</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<!-- END OF FILE admin/views/themes.php -->