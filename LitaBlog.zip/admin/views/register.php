<!-- START OF FILE admin/views/register.php -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<title>注册账号 · <?php echo get_option('site_title', 'LitaBlog'); ?></title>
<link rel="stylesheet" href="admin.css" />
<style>
    /* 独立认证页面专属样式：屏幕居中 */
    body {
        padding: 20px;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: var(--warm-bg);
    }
    .auth-wrapper {
        width: 100%;
        max-width: 400px;
    }
    .auth-card {
        background: var(--warm-card-bg);
        border-radius: var(--radius-md);
        padding: 30px;
        box-shadow: 0 10px 25px var(--shadow-color);
    }
    .auth-header { text-align: center; margin-bottom: 25px; }
    .auth-header h1 { color: var(--primary-green); font-size: 1.8rem; font-weight: 700; margin-bottom: 5px; }
    .auth-header p { color: #888; font-size: 0.9rem; }
    .auth-links { text-align: center; margin-top: 20px; font-size: 0.9rem; color: #888; }
</style>
</head>
<body>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-header">
            <h1>LitaBlog</h1>
            <p>创建一个新账户</p>
        </div>

        <?php if (!empty($feedback_message)): ?>
            <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
                <?php echo $feedback_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($registration_enabled): ?>
            <form method="post">
                <div class="form-group">
                    <label for="username">设置账号名</label>
                    <input type="text" id="username" name="username" value="<?php echo e($username_input); ?>" placeholder="用于登录的唯一名称" required autofocus>
                </div>
                <div class="form-group">
                    <label for="password">设置密码</label>
                    <input type="password" id="password" name="password" placeholder="建议使用复杂密码" required>
                </div>
                <div class="form-group">
                    <label for="email">联系邮箱</label>
                    <input type="email" id="email" name="email" value="<?php echo e($email_input); ?>" placeholder="用于接收通知和找回密码" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 1.1rem; border-radius: var(--radius-sm); margin-top: 10px;">
                    立即注册
                </button>
            </form>
        <?php else: ?>
            <div style="text-align: center; padding: 20px 0;">
                <div style="font-size: 3rem; margin-bottom: 10px;">🔒</div>
                <h3 style="color: var(--text-color); margin-bottom: 10px;">抱歉，注册已关闭</h3>
                <p style="color: #888; font-size: 0.9rem;">管理员当前未开放公众注册功能。</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="auth-links">
        <a href="login.php">已有账号？去登录</a> &nbsp;·&nbsp; 
        <a href="../index.php">返回首页</a>
    </div>
</div>

</body>
</html>
<!-- END OF FILE admin/views/register.php -->