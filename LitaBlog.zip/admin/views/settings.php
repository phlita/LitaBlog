<!-- START OF FILE admin/views/settings.php -->
<div class="desktop-header">
    <h1>系统设置</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>"><?php echo $feedback_message; ?></div>
<?php endif; ?>

<form method="post"><?php csrf_token_field('admin_settings'); ?>
    <div class="card">
        <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">站点标识</h3>
        <div class="form-group">
            <label>站点标题</label>
            <input type="text" name="site_title" value="<?php echo e($current_settings['site_title']); ?>" required>
        </div>
        <div class="form-group">
            <label>站点描述</label>
            <textarea name="site_description" rows="2"><?php echo e($current_settings['site_description']); ?></textarea>
        </div>
        <div class="form-group" style="margin-bottom:0;">
            <label>每页显示文章数</label>
            <input type="number" name="posts_per_page" value="<?php echo e($current_settings['posts_per_page']); ?>" required>
        </div>
    </div>

    <!-- 交互功能开关：原生 App 体验 -->
    <div class="card">
        <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">讨论与注册</h3>
        <div class="switch-wrapper">
            <div>
                <strong style="display:block; color:var(--text-color);">开放评论功能</strong>
                <span style="font-size:0.85rem; color:#888;">允许访客在文章底部留言</span>
            </div>
            <label class="switch">
                <input type="checkbox" name="enable_comments" value="1" <?php echo ($current_settings['enable_comments'] === '1') ? 'checked' : ''; ?>>
                <span class="slider"></span>
            </label>
        </div>
        <hr style="border:0; border-top:1px solid var(--border-color); margin:10px 0;">
        <div class="switch-wrapper">
            <div>
                <strong style="display:block; color:var(--text-color);">开放新用户注册</strong>
                <span style="font-size:0.85rem; color:#888;">允许公众注册成为本站用户</span>
            </div>
            <label class="switch">
                <input type="checkbox" name="enable_registration" value="1" <?php echo ($current_settings['enable_registration'] === '1') ? 'checked' : ''; ?>>
                <span class="slider"></span>
            </label>
        </div>
    </div>

    <div class="card">
        <h3 style="margin-bottom:15px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">高级选项</h3>
        <div class="form-group">
            <label>固定链接模式</label>
            <select name="permalink_type">
                <option value="default" <?php echo ($current_settings['permalink_type'] === 'default') ? 'selected' : ''; ?>>默认模式 (?p=123)</option>
                <option value="numeric" <?php echo ($current_settings['permalink_type'] === 'numeric') ? 'selected' : ''; ?>>数字后缀 (123.html)</option>
                <option value="post" <?php echo ($current_settings['permalink_type'] === 'post') ? 'selected' : ''; ?>>文章名后缀 (post/123)</option>
            </select>
        </div>
        <div class="form-group" style="margin-bottom:0;">
            <label>系统时区</label>
            <select name="site_timezone">
                <?php
                $available_timezones = DateTimeZone::listIdentifiers(DateTimeZone::ALL);
                foreach ($available_timezones as $tz) {
                    $selected = ($tz === $current_settings['site_timezone']) ? 'selected' : '';
                    echo '<option value="'.e($tz).'" '.$selected.'>'.e($tz).'</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <?php do_action('admin_settings_sections'); ?>
    <?php do_settings_sections('general_settings'); ?>

    <button type="submit" class="btn btn-primary" style="width:100%; padding:14px; font-size:1.1rem; box-shadow: 0 4px 12px var(--shadow-color);">保存更改</button>
</form>
<!-- END OF FILE admin/views/settings.php -->