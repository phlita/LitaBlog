<!-- START OF FILE admin/views/dashboard.php -->
<div class="desktop-header">
    <h1>管理<?php echo e($title_prefix); ?></h1>
    <a href="content.php?type=<?php echo $type; ?>" class="btn btn-primary">+ 撰写新篇</a>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type; ?>"><?php echo e($feedback_message); ?></div>
<?php endif; ?>

<!-- 精简版筛选器 -->
<div class="card" style="margin-bottom: 20px; padding: 15px;">
    <form method="get" style="display:flex; flex-wrap:wrap; gap:10px;">
        <input type="hidden" name="type" value="<?php echo e($type); ?>">
        
        <select name="status" onchange="this.form.submit()" style="flex:1; min-width: 100px; padding: 8px;">
            <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>全部状态</option>
            <option value="publish" <?php echo $status_filter === 'publish' ? 'selected' : ''; ?>>✅ 已发布</option>
            <option value="draft" <?php echo $status_filter === 'draft' ? 'selected' : ''; ?>>📝 草稿箱</option>
        </select>
        
        <select name="sort" onchange="this.form.submit()" style="flex:1; min-width: 100px; padding: 8px;">
            <option value="newest" <?php echo $sort_order === 'newest' ? 'selected' : ''; ?>>⏳ 最新优先</option>
            <option value="oldest" <?php echo $sort_order === 'oldest' ? 'selected' : ''; ?>>⌛ 最早优先</option>
        </select>
    </form>
</div>

<div class="card-list">
    <?php if (!empty($items_data)): ?>
        <?php foreach ($items_data as $item): ?>
            <?php $can_edit = $is_administrator || ($item['author'] == $current_user_id && $item['type'] === 'post'); ?>
            
            <div class="card" style="position: relative;">
                <div class="card-header" style="margin-bottom: 8px;">
                    <?php if ($item['status'] === 'publish'): ?>
                        <span class="badge" style="background: #d1fae5; color: #065f46;">已发布</span>
                    <?php else: ?>
                        <span class="badge" style="background: #fef3c7; color: #92400e;">草稿</span>
                    <?php endif; ?>
                    <span style="font-size: 0.8rem; color: #999;"><?php echo date('Y-m-d H:i', strtotime($item['created'])); ?></span>
                </div>
                
                <h3 class="card-title" style="margin-bottom: 10px;">
                    <a href="content.php?id=<?php echo $item['id']; ?>&type=<?php echo e($item['type']); ?>" style="color: var(--text-color);">
                        <?php echo e($item['title']); ?>
                    </a>
                </h3>
                
                <div class="card-meta" style="border-bottom: 1px dashed var(--border-color); padding-bottom: 12px;">
                    <span>👤 <?php echo e($item['author_name'] ?? '未知'); ?></span>
                    <?php if ($item['status'] === 'publish'): ?>
                        <span style="margin-left: 15px;">🔗 <a href="<?php echo Permalink::get_post_link($item['id']); ?>" target="_blank" style="color:var(--primary-green)">前台查看</a></span>
                    <?php endif; ?>
                </div>

                
				<div class="card-actions" style="margin-top: 12px; padding-top: 0; border: none; display: flex; gap: 10px; align-items: center;">
                    <?php if ($can_edit): ?>
                        <a href="content.php?id=<?php echo $item['id']; ?>&type=<?php echo e($item['type']); ?>" class="btn btn-outline" style="padding: 6px 14px; font-size: 0.85rem;">✏️ 编辑</a>
                        <form method="post" onsubmit="return confirm('警告：确定要彻底删除吗？此操作无法撤销。');" style="margin:0;">
                            <input type="hidden" name="content_id" value="<?php echo $item['id']; ?>">
                            <input type="hidden" name="delete" value="1">
                            <button type="submit" class="btn btn-danger" style="padding: 6px 14px; font-size: 0.85rem;">🗑️ 删除</button>
                        </form>
                    <?php else: ?>
                        <span style="font-size: 0.8rem; color:#ccc;">无修改权限</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="card"><p style="text-align:center; color:#888; padding: 20px 0;">空空如也，开始你的创作吧。</p></div>
    <?php endif; ?>
</div>

<!-- 移动端悬浮发文按钮 FAB -->
<a href="content.php?type=<?php echo $type; ?>" class="fab-btn" title="撰写新篇">
    <svg viewBox="0 0 24 24" width="28" height="28" fill="#fff"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
</a>

<!-- 简化版分页 -->
<?php if ($total_pages > 1): ?>
    <div style="display: flex; justify-content: center; gap: 10px; margin-top: 25px;">
        <?php if ($page > 1): ?>
            <a href="?<?php echo http_build_query(array_merge($pagination_params, ['page' => ($page - 1)])); ?>" class="btn btn-outline">上一页</a>
        <?php endif; ?>
        <span class="btn" style="background: var(--warm-card-bg); border: 1px solid var(--border-color); color: #888; pointer-events: none;">
            <?php echo $page; ?> / <?php echo $total_pages; ?>
        </span>
        <?php if ($page < $total_pages): ?>
            <a href="?<?php echo http_build_query(array_merge($pagination_params, ['page' => ($page + 1)])); ?>" class="btn btn-outline">下一页</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
<!-- END OF FILE admin/views/dashboard.php -->