<!-- START OF FILE admin/views/install.php -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
<title>安装向导 · LitaBlog</title>
<link rel="stylesheet" href="admin.css" />
<style>
    /* 独立安装页面专属样式 */
    body {
        padding: 20px;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: var(--warm-bg);
    }
    .install-wrapper {
        width: 100%;
        max-width: 450px;
    }
    .install-card {
        background: var(--warm-card-bg);
        border-radius: var(--radius-md);
        padding: 35px 30px;
        box-shadow: 0 10px 30px var(--shadow-color);
    }
    .install-header { text-align: center; margin-bottom: 25px; }
    .install-header h1 { color: var(--primary-green); font-size: 2rem; font-weight: 700; margin-bottom: 8px; letter-spacing: -0.5px;}
    .install-header p { color: #888; font-size: 0.95rem; }
    
    .env-status-box {
        background: rgba(74, 159, 107, 0.05);
        border: 1px dashed var(--secondary-green);
        border-radius: var(--radius-sm);
        padding: 12px;
        margin-bottom: 25px;
        font-size: 0.85rem;
        color: #555;
        text-align: center;
        line-height: 1.6;
    }
</style>
</head>
<body>

<div class="install-wrapper">
    <div class="install-card">
        <div class="install-header">
            <h1>LitaBlog</h1>
            <p>只需几秒，开启您的写作之旅</p>
        </div>

        <!-- 运行环境检测提示 -->
        <div class="env-status-box">
            <div><?php echo htmlspecialchars($recommend_status); ?></div>
            <?php if (!empty($sqlite_status)): ?>
                <div style="color: var(--danger-color); font-weight: bold; margin-top: 5px;">
                    ⚠️ <?php echo htmlspecialchars($sqlite_status); ?>
                </div>
            <?php else: ?>
                <div style="color: var(--primary-green); font-weight: bold; margin-top: 5px;">
                    ✅ SQLite 数据库支持就绪
                </div>
            <?php endif; ?>
        </div>

        <form method="post">
            <div class="form-group">
                <label for="username">管理员账号</label>
                <input type="text" id="username" name="username" placeholder="请设置最高权限的账号名" required autofocus>
            </div>
            
            <div class="form-group">
                <label for="password">管理员密码</label>
                <input type="password" id="password" name="password" placeholder="请妥善保管您的密码" required>
            </div>
            
            <div class="form-group">
                <label for="email">管理员邮箱</label>
                <input type="email" id="email" name="email" value="hi@lita.eu.org" placeholder="用于接收重要通知" required>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px; font-size: 1.15rem; font-weight: 600; border-radius: var(--radius-sm); margin-top: 15px; box-shadow: 0 4px 12px var(--shadow-color);">
                ✨ 开始安装
            </button>
        </form>
    </div>
</div>


<script>
document.querySelector('form').addEventListener('submit', function() {
    const submitBtn = this.querySelector('button[type="submit"]');
    // 禁用按钮
    submitBtn.disabled = true;
    // 改变样式（变灰）
    submitBtn.style.background = '#a0aab5';
    submitBtn.style.borderColor = '#a0aab5';
    submitBtn.style.boxShadow = 'none';
    submitBtn.style.cursor = 'not-allowed';
    // 改变文字
    submitBtn.innerHTML = '⏳ 正在安装，请稍候...';
});
</script>
</body>
</html>
<!-- END OF FILE admin/views/install.php -->