<!-- START OF FILE admin/views/profile.php -->
<div class="desktop-header">
    <h1>账号资料</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo $feedback_message; ?>
    </div>
<?php endif; ?>

<!-- 1. 基本资料卡片 -->
<div class="card" style="margin-bottom: 25px;">
    <h3 style="margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px; display: flex; justify-content: space-between;">
        <span>📝 基本信息</span>
        <span style="font-size: 0.8rem; font-weight: normal; color: #888; background: var(--warm-bg); padding: 2px 8px; border-radius: 10px;">
            级别: <?php echo isset($user_data_for_form['role']) ? e(ucfirst($user_data_for_form['role'])) : 'N/A'; ?>
        </span>
    </h3>
    
    <form method="post" action="profile.php">
        <input type="hidden" name="action" value="update_profile">

        <div class="form-group">
            <label for="username">系统账号名</label>
            <input type="text" id="username" name="username" value="<?php echo e($user_data_for_form['username'] ?? ''); ?>" required>
            <p style="font-size: 0.8rem; color: #888; margin-top: 5px;">用于登录系统的唯一凭证。</p>
        </div>

        <div class="form-group">
            <label for="display_name">前台显示昵称</label>
            <input type="text" id="display_name" name="display_name" value="<?php echo e($user_data_for_form['display_name'] ?? ''); ?>" required>
            <p style="font-size: 0.8rem; color: #888; margin-top: 5px;">在文章作者或评论区展示的名字。</p>
        </div>

        <div class="form-group">
            <label for="email">联络邮箱</label>
            <input type="email" id="email" name="email" value="<?php echo e($user_data_for_form['email'] ?? ''); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;">更新基本资料</button>
    </form>
</div>

<!-- 2. 密码修改卡片 -->
<div class="card">
    <h3 style="margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px; color: var(--danger-color);">
        🔒 安全与密码
    </h3>
    
    <form method="post" action="profile.php">
        <input type="hidden" name="action" value="change_password">

        <div class="form-group">
            <label for="current_password">验证当前密码</label>
            <input type="password" id="current_password" name="current_password" placeholder="请输入现在的密码" required>
        </div>

        <div class="form-group">
            <label for="new_password">设置新密码</label>
            <input type="password" id="new_password" name="new_password" placeholder="输入新的复杂密码" required>
        </div>

        <div class="form-group">
            <label for="confirm_password">再次确认新密码</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="重复输入一次" required>
        </div>

        <button type="submit" class="btn btn-outline" style="width: 100%; border-color: var(--danger-color); color: var(--danger-color);">修改密码</button>
    </form>
</div>
<!-- END OF FILE admin/views/profile.php -->