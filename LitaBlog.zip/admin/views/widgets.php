<!-- START OF FILE admin/views/widgets.php -->
<div class="desktop-header">
    <h1>侧边栏挂件</h1>
</div>

<?php if (!empty($feedback_message)): ?>
    <div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
        <?php echo e($feedback_message); ?>
    </div>
<?php endif; ?>

<div class="card">
    <p style="color: #666; font-size: 0.9rem; margin-bottom: 20px;">管理显示在主题侧边栏中的挂件。您可以上下拖拽 ☰ 符号来调整显示顺序。</p>

    <form method="post" id="sidebar-form">
        <div id="widget-items-container">
            <?php if (empty($current_widgets_data)): ?>
                <div id="no-widgets-placeholder" style="text-align:center; padding: 30px; background: var(--warm-bg); border-radius: var(--radius-sm); color: #888; margin-bottom: 15px;">
                    暂时没有挂件。点击下方按钮添加。
                </div>
            <?php endif; ?>
            
            <?php foreach ($current_widgets_data as $i => $widget): ?>
                <!-- 单个挂件块 -->
                <div class="widget-item" draggable="true" data-id="<?php echo $i; ?>" style="background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 15px; margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.02);">
                    
                    <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px dashed var(--border-color); padding-bottom: 10px; margin-bottom: 10px;">
                        <span class="drag-handle" style="cursor: grab; font-size: 1.2rem; color: #999; padding: 5px;">☰</span>
						 <button type="button" class="btn btn-outline move-up" style="padding: 6px 10px; font-size: 0.8rem;" title="上移">↑</button>
    <button type="button" class="btn btn-outline move-down" style="padding: 6px 10px; font-size: 0.8rem;" title="下移">↓</button>
                        <select name="widget_type[]" style="width: auto; padding: 6px; font-size: 0.85rem; border: none; background: var(--warm-bg); border-radius: 4px;">
                            <option value="text" <?php echo $widget['type'] === 'text' ? 'selected' : ''; ?>>纯文本模式</option>
                            <option value="html" <?php echo $widget['type'] === 'html' ? 'selected' : ''; ?>>自定义 HTML</option>
                        </select>

	 <button type="button" class="btn btn-danger remove-widget" style="padding: 6px 10px; font-size: 0.8rem;" title="移除">✕ 移除</button>
                    </div>
					
			
					
                    
                    <input type="text" name="widget_title[]" value="<?php echo e($widget['title']); ?>" placeholder="挂件标题 (选填)" style="margin-bottom: 10px; font-weight: bold;" />
                    <textarea name="widget_content[]" placeholder="<?php echo $widget['type'] === 'html' ? '在此粘贴 HTML 代码...' : '在此输入正文...'; ?>" rows="4" style="resize: vertical; font-family: monospace; font-size: 0.9rem;"><?php echo $widget['type'] === 'text' ? e($widget['content']) : $widget['content']; ?></textarea>
                    
                    <input type="hidden" name="widget_order[]" value="<?php echo $widget['order']; ?>" class="widget-order">
                </div>
            <?php endforeach; ?>
        </div>

        <div style="display: flex; flex-direction: column; gap: 15px; margin-top: 25px;">
            <button type="button" id="add-widget" class="btn btn-outline" style="border-style: dashed; padding: 12px;">+ 添加新挂件</button>
            <button type="submit" class="btn btn-primary" style="padding: 14px; font-size: 1.1rem; box-shadow: 0 4px 12px var(--shadow-color);">💾 提交保存所有挂件</button>
        </div>
    </form>
</div>

<!-- 拖拽 JS 逻辑 (继承自原版，只需轻微改动 HTML 注入部分) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('widget-items-container');
    const addBtn = document.getElementById('add-widget');
    const placeholder = document.getElementById('no-widgets-placeholder');
    let draggedItem = null;

    function updateOrder() {
        container.querySelectorAll('.widget-item').forEach((item, idx) => {
            const input = item.querySelector('.widget-order');
            if(input) input.value = idx;
            item.dataset.id = idx;
        });
    }

    addBtn.onclick = function() {
        const idx = container.querySelectorAll('.widget-item').length;
        const div = document.createElement('div');
        div.className = 'widget-item';
        div.draggable = true;
        div.dataset.id = idx;
        div.style.cssText = "background: #fff; border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 15px; margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.02);";
        div.innerHTML = `
            <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px dashed var(--border-color); padding-bottom: 10px; margin-bottom: 10px;">
                <span class="drag-handle" style="cursor: grab; font-size: 1.2rem; color: #999; padding: 5px;">☰</span>
				   <button type="button" class="btn btn-outline move-up" style="padding: 6px 10px; font-size: 0.8rem;" title="上移">↑</button>
                <button type="button" class="btn btn-outline move-down" style="padding: 6px 10px; font-size: 0.8rem;" title="下移">↓</button>
                <select name="widget_type[]" style="width: auto; padding: 6px; font-size: 0.85rem; border: none; background: var(--warm-bg); border-radius: 4px;">
                    <option value="text" selected>纯文本模式</option>
                    <option value="html">自定义 HTML</option>
                </select>
			      
                <button type="button" class="btn btn-danger remove-widget" style="padding: 6px 10px; font-size: 0.8rem;">✕ 移除</button>
            </div>
            <input type="text" name="widget_title[]" placeholder="挂件标题 (选填)" style="margin-bottom: 10px; font-weight: bold;" />
            <textarea name="widget_content[]" placeholder="在此输入正文..." rows="4" style="resize: vertical; font-family: monospace; font-size: 0.9rem;"></textarea>
            <input type="hidden" name="widget_order[]" value="${idx}" class="widget-order">
        `;
        container.appendChild(div);
        setupDrag(div);
        updateOrder();
        if(placeholder) placeholder.style.display = 'none';
    };

    container.addEventListener('click', e => {
        if(e.target.classList.contains('remove-widget') && confirm('确定要移除这个挂件吗？')) {
            e.target.closest('.widget-item').remove();
            updateOrder();
            if(container.querySelectorAll('.widget-item').length === 0 && placeholder) placeholder.style.display = 'block';
        }
		
		
 // --- 新增：上移逻辑 ---
        if (e.target.classList.contains('move-up')) {
            const item = e.target.closest('.widget-item');
            const prev = item.previousElementSibling;
            if (prev && prev.classList.contains('widget-item')) {
                container.insertBefore(item, prev);
                updateOrder(); // 【关键】每次移动后必须调用此函数，重新计算并写入数据库排序序号
            }
        }
        
        // --- 新增：下移逻辑 ---
        if (e.target.classList.contains('move-down')) {
            const item = e.target.closest('.widget-item');
            const next = item.nextElementSibling;
            if (next && next.classList.contains('widget-item')) {
                container.insertBefore(next, item);
                updateOrder(); // 【关键】每次移动后必须调用此函数，重新计算并写入数据库排序序号
            }
        }
		
    });

    function setupDrag(item) {
        item.addEventListener('dragstart', function(e) {
            draggedItem = this; e.dataTransfer.effectAllowed = 'move';
            setTimeout(() => this.style.opacity = '0.5', 0);
        });
        item.addEventListener('dragend', function() {
            if(draggedItem) { this.style.opacity = '1'; draggedItem = null; }
            container.querySelectorAll('.widget-item').forEach(el => el.style.borderTop = '');
            updateOrder();
        });
        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            if(draggedItem && this !== draggedItem) this.style.borderTop = '2px solid var(--primary-green)';
        });
        item.addEventListener('dragleave', function() { this.style.borderTop = ''; });
        item.addEventListener('drop', function(e) {
            e.preventDefault(); this.style.borderTop = '';
            if(draggedItem && this !== draggedItem) {
                const rect = this.getBoundingClientRect();
                if(e.clientY < rect.top + rect.height / 2) container.insertBefore(draggedItem, this);
                else container.insertBefore(draggedItem, this.nextSibling);
            }
        });
    }
    container.querySelectorAll('.widget-item').forEach(setupDrag);
});
</script>
<!-- END OF FILE admin/views/widgets.php -->