<?php
// admin/tags.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';
$tags_data = [];
$tag_name_input = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
$db = get_db();

if ($_POST['action'] === 'add') {
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$tag_name_input = $name;

if (empty($name)) {
$feedback_message = 'Tag name cannot be empty.';
$feedback_type = 'error';
} else {
$slug = create_slug($name);
try {
$stmt = $db->prepare('INSERT INTO tags (name, slug) VALUES (?, ?)');
if ($stmt->execute([$name, $slug])) {
$feedback_message = 'Tag added successfully.';
$feedback_type = 'success';
$tag_name_input = '';
} else {
$feedback_message = 'Failed to add tag.';
$feedback_type = 'error';
}
} catch (PDOException $e) {
if ($e->getCode() == 23000 || strpos($e->getMessage(), 'UNIQUE constraint failed') !== false) {
$feedback_message = 'Failed to add tag: Name or slug already exists.';
} else {
$feedback_message = 'Failed to add tag: Database error.';
}
$feedback_type = 'error';
}
}
} elseif ($_POST['action'] === 'delete' && isset($_POST['tag_id'])) {
$tag_id = filter_input(INPUT_POST, 'tag_id', FILTER_SANITIZE_NUMBER_INT);
if ($tag_id > 0) {
try {
$db->beginTransaction();
$stmt_del_tag = $db->prepare('DELETE FROM tags WHERE id = ?');
$deleted = $stmt_del_tag->execute([$tag_id]);

if ($deleted) {
$stmt_del_rel = $db->prepare('DELETE FROM post_tags WHERE tag_id = ?');
$stmt_del_rel->execute([$tag_id]);
$db->commit();
$feedback_message = 'Tag deleted successfully.';
$feedback_type = 'success';
} else {
$db->rollBack();
$feedback_message = 'Failed to delete tag.';
$feedback_type = 'error';
}
} catch (PDOException $e) {
$db->rollBack();
$feedback_message = 'Failed to delete tag: Database error.';
$feedback_type = 'error';
}
} else {
$feedback_message = 'Invalid tag ID for deletion.';
$feedback_type = 'error';
}
}
}

try {
$db = get_db();
$stmt = $db->prepare('
SELECT t.*, COUNT(pt.post_id) as post_count 
FROM tags t 
LEFT JOIN post_tags pt ON t.id = pt.tag_id 
GROUP BY t.id 
ORDER BY t.name COLLATE NOCASE ASC
');
$stmt->execute();
$tags_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
$feedback_message = 'Database error loading tags: ' . $e->getMessage();
$feedback_type = 'error';
}

// 调度渲染标签页面
include dirname(__FILE__) . '/views/tags.php';
require_once 'foot.php';