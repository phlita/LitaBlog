<?php
// admin/install.php
if (file_exists(dirname(__FILE__) . '/../config.php')) {http_response_code(403);
die('博客已经安装！如需重新安装，请手动删除根目录下的 config.php 文件。');
}

$recommend_status = "推荐 PHP 7.4+ 当前 " . PHP_VERSION;
$sqlite_status = "";
if (!extension_loaded('pdo_sqlite')) { 
$sqlite_status = "pdo_sqlite 未启用 安装不了"; 
} else {
if (!extension_loaded('sqlite3')) { 
$sqlite_status = "sqlite3 未启用 pdo_sqlite 启用 将就"; 
}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = $_POST['password'] ?? '';
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

$is_install_secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
|| (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
|| (($_SERVER['HTTP_CF_VISITOR'] ?? '') === '{"scheme":"https"}');
$protocol = $is_install_secure ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];

$path = str_replace('\\', '/', dirname(dirname($_SERVER['REQUEST_URI'])));
$site_url = rtrim($protocol . $host . $path, '/');

if (!$username || !$password) {
die('请填写所有必填字段');
}

$dirs = [
'../content',
'../content/themes',
'../content/plugins',
'../content/uploads',
'../content/database'
];

foreach ($dirs as $dir) {
if (!file_exists(dirname(__FILE__) . '/' . $dir)) {
mkdir(dirname(__FILE__) . '/' . $dir, 0755, true);
}
}

try {
$db_name = 'blog_' . bin2hex(random_bytes(8)) . '.db';
$db_file = dirname(__FILE__) . '/../content/database/' . $db_name;
$db = new PDO('sqlite:' . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$tables = [
"CREATE TABLE IF NOT EXISTS posts (
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT NOT NULL,
content TEXT,
author INTEGER,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP,
status TEXT DEFAULT 'draft',
type TEXT DEFAULT 'post',
slug TEXT NOT NULL UNIQUE,
excerpt TEXT,
sticky_order INTEGER DEFAULT 0,
FOREIGN KEY (author) REFERENCES users(id) ON DELETE SET NULL
)",
"CREATE INDEX IF NOT EXISTS idx_posts_type_status_created ON posts (type, status, created)",
"CREATE TABLE IF NOT EXISTS postmeta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
post_id INTEGER NOT NULL,
meta_key TEXT,
meta_value TEXT,
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_postmeta_post_id ON postmeta (post_id)",
"CREATE INDEX IF NOT EXISTS idx_postmeta_meta_key ON postmeta (meta_key)",
"CREATE TABLE IF NOT EXISTS users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT UNIQUE NOT NULL,
password TEXT NOT NULL,
email TEXT UNIQUE NOT NULL,
display_name TEXT NOT NULL,
status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive', 'banned')),
created DATETIME DEFAULT CURRENT_TIMESTAMP,
role TEXT DEFAULT 'administrator'
)",
"CREATE TABLE IF NOT EXISTS usermeta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL,
meta_key TEXT,
meta_value TEXT,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_usermeta_user_id ON usermeta (user_id)",
"CREATE INDEX IF NOT EXISTS idx_usermeta_meta_key ON usermeta (meta_key)",
"CREATE TABLE IF NOT EXISTS options (
name TEXT PRIMARY KEY,
value TEXT
)",
"CREATE TABLE IF NOT EXISTS categories (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE,
parent_id INTEGER DEFAULT 0,
description TEXT
)",
"CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug)",
"CREATE TABLE IF NOT EXISTS post_categories (
post_id INTEGER,
category_id INTEGER,
PRIMARY KEY (post_id, category_id),
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_post_categories_category ON post_categories(category_id)",
"CREATE TABLE IF NOT EXISTS tags (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE
)",
"CREATE INDEX IF NOT EXISTS idx_tags_slug ON tags(slug)",
"CREATE TABLE IF NOT EXISTS post_tags (
post_id INTEGER,
tag_id INTEGER,
PRIMARY KEY (post_id, tag_id),
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_post_tags_tag ON post_tags(tag_id)",
"CREATE TABLE IF NOT EXISTS plugins (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE,
description TEXT,
version TEXT NOT NULL,
author TEXT,
author_url TEXT,
plugin_uri TEXT,
status TEXT DEFAULT 'inactive',
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP
)",
"CREATE INDEX IF NOT EXISTS idx_plugins_slug ON plugins(slug)",
"CREATE INDEX IF NOT EXISTS idx_plugins_status ON plugins(status)", 
"CREATE TABLE IF NOT EXISTS comments (
id INTEGER PRIMARY KEY AUTOINCREMENT,
post_id INTEGER NOT NULL,
user_id INTEGER,
author TEXT,
email TEXT,
content TEXT NOT NULL,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
status TEXT DEFAULT 'pending',
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)",
"CREATE INDEX IF NOT EXISTS idx_comments_post_status_created ON comments (post_id, status, created)",
"CREATE INDEX IF NOT EXISTS idx_comments_status ON comments(status)",
"CREATE TABLE IF NOT EXISTS sidebar_widgets (
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT,
type TEXT NOT NULL,
content TEXT,
`order` INTEGER DEFAULT 0,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP
)",
"CREATE INDEX IF NOT EXISTS idx_sidebar_widgets_order ON sidebar_widgets (`order`)",
"CREATE INDEX IF NOT EXISTS idx_posts_author ON posts (author)",
];

foreach ($tables as $sql) {
$db->exec($sql);
}

$stmt = $db->prepare('INSERT INTO users (username, password, email, display_name, role) VALUES (?, ?, ?, ?, ?)');
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$stmt->execute([$username, $hashed_password, $email, $username, 'administrator']);

$default_options = [
['site_title', '小博客'],
['site_description', 'Lita web hosting'],
['admin_email', 'hi@lita.eu.org'],
['current_theme', 'default'],
['posts_per_page', '10'],
['date_format', 'Y-m-d'],
['time_format', 'H:i:s'],
['nav_menu', '[]'],
['enable_comments', '0'],
['enable_registration', '0'],
['site_timezone', 'Asia/Shanghai']
];
$stmt = $db->prepare('INSERT INTO options (name, value) VALUES (?, ?)');
foreach ($default_options as $option) {
$stmt->execute($option);
}

$default_widgets = [
[
'title' => '芙里塔',
'type' => 'text',
'content' => '芙摇别素月，塔影待星归。',
'order' => 1
]
];

$stmt = $db->prepare('INSERT INTO sidebar_widgets (title, type, content, `order`) VALUES (?, ?, ?, ?)');
foreach ($default_widgets as $widget) {
$stmt->execute([$widget['title'], $widget['type'], $widget['content'], $widget['order']]);
}

if (!file_exists(dirname(__FILE__) . '/../config.php')) {
$config_sample = file_get_contents(dirname(__FILE__) . '/../config-sample.php');
$auth_key = bin2hex(random_bytes(32));
$secure_auth_key = bin2hex(random_bytes(32));

$config = str_replace(
["define('SITE_URL', '');", "define('AUTH_KEY', '');", "define('SECURE_AUTH_KEY', '');", "define('DB_FILE', ABSPATH . 'content/database/blog.db');"],
["define('SITE_URL', '" . $site_url . "');", "define('AUTH_KEY', '" . $auth_key . "');", "define('SECURE_AUTH_KEY', '" . $secure_auth_key . "');", "define('DB_FILE', ABSPATH . 'content/database/" . $db_name . "');"],
$config_sample
);

if (!file_put_contents(dirname(__FILE__) . '/../config.php', $config)) {
die('无法创建配置文件');
}
chmod($db_file, 0600);
}

header('Location: ../admin/login.php');
exit;

} catch (PDOException $e) {
die('数据库错误：' . $e->getMessage());
}
}

// 调度安装页面视图
include dirname(__FILE__) . '/views/install.php';