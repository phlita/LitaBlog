<?php
// admin/themes.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['force_theme_refresh'])) {
update_option('cached_themes_timestamp', 0);
$feedback_message = '主题列表缓存已清除';
$feedback_type = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activate_theme']) && isset($_POST['theme_dir'])) {
$theme_dir_to_activate = filter_input(INPUT_POST, 'theme_dir', FILTER_SANITIZE_STRING);
$theme_path = THEME_DIR . '/' . $theme_dir_to_activate;

$required_files_exist = is_dir($theme_path) &&
file_exists($theme_path . '/index.php') &&
file_exists($theme_path . '/single.php');

if ($required_files_exist) {
if (switch_theme($theme_dir_to_activate)) {
$feedback_message = "主题 '" . e($theme_dir_to_activate) . "' 激活成功。";
$feedback_type = 'success';
$current_theme_slug = $theme_dir_to_activate;
update_option('cached_themes_timestamp', 0);
} else {
$feedback_message = "切换主题到 '" . e($theme_dir_to_activate) . "' 失败。";
$feedback_type = 'error';
}
} else {
$feedback_message = "无法激活主题: 缺少必需的模板文件。";
$feedback_type = 'error';
}
}

$themes_data = [];
$current_theme_slug = '';
$cache_ttl = 3600;

try {
if (empty($current_theme_slug)) {
$current_theme_slug = get_current_theme();
}
$themes_data = get_cached_themes_data($cache_ttl);
} catch (Exception $e) {
$feedback_message = '发生错误: ' . $e->getMessage();
$feedback_type = 'error';
}

// 调度渲染主题管理视图
include dirname(__FILE__) . '/views/themes.php';
require_once 'foot.php';