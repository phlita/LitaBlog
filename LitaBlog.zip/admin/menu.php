<?php
// admin/menu.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';
$current_menu_items = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$menu_items_to_save = [];
$names = isset($_POST['menu_name']) && is_array($_POST['menu_name']) ? $_POST['menu_name'] : [];
$urls = isset($_POST['menu_url']) && is_array($_POST['menu_url']) ? $_POST['menu_url'] : [];
$count = min(count($names), count($urls));

for ($i = 0; $i < $count; $i++) {
$name = trim(filter_var($names[$i], FILTER_SANITIZE_STRING));
$url = trim(filter_var($urls[$i], FILTER_SANITIZE_URL));

if (!empty($name) && !empty($url)) {
if (filter_var($url, FILTER_VALIDATE_URL) || preg_match('/^(\/|#|mailto:|tel:)/', $url)) {
$menu_items_to_save[] = ['name' => $name, 'url' => $url];
}
}
}

if (update_nav_menu($menu_items_to_save)) {
$feedback_message = 'Menu updated successfully.';
$feedback_type = 'success';
} else {
$feedback_message = 'Failed to save menu.';
$feedback_type = 'error';
}
}

$current_menu_items = get_nav_menu();

// 调度渲染菜单设置页面
include dirname(__FILE__) . '/views/menu.php';
require_once 'foot.php';