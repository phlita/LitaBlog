<?php
// admin/categories.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';
$categories_data = [];
$category_name_input = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
$db = get_db();

if ($_POST['action'] === 'add') {
$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$category_name_input = $name;

if (empty($name)) {
$feedback_message = 'Category name cannot be empty.';
$feedback_type = 'error';
} else {
$slug = create_slug($name);
try {
$stmt = $db->prepare('INSERT INTO categories (name, slug) VALUES (?, ?)');
if ($stmt->execute([$name, $slug])) {
$feedback_message = 'Category added successfully.';
$feedback_type = 'success';
$category_name_input = '';
} else {
$feedback_message = 'Failed to add category.';
$feedback_type = 'error';
}
} catch (PDOException $e) {
if ($e->getCode() == 23000 || strpos($e->getMessage(), 'UNIQUE constraint failed') !== false) {
$feedback_message = 'Failed to add category: Name or slug already exists.';
} else {
$feedback_message = 'Failed to add category: Database error.';
}
$feedback_type = 'error';
}
}
} elseif ($_POST['action'] === 'delete' && isset($_POST['category_id'])) {
$category_id = filter_input(INPUT_POST, 'category_id', FILTER_SANITIZE_NUMBER_INT);
if ($category_id > 0) {
try {
$db->beginTransaction();
$stmt = $db->prepare('DELETE FROM categories WHERE id = ?');
$deleted = $stmt->execute([$category_id]);

if ($deleted) {
$stmt = $db->prepare('DELETE FROM post_categories WHERE category_id = ?');
$stmt->execute([$category_id]);
$db->commit();
$feedback_message = 'Category deleted successfully.';
$feedback_type = 'success';
} else {
$db->rollBack();
$feedback_message = 'Failed to delete category.';
$feedback_type = 'error';
}
} catch (PDOException $e) {
$db->rollBack();
$feedback_message = 'Failed to delete category: Database error.';
$feedback_type = 'error';
}
} else {
$feedback_message = 'Invalid category ID for deletion.';
$feedback_type = 'error';
}
}
}

try {
$db = get_db();
$stmt = $db->prepare('SELECT c.*, COUNT(pc.post_id) as post_count FROM categories c LEFT JOIN post_categories pc ON c.id = pc.category_id GROUP BY c.id ORDER BY c.name');
$stmt->execute();
$categories_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
$feedback_message = 'Database error loading categories: ' . $e->getMessage();
$feedback_type = 'error';
}

// 调度渲染分类管理页面视图
include dirname(__FILE__) . '/views/categories.php';
require_once 'foot.php';