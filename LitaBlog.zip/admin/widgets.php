<?php
// admin/widgets.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$db = get_db();
$feedback_message = '';
$feedback_type = '';
$current_widgets_data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$widgets_to_save = [];
$titles = isset($_POST['widget_title']) && is_array($_POST['widget_title']) ? $_POST['widget_title'] : [];
$types = isset($_POST['widget_type']) && is_array($_POST['widget_type']) ? $_POST['widget_type'] : [];
$contents = isset($_POST['widget_content']) && is_array($_POST['widget_content']) ? $_POST['widget_content'] : [];
$orders = isset($_POST['widget_order']) && is_array($_POST['widget_order']) ? $_POST['widget_order'] : [];

$count = count($titles);

for ($i = 0; $i < $count; $i++) {
//$title = trim(filter_var($titles[$i], FILTER_SANITIZE_STRING));
$title = sanitize_text_field($titles[$i]); 
$type = isset($types[$i]) && in_array($types[$i], ['text', 'html']) ? $types[$i] : 'text';
$content = isset($contents[$i]) ? trim($contents[$i]) : '';
$order = isset($orders[$i]) ? (int)$orders[$i] : $i;

    // 如果是 HTML 挂件，在写入数据库前进行底层特征清洗
    if ($type === 'html') {
        $content = litablog_purify_html($content); 
    } else {
        $content = sanitize_textarea_field($content);
    }

$widgets_to_save[] = [
'title' => $title,
'type' => $type,
'content' => $content,
'order' => $order
];
}

usort($widgets_to_save, function($a, $b) {
return $a['order'] - $b['order'];
});

foreach ($widgets_to_save as $index => &$widget) {
$widget['order'] = $index;
}
unset($widget);

if (update_sidebar_widgets($widgets_to_save)) {
$feedback_message = 'Sidebar widgets updated successfully.';
$feedback_type = 'success';
} else {
$feedback_message = 'Failed to save sidebar widgets.';
$feedback_type = 'error';
}
$current_widgets_data = get_sidebar_widgets();
} else {
$current_widgets_data = get_sidebar_widgets();
}

// 调度加载挂件配置视图
include dirname(__FILE__) . '/views/widgets.php';
require_once 'foot.php';