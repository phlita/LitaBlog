
<?php
// admin/header.php
if (!file_exists(dirname(__FILE__) . '/../config.php')) {
header('Location: install.php');
exit;
}

require_once dirname(__FILE__) . '/../includes/load.php';

if (!defined('ADMIN_PLUGINS_LOADED')) {
define('ADMIN_PLUGINS_LOADED', true);
$specific_plugins_to_load = ['abc', 'jscrypt', 'litapay', 'test'];
$plugins_lookup = array_flip($specific_plugins_to_load);
$active_plugins = get_active_plugins();
if (!empty($active_plugins) && is_array($active_plugins)) {
foreach ($active_plugins as $plugin) {
if (!empty($plugin['slug']) && isset($plugins_lookup[$plugin['slug']])) {
$plugin_file = ABSPATH . 'content/plugins/' . $plugin['slug'] . '/' . $plugin['slug'] . '.php';
if (file_exists($plugin_file)) {
error_log("LitaBlog DEBUG: Requiring plugin file: " . $plugin_file);
require_once $plugin_file;
}
}
}
}
}

error_log('LitaBlog DEBUG (admin/header.php BEFORE do_action(admin_menu)): $wp_actions[admin_menu] = ' . print_r($GLOBALS['wp_actions']['admin_menu'] ?? "NOT SET OR EMPTY", true));
do_action('admin_menu');
error_log('LitaBlog DEBUG: do_action("admin_menu") EXECUTED.');

if (!is_logged_in()) {
header('Location: login.php');
exit;
}

// 资源注册与排队
function content_page_enqueue_quill_assets($hook_suffix) {
if ($hook_suffix === 'content.php' || strpos($hook_suffix, 'content.php_page_') === 0 || $hook_suffix === 'content.php_post' || $hook_suffix === 'content.php_page') {
wp_register_style('quill-snow-css', 'assets/quill/quill.snow.css', [], filemtime(ABSPATH . 'admin/assets/quill/quill.snow.css'));
wp_enqueue_style('quill-snow-css');
wp_register_script('quill-js', 'assets/quill/quill.min.js', [], filemtime(ABSPATH . 'admin/assets/quill/quill.min.js'), true);
wp_enqueue_script('quill-js');
}
}
add_action('admin_enqueue_scripts', 'content_page_enqueue_quill_assets', 10, 1);

wp_register_style('admin-core-css', 'admin.css', [], filemtime(ABSPATH . 'admin/admin.css'));
wp_enqueue_style('admin-core-css');

$hook_suffix = get_current_admin_page_hook_suffix();
error_log('LitaBlog DEBUG: (admin/header.php) Current hook_suffix: ' . $hook_suffix);
do_action('admin_enqueue_scripts', $hook_suffix);

wp_register_script('admin-menu-active', 'assets/js/admin-menu.js', [], filemtime(ABSPATH . 'admin/assets/js/admin-menu.js'));
wp_enqueue_script('admin-menu-active');


// 注入核心菜单定义 (去除冗余的总览控制台)
function get_core_admin_menus() {
    return [
        'home' => ['title' => '查看网站', 'url' => SITE_URL . '/', 'capability' => 'is_logged_in', 'type' => 'external'],
        'separator1' => ['type' => 'separator'],
        
        // 【核心修改】：将文章的 URL 直接指向 index.php，取消多余的参数
        'posts' => ['title' => '内容管理', 'url' => SITE_URL . '/admin/index.php', 'capability' => 'is_logged_in', 'type' => 'internal'],
        'pages' => ['title' => '独立页面', 'url' => SITE_URL . '/admin/index.php?type=page', 'capability' => 'is_admin', 'type' => 'internal'],
        'comments' => ['title' => '互动评论', 'url' => SITE_URL . '/admin/comments.php', 'capability' => 'is_admin', 'type' => 'internal'],
        
        'separator2' => ['type' => 'separator'],
        'menu' => ['title' => '导航菜单', 'url' => SITE_URL . '/admin/menu.php', 'capability' => 'is_admin', 'type' => 'internal'],
        'categories' => ['title' => '文章分类', 'url' => SITE_URL . '/admin/categories.php', 'capability' => 'is_admin', 'type' => 'internal'],
        'tags' => ['title' => '内容标签', 'url' => SITE_URL . '/admin/tags.php', 'capability' => 'is_admin', 'type' => 'internal'],
        
        'separator3' => ['type' => 'separator'],
        'themes' => ['title' => '外观主题', 'url' => SITE_URL . '/admin/themes.php', 'capability' => 'is_admin', 'type' => 'internal'],
        'plugins' => ['title' => '扩展插件', 'url' => SITE_URL . '/admin/plugins.php', 'capability' => 'is_admin', 'type' => 'internal'],
        'widgets' => ['title' => '侧边挂件', 'url' => SITE_URL . '/admin/widgets.php', 'capability' => 'is_admin', 'type' => 'internal'],
        
        'separator4' => ['type' => 'separator'],
        'profile' => ['title' => '账号资料', 'url' => SITE_URL . '/admin/profile.php', 'capability' => 'is_logged_in', 'type' => 'internal'],
        'settings' => ['title' => '系统设置', 'url' => SITE_URL . '/admin/settings.php', 'capability' => 'is_admin', 'type' => 'internal'],
        
        'separator5' => ['type' => 'separator'],
        'logout' => ['title' => '安全退出', 'url' => SITE_URL . '/admin/logout.php', 'capability' => 'is_logged_in', 'type' => 'internal']
    ];
}



function can_user_access_menu($capability) {
switch ($capability) {
case 'is_admin': return is_admin();
case 'is_logged_in': return is_logged_in();
case 'manage_options': return is_admin();
default: return false;
}
}

// 调度视图渲染
include dirname(__FILE__) . '/views/header.php';
?>