/**
 * 管理后台菜单 Active 状态管理
 * 添加到 admin/header.php 中
 */
(function() {
    'use strict';
    
    class AdminMenuActiveManager {
        constructor() {
            this.init();
        }
        
        init() {
            // 页面加载完成后设置 active 状态
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => {
                    this.setActiveMenuItem();
                });
            } else {
                this.setActiveMenuItem();
            }
        }
        
        /**
         * 设置当前活动菜单项
         */
        setActiveMenuItem() {
            // 清除所有现有的 active 类
            document.querySelectorAll('.admin-nav li.active').forEach(item => {
                item.classList.remove('active');
            });
            
            const currentUrl = window.location.href;
            const currentPath = window.location.pathname;
            const currentSearch = window.location.search;
            const urlParams = new URLSearchParams(currentSearch);
            
            // 查找匹配的菜单项
            const menuLinks = document.querySelectorAll('.admin-nav a[href]');
            let matchedLink = null;
            let bestMatchScore = 0;
            
            menuLinks.forEach(link => {
                const href = link.getAttribute('href');
                const matchScore = this.calculateUrlMatchScore(currentUrl, currentPath, currentSearch, urlParams, href);
                
                if (matchScore > bestMatchScore) {
                    bestMatchScore = matchScore;
                    matchedLink = link;
                }
            });
            
            // 为匹配的菜单项添加 active 类
            if (matchedLink && bestMatchScore > 0) {
                const menuItem = matchedLink.closest('li');
                if (menuItem) {
                    menuItem.classList.add('active');
                    
                    // 如果是子菜单，也为父菜单添加 active
                    if (menuItem.closest('.sub-menu')) {
                        const parentMenuItem = menuItem.closest('.sub-menu').closest('li');
                        if (parentMenuItem) {
                            parentMenuItem.classList.add('active');
                        }
                    }
                }
            }
        }
        
        /**
         * 计算 URL 匹配分数
         */
        calculateUrlMatchScore(currentUrl, currentPath, currentSearch, urlParams, href) {
            if (!href) return 0;
            
            // 处理相对路径和绝对路径
            let targetUrl;
            try {
                if (href.startsWith('http')) {
                    targetUrl = new URL(href);
                } else if (href.startsWith('/')) {
                    targetUrl = new URL(href, window.location.origin);
                } else {
                    targetUrl = new URL(href, window.location.href);
                }
            } catch (e) {
                return 0;
            }
            
            const targetPath = targetUrl.pathname;
            const targetSearch = targetUrl.search;
            const targetParams = new URLSearchParams(targetSearch);
            
            let score = 0;
            
            // 路径匹配（权重最高）
            if (currentPath === targetPath) {
                score += 100;
            } else if (targetPath !== '/' && currentPath.includes(targetPath)) {
                score += 50;
            }
            
            // 查询参数匹配
            let paramMatches = 0;
            let totalTargetParams = 0;
            
            for (const [key, value] of targetParams) {
                totalTargetParams++;
                if (urlParams.get(key) === value) {
                    paramMatches++;
                    score += 20;
                }
            }
            
            // 如果目标 URL 有参数但不匹配，降低分数
            if (totalTargetParams > 0 && paramMatches === 0) {
                score -= 30;
            }
            
            // 完全匹配额外加分
            if (currentUrl === href || 
                (currentPath === targetPath && currentSearch === targetSearch)) {
                score += 200;
            }
            
            // 特殊处理一些常见情况
            const currentScript = currentPath.split('/').pop();
            const targetScript = targetPath.split('/').pop();
            
            // 处理 admin/index.php 的特殊情况
            if (currentScript === 'index.php' || currentScript === '') {
                if (targetScript === 'index.php' || targetScript === '' || targetPath.endsWith('/admin/')) {
                    // 检查 type 参数
                    const currentType = urlParams.get('type');
                    const targetType = targetParams.get('type');
                    
                    if (currentType === targetType) {
                        score += 50;
                    }
                }
            }
            
            return score;
        }
        
        /**
         * 手动更新活动菜单（可用于 AJAX 导航后调用）
         */
        updateActiveMenu() {
            this.setActiveMenuItem();
        }
    }
    
    // 初始化菜单管理器
    window.adminMenuManager = new AdminMenuActiveManager();
    
})();