<?php
// admin/plugins.php

// 1. 仅加载核心环境，不输出任何 HTML
require_once dirname(__FILE__) . '/../includes/load.php';

// 2. 权限验证（如果未登录或非管理员，直接重定向到错误页）
if (!is_logged_in() || !is_admin()) {
    header('Location: index.php?type=post&error=adminonly');
    exit;
}

// ---------------------------------------------------------
// 3. 集中处理所有的 POST 请求与重定向 (PRG 模式)
// ---------------------------------------------------------

function delete_plugin_directory($dirPath) {
    if (!is_dir($dirPath)) return false;
    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') $dirPath .= '/';
    $files = glob($dirPath . '*', GLOB_MARK);
    foreach ($files as $file) {
        if (is_dir($file)) delete_plugin_directory($file);
        else @unlink($file);
    }
    if (is_dir($dirPath)) return @rmdir($dirPath);
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // A. 处理删除插件
    if (isset($_POST['action']) && $_POST['action'] === 'delete_plugin' && isset($_POST['plugin_slug'])) {
        if (!isset($_POST['_csrf_token']) || !verifyCsrfToken($_POST['_csrf_token'], 'delete_plugin_' . $_POST['plugin_slug'])) {
            set_flash_message('安全校验失败，请重试。', 'error');
        } else {
            $plugin_slug_to_delete = sanitize_text_field($_POST['plugin_slug']);
            $plugin_dir_to_delete = ABSPATH . 'content/plugins/' . $plugin_slug_to_delete;

            if (empty($plugin_slug_to_delete) || !is_dir($plugin_dir_to_delete) || $plugin_slug_to_delete === '.' || $plugin_slug_to_delete === '..') {
                set_flash_message('指定的插件无效。', 'error');
            } else {
                if (is_plugin_active($plugin_slug_to_delete)) deactivate_plugin($plugin_slug_to_delete);
                do_uninstall_plugin($plugin_slug_to_delete);

                if (strpos(realpath($plugin_dir_to_delete), realpath(ABSPATH . 'content/plugins/')) === 0) {
                    if (delete_plugin_directory($plugin_dir_to_delete)) {
                        try {
                            $db = get_db();
                            $stmt = $db->prepare("DELETE FROM plugins WHERE slug = ?");
                            $stmt->execute([$plugin_slug_to_delete]);
                            set_flash_message('插件 "' . e($plugin_slug_to_delete) . '" 已成功删除。', 'success');
                            update_option('cached_plugins_filesystem_timestamp', 0);
                        } catch (PDOException $e) {
                            set_flash_message('文件已删除，但清理数据库记录失败。', 'error');
                        }
                    } else {
                        set_flash_message('删除文件失败，请检查目录权限。', 'error');
                    }
                } else {
                    set_flash_message('插件删除路径异常。', 'error');
                }
            }
        }
        header('Location: plugins.php');
        exit;
    }

    // B. 处理刷新插件缓存
    if (isset($_POST['force_plugin_refresh'])) {
        update_option('cached_plugins_filesystem_timestamp', 0);
        set_flash_message('插件列表缓存已清除并重新扫描。', 'success');
        header('Location: plugins.php');
        exit;
    }

    // C. 处理启用/停用
    if (isset($_POST['action'], $_POST['plugin']) && !isset($_POST['force_plugin_refresh'])) {
        $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
        $plugin_slug = filter_input(INPUT_POST, 'plugin', FILTER_SANITIZE_STRING);

        if (($action === 'activate' || $action === 'deactivate') && !empty($plugin_slug)) {
            if ($action === 'activate') {
                $result = activate_plugin($plugin_slug);
                if ($result) {
                    set_flash_message('插件 "' . e($plugin_slug) . '" 激活成功。', 'success');
                    update_option('cached_plugins_filesystem_timestamp', 0);
                } else {
                    set_flash_message('激活插件失败。请检查插件文件。', 'error');
                }
            } elseif ($action === 'deactivate') {
                $result = deactivate_plugin($plugin_slug);
                if ($result) {
                    set_flash_message('插件 "' . e($plugin_slug) . '" 停用成功。', 'success');
                    update_option('cached_plugins_filesystem_timestamp', 0);
                } else {
                    set_flash_message('停用插件失败。', 'error');
                }
            }
            header('Location: plugins.php');
            exit;
        }
    }
}

// ---------------------------------------------------------
// 4. 所有 POST 和重定向处理完毕，现在可以安全地输出 HTML 头部了
// ---------------------------------------------------------
require_once 'header.php';

// 5. 准备视图需要的数据
$plugins_display_data = [];
$cache_ttl = 3600;

try {
    $filesystem_plugins = get_cached_plugins_data($cache_ttl);
    $db_plugins_raw = get_plugins();

    $db_plugins_lookup = [];
    foreach ($db_plugins_raw as $db_plugin) {
        $db_plugins_lookup[$db_plugin['slug']] = $db_plugin;
    }

    $db = get_db();
    $plugins_needing_db_insert = [];

    foreach ($filesystem_plugins as $slug => $fs_data) {
        if (!isset($db_plugins_lookup[$slug])) {
            $plugins_needing_db_insert[$slug] = $fs_data;
            $plugins_display_data[$slug] = array_merge($fs_data, [
                'status' => 'inactive',
                'plugin_exists' => true,
                'needs_db_insert' => true
            ]);
        } else {
            $db_status = $db_plugins_lookup[$slug]['status'];
            $combined_data = array_merge($fs_data, ['status' => $db_status]);
            $combined_data['plugin_exists'] = true;
            $plugins_display_data[$slug] = $combined_data;
        }
    }

    if (!empty($plugins_needing_db_insert)) {
        try {
            $stmt = $db->prepare('INSERT INTO plugins (name, slug, description, version, author, author_url, plugin_uri, status, created, modified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)');
            foreach ($plugins_needing_db_insert as $slug => $fs_data) {
                $executed = $stmt->execute([
                    $fs_data['name'] ?? $slug,
                    $slug,
                    $fs_data['description'] ?? '',
                    $fs_data['version'] ?? 'N/A',
                    $fs_data['author'] ?? '',
                    $fs_data['author_url'] ?? '',
                    $fs_data['plugin_uri'] ?? '',
                    'inactive'
                ]);
                if ($executed && isset($plugins_display_data[$slug])) {
                    unset($plugins_display_data[$slug]['needs_db_insert']);
                }
            }
        } catch (PDOException $e) {
            set_flash_message('添加新插件到数据库时出错。', 'error');
        }
    }

    foreach ($db_plugins_lookup as $slug => $db_data) {
        if (!isset($filesystem_plugins[$slug])) {
            if (!isset($plugins_display_data[$slug])) {
                $missing_plugin_data = $db_data;
                $missing_plugin_data['plugin_exists'] = false;
                $missing_plugin_data['error_message'] = '插件文件丢失！';
                $plugins_display_data[$slug] = $missing_plugin_data;
            }
        }
    }

    // 按名称排序
    uasort($plugins_display_data, function($a, $b) {
        $nameA = $a['name'] ?? $a['slug'];
        $nameB = $b['name'] ?? $b['slug'];
        return strcasecmp($nameA, $nameB);
    });

} catch (Exception $e) {
    set_flash_message('发生错误: ' . $e->getMessage(), 'error');
    $plugins_display_data = [];
}

// 6. 调度视图
include dirname(__FILE__) . '/views/plugins.php';
require_once 'foot.php';