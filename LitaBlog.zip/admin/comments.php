<?php
// admin/comments.php
require_once 'header.php';
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';
$comments_data = [];
$total_comments = 0;
$total_pages = 0;

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = isset($_GET['per_page']) ? max(5, min(100, intval($_GET['per_page']))) : 20;
$status_filter = isset($_GET['status']) && in_array($_GET['status'], ['approved', 'pending', 'all']) ? $_GET['status'] : 'all';
$sort_order = isset($_GET['sort']) && in_array($_GET['sort'], ['newest', 'oldest', 'author']) ? $_GET['sort'] : 'newest';
$offset = ($page - 1) * $per_page;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['comment_id'])) {
$comment_id = filter_input(INPUT_POST, 'comment_id', FILTER_SANITIZE_NUMBER_INT);
$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
$db = get_db();

if ($comment_id > 0 && in_array($action, ['approve', 'unapprove', 'delete'])) {
try {
$success = false;
switch ($action) {
case 'approve':
$stmt = $db->prepare('UPDATE comments SET status = ? WHERE id = ?');
$success = $stmt->execute(['approved', $comment_id]);
break;
case 'unapprove':
$stmt = $db->prepare('UPDATE comments SET status = ? WHERE id = ?');
$success = $stmt->execute(['pending', $comment_id]);
break;
case 'delete':
$stmt = $db->prepare('DELETE FROM comments WHERE id = ?');
$success = $stmt->execute([$comment_id]);
break;
}

if ($success) {
$redirect_params = [
'action' => 'success',
'page' => $page,
'per_page' => $per_page,
'status' => $status_filter,
'sort' => $sort_order
];
header('Location: comments.php?' . http_build_query($redirect_params));
exit;
} else {
$feedback_message = 'Action failed.';
$feedback_type = 'error';
}
} catch (PDOException $e) {
$feedback_message = 'Action failed: Database error.';
$feedback_type = 'error';
}
} else {
$feedback_message = 'Invalid action or comment ID.';
$feedback_type = 'error';
}
}

if (isset($_GET['action']) && $_GET['action'] === 'success') {
$feedback_message = 'Action completed successfully.';
$feedback_type = 'success';
}

try {
$db = get_db();
$where_clause = '';
$params = [];
if ($status_filter !== 'all') {
$where_clause = 'WHERE c.status = ?';
$params[] = $status_filter;
}

$order_by_clause = 'ORDER BY ';
switch($sort_order) {
case 'oldest': $order_by_clause .= 'c.created ASC'; break;
case 'author': $order_by_clause .= 'c.author ASC'; break;
default: $order_by_clause .= 'c.created DESC';
}

$count_sql = 'SELECT COUNT(*) FROM comments c ' . $where_clause;
$stmt_count = $db->prepare($count_sql);
$stmt_count->execute($params);
$total_comments = (int)$stmt_count->fetchColumn();
$total_pages = ceil($total_comments / $per_page);

if ($page > $total_pages && $total_pages > 0) {
$page = $total_pages;
$offset = ($page - 1) * $per_page;
} elseif ($page < 1) {
$page = 1;
$offset = 0;
}

$sql = "
SELECT c.*, p.title as post_title, 
u.username as comment_user_username
FROM comments c 
LEFT JOIN posts p ON c.post_id = p.id 
LEFT JOIN users u ON c.user_id = u.id 
{$where_clause}
{$order_by_clause}
LIMIT ? OFFSET ?
";

$stmt_comments = $db->prepare($sql);
$exec_params = $params;
$stmt_comments->bindValue(count($exec_params) + 1, $per_page, PDO::PARAM_INT);
$stmt_comments->bindValue(count($exec_params) + 2, $offset, PDO::PARAM_INT);

foreach ($exec_params as $key => $val) {
$stmt_comments->bindValue($key + 1, $val);
}

$stmt_comments->execute();
$comments_data = $stmt_comments->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
$feedback_message = 'Database error loading comments: ' . $e->getMessage();
$feedback_type = 'error';
$comments_data = []; $total_comments = 0; $total_pages = 0;
}

$pagination_params = ['per_page' => $per_page, 'status' => $status_filter, 'sort' => $sort_order];

// 调度评论管理视图
include dirname(__FILE__) . '/views/comments.php';
require_once 'foot.php';