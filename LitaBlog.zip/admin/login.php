<?php
// admin/login.php
if (!file_exists(dirname(__FILE__) . '/../config.php')) {
header('Location: install.php');
exit;
}
require_once dirname(__FILE__) . '/../includes/load.php';

if (is_logged_in()) {
header('Location: index.php');
exit;
}

$registration_enabled = (get_option('enable_registration', '1') === '1');
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'admin_login')) {
        $error = '安全令牌验证失败，请刷新页面重试。';
    } else {
$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$password = $_POST['password'] ?? '';

if (!$username || !$password) {
$error = '请填写所有字段';
} else {
try {
$db = get_db();
$stmt = $db->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password'])) {
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

$remember_days = isset($_POST['remember_me']) ? (int)$_POST['remember_me'] : 0;
if (in_array($remember_days, [1, 7, 30])) {
$seconds = $remember_days * 86400;
$expires = time() + $seconds;

$selector = bin2hex(random_bytes(12));
$validator = bin2hex(random_bytes(24));

// （兼容 PHP 7.3+ 推荐配置形式）：
setcookie('lita_remember', $selector . ':' . $validator, [
    'expires' => $expires,
    'path' => '/',
    'domain' => '', // 保持为空，由浏览器自动解析锁定为当前精确访问的 Host 域名
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax' // 预防第三方 CSRF 携带
]);

$existing_tokens = get_user_meta($user['id'], 'remember_tokens', true);
if (!is_array($existing_tokens)) {
$existing_tokens = [];
}

$existing_tokens = array_filter($existing_tokens, function($t) {
return isset($t['expires']) && $t['expires'] > time();
});

$existing_tokens[] = [
'selector' => $selector,
'hashed_validator' => hash('sha256', $validator),
'expires' => $expires
];

update_user_meta($user['id'], 'remember_tokens', $existing_tokens);
}

header('Location: index.php');
exit;
} else {
$error = '用户名或密码无效';
}
} catch (PDOException $e) {
    error_log('User Registration Database Exception: ' . $e->getMessage()); // 仅保存在服务器本地日志
    $errors[] = '数据库操作失败，请联系管理员或稍后重试。';
}
}
}
}
// 调度渲染登录页面
include dirname(__FILE__) . '/views/login.php';