<?php
// admin/profile.php
require_once 'header.php';

$feedback_message = '';
$feedback_type = '';
$user_data_for_form = [];
$current_user_id = $_SESSION['user_id'] ?? null;

if (!$current_user_id) {
header('Location: login.php'); 
exit;
}

$initial_user_data = get_user($current_user_id);
if (!$initial_user_data) {
header('Location: logout.php'); 
exit;
}
$user_data_for_form = $initial_user_data;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
if ($_POST['action'] === 'update_profile') {
$new_username = trim(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));
$new_display_name = trim(filter_input(INPUT_POST, 'display_name', FILTER_SANITIZE_STRING));
$new_email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));

$user_data_for_form['username'] = $new_username;
$user_data_for_form['display_name'] = $new_display_name;
$user_data_for_form['email'] = $new_email;

$errors = [];
if (empty($new_username)) $errors[] = '用户名不能为空。';
if (empty($new_display_name)) $errors[] = '显示名称不能为空。';
if (empty($new_email)) {
$errors[] = '电子邮箱不能为空。';
} elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
$errors[] = '电子邮箱格式不正确。';
}

if (empty($errors)) {
try {
$db = get_db();
$stmt_check = $db->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ? LIMIT 1');
$stmt_check->execute([$new_username, $new_email, $current_user_id]);
if ($stmt_check->fetch()) {
$errors[] = '用户名或电子邮箱已被其他用户使用。';
}

if (empty($errors)) {
$stmt_update = $db->prepare('UPDATE users SET username = ?, display_name = ?, email = ? WHERE id = ?');
if ($stmt_update->execute([$new_username, $new_display_name, $new_email, $current_user_id])) {
$feedback_message = '用户资料更新成功。';
$feedback_type = 'success';
if ($new_username !== $initial_user_data['username']) {
$_SESSION['username'] = $new_username;
}
$user_data_for_form = get_user($current_user_id);
} else {
$errors[] = '资料更新失败，数据库执行错误。';
}
}
} catch (PDOException $e) {
if ($e->getCode() == 23000 || strpos($e->getMessage(), 'UNIQUE constraint failed') !== false) {
$errors[] = '用户名或电子邮箱已被占用，请更换。';
} else {
$errors[] = '数据库操作失败: ' . $e->getMessage();
error_log('Profile update error: ' . $e->getMessage());
}
}
}

if (!empty($errors)) {
$feedback_message = implode('<br>', $errors);
$feedback_type = 'error';
}

} elseif ($_POST['action'] === 'change_password') {
$current_password = filter_input(INPUT_POST, 'current_password', FILTER_SANITIZE_STRING);
$new_password = filter_input(INPUT_POST, 'new_password', FILTER_SANITIZE_STRING);
$confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);
$errors = [];

if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
$errors[] = '所有密码字段均为必填项。';
} elseif ($new_password !== $confirm_password) {
$errors[] = '新密码和确认密码不匹配。';
} else {
try {
$db = get_db();
$stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
$stmt->execute([$current_user_id]);
$stored_hash = $stmt->fetchColumn();

if ($stored_hash && password_verify($current_password, $stored_hash)) {
$new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
$stmt_update = $db->prepare('UPDATE users SET password = ? WHERE id = ?');

if ($stmt_update->execute([$new_password_hash, $current_user_id])) {
$feedback_message = '密码更新成功。';
$feedback_type = 'success';
$user_data_for_form = $initial_user_data;
} else {
$errors[] = '密码更新失败，数据库错误。';
}
} else {
$errors[] = '当前密码不正确。';
}
} catch (PDOException $e) {
$errors[] = '数据库操作失败: ' . $e->getMessage();
error_log('Profile password change error: ' . $e->getMessage());
}
}

if (!empty($errors)) {
$feedback_message = implode('<br>', $errors);
$feedback_type = 'error';
}
}
}

// 调度个人资料视图
include dirname(__FILE__) . '/views/profile.php';
require_once 'foot.php';