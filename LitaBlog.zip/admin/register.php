<?php
// admin/register.php
require_once dirname(__FILE__) . '/../includes/load.php';
require_once dirname(__FILE__) . '/../includes/functions.php';

if (is_logged_in()) {
header('Location: index.php');
exit;
}

$registration_enabled = (get_option('enable_registration', '1') === '1');
$feedback_message = '';
$feedback_type = '';
$username_input = '';
$email_input = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
if (!$registration_enabled) {
$feedback_message = '用户注册功能当前已关闭。';
$feedback_type = 'error';
} else {
$username = trim(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));
$password = $_POST['password'] ?? '';
$email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));

$username_input = $username;
$email_input = $email;

$errors = [];
if (empty($username)) $errors[] = '用户名不能为空。';
if (empty($password)) $errors[] = '密码不能为空。';
if (empty($email)) {
$errors[] = '电子邮箱不能为空。';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
$errors[] = '电子邮箱格式不正确。';
}

if (empty($errors)) {
try {
$db = get_db();
$stmt_check_user = $db->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
$stmt_check_user->execute([$username]);
if ($stmt_check_user->fetch()) {
$errors[] = '用户名 "' . e($username) . '" 已被使用。';
}

if (!empty($email)) {
$stmt_check_email = $db->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$stmt_check_email->execute([$email]);
if ($stmt_check_email->fetch()) {
$errors[] = '电子邮箱 "' . e($email) . '" 已被使用。';
}
}

if (empty($errors)) {
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$stmt_insert = $db->prepare('
INSERT INTO users (username, password, email, display_name, status, role, created)
VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
');

$executed_insert = $stmt_insert->execute([
$username,
$hashed_password,
$email,
$username,
'active',
'user'
]);

if ($executed_insert) {
header('Location: login.php?registered=1');
exit;
} else {
$errors[] = '用户注册失败，数据库插入错误。';
}
}
} catch (PDOException $e) {
    error_log('User Registration Database Exception: ' . $e->getMessage()); // 仅保存在服务器本地日志
    $errors[] = '数据库操作失败，请联系管理员或稍后重试。';
}
}

if (!empty($errors)) {
$feedback_message = implode('<br>', $errors);
$feedback_type = 'error';
}
}
}

if (isset($_GET['registered']) && $_GET['registered'] == 1) {
$feedback_message = '用户注册成功！请登录。';
$feedback_type = 'success';
}

// 调度注册视图
include dirname(__FILE__) . '/views/register.php';