<?php
// admin/index.php
require_once 'header.php';

$feedback_message = '';
$feedback_type = '';
$items_data = [];
$total_items = 0;
$total_pages = 0;

// 【核心修改】：废除 'all'，默认强制为 'post'
$valid_types = ['post', 'page'];
$type = isset($_GET['type']) && in_array($_GET['type'], $valid_types) ? $_GET['type'] : 'post';

// 优化中文标题前缀
$title_prefix = ($type === 'page') ? '独立页面' : '文章';

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = isset($_GET['per_page']) ? max(5, min(100, intval($_GET['per_page']))) : 20;
$status_filter = isset($_GET['status']) && in_array($_GET['status'], ['publish', 'draft', 'all']) ? $_GET['status'] : 'all';
$sort_order = isset($_GET['sort']) && in_array($_GET['sort'], ['newest', 'oldest', 'title', 'author']) ? $_GET['sort'] : 'newest';
$offset = ($page - 1) * $per_page;

$current_user_id = is_logged_in() ? $_SESSION['user_id'] : null;
$is_administrator = is_admin();

// ----- 下方的删除逻辑和查询逻辑保持不变，只需稍作精简 -----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && isset($_POST['content_id'])) {
    $content_id = filter_input(INPUT_POST, 'content_id', FILTER_SANITIZE_NUMBER_INT);
    $db = get_db();
    if ($content_id > 0) {
        try {
            $db->beginTransaction();
            $stmt_check_owner = $db->prepare('SELECT author FROM posts WHERE id = ?');
            $stmt_check_owner->execute([$content_id]);
            $item_author_id = $stmt_check_owner->fetchColumn();

            if (!$is_administrator && $item_author_id != $current_user_id) {
                $db->rollBack();
                $feedback_message = "您无权删除此内容。";
                $feedback_type = 'error';
            } else {
                $stmt_del_cat = $db->prepare('DELETE FROM post_categories WHERE post_id = ?');
                $stmt_del_cat->execute([$content_id]);
                $stmt_del_tag = $db->prepare('DELETE FROM post_tags WHERE post_id = ?');
                $stmt_del_tag->execute([$content_id]);

                $stmt_delete = $db->prepare('DELETE FROM posts WHERE id = ?');
                if ($stmt_delete->execute([$content_id])) {
                    $db->commit();
                    $redirect_params = ['type' => $type, 'deleted' => 1, 'page' => $page, 'per_page' => $per_page, 'status' => $status_filter, 'sort' => $sort_order];
                    if (!$is_administrator && $type !== 'post') $redirect_params['type'] = 'post';
                    header('Location: index.php?' . http_build_query($redirect_params));
                    exit;
                } else {
                    $db->rollBack();
                    $feedback_message = $title_prefix . ' 删除失败。';
                    $feedback_type = 'error';
                }
            }
        } catch (PDOException $e) {
            $db->rollBack();
            $feedback_message = '数据库错误，删除失败。';
            $feedback_type = 'error';
        }
    }
}

if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
    $feedback_message = $title_prefix . ' 已成功删除。';
    $feedback_type = 'success';
} elseif (isset($_GET['created']) && $_GET['created'] == 1) {
    $feedback_message = $title_prefix . ' 发布成功！';
    $feedback_type = 'success';
} elseif (isset($_GET['error'])) {
    $feedback_message = ($_GET['error'] === 'notfound') ? '未找到请求的项目。' : '您无权访问该页面。';
    $feedback_type = 'warning';
}

try {
    $db = get_db();
    $where_conditions = [];
    $params = [];

    if (!$is_administrator) {
        $where_conditions[] = 'posts.author = ?';
        $params[] = $current_user_id;
        $type = 'post'; // 强制非管理员只能看 post
        $title_prefix = '文章';
    }

    // 此时 $type 必为 'post' 或 'page'
    $where_conditions[] = 'posts.type = ?';
    $params[] = $type;

    if ($status_filter !== 'all') {
        $where_conditions[] = 'posts.status = ?';
        $params[] = $status_filter;
    }
    
    $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

    $order_by_clause = 'ORDER BY ';
    switch($sort_order) {
        case 'oldest': $order_by_clause .= 'posts.created ASC'; break;
        case 'title': $order_by_clause .= 'posts.title ASC'; break;
        case 'author': $order_by_clause .= ($is_administrator) ? 'users.username ASC' : 'posts.created DESC'; break;
        default: $order_by_clause .= 'posts.created DESC';
    }

    $count_sql = 'SELECT COUNT(posts.id) FROM posts ';
    if ($sort_order === 'author' && $is_administrator) $count_sql .= 'LEFT JOIN users ON posts.author = users.id ';
    $count_sql .= $where_clause;

    $stmt_count = $db->prepare($count_sql);
    $stmt_count->execute($params);
    $total_items = (int)$stmt_count->fetchColumn();
    $total_pages = ceil($total_items / $per_page);

    if ($page > $total_pages && $total_pages > 0) { $page = $total_pages; $offset = ($page - 1) * $per_page; }
    elseif ($page < 1) { $page = 1; $offset = 0; }

    $sql = "SELECT posts.id, posts.title, posts.status, posts.created, posts.type, posts.author, users.username as author_name 
            FROM posts LEFT JOIN users ON posts.author = users.id 
            {$where_clause} {$order_by_clause} LIMIT ? OFFSET ?";
    
    $stmt_items = $db->prepare($sql);
    $param_index = 1;
    foreach ($params as $val) $stmt_items->bindValue($param_index++, $val);
    $stmt_items->bindValue($param_index++, (int)$per_page, PDO::PARAM_INT);
    $stmt_items->bindValue($param_index++, (int)$offset, PDO::PARAM_INT);
    $stmt_items->execute();
    
    $items_data = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $feedback_message = '数据库错误: ' . $e->getMessage();
    $feedback_type = 'error';
}

$pagination_params = ['type' => $type, 'per_page' => $per_page, 'status' => $status_filter, 'sort' => $sort_order];

// 调用渲染视图
include dirname(__FILE__) . '/views/dashboard.php';
require_once 'foot.php';
?>