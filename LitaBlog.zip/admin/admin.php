<?php
// admin/admin.php - Plugin Page Dispatcher

// 1. Load Core and Admin Environment
// Ensure this path is correct to load your main admin header logic
// which should include config, functions, session, login check etc.
require_once 'header.php'; // This will perform login checks etc.

// 2. Get the requested page slug
$page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : ''; // Sanitize input

// 3. Find the registered function/file for this page slug
global $admin_menu, $admin_submenu;
$page_to_render_callback = null;
$page_title_for_render = '后台管理'; // Default title

// Check top-level menus
if (!empty($admin_menu)) {
foreach ($admin_menu as $menu_item) {
if ($menu_item[2] === $page_slug) {
// Check capability again before rendering
if ($menu_item[1] === 'manage_options' && !is_admin()) {
echo '<div class="content"><div class="alert alert-danger">您没有权限访问此页面。</div></div>';
require_once 'foot.php';
exit;
}
$page_to_render_callback = $menu_item[4]; // Function or file path
$page_title_for_render = $menu_item[3]; // Page Title
break;
}
}
}

// Check submenus if not found in top-level
if (!$page_to_render_callback && !empty($admin_submenu)) {

foreach ($admin_submenu as $parent_slug => $sub_items) {
foreach ($sub_items as $submenu_item) {
if ($submenu_item[2] === $page_slug) {
if ($submenu_item[1] === 'manage_options' && !is_admin()) {
echo '<div class="content"><div class="alert alert-danger">您没有权限访问此页面。</div></div>';
require_once 'foot.php';
exit;
}
$page_to_render_callback = $submenu_item[4];
$page_title_for_render = $submenu_item[3];
break 2; // Break both loops
}
}
}
}

// 4. Render the page content
?>
<div class="card"> <?php // Standard content wrapper from Small Blog's admin pages ?>
<h1><?php echo e($page_title_for_render); ?></h1>
<?php
if ($page_to_render_callback) {
if (is_callable($page_to_render_callback)) {
call_user_func($page_to_render_callback);
} elseif (is_string($page_to_render_callback) && file_exists($page_to_render_callback)) {
// If it's a file path (e.g., relative to plugin dir)
// This requires careful path construction or convention.
// Example: plugin registers 'my-plugin/admin/settings-page.php'
// $plugin_base_path = ABSPATH . 'content/plugins/';
// include $plugin_base_path . $page_to_render_callback;
// For now, let's assume $function is a callable or we show an error.
// A better approach for file paths is to make the plugin callable wrap an include.
echo '<div class="alert alert-warning">页面回调 "'.$page_to_render_callback.'" 不是一个有效的函数或未能找到文件。</div>';
} else {
echo '<div class="alert alert-warning">无法加载页面内容。回调函数或文件路径无效。</div>';
}
} else {
// If no specific page is requested via ?page= or slug not found,
// you might redirect to admin dashboard or show a default message.
// For now, if it reaches here and $page_slug was empty, it means direct access to admin.php
// If $page_slug was set but not found, it's an invalid plugin page.
if (empty($page_slug)) {
echo '<p>请从左侧菜单选择一个管理选项。</p>'; // Or redirect to index.php
} else {
echo '<div class="alert alert-danger">请求的管理页面 "'.e($page_slug).'" 未找到。</div>';
}
}
?>
</div>
<?php
require_once 'foot.php'; // Admin footer
?>
<?php // --- END OF FILE admin/admin.php --- (This replaces the logic of admin/index.php if you want a single dispatcher)

// Helper function (add to functions.php or keep here if admin.php is standalone)
if (!function_exists('sanitize_text_field')) {
function sanitize_text_field($str) {
$filtered = trim($str);
// Add more sanitization as needed, e.g., strip_tags, or specific character removal
// For a slug, more aggressive sanitization is needed. For a general text field,
// htmlspecialchars on output is key.
return $filtered;
}
}
?>