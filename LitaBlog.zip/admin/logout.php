<?php
// 引入全局引导文件以获取相同的 session_name() 和 cookie 配置
require_once dirname(__FILE__) . '/../includes/load.php';

// --- 新增：注销时清理持久化 Token 记录 ---
if (isset($_COOKIE['lita_remember'])) {
$parts = explode(':', $_COOKIE['lita_remember'], 2);
if (count($parts) === 2) {
$selector = $parts[0];
try {
$db = get_db();
$stmt = $db->prepare("SELECT user_id, meta_value FROM usermeta WHERE meta_key = 'remember_tokens'");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($rows as $row) {
$tokens = unserialize($row['meta_value']);
if (is_array($tokens)) {
$new_tokens = array_filter($tokens, function($t) use ($selector) {
return $t['selector'] !== $selector;
});
if (count($new_tokens) !== count($tokens)) {
update_user_meta($row['user_id'], 'remember_tokens', $new_tokens);
}
}
}
} catch (Exception $e) {
error_log("Error clearing token on logout: " . $e->getMessage());
}
}
// 清除客户端 Cookie
setcookie('lita_remember', '', time() - 3600, '/');
}
// --- 结束 ---

// 清空 Session 内存数据
$_SESSION = array();

// 显式向浏览器发送过期 Cookie，通知浏览器立即删除该会话 Cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// 销毁服务器端会话文件
session_destroy();

// 重定向到首页
header('Location: ../index.php');
exit;