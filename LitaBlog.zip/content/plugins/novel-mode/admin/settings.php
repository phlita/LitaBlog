<?php
if (!defined('ABSPATH')) exit;

/**
 * 添加 "小说模式" 到后台顶级菜单
 */
function novel_mode_add_settings_menu() {
    add_menu_page(
        '小说模式设置',
        '小说模式',
        'manage_options',
        'novel-mode-settings',
        'novel_mode_render_settings_page',
        'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v15H6.5A2.5 2.5 0 0 1 4 14.5v-10A2.5 2.5 0 0 1 6.5 2z"></path></svg>'),
        30
    );
}
add_action('admin_menu', 'novel_mode_add_settings_menu');


/**
 * 渲染小说模式设置页面
 */
function novel_mode_render_settings_page() {
    // --- 修正与优化：处理表单提交 ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf_token'])) {
        // 步骤 1: 使用正确的函数验证 CSRF token
        if (verifyCsrfToken($_POST['csrf_token'], 'novel_mode_settings_action')) {
            $selected_categories = isset($_POST['novel_categories']) && is_array($_POST['novel_categories'])
                ? array_map('intval', $_POST['novel_categories'])
                : [];

            update_option('novel_mode_categories', json_encode($selected_categories));
            set_flash_message('小说分类设置已保存。', 'success');
        } else {
            set_flash_message('安全验证失败，请重试。', 'error');
        }
        
        // 步骤 2: 采用 PRG 模式，处理完后立即重定向，防止重复提交
        // 这会刷新页面，并在新页面上显示 flash message
        $redirect_url = SITE_URL . '/admin/admin.php?page=novel-mode-settings';
        header('Location: ' . $redirect_url);
        exit; // 必须 exit 来终止当前脚本执行
    }

    // --- 显示页面的逻辑 (保持不变) ---
    $all_categories = [];
    try {
        $db = get_db();
        $stmt = $db->query('SELECT id, name FROM categories ORDER BY name');
        $all_categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // 如果数据库出错，也应该显示一个 flash message
        set_flash_message('无法加载分类列表：' . $e->getMessage(), 'error');
    }

    $saved_novel_cat_ids = json_decode(get_option('novel_mode_categories', '[]'), true);
    if (!is_array($saved_novel_cat_ids)) $saved_novel_cat_ids = [];

    ?>
    <div class="card">
        <h1>小说模式设置</h1>
        
        <?php display_flash_message(); // 这个函数现在会在重定向后的新页面上正确显示消息 ?>

        <p>请选择哪些文章分类应被视为“小说”。只有被选中的分类下的文章才会启用章节导航和阅读器功能。</p>
        
        <form method="post">
            <?php // 步骤 3: 使用正确的函数生成 CSRF token 字段 ?>
            <?php csrf_token_field('novel_mode_settings_action'); ?>

            <div class="form-group">
                <label><strong>选择小说分类:</strong></label>
                <?php if (empty($all_categories)): ?>
                    <p>还没有创建任何分类。</p>
                <?php else: ?>
                    <div class="checkbox-group">
                        <?php foreach ($all_categories as $category): ?>
                            <label>
                                <input type="checkbox" name="novel_categories[]" value="<?php echo $category['id']; ?>"
                                    <?php echo in_array($category['id'], $saved_novel_cat_ids) ? 'checked' : ''; ?>>
                                <?php echo e($category['name']); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <button type="submit" class="button btn-primary">保存设置</button>
        </form>
    </div>
    <?php
}