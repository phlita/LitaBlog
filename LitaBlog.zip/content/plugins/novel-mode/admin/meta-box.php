<?php
if (!defined('ABSPATH')) exit;

/**
 * 在文章编辑页面添加 "小说章节设置" Meta Box
 */
function novel_mode_add_meta_box($post_type, $post_data) {
    // 只在 'post' 类型的编辑页显示
    if ($post_type === 'post') {
        // 获取当前文章保存的章节序号
		$post_id = isset($_GET['id']) ? (int)$_GET['id'] : null;
		 if (!$post_id && isset($post_data['id'])) {        $post_id = (int)$post_data['id'];    }
        $chapter_order = $post_id ? get_post_meta($post_id, '_novel_chapter_order', true) : '';
        
        // 使用输出缓冲来构建HTML
        ob_start();
        ?>
        <div class="form-group">
            <label for="novel_chapter_order"><strong>章节序号:</strong></label>
            <input type="number" id="novel_chapter_order" name="novel_chapter_order" value="<?php echo e($chapter_order); ?>" min="1" step="1" />
            <p class="description">为这篇文章设置在小说中的顺序。例如：1, 2, 3... 留空或为0则不作为章节处理。</p>
        </div>
        <?php
        $html = ob_get_clean();
        
        // 简单地直接输出，因为 LitaBlog 没有 add_meta_box() 函数
        echo '<div class="litapay-meta-box-section">' . $html . '</div>'; // 复用一个现有样式
    }
}
add_action('do_meta_boxes', 'novel_mode_add_meta_box', 10, 2);

/**
 * 保存文章时，保存小说章节序号
 */
function novel_mode_save_meta_box_data($post_id, $post_data_submitted) {
	

	
    if (isset($_POST['novel_chapter_order'])) {
        $chapter_number = trim($_POST['novel_chapter_order']);
        
        if ($chapter_number === '' || (int)$chapter_number <= 0) {
            // 如果输入为空或小于1，则删除该 meta
            delete_post_meta($post_id, '_novel_chapter_order');
        } else {
            // 否则，更新或添加 meta
            update_post_meta($post_id, '_novel_chapter_order', (int)$chapter_number);
        }
    }
}
add_action('save_post', 'novel_mode_save_meta_box_data', 10, 2);