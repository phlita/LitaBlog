<?php
if (!defined('ABSPATH')) exit;

/**
 * 在前端页头加载插件CSS
 */
function novel_mode_enqueue_frontend_styles() {
    wp_register_style(
        'novel-mode-frontend-css',
        NOVEL_MODE_PLUGIN_URL . 'public/css/novel-mode-frontend.css',
        [],
        '1.0'
    );
    wp_enqueue_style('novel-mode-frontend-css');
}

/**
 * 在前端页脚加载插件JS
 */
function novel_mode_enqueue_frontend_scripts() {
    wp_register_script(
        'novel-mode-frontend-js',
        NOVEL_MODE_PLUGIN_URL . 'public/js/novel-mode-frontend.js',
        [],
        '1.0',
        true // true 表示在页脚加载
    );
    wp_enqueue_script('novel-mode-frontend-js');
}

/**
 * 检查文章是否为小说章节
 * @param int $post_id
 * @param array &$post_categories (引用传递，避免重复查询)
 * @return bool|array 返回小说分类信息数组，或 false
 */
function is_novel_chapter($post_id, &$post_categories) {
    if (empty($post_id)) return false;
    
    $novel_cat_ids_json = get_option('novel_mode_categories', '[]');
    $novel_cat_ids = json_decode($novel_cat_ids_json, true);

    if (empty($novel_cat_ids) || !is_array($novel_cat_ids)) {
        return false;
    }
    
    $post_categories = get_post_categories($post_id);
    if (empty($post_categories)) {
        return false;
    }

    foreach ($post_categories as $category) {
        if (in_array($category['id'], $novel_cat_ids)) {
            return $category; // 找到第一个匹配的小说分类即可
        }
    }
    
    return false;
}

/**
 * 在文章内容末尾添加章节导航
 * @param string $content 原始内容
 * @param int $post_id 当前文章ID
 * @return string 修改后的内容
 */
function novel_mode_add_chapter_navigation($content, $post_id) {
if (empty($post_id)) {
    return $content;
}

    $post_categories = [];
    $novel_category = is_novel_chapter($post_id, $post_categories);
    
    $chapter_order = (int) get_post_meta($post_id, '_novel_chapter_order', true);

	

	
    if (!$novel_category || $chapter_order <= 0) {
        return $content;
    }
    
    $db = get_db();
    $prev_post = null;
    $next_post = null;

    // 查询上一章
    $stmt_prev = $db->prepare("
        SELECT p.id, p.title FROM posts p
        JOIN postmeta pm ON p.id = pm.post_id
        JOIN post_categories pc ON p.id = pc.post_id
        WHERE pc.category_id = :cat_id
        AND pm.meta_key = '_novel_chapter_order'
AND CAST(pm.meta_value AS INTEGER) = :prev_order
        AND p.status = 'publish' LIMIT 1
    ");
    $stmt_prev->execute([':cat_id' => $novel_category['id'], ':prev_order' => $chapter_order - 1]);
    $prev_post = $stmt_prev->fetch(PDO::FETCH_ASSOC);

    // 查询下一章
    $stmt_next = $db->prepare("
        SELECT p.id, p.title FROM posts p
        JOIN postmeta pm ON p.id = pm.post_id
        JOIN post_categories pc ON p.id = pc.post_id
        WHERE pc.category_id = :cat_id
        AND pm.meta_key = '_novel_chapter_order'
AND CAST(pm.meta_value AS INTEGER) = :next_order
        AND p.status = 'publish' LIMIT 1
    ");
    $stmt_next->execute([':cat_id' => $novel_category['id'], ':next_order' => $chapter_order + 1]);
    $next_post = $stmt_next->fetch(PDO::FETCH_ASSOC);

    // 构建导航HTML
    ob_start();
    ?>
    <nav class="novel-navigation">
        <div class="nav-link prev">
            <?php if ($prev_post): ?>
                <a href="<?php echo Permalink::get_post_link($prev_post['id']); ?>">
                    <span>« 上一章</span>
                    <span class="nav-title"><?php echo e($prev_post['title']); ?></span>
                </a>
            <?php else: ?>
                <span>已是第一章</span>
            <?php endif; ?>
        </div>
        <div class="nav-link toc">
            <a href="<?php echo SITE_URL . '/?category=' . e($novel_category['slug']); ?>">
                <span>返回目录</span>
            </a>
        </div>
        <div class="nav-link next">
            <?php if ($next_post): ?>
                <a href="<?php echo Permalink::get_post_link($next_post['id']); ?>">
                    <span>下一章 »</span>
                    <span class="nav-title"><?php echo e($next_post['title']); ?></span>
                </a>
            <?php else: ?>
                <span>已是最新章</span>
            <?php endif; ?>
        </div>
    </nav>
    <?php
    $navigation_html = ob_get_clean();
    
    return $content . $navigation_html;
}

/**
 * 在页脚输出阅读器工具的HTML结构
 */
function novel_mode_add_reader_tools_html() {
    global $template_data;
    if (($template_data['request_type'] ?? '') !== 'single') {
        return;
    }
    
    $post_id = $template_data['post']['id'] ?? null;
    $post_categories = [];
    if (!is_novel_chapter($post_id, $post_categories)) {
        return;
    }

    // 只在小说章节页面输出
    ?>
    <div class="reader-tools-toggle" id="reader-tools-toggle" title="阅读设置">
        <span>A</span>
    </div>
    <div class="reader-tools-panel" id="reader-tools-panel">
        <div class="tool-group font-size-group">
            <div class="tool-label">字号</div>
            <button data-size="small">小</button>
            <button data-size="medium" class="active">中</button>
            <button data-size="large">大</button>
        </div>
        <div class="tool-group theme-group">
            <div class="tool-label">背景</div>
            <button data-theme="default" class="active" style="background-color: #fdfaf7;"></button>
            <button data-theme="sepia" style="background-color: #f3eace;"></button>
            <button data-theme="dark" style="background-color: #1e1e1e;"></button>
        </div>
    </div>
    <?php
}