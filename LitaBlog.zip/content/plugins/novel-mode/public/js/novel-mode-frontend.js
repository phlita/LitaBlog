document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('reader-tools-toggle');
    const panel = document.getElementById('reader-tools-panel');
    const contentArea = document.querySelector('.entry-content');
    const body = document.body;

    if (!toggleButton || !panel || !contentArea) {
        return; // 如果关键元素不存在，则不执行任何操作
    }

    // --- Panel Visibility ---
    toggleButton.addEventListener('click', () => {
        panel.classList.toggle('visible');
    });

    // Click outside to close
    document.addEventListener('click', (event) => {
        if (!panel.contains(event.target) && !toggleButton.contains(event.target)) {
            panel.classList.remove('visible');
        }
    });


    // --- Settings Logic ---
    const settings = {
        fontSize: 'medium',
        theme: 'default'
    };
    const storageKey = 'novelReaderSettings';

    // Load saved settings
    function loadSettings() {
        const saved = localStorage.getItem(storageKey);
        if (saved) {
            Object.assign(settings, JSON.parse(saved));
        }
        applySettings();
    }

    // Apply current settings to the DOM
    function applySettings() {
        // Apply font size
        contentArea.classList.remove('font-size-small', 'font-size-medium', 'font-size-large');
        contentArea.classList.add(`font-size-${settings.fontSize}`);
        
        // Apply theme
        body.classList.remove('reader-theme-sepia', 'reader-theme-dark');
        if (settings.theme !== 'default') {
            body.classList.add(`reader-theme-${settings.theme}`);
        }

        // Update active buttons in panel
        updateActiveButtons();
    }
    
    // Save settings to localStorage
    function saveSettings() {
        localStorage.setItem(storageKey, JSON.stringify(settings));
    }
    
    // Update which buttons look "active"
    function updateActiveButtons() {
        // Font size
        panel.querySelectorAll('.font-size-group button').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.size === settings.fontSize);
        });
        // Theme
        panel.querySelectorAll('.theme-group button').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.theme === settings.theme);
        });
    }

    // --- Event Listeners for controls ---
    panel.addEventListener('click', (event) => {
        const target = event.target;
        if (target.tagName !== 'BUTTON' || !target.dataset) return;

        const size = target.dataset.size;
        const theme = target.dataset.theme;

        if (size) {
            settings.fontSize = size;
        }
        if (theme) {
            settings.theme = theme;
        }
        
        applySettings();
        saveSettings();
    });
    
    // Initial load
    loadSettings();
});