<?php
// if uninstall.php is not called by LitaBlog's core uninstall process, exit
if (!defined('ABSPATH') && !defined('SBP_UNINSTALL_PLUGIN')) {
    die;
}

// 确保核心函数已加载
if (file_exists(dirname(__FILE__) . '/../../../config.php')) {
    require_once dirname(__FILE__) . '/../../../config.php';
}
if (defined('ABSPATH') && file_exists(ABSPATH . 'includes/functions.php')) {
    require_once ABSPATH . 'includes/functions.php';
} else {
    // 无法加载核心函数，无法继续
    return;
}

// 删除插件创建的选项
delete_option('novel_mode_categories');

// 未来如果添加更多选项，也在这里删除
// delete_option('another_novel_mode_option');