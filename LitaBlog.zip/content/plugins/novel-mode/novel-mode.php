<?php
/**
 * Plugin Name: 小说模式 (Novel Mode)
 * Description: 将文章分类作为小说合集，通过自定义字段设置章节顺序，并在前端提供章节导航和阅读器增强功能。
 * Version: 1.0
 * Author: Lita
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// 定义插件常量
define('NOVEL_MODE_PLUGIN_DIR', __DIR__ . '/');
define('NOVEL_MODE_PLUGIN_URL', rtrim(SITE_URL, '/') . '/content/plugins/novel-mode/');

// 包含后台和前端功能文件
require_once NOVEL_MODE_PLUGIN_DIR . 'admin/settings.php';
require_once NOVEL_MODE_PLUGIN_DIR . 'admin/meta-box.php';
require_once NOVEL_MODE_PLUGIN_DIR . 'public/frontend.php';

/**
 * 插件激活时执行的函数
 * 设置默认选项
 */
function novel_mode_activate() {
    // 默认没有小说分类，需要用户手动选择
    $existing_option = get_option('novel_mode_categories');
    if ($existing_option === false || $existing_option === '') {
        update_option('novel_mode_categories', json_encode([]));
    }
}
register_activation_hook(__FILE__, 'novel_mode_activate');


/**
 * 初始化插件，注册所有钩子
 */
function novel_mode_init() {
    // 注册前端资源 (CSS 和 JS)
    add_action('header', 'novel_mode_enqueue_frontend_styles');
    add_action('wp_footer', 'novel_mode_enqueue_frontend_scripts');

    // 在文章内容末尾添加章节导航
    add_filter('the_content', 'novel_mode_add_chapter_navigation', 20, 2); // 较高优先级，在其他内容过滤器之后

    // 在页脚添加阅读器工具的 HTML
    add_action('wp_footer', 'novel_mode_add_reader_tools_html');
}
add_action('init', 'novel_mode_init');