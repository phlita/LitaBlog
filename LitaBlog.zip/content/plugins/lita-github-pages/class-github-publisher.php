<?php
class LitaGithubPublisher {
    private $build_dir;
    private $username;
    private $repo;
    private $branch;
    private $token;
    private $push_method;

    public function __construct() {
        $this->build_dir  = ABSPATH . 'content/static_build';
        $this->username   = get_option('lita_gh_username');
        $this->repo       = get_option('lita_gh_repo');
        $this->branch     = get_option('lita_gh_branch', 'main');
        $this->token      = get_option('lita_gh_token');
        $this->push_method = get_option('lita_gh_push_method', 'api');
    }

    public function deploy() {
        if (empty($this->username) || empty($this->repo) || empty($this->token)) {
            throw new Exception("GitHub 同步参数未完全配置，请前往设置面板确认。");
        }

        if ($this->push_method === 'cli') {
            return $this->deploy_via_cli();
        } else {
            return $this->deploy_via_api();
        }
    }

    /**
     * 策略 A：Git CLI 传输支持
     */
    private function deploy_via_cli() {
        if (!function_exists('exec')) {
            throw new Exception("服务器 PHP 的 exec 执行函数被禁用。请改用 API 推送模式。");
        }

        $git_version = @shell_exec('git --version');
        if (empty($git_version)) {
            throw new Exception("服务器系统层级未部署 Git 运行环境，无法调用 CLI 推送。");
        }

        $cmds = [
            "cd " . escapeshellarg($this->build_dir),
            "git init",
            "git config user.name 'LitaBlog Static Publisher'",
            "git config user.email 'publisher@lita.eu.org'",
            "git checkout -b " . escapeshellarg($this->branch),
            "git add .",
            "git commit -m 'Site updated at " . date('Y-m-d H:i:s') . "'",
            "git push --force https://" . urlencode($this->username) . ":" . urlencode($this->token) . "@github.com/" . urlencode($this->username) . "/" . urlencode($this->repo) . ".git " . escapeshellarg($this->branch)
        ];

        $output = [];
        $return_var = 0;
        $full_cmd = implode(" && ", $cmds);
        @exec($full_cmd, $output, $return_var);

        if ($return_var !== 0) {
            error_log("Git CLI Deploy Fail: " . implode("\n", $output));
            return false;
        }

        return true;
    }

    /**
     * 策略 B：纯 PHP 的 GitHub API（Git Data 树级合并单次提交）
     */
    private function deploy_via_api() {
        $files = $this->get_files_flat_list($this->build_dir);
        if (empty($files)) {
            throw new Exception("静态编译构建目录未产出任何有效资源。");
        }

        // 1. 读取分支当前的最新 Commit
        $ref_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/refs/heads/{$this->branch}";
        
        $base_tree_sha = null;
        $parent_commit_sha = null;

        try {
            $ref_res = $this->send_curl_request($ref_url, 'GET');
            if (isset($ref_res['object']['sha'])) {
                $parent_commit_sha = $ref_res['object']['sha'];
                $commit_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/commits/{$parent_commit_sha}";
                $commit_res = $this->send_curl_request($commit_url, 'GET');
                if (isset($commit_res['tree']['sha'])) {
                    $base_tree_sha = $commit_res['tree']['sha'];
                }
            }
        } catch (Exception $e) {
            // 分支未创建或是一个全新的仓库时，捕获异常，视为初次初始化提交
            error_log("GitHub branch pointer may not exist yet, initializing first commit: " . $e->getMessage());
        }

        // 2. 依次遍历创建 Blob 文件镜像
        $tree_nodes = [];
        foreach ($files as $file) {
            $local_path = $file['full_path'];
            $repo_path = $file['relative_path'];
            $content = file_get_contents($local_path);

            $blob_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/blobs";
            $blob_payload = [
                'content' => base64_encode($content),
                'encoding' => 'base64'
            ];
            $blob_res = $this->send_curl_request($blob_url, 'POST', $blob_payload);

            if (isset($blob_res['sha'])) {
                $tree_nodes[] = [
                    'path' => $repo_path,
                    'mode' => '100644',
                    'type' => 'blob',
                    'sha'  => $blob_res['sha']
                ];
            }
        }

        if (empty($tree_nodes)) {
            throw new Exception("构建的本地文件特征树无有效子叶节点。");
        }

        // 3. 构建新的整体静态 Git 节点树 (Git Tree)
        $new_tree_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/trees";
        $new_tree_payload = ['tree' => $tree_nodes];
        if ($base_tree_sha) {
            $new_tree_payload['base_tree'] = $base_tree_sha;
        }
        $new_tree_res = $this->send_curl_request($new_tree_url, 'POST', $new_tree_payload);
        if (!isset($new_tree_res['sha'])) {
            throw new Exception("GitHub 无法构建目录结构。");
        }
        $new_tree_sha = $new_tree_res['sha'];

        // 4. 创建 Commit 对象
        $new_commit_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/commits";
        $new_commit_payload = [
            'message' => 'Site static assets updated at ' . date('Y-m-d H:i:s'),
            'tree'    => $new_tree_sha
        ];
        if ($parent_commit_sha) {
            $new_commit_payload['parents'] = [$parent_commit_sha];
        }
        $new_commit_res = $this->send_curl_request($new_commit_url, 'POST', $new_commit_payload);
        if (!isset($new_commit_res['sha'])) {
            throw new Exception("打包生成提交对象错误。");
        }
        $new_commit_sha = $new_commit_res['sha'];

        // 5. 更新分支指针（修复此前未读取 object.sha 的逻辑缺陷）
        $ref_update_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/refs/heads/{$this->branch}";
        $ref_update_payload = [
            'sha' => $new_commit_sha,
            'force' => true
        ];

        $method = ($parent_commit_sha) ? 'PATCH' : 'POST';
        if ($method === 'POST') {
             $ref_update_url = "https://api.github.com/repos/{$this->username}/{$this->repo}/git/refs";
             $ref_update_payload = [
                 'ref' => "refs/heads/{$this->branch}",
                 'sha' => $new_commit_sha
             ];
        }

        $ref_update_res = $this->send_curl_request($ref_update_url, $method, $ref_update_payload);
        
        // 核心修正：同时兼容 PATCH/POST 成功返回结果包中的 sha 判断，彻底解决误报失败的问题
        return isset($ref_update_res['object']['sha']) || isset($ref_update_res['ref']);
    }

    private function get_files_flat_list($dir, $relative_prefix = '') {
        $result = [];
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $full_path = $dir . '/' . $file;
            $relative_path = ($relative_prefix === '') ? $file : $relative_prefix . '/' . $file;
            if (is_dir($full_path)) {
                $result = array_merge($result, $this->get_files_flat_list($full_path, $relative_path));
            } else {
                $result[] = [
                    'full_path'     => $full_path,
                    'relative_path' => $relative_path
                ];
            }
        }
        return $result;
    }

    private function send_curl_request($url, $method = 'GET', $data = null) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'LitaBlog-Pages-Publisher/1.2');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        // 设置合理的网络超时，防止大附件上传时卡死
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);

        $headers = [
            "Authorization: token {$this->token}",
            "Accept: application/vnd.github.v3+json"
        ];

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                $headers[] = "Content-Type: application/json";
            }
        } elseif ($method === 'PATCH') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                $headers[] = "Content-Type: application/json";
            }
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            $err_msg = curl_error($ch);
            curl_close($ch);
            throw new Exception("向 GitHub 发起连接时发生网络错误: " . $err_msg);
        }
        curl_close($ch);

        $result_data = json_decode($response, true);
        if ($http_code >= 400) {
            $error_detail = isset($result_data['message']) ? $result_data['message'] : '未知校验失败';
            throw new Exception("GitHub API 返回故障 (代码 {$http_code}): " . $error_detail);
        }

        return $result_data;
    }
}
?>