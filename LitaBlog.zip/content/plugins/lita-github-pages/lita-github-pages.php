<?php
/**
 * Plugin Name: Lita GitHub Pages Publisher
 * Plugin URI: https://lita.eu.org/
 * Description: 完美优化版：将 LitaBlog 导出为高兼容的静态 HTML 并部署至 GitHub Pages。支持自动重定向（Headless 模式）和静态分页兼容。
 * Version: 1.2
 * Author: 芙里塔
 * Author URI: https://blog.lita.eu.org/
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/class-static-generator.php';
require_once __DIR__ . '/class-github-publisher.php';

// 初始化默认配置
add_action('init', 'lita_gh_publisher_init_options');
function lita_gh_publisher_init_options() {
    if (get_option('lita_gh_publish_mode') === '') update_option('lita_gh_publish_mode', 'dual');
    if (get_option('lita_gh_push_method') === '') update_option('lita_gh_push_method', 'api');
    if (get_option('lita_gh_branch') === '') update_option('lita_gh_branch', 'main');
    if (get_option('lita_gh_auto_sync') === '') update_option('lita_gh_auto_sync', '0');
}

// 注册后台菜单
add_action('admin_menu', 'lita_gh_publisher_menu');
function lita_gh_publisher_menu() {
    add_menu_page(
        'GitHub Pages 部署',
        'GitHub 部署',
        'manage_options',
        'lita-gh-publisher',
        'lita_gh_publisher_settings_page'
    );
}

function lita_gh_publisher_settings_page() {
    require_once __DIR__ . '/admin-settings.php';
}

// 自动发布逻辑：在 PHP 进程即将结束（shutdown）时静默执行，防止阻塞后台和事务未提交问题
add_action('save_post', 'lita_gh_auto_publish_scheduler', 20, 2);
function lita_gh_auto_publish_scheduler($post_id, $post_data) {
    if (get_option('lita_gh_auto_sync') !== '1') return;
    if (isset($post_data['status']) && $post_data['status'] !== 'publish') return;

    // 注册进程退出时的异步任务
    register_shutdown_function('lita_gh_background_deploy');
}

function lita_gh_background_deploy() {
    try {
        $generator = new LitaStaticGenerator();
        $generator->generate_all();

        $publisher = new LitaGithubPublisher();
        $publisher->deploy();
    } catch (Exception $e) {
        error_log("LitaBlog Auto Deploy Error on shutdown: " . $e->getMessage());
    }
}

// 内容管理模式（Headless CMS）重定向逻辑
add_action('before_render_template_action', 'lita_gh_headless_redirect_handler', 10, 2);
function lita_gh_headless_redirect_handler($template_file_name, $template_data) {
    if (get_option('lita_gh_publish_mode') === 'headless') {
        if (!is_logged_in()) {
            $username = get_option('lita_gh_username');
            $repo = get_option('lita_gh_repo');
            $cname = get_option('lita_gh_cname');

            if (!empty($cname)) {
                $target_domain = 'https://' . rtrim($cname, '/');
            } elseif (!empty($username) && !empty($repo)) {
                if (strtolower($repo) === strtolower($username . '.github.io')) {
                    $target_domain = 'https://' . $username . '.github.io';
                } else {
                    $target_domain = 'https://' . $username . '.github.io/' . $repo;
                }
            } else {
                return;
            }

            $request_uri = $_SERVER['REQUEST_URI'];
            $sub_dir = parse_url(SITE_URL, PHP_URL_PATH);
            if ($sub_dir && $sub_dir !== '/') {
                $request_uri = substr($request_uri, strlen($sub_dir));
            }

            // 转换动态 query 参数到静态路径
            if (isset($_GET['p'])) {
                $p_id = (int)$_GET['p'];
                $permalink_type = get_option('permalink_type', 'default');
                if ($permalink_type === 'numeric') {
                    $request_uri = '/' . $p_id . '.html';
                } else {
                    $request_uri = '/post/' . $p_id . '/';
                }
            }

            header('Location: ' . $target_domain . '/' . ltrim($request_uri, '/'), true, 302);
            exit;
        }
    }
}