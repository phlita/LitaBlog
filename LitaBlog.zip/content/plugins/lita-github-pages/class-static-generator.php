<?php
class LitaStaticGenerator {
    private $build_dir;
    private $theme_name;
    private $target_base;

    public function __construct() {
        $this->build_dir = ABSPATH . 'content/static_build';
        $this->theme_name = get_option('current_theme', 'default');
        
        $cname = get_option('lita_gh_cname');
        $username = get_option('lita_gh_username');
        $repo = get_option('lita_gh_repo');

        if (!empty($cname)) {
            $this->target_base = 'https://' . rtrim($cname, '/');
        } elseif (!empty($username) && !empty($repo)) {
            if (strtolower($repo) === strtolower($username . '.github.io')) {
                $this->target_base = 'https://' . $username . '.github.io';
            } else {
                $this->target_base = 'https://' . $username . '.github.io/' . $repo;
            }
        } else {
            $this->target_base = '';
        }
    }

    private function clean_dir($dir) {
        if (!is_dir($dir)) return;
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            (is_dir("$dir/$file")) ? $this->clean_dir("$dir/$file") : unlink("$dir/$file");
        }
        return rmdir($dir);
    }

    /**
     * 将本站所有的动态链接与物理路径，重写为适用于静态托管的 .html 链接
     */
    private function rewrite_link($url) {
        $local_site_url = rtrim(SITE_URL, '/');

        // 如果是外链则不处理
        if (strpos($url, 'http') === 0 && strpos($url, $local_site_url) !== 0) {
            return $url;
        }

        // 提取相对路径
        if (strpos($url, $local_site_url) === 0) {
            $path = substr($url, strlen($local_site_url));
        } else {
            $path = $url;
        }

        $path = '/' . ltrim($path, '/');
        $permalink_type = get_option('permalink_type', 'default');

        // 1. 匹配动态文章链接: /?p=123
        if (preg_match('/^\/\?p=(\d+)/i', $path, $matches)) {
            $id = $matches[1];
            if ($permalink_type === 'post') {
                return $this->target_base . '/post/' . $id . '.html';
            } else {
                return $this->target_base . '/' . $id . '.html';
            }
        }

        // 2. 匹配已有数字型链接: /123.html
        if (preg_match('/^\/(\d+)\.html/i', $path, $matches)) {
            $id = $matches[1];
            if ($permalink_type === 'post') {
                return $this->target_base . '/post/' . $id . '.html';
            } else {
                return $this->target_base . '/' . $id . '.html';
            }
        }

        // 3. 匹配文章名型链接: /post/123
        if (preg_match('/^\/post\/([^\/]+)/i', $path, $matches)) {
            $slug = $matches[1];
            if (substr($slug, -5) !== '.html') {
                $slug .= '.html';
            }
            return $this->target_base . '/post/' . $slug;
        }

        // 4. 首页处理
        if ($path === '/' || $path === '/index.php' || $path === '') {
            return $this->target_base . '/index.html';
        }

        return $this->target_base . $path;
    }

/**
     * 对生成的 HTML 进行全局链接和资源重写
     */
    private function process_html_links($html) {
        if (empty($this->target_base)) return $html;

        $local_site_url = rtrim(SITE_URL, '/');

        // 1. 重写静态资源的基础物理路径
        $html = str_replace($local_site_url . '/content/themes/', $this->target_base . '/content/themes/', $html);
        $html = str_replace($local_site_url . '/content/uploads/', $this->target_base . '/content/uploads/', $html);

        // 2. 匹配并替换常规的 href 和 src 属性中的本站链接
        $html = preg_replace_callback('/(href|src)=["\'](' . preg_quote($local_site_url, '/') . '[^\'"]*?)["\']/i', function($matches) {
            $attr = $matches[1];
            $url = $matches[2];
            return $attr . '="' . $this->rewrite_link($url) . '"';
        }, $html);

        // 3. 重构分页路径匹配（修复版）：匹配带有任意额外参数（如 &saved=1）的翻页链接
        $html = preg_replace_callback('/href=["\']([^"\']*?\?page=(\d+)[^"\']*?)["\']/i', function($matches) {
            $page_num = (int)$matches[2];
            
            // 无论携带何种参数，统一重写为标准的静态分页路径
            if ($page_num === 1) {
                return 'href="' . $this->target_base . '/index.html"';
            } else {
                return 'href="' . $this->target_base . '/index-page-' . $page_num . '.html"';
            }
        }, $html);

        return $html;
    }

    /**
     * 核心安全渲染：将 require_once 替换为 require 载入，打破 PHP 单次生命周期内的文件阻断
     */
    private function compile_and_include_theme_file($file_path, $template_data) {
        $content = file_get_contents($file_path);

        $theme_dir = rtrim(str_replace('\\', '/', dirname($file_path)), '/');
        $content = str_replace('__DIR__', "'" . $theme_dir . "'", $content);
        $content = str_replace('dirname(__FILE__)', "'" . $theme_dir . "'", $content);

        // 将 require_once 和 include_once 转换为可重入的常规载入
        $content = preg_replace('/\brequire_once\b/i', 'require', $content);
        $content = preg_replace('/\binclude_once\b/i', 'include', $content);

        // 生成临时的预编译文件执行渲染
        $temp_renderer = $this->build_dir . '/temp_renderer_' . uniqid() . '.php';
        file_put_contents($temp_renderer, $content);

        extract(['template_data' => $template_data]);

        ob_start();
        try {
            include $temp_renderer;
        } catch (Exception $e) {
            error_log("Render Error in file {$file_path}: " . $e->getMessage());
        }
        $html = ob_get_clean();

        @unlink($temp_renderer);
        return $html;
    }

    private function capture_render($request_type, $main_object, $template_file_name) {
        $template_data = prepare_template_data($request_type, $main_object);
        
        $template_data['theme_url'] = './content/themes/' . $this->theme_name;
        $template_data['site_url'] = $this->target_base;

        // 全量处理菜单中的链接
        if (isset($template_data['nav_menu']) && is_array($template_data['nav_menu'])) {
            foreach ($template_data['nav_menu'] as &$menu_item) {
                if (isset($menu_item['url'])) {
                    $menu_item['url'] = $this->rewrite_link($menu_item['url']);
                }
            }
        }

        $template_data = apply_filters('before_render_template_data', $template_data, $template_file_name);
        $theme_file = ABSPATH . 'content/themes/' . $this->theme_name . '/' . $template_file_name;

        if (!file_exists($theme_file)) {
            $theme_file = ABSPATH . 'content/themes/' . $this->theme_name . '/index.php';
        }

        $html = $this->compile_and_include_theme_file($theme_file, $template_data);
        return $this->process_html_links($html);
    }

    public function generate_all() {
        if (is_dir($this->build_dir)) {
            $this->clean_dir($this->build_dir);
        }
        mkdir($this->build_dir, 0755, true);

        // 1. 生成首页分页列表
        $posts_per_page = (int)get_option('posts_per_page', 10);
        $total_posts = get_total_posts(['status' => 'publish', 'type' => 'post']);
        $total_pages = max(1, ceil($total_posts / $posts_per_page));

        $orig_get = $_GET;

        for ($p = 1; $p <= $total_pages; $p++) {
            $_GET['page'] = $p;
            $home_html = $this->capture_render('home', null, 'index.php');

            if ($p === 1) {
                file_put_contents($this->build_dir . '/index.html', $home_html);
            } else {
                file_put_contents($this->build_dir . '/index-page-' . $p . '.html', $home_html);
            }
        }

        $_GET = $orig_get;

        // 2. 编译生成所有常规文章与页面（扁平化文件，降低目录深度）
        $posts = get_posts(['limit' => -1, 'status' => 'publish', 'type' => 'post']);
        $pages = get_posts(['limit' => -1, 'status' => 'publish', 'type' => 'page']);
        $all_contents = array_merge($posts, $pages);

        $permalink_type = get_option('permalink_type', 'default');

        // 如果是文章名型，先创建基础 post 存放目录
        if ($permalink_type === 'post') {
            $post_dir = $this->build_dir . '/post';
            if (!is_dir($post_dir)) mkdir($post_dir, 0755, true);
        }

        foreach ($all_contents as $item) {
            $is_page = ($item['type'] === 'page');
            $request_type = $is_page ? 'page' : 'single';
            
            $item_html = $this->capture_render($request_type, $item, 'single.php');

            if ($is_page) {
                // 页面保持根目录直出格式
                file_put_contents($this->build_dir . '/' . $item['id'] . '.html', $item_html);
            } else {
                if ($permalink_type === 'post') {
                    // 文章名型直出到 post 目录下
                    file_put_contents($this->build_dir . '/post/' . $item['id'] . '.html', $item_html);
                } else {
                    // 数字型和默认型直出到根目录
                    file_put_contents($this->build_dir . '/' . $item['id'] . '.html', $item_html);
                }
            }
        }

        // 3. 复制静态主题资产
        $theme_src = ABSPATH . 'content/themes/' . $this->theme_name;
        $theme_dst = $this->build_dir . '/content/themes/' . $this->theme_name;
        $this->copy_assets_recursive($theme_src, $theme_dst);

        // 4. 复制附件
        $uploads_src = ABSPATH . 'content/uploads';
        $uploads_dst = $this->build_dir . '/content/uploads';
        if (is_dir($uploads_src)) {
            $this->copy_assets_recursive($uploads_src, $uploads_dst);
        }

        // 5. CNAME 支持
        $cname = get_option('lita_gh_cname');
        if (!empty($cname)) {
            file_put_contents($this->build_dir . '/CNAME', trim($cname));
        }

        // 6. 生成搜索静态索引
        $this->generate_search_index($posts);
    }

    private function copy_assets_recursive($src, $dst) {
        if (!is_dir($src)) return;
        @mkdir($dst, 0755, true);
        $files = scandir($src);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            if (is_dir($src . '/' . $file)) {
                $this->copy_assets_recursive($src . '/' . $file, $dst . '/' . $file);
            } else {
                $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                if ($ext !== 'php' && $ext !== 'db') {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
    }

    private function generate_search_index($posts) {
        $index = [];
        foreach ($posts as $post) {
            $index[] = [
                'id'      => $post['id'],
                'title'   => $post['title'],
                'excerpt' => !empty($post['excerpt']) ? $post['excerpt'] : mb_substr(strip_tags($post['content']), 0, 120, 'UTF-8')
            ];
        }
        file_put_contents($this->build_dir . '/search-index.json', json_encode($index, JSON_UNESCAPED_UNICODE));
    }
}
?>