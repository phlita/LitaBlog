<?php
if (!defined('ABSPATH')) exit;

$message = '';
$message_type = 'success';

// 读取跳转状态
if (isset($_GET['saved']) && $_GET['saved'] === '1') {
    $message = '设置保存成功。';
    $message_type = 'success';
}

// 处理手动发布请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lita_gh_manual_deploy'])) {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'lita_gh_deploy_action')) {
        $message = '安全校验失败，请刷新重试。';
        $message_type = 'danger';
    } else {
        try {
            $generator = new LitaStaticGenerator();
            $generator->generate_all();

            $publisher = new LitaGithubPublisher();
            $result = $publisher->deploy();

            if ($result) {
                $message = '恭喜！静态页面已成功生成，且成功同步推送至 GitHub Pages。';
                $message_type = 'success';
            } else {
                $message = '静态生成成功，但在推送至 GitHub 过程中失败，请检查配置信息或令牌权限。';
                $message_type = 'danger';
            }
        } catch (Exception $e) {
            $message = '部署失败，系统抛出错误: ' . $e->getMessage();
            $message_type = 'danger';
        }
    }
}

// 保存设置
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lita_gh_save_settings'])) {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'lita_gh_settings_action')) {
        $message = '安全校验失败，请刷新重试。';
        $message_type = 'danger';
    } else {
        update_option('lita_gh_publish_mode', sanitize_text_field($_POST['publish_mode']));
        update_option('lita_gh_push_method', sanitize_text_field($_POST['push_method']));
        update_option('lita_gh_username', sanitize_text_field($_POST['username']));
        update_option('lita_gh_repo', sanitize_text_field($_POST['repo']));
        update_option('lita_gh_branch', sanitize_text_field($_POST['branch']));
        update_option('lita_gh_token', sanitize_text_field($_POST['token']));
        update_option('lita_gh_cname', sanitize_text_field($_POST['cname']));
        update_option('lita_gh_auto_sync', isset($_POST['auto_sync']) ? '1' : '0');

        // 发起物理重定向，绕过 LitaBlog 的 options static 内存缓存阻碍
        header('Location: ' . SITE_URL . '/admin/admin.php?page=lita-gh-publisher&saved=1');
        exit;
    }
}

$publish_mode = get_option('lita_gh_publish_mode', 'dual');
$push_method = get_option('lita_gh_push_method', 'api');
$username = get_option('lita_gh_username', '');
$repo = get_option('lita_gh_repo', '');
$branch = get_option('lita_gh_branch', 'main');
$token = get_option('lita_gh_token', '');
$cname = get_option('lita_gh_cname', '');
$auto_sync = get_option('lita_gh_auto_sync', '0');
?>

<div class="card">
    <h1>GitHub Pages 静态发布中心</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $message_type; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <div style="background: #f0f9eb; padding: 15px; border-left: 4px solid var(--primary-green); margin-bottom: 25px; border-radius: 4px; color: #606266;">
        <h3 style="margin-top:0; color: var(--primary-green);">⚠️ 静态环境适配警告</h3>
        <p style="font-size:0.9rem; margin-bottom:8px;">1. <strong>固定链接优化</strong>：本版本已实现超链接、多栏菜单、以及文章资产路径的**全扁平化重写转换**，不再生成多级嵌套文件夹，生成内容更为轻量。</p>
        <p style="font-size:0.9rem;">2. <strong>兼容范围</strong>：无论是默认动态链接（<code>?p=xxx</code>）、数字型链接还是文章名型链接，均会被全量重构为静态 <code>.html</code> 后缀，极大地提升了在 GitHub Pages 上的加载表现。</p>
    </div>

    <!-- 手动发布 -->
    <div style="margin-bottom: 30px; padding: 20px; border: 1px solid var(--border-color); border-radius: 8px; background: #fff;">
        <h2>全站手动同步部署</h2>
        <p class="description" style="margin-bottom: 15px;">此操作将完全重新扫描数据库，渲染全站最新的文章、独立页面、附件和多页分页，并覆写推送至 GitHub 仓库。</p>
        <form method="post">
            <?php csrf_token_field('lita_gh_deploy_action'); ?>
            <button type="submit" name="lita_gh_manual_deploy" class="button btn-success" style="padding: 10px 20px;">
                🚀 开始编译并发布
            </button>
        </form>
    </div>

    <!-- 配置项 -->
    <form method="post">
        <?php csrf_token_field('lita_gh_settings_action'); ?>
        
        <div class="form-group">
            <label>发布显示模式</label>
            <div class="radio-group">
                <label>
                    <input type="radio" name="publish_mode" value="dual" <?php echo $publish_mode === 'dual' ? 'checked' : ''; ?>>
                    <span><strong>双重部署模式</strong>（本地前台和 GitHub 同时可正常访问，适合预览测试）</span>
                </label>
                <label>
                    <input type="radio" name="publish_mode" value="headless" <?php echo $publish_mode === 'headless' ? 'checked' : ''; ?>>
                    <span><strong>纯内容管理模式 (Headless)</strong>（本地仅充当管理后台，普通访客访问本地前台将自动重定向至 GitHub Pages 线上地址）</span>
                </label>
            </div>
        </div>

        <div class="form-group">
            <label>推送传输方式</label>
            <div class="radio-group">
                <label>
                    <input type="radio" name="push_method" value="api" <?php echo $push_method === 'api' ? 'checked' : ''; ?>>
                    <span><strong>GitHub API</strong>（纯 PHP 通讯实现，不依赖服务器 Git，兼容所有虚拟主机）</span>
                </label>
                <label>
                    <input type="radio" name="push_method" value="cli" <?php echo $push_method === 'cli' ? 'checked' : ''; ?>>
                    <span><strong>本地 Git 命令行</strong>（效率极高，要求服务器端装有 Git 并且 PHP 未禁用 exec 函数）</span>
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="username">GitHub 用户名</label>
            <input type="text" id="username" name="username" value="<?php echo e($username); ?>" placeholder="例如: your-github-name" required>
        </div>

        <div class="form-group">
            <label for="repo">仓库名称 (Repository)</label>
            <input type="text" id="repo" name="repo" value="<?php echo e($repo); ?>" placeholder="例如: blog-pages 或 your-github-name.github.io" required>
            <small class="description">
                主页型：填写 <code>your-github-name.github.io</code><br>
                项目子目录型：填写您的项目名，例如 <code>hi</code>
            </small>
        </div>

        <div class="form-group">
            <label for="branch">分支名 (Branch)</label>
            <input type="text" id="branch" name="branch" value="<?php echo e($branch); ?>" placeholder="通常为 main 或 gh-pages" required>
        </div>

        <div class="form-group">
            <label for="token">GitHub 访问令牌 (PAT)</label>
            <input type="password" id="token" name="token" value="<?php echo e($token); ?>" placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxx" required>
        </div>

        <div class="form-group">
            <label for="cname">自定义解析域名 (CNAME)</label>
            <input type="text" id="cname" name="cname" value="<?php echo e($cname); ?>" placeholder="例如: blog.yourdomain.com (无须写 http://)">
        </div>

        <div class="form-group comment-option">
            <label for="auto_sync">
                <input type="checkbox" id="auto_sync" name="auto_sync" value="1" <?php echo $auto_sync === '1' ? 'checked' : ''; ?>>
                开启保存自动部署（发布新内容时自动在后台静默向 GitHub 同步）
            </label>
        </div>

        <button type="submit" name="lita_gh_save_settings" class="button btn-primary">保存设置</button>
    </form>
</div>