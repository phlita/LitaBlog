<?php
/**
 * Plugin Name: Lita Agent API
 * Plugin URI: https://lita.eu.org/
 * Description: 为 AI Agent 提供严格权限隔离的 RESTful API。支持独立的管理密钥(发文/删文)和互动密钥(仅限评论)。
 * Version: 2.0
 * Author: Lita
 */

if (!defined('ABSPATH')) exit;

// =========================================================================
// 1. 初始化时拦截文章管理 API 请求 (仅限 Admin Key)
// =========================================================================
add_action('init', 'lita_agent_api_interceptor', 1); // 优先级设为 1，最早执行

function lita_agent_api_interceptor() {
    $api_type = $_GET['agent_api'] ?? '';
    // 现在我们允许 posts 和 comments 两个端点
    if (!in_array($api_type, ['posts', 'comments'])) return;

    if (ob_get_level() > 0) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (empty($auth_header) && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        $auth_header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }

    preg_match('/Bearer\s(\S+)/', $auth_header, $matches);
    $provided_token = $matches[1] ?? '';

    $admin_key = get_option('lita_agent_api_key_admin', '');
    $comment_key = get_option('lita_agent_api_key_comment', '');

    // 【权限鉴定】
    $api_role = '';
    if (!empty($admin_key) && $provided_token === $admin_key) $api_role = 'admin';
    elseif (!empty($comment_key) && $provided_token === $comment_key) $api_role = 'bot';
    else lita_api_response(401, '认证失败：无效或被撤销的 API Key。');

    // 【权限拦截】：如果是文章操作，拒绝 Bot
    if ($api_type === 'posts' && $api_role !== 'admin') {
        lita_api_response(401, '越权拦截：该端点仅限 Admin Key 访问！');
    }

    $request_body = file_get_contents('php://input');
    $data = json_decode($request_body, true) ?: [];
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'POST') {
        if (isset($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'])) $method = strtoupper($_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE']);
        elseif (isset($_POST['_method'])) $method = strtoupper($_POST['_method']);
    }

    // 【路由分发】
    try {
        if ($api_type === 'posts') {
            if ($method === 'POST') lita_api_handle_create_post($data);
            elseif ($method === 'PUT' && isset($_GET['id'])) lita_api_handle_update_post((int)$_GET['id'], $data);
            elseif ($method === 'DELETE' && isset($_GET['id'])) lita_api_handle_delete_post((int)$_GET['id']);
            else lita_api_response(405, 'Method Not Allowed');
        } 
        elseif ($api_type === 'comments') {
            // 新增的评论专属路由
            if ($method === 'POST') lita_api_handle_create_comment($data, $api_role);
            elseif ($method === 'DELETE' && isset($_GET['id'])) lita_api_handle_delete_comment((int)$_GET['id'], $api_role);
            else lita_api_response(405, 'Method Not Allowed');
        }
    } catch (Exception $e) {
        lita_api_response(500, '服务器内部错误：' . $e->getMessage());
    }
}

// =========================================================================
// 新增：评论 API 核心逻辑 (完全剥离核心文件)
// =========================================================================
function lita_api_handle_create_comment($data, $api_role) {
    if (get_option('enable_comments', '1') !== '1') lita_api_response(403, '博客已全局关闭评论功能');
    
    $post_id = isset($data['post_id']) ? (int)$data['post_id'] : 0;
    if (!$post_id || !get_post($post_id)) lita_api_response(400, '文章不存在');
    
    $content = isset($data['content']) ? trim($data['content']) : '';
    if (empty($content)) lita_api_response(400, '评论内容不能为空');

    $db = get_db();
    $user_id = null;
    $author = null;

    // 严苛身份判定
    if ($api_role === 'admin' && !empty($data['user_id'])) {
        $user_id = (int)$data['user_id'];
        $user_info = get_user($user_id);
        $author = $user_info ? $user_info['username'] : 'System';
    } else {
        // Bot 或 未指明 user_id 的 Admin，均作为纯文本名称发言
        $author = sanitize_text_field($data['author'] ?? 'AI Agent');
    }

    try {
        $stmt = $db->prepare('INSERT INTO comments (post_id, user_id, author, email, content, status) VALUES (?, ?, ?, ?, ?, ?)');
        if ($stmt->execute([$post_id, $user_id, $author, null, $content, 'approved'])) {
            lita_api_response(201, '评论提交成功');
        } else {
            lita_api_response(500, '写入数据库失败');
        }
    } catch (Exception $e) { lita_api_response(500, '数据库异常'); }
}

function lita_api_handle_delete_comment($comment_id, $api_role) {
    if ($api_role !== 'admin') lita_api_response(401, '权限不足：仅 Admin Key 可删除评论');
    if ($comment_id <= 0) lita_api_response(400, '无效的 ID');

    $db = get_db();
    $stmt = $db->prepare('DELETE FROM comments WHERE id = ?');
    if ($stmt->execute([$comment_id]) && $stmt->rowCount() > 0) {
        lita_api_response(200, '删除成功');
    } else {
        lita_api_response(404, '评论不存在或删除失败');
    }
}

// =========================================================================
// 文章管理核心逻辑 (底层增删改)
// =========================================================================

function lita_api_handle_create_post($data) {
    if (empty($data['title']) || empty($data['content'])) {
        lita_api_response(400, '缺少必填字段：title 或 content');
    }

    $title = sanitize_text_field($data['title']);
    $content = $data['content']; 

    // AI 防呆机制 (自动包裹 Markdown 短代码)
    if (strpos($content, '[markdown]') === false) {
        $content = "[markdown]\n" . $content . "\n[/markdown]";
    }

    $status = isset($data['status']) && in_array($data['status'], ['publish', 'draft']) ? $data['status'] : 'publish';
    
    // 获取系统的真实站长账号作为发布者
    $db = get_db();
    $stmt = $db->query("SELECT id FROM users WHERE role = 'administrator' LIMIT 1");
    $admin_id = $stmt->fetchColumn() ?: 1;

    if (create_post($title, $content, $admin_id, $status)) {
        $post_id = $db->lastInsertId();
        lita_api_response(201, '发布成功', ['id' => $post_id, 'url' => Permalink::get_post_link($post_id)]);
    } else {
        lita_api_response(500, '数据库写入失败');
    }
}

function lita_api_handle_update_post($post_id, $data) {
    if ($post_id <= 0) lita_api_response(400, '无效的 ID');
    
    $update_data = [];
    if (isset($data['title'])) {
        $update_data['title'] = sanitize_text_field($data['title']);
    }
    
    if (isset($data['content'])) {
        $content = $data['content'];
        // 更新时同样执行 AI 防呆机制
        if (strpos($content, '[markdown]') === false) {
            $content = "[markdown]\n" . $content . "\n[/markdown]";
        }
        $update_data['content'] = $content;
    }
    
    if (isset($data['status']) && in_array($data['status'], ['publish', 'draft'])) {
        $update_data['status'] = $data['status'];
    }

    if (empty($update_data)) lita_api_response(400, '没有提供需要更新的字段');

    if (update_post($post_id, $update_data)) {
        lita_api_response(200, '更新成功', ['id' => $post_id, 'url' => Permalink::get_post_link($post_id)]);
    } else {
        lita_api_response(500, '更新失败，请检查 ID 是否存在');
    }
}

function lita_api_handle_delete_post($post_id) {
    if ($post_id <= 0) lita_api_response(400, '无效的 ID');
    
    $db = get_db();
    $stmt = $db->prepare('DELETE FROM posts WHERE id = ?');
    if ($stmt->execute([$post_id]) && $stmt->rowCount() > 0) {
        $db->prepare('DELETE FROM post_categories WHERE post_id = ?')->execute([$post_id]);
        $db->prepare('DELETE FROM post_tags WHERE post_id = ?')->execute([$post_id]);
        lita_api_response(200, '删除成功', ['id' => $post_id]);
    } else {
        lita_api_response(404, '文章不存在或删除失败');
    }
}

function lita_api_response($status_code, $message, $data = null) {
    http_response_code($status_code);
    $response = ['code' => $status_code, 'message' => $message];
    if ($data !== null) $response['data'] = $data;
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// =========================================================================
// 后台设置面板：双密钥隔离管理 UI 及使用说明
// =========================================================================
add_action('admin_menu', 'lita_agent_api_menu');
function lita_agent_api_menu() {
    add_menu_page(
        'Agent API 设置',
        'Agent API',
        'manage_options',
        'agent_api_settings',
        'lita_agent_api_settings_page',
        'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM0YTlmNmIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cmVjdCB4PSIzIiB5PSIxMSIgd2lkdGg9IjE4IiBoZWlnaHQ9IjEwIiByeD0iMiIvPjxjaXJjbGUgY3g9IjEyIiBjeT0iNSIgcj0iMiIvPjxwYXRoIGQ9Ik0xMiA3djQiLz48bGluZSB4MT0iOCIgeTE9IjE0IiB4Mj0iOCIgeTI9IjE2Ii8+PGxpbmUgeDE9IjE2IiB5MT0iMTQiIHgyPSIxNiIgeTI9IjE2Ii8+PC9zdmc+'
    );
}

function lita_agent_api_settings_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['generate_admin_key'])) {
            update_option('lita_agent_api_key_admin', 'sk-admin-' . bin2hex(random_bytes(16)));
            echo '<div class="alert alert-success">全能管理 Key (Admin) 已更新！请妥善保存。</div>';
        } elseif (isset($_POST['generate_comment_key'])) {
            update_option('lita_agent_api_key_comment', 'sk-comment-' . bin2hex(random_bytes(16)));
            echo '<div class="alert alert-success">互动评论 Key (Comment) 已更新！</div>';
        }
    }

    $admin_key = get_option('lita_agent_api_key_admin', '');
    $comment_key = get_option('lita_agent_api_key_comment', '');
    $api_base_url = SITE_URL;
    ?>
    <div class="card">
        <h2 style="margin-bottom: 20px; color: var(--primary-green);">🤖 权限隔离 API 密钥分配</h2>
        <p style="color: #666; margin-bottom: 20px;">使用本系统的 AI Agent，通过严格的密钥隔离保障数据安全。</p>

        <!-- 危险权限：Admin Key -->
        <div style="background: rgba(220, 53, 69, 0.05); padding: 15px; border-radius: 8px; border: 1px solid #f5c6cb; margin-bottom: 20px;">
            <label style="font-weight: bold; color: #dc3545;">⚠️ 全能管理密钥 (Admin Key)</label>
            <p style="font-size: 0.85rem; color: #666; margin-top: 5px;">拥有 <strong>创建、修改、彻底删除文章</strong> 以及在评论区 <strong>冒充管理员发言</strong> 的最高权限，严禁泄露！</p>
            
            <div style="display: flex; gap: 10px; align-items: center; margin-top: 10px;">
                <input type="password" id="adminKeyInput" value="<?php echo e($admin_key ?: '尚未生成'); ?>" readonly style="flex: 1; background: #fff; color: #dc3545; font-family: monospace; font-size: 1rem; border: 1px solid #f5c6cb; padding: 10px; border-radius: 4px;" />
                <button type="button" id="copyAdminBtn" class="btn btn-outline" style="border-color: #dc3545; color: #dc3545;" onclick="universalCopy(document.getElementById('adminKeyInput').value, 'copyAdminBtn')">📋 复制 Admin Key</button>
            </div>
            <form method="post" style="margin-top: 10px;"><button type="submit" name="generate_admin_key" class="btn btn-danger btn-sm" onclick="return confirm('重置将导致旧的 Admin Key 失效，确定吗？');">🔄 重新生成</button></form>
        </div>

        <!-- 安全权限：Comment Key -->
        <div style="background: #e8f4f8; padding: 15px; border-radius: 8px; border: 1px solid var(--secondary-green); margin-bottom: 20px;">
            <label style="font-weight: bold; color: var(--primary-green);">💬 互动评论密钥 (Comment Key)</label>
            <p style="font-size: 0.85rem; color: #666; margin-top: 5px;">仅限用于提交评论。底层强隔离，<strong>绝对无法调用文章管理接口，也无法篡改 user_id 冒充管理员</strong>。适合分配给外部客服机器人。</p>
            
            <div style="display: flex; gap: 10px; align-items: center; margin-top: 10px;">
                <input type="password" id="commentKeyInput" value="<?php echo e($comment_key ?: '尚未生成'); ?>" readonly style="flex: 1; background: #fff; color: var(--primary-green); font-family: monospace; font-size: 1rem; border: 1px solid var(--secondary-green); padding: 10px; border-radius: 4px;" />
                <button type="button" id="copyCommentBtn" class="btn btn-primary" onclick="universalCopy(document.getElementById('commentKeyInput').value, 'copyCommentBtn')">📋 复制 Comment Key</button>
            </div>
            <form method="post" style="margin-top: 10px;"><button type="submit" name="generate_comment_key" class="btn btn-outline btn-sm" onclick="return confirm('重置将导致旧的 Comment Key 失效，确定吗？');">🔄 重新生成</button></form>
        </div>

        <hr style="border-top: 1px dashed var(--border-color); margin: 30px 0;">

        <h3 style="margin: 20px 0 10px;">📝 提供给 AI 的接口说明书</h3>
        <button type="button" id="copyTextareaBtn" class="btn btn-primary btn-sm" style="margin-bottom: 15px;" onclick="universalCopy(document.getElementById('apiInstructions').value, 'copyTextareaBtn')">
            📋 一键复制完整说明给 AI
        </button>
        
        <textarea id="apiInstructions" style="width: 100%; height: 400px; line-height: 1.8; font-family: monospace; font-size: 0.85rem; background: #282c34; color: #abb2bf; padding: 15px; border-radius: 8px; border: none;" readonly>
博客域名：<?php echo $api_base_url; ?>

【全局认证方式】
所有请求必须在 Header 中携带 Bearer Token：
Authorization: Bearer {API_KEY}
Content-Type: application/json

====================
1. 创建文章 (需 Admin Key)
====================
请求方式：POST
请求地址：/?agent_api=posts

请求体：
{"title": "文章标题", "content": "正文内容", "status": "publish"}

响应：{"code": 201, "message": "发布成功", "data": {"id": "10", "url": "/?p=10"}}

====================
2. 修改文章 (需 Admin Key)
====================
请求方式：PUT
请求地址：/?agent_api=posts&id={文章ID}

请求体：
{"title": "修改标题", "content": "修改内容"}

响应：{"code": 200, "message": "更新成功", "data": {"id": 10}}

====================
3. 删除文章 (需 Admin Key)
====================
请求方式：DELETE
请求地址：/?agent_api=posts&id={文章ID}

请求体：{}
响应：{"code": 200, "message": "删除成功", "data": {"id": 10}}

====================
4. 发布互动评论 (通用)
====================
请求方式：POST
请求地址：/?agent_api=comments 

请求体（JSON）：
- post_id：必填，数字，要评论的文章ID
- content：必填，评论的正文
- user_id：可选，数字。如果你使用 Admin Key 并想代表网站管理员发言，传入管理员ID(通常为1)。Comment Key 使用此参数无效。
- author：可选，字符串。不传 user_id 时生效，代表机器人身份（如 "AI 总结"）。

示例 A（Admin Key 管理员回复）：
{"action": "add", "post_id": 12, "content": "感谢支持！", "user_id": 1}

示例 B（Comment Key 机器人留言）：
{"action": "add", "post_id": 12, "content": "本文共有 1200 字。", "author": "数据助手"}

响应：{"success": true, "code": 201, "message": "评论提交成功"}
        </textarea>
    </div>

    <!-- 终极隐形文本域复制黑科技 -->
    <script>
    function universalCopy(textToCopy, btnId) {
        if (!textToCopy || textToCopy === '尚未生成') {
            alert('内容为空，无法复制！');
            return;
        }

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy)
                .then(function() { showCopySuccess(btnId); })
                .catch(function() { fallbackCopy(textToCopy, btnId); });
        } else {
            fallbackCopy(textToCopy, btnId);
        }
    }

    function fallbackCopy(text, btnId) {
        var tempTextArea = document.createElement("textarea");
        tempTextArea.value = text;
        tempTextArea.setAttribute('readonly', '');
        tempTextArea.style.position = 'fixed';
        tempTextArea.style.top = '-9999px';
        tempTextArea.style.left = '-9999px';
        tempTextArea.style.opacity = '0';
        document.body.appendChild(tempTextArea);

        tempTextArea.select();
        tempTextArea.setSelectionRange(0, 99999);

        try {
            if (document.execCommand('copy')) showCopySuccess(btnId);
            else alert('您的环境不支持自动复制，请手动复制。');
        } catch (err) {
            alert('复制失败，请手动选择文本进行复制。');
        }
        document.body.removeChild(tempTextArea);
    }

    function showCopySuccess(btnId) {
        var btn = document.getElementById(btnId);
        if (!btn) return;
        
        var originalText = btn.getAttribute('data-orig-text') || btn.innerHTML;
        var originalBg = btn.getAttribute('data-orig-bg') || btn.style.background || '';
        var originalBorder = btn.getAttribute('data-orig-border') || btn.style.borderColor || '';
        var originalColor = btn.getAttribute('data-orig-color') || btn.style.color || '';
        
        if (!btn.hasAttribute('data-orig-text')) {
            btn.setAttribute('data-orig-text', originalText);
            btn.setAttribute('data-orig-bg', originalBg);
            btn.setAttribute('data-orig-border', originalBorder);
            btn.setAttribute('data-orig-color', originalColor);
        }

        btn.innerHTML = '✅ 已复制';
        btn.style.background = '#28a745';
        btn.style.borderColor = '#28a745';
        btn.style.color = '#fff';
        
        setTimeout(function() {
            btn.innerHTML = originalText;
            btn.style.background = originalBg;
            btn.style.borderColor = originalBorder;
            btn.style.color = originalColor;
        }, 2000);
    }
    </script>
    <?php
}