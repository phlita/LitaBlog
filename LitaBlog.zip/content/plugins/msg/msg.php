<?php
/*
*Plugin Name: Msg
*Description: A plugin to configure SMTP settings and send emails. Provides an [email] shortcode for a frontend form.
*Version: 1.0
*Author: 芙里塔
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// 定义插件目录常量
define('MSG_PLUGIN_DIR', __DIR__ . '/');

// 1. 注册后台菜单 (使用 LitaBlog 的 API)
add_action('admin_menu', 'msg_plugin_menu');
function msg_plugin_menu() {
    add_menu_page(
        'SMTP 设置',           // 页面标题
        'SMTP 邮件',            // 菜单标题
        'manage_options',        // 权限要求 (is_admin())
        'smtp-plugin-settings',  // 菜单 slug
        'msg_plugin_settings_page' // 页面渲染函数
    );
}

// 2. 渲染设置页面并处理表单提交
function msg_plugin_settings_page() {
    // --- 处理 POST 请求 ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // 验证 CSRF token
        if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'smtp_settings_update')) {
            set_flash_message('安全验证失败，请重试。', 'error');
        } else {
            // 定义需要保存的选项
            $options = [
                'smtp_host', 'smtp_username', 'smtp_port', 
                'smtp_encryption', 'recipient_email'
            ];
            
            foreach ($options as $option_name) {
                if (isset($_POST[$option_name])) {
                    update_option($option_name, sanitize_text_field($_POST[$option_name]));
                }
            }

            // 特殊处理密码和复选框
            if (isset($_POST['smtp_password']) && !empty($_POST['smtp_password'])) {
                // 只有在输入新密码时才更新
                update_option('smtp_password', sanitize_text_field($_POST['smtp_password']));
            }
            update_option('enable_email_shortcode', isset($_POST['enable_email_shortcode']) ? '1' : '0');

            set_flash_message('SMTP 设置已保存。', 'success');
        }
    }

    // --- 显示设置页面表单 ---
    ?>
    <div class="card"> <?php // 使用 LitaBlog 的 .content wrapper ?>
        <h1>SMTP 设置</h1>
        
        <?php display_flash_message(); // 显示操作反馈信息 ?>

        <form method="post" action="admin.php?page=smtp-plugin-settings">
            <?php csrf_token_field('smtp_settings_update'); // 添加 CSRF token 隐藏字段 ?>
            
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="smtp_host">SMTP Host</label></th>
                    <td><input type="text" id="smtp_host" name="smtp_host" value="<?php echo e(get_option('smtp_host')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="smtp_username">SMTP Username</label></th>
                    <td><input type="text" id="smtp_username" name="smtp_username" value="<?php echo e(get_option('smtp_username')); ?>" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="smtp_password">SMTP Password</label></th>
                    <td><input type="password" id="smtp_password" name="smtp_password" value="" placeholder="保留为空则不修改" class="regular-text" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="smtp_port">SMTP Port</label></th>
                    <td>
                        <select name="smtp_port" id="smtp_port">
                            <?php $current_port = get_option('smtp_port', '587'); ?>
                            <option value="587" <?php echo ($current_port == '587' ? 'selected' : ''); ?>>587 (TLS)</option>
                            <option value="465" <?php echo ($current_port == '465' ? 'selected' : ''); ?>>465 (SSL)</option>
                            <option value="25" <?php echo ($current_port == '25' ? 'selected' : ''); ?>>25 (不加密)</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="smtp_encryption">Encryption</label></th>
                    <td>
                        <select name="smtp_encryption" id="smtp_encryption">
                             <?php $current_enc = get_option('smtp_encryption', 'tls'); ?>
                            <option value="tls" <?php echo ($current_enc == 'tls' ? 'selected' : ''); ?>>TLS</option>
                            <option value="ssl" <?php echo ($current_enc == 'ssl' ? 'selected' : ''); ?>>SSL</option>
                            <option value="" <?php echo ($current_enc == '' ? 'selected' : ''); ?>>无</option>
                        </select>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="enable_email_shortcode">启用 [email] 短代码</label></th>
                    <td><input type="checkbox" id="enable_email_shortcode" name="enable_email_shortcode" value="1" <?php echo (get_option('enable_email_shortcode') == '1' ? 'checked' : ''); ?> />
                    <p class="description">勾选后，可在页面或文章中使用 <code>[email]</code> 短代码来显示一个邮件发送表单。</p></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="recipient_email">收件人邮箱</label></th>
                    <td><input type="email" id="recipient_email" name="recipient_email" value="<?php echo e(get_option('recipient_email')); ?>" class="regular-text" />
                    <p class="description">前端表单发送的邮件将发送到此地址。</p></td>
                </tr>
            </table>
            <button type="submit" class="button btn-primary">保存设置</button>
        </form>
    </div>
    <?php
}

// 3. 引入 PHPMailer 并创建邮件发送函数
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * 自定义的邮件发送函数
 * @param string $to 收件人
 * @param string $subject 邮件主题
 * @param string $body 邮件内容
 * @param array $headers (可选) 邮件头，这里主要用来获取发件人名
 * @return bool 是否发送成功
 */
function msg_send_mail($to, $subject, $body, $headers = []) {
    require_once MSG_PLUGIN_DIR . 'lib/PHPMailer.php';
    require_once MSG_PLUGIN_DIR . 'lib/SMTP.php';
    require_once MSG_PLUGIN_DIR . 'lib/Exception.php';

    $mail = new PHPMailer(true);

    try {
        //服务器配置
        $mail->isSMTP();
        $mail->Host       = get_option('smtp_host');
        $mail->SMTPAuth   = true;
        $mail->Username   = get_option('smtp_username');
        $mail->Password   = get_option('smtp_password');
        $mail->SMTPSecure = get_option('smtp_encryption');
        $mail->Port       = get_option('smtp_port');
        $mail->CharSet    = 'UTF-8'; // 设置编码

        //发件人
        $from_email = get_option('smtp_username');
        $from_name = 'LitaBlog'; // 默认发件人名
        // 从 header 中解析发件人名
        if (!empty($headers)) {
            foreach($headers as $header) {
                if (stripos($header, 'From:') === 0) {
                     if (preg_match('/From:\s*(.*?)\s*<.*>/', $header, $matches)) {
                         $from_name = trim($matches[1]);
                     }
                }
            }
        }
        $mail->setFrom($from_email, $from_name);

        //收件人
        $mail->addAddress($to);

        //内容
        $mail->isHTML(false); // 发送纯文本邮件
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: {$mail->ErrorInfo}");
        return false;
    }
}


// 4. 短代码逻辑
if (get_option('enable_email_shortcode') == '1') {
    add_shortcode('email', 'msg_email_form_shortcode');
}

function msg_email_form_shortcode() {
    ob_start();
    ?>
    <h2>给我发短信</h2>
    <form id="email-form" method="post">
        <?php // 添加 CSRF token for AJAX ?>
        <input type="hidden" name="_ajax_csrf_token" value="<?php echo generateCsrfToken('send_email'); ?>">
        <input type="text" id="name" name="name" required placeholder="您的称呼" />
        <textarea id="title" name="title" required placeholder="邮件内容" rows="4"></textarea> <?php // title 现在是 textarea ?>
        <button type="submit">确认发送</button>
    </form>
    <p id="msg-feedback" style="display:none;"></p>
    <script>
    document.getElementById("email-form").addEventListener("submit", function(event) {
        event.preventDefault(); 
        
        const feedbackEl = document.getElementById('msg-feedback');
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        
        feedbackEl.style.display = 'block';
        feedbackEl.style.color = 'blue';
        feedbackEl.textContent = '正在发送...';
        submitBtn.disabled = true;

        const formData = new FormData(this);
        formData.append('action', 'send_email'); // LitaBlog AJAX action

        fetch('<?php echo rtrim(SITE_URL, "/"); ?>/ajax.php', { // 指向 LitaBlog 的 ajax.php
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                feedbackEl.textContent = data.data.message || '发送成功！';
                feedbackEl.style.color = 'green';
                this.reset(); // 清空表单
            } else {
                feedbackEl.textContent = '发送失败: ' + (data.data.message || '未知错误');
                feedbackEl.style.color = 'red';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            feedbackEl.textContent = '发送时发生网络错误。';
            feedbackEl.style.color = 'red';
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
            // 3秒后隐藏提示信息
            setTimeout(() => {
                 feedbackEl.style.display = 'none';
            }, 3000);
        });
    });
    </script>
    <?php
    return ob_get_clean();
}

// 5. AJAX 处理逻辑
function msg_process_ajax_email() {
    // CSRF 验证已在 ajax.php 中完成
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '匿名用户';
    $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '无主题';
    
    $recipient_email = get_option('recipient_email');
    if (empty($recipient_email) || !filter_var($recipient_email, FILTER_VALIDATE_EMAIL)) {
        wp_send_json_error(['message' => '管理员未配置收件人邮箱。']);
        return;
    }

    $sender_email = get_option('smtp_username');
    if (empty($sender_email)) {
        wp_send_json_error(['message' => 'SMTP 发件人未配置。']);
        return;
    }

    $headers = ['From: ' . $title . ' <' . $sender_email . '>'];
    
    // 使用新的邮件发送函数
    $mail_sent = msg_send_mail($recipient_email, $name, $title, $headers);

    if ($mail_sent) {
        wp_send_json_success(['message' => '消息已成功发送！']);
    } else {
        wp_send_json_error(['message' => '邮件发送失败，请检查后台SMTP设置或联系管理员。']);
    }
}
// 为登录和未登录用户都注册 AJAX 动作
add_action('wp_ajax_send_email', 'msg_process_ajax_email');
add_action('wp_ajax_nopriv_send_email', 'msg_process_ajax_email');