<?php
/**
 * Plugin Name: LitaMarkdown
 * Plugin URI: https://lita.eu.org/
 * Description: 高解析度、高兼容性 Markdown 解析插件。具备标签防分割、标题换行隔离保护、公式与代码块安全隔离技术。
 * Version: 2.5
 * Author: 芙里塔
 * Author URI: https://blog.lita.eu.org/
 */

if (!defined('ABSPATH')) {
    exit;
}

// 1. 初始化短代码注册及前台预渲染修复过滤器
function lita_markdown_plugin_init() {
    add_shortcode('markdown', 'lita_markdown_shortcode_handler');
    
    // 注册前台预渲染「自我修复」过滤器，优先级设为 10
    add_filter('before_render_template_data', 'lita_markdown_pre_render_repair_filter', 10);
}
add_action('init', 'lita_markdown_plugin_init');

/**
 * 核心防御机制：短代码标签「严格自我修复」过滤器
 * 采用严格成对匹配正则，完美杜绝将讲解文字、标题里的 [markdown] 误判为短代码的问题
 */
function lita_markdown_pre_render_repair_filter($template_data) {
    if (empty($template_data['post']['content'])) {
        return $template_data;
    }
    
    $content = $template_data['post']['content'];
    
    // 1. 修复可能被转义的方括号实体
    $content = str_replace(
        ['&#91;', '&#93;', '&amp;#91;', '&amp;#93;', '%5B', '%5D', '%5b', '%5d'],
        ['[', ']', '[', ']', '[', ']', '[', ']'],
        $content
    );
    
    // 2. 净化标签：剥离可能被 Quill 注入到 [markdown] 内部的任何 HTML 标签
    $content = preg_replace_callback('/\[([^\]]*?markdown[^\]]*?)\]/i', function($m) {
        return '[' . trim(strip_tags($m[1])) . ']';
    }, $content);
    
    $content = preg_replace_callback('/\[\/([^\]]*?markdown[^\]]*?)\]/i', function($m) {
        return '[/' . trim(strip_tags($m[1])) . ']';
    }, $content);
    
    // 3. 使用严格必须成对出现的正则表达式手动解析短代码！
    // 绝不调用 LitaBlog 核心宽松的 do_shortcode()，从源头上避开单边 [markdown] 被误判和二次污染的漏洞
    $content = preg_replace_callback('/\[markdown\](.*?)\[\/markdown\]/is', function($matches) {
        return lita_markdown_shortcode_handler([], $matches[1]);
    }, $content);
    
    $template_data['post']['content'] = $content;
    
    return $template_data;
}

/**
 * 短代码回调
 */
function lita_markdown_shortcode_handler($atts, $content = null) {
    if (empty($content)) {
        return '';
    }
    
    // 1. 采用高精密占位符清洗算法还原 Markdown 文本
    $clean_markdown = lita_markdown_clean_quill_html($content);
    
    // 2. 标记当前页面需要加载数学公式引擎
    $GLOBALS['lita_markdown_has_math'] = true;
    
    // 3. 使用安全状态机解析 Markdown
    return LitaStatefulMarkdownParser::parse($clean_markdown);
}

/**
 * 动态加载 KaTeX 公式渲染引擎
 */
function lita_markdown_inject_katex_assets() {
    if (empty($GLOBALS['lita_markdown_has_math'])) {
        return;
    }

    static $already_injected = false;
    if ($already_injected) {
        return;
    }
    $already_injected = true;
    ?>
    <!-- KaTeX 样式表 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css" crossorigin="anonymous">
    <!-- KaTeX 主核心 JS -->
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js" crossorigin="anonymous"></script>
    <!-- Auto-render 自动渲染扩展 -->
    <script defer src="https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js" crossorigin="anonymous" onload="litaInitKaTeX()"></script>
    
    <script>
    function litaInitKaTeX() {
        let attempts = 0;
        const timer = setInterval(() => {
            attempts++;
            if (typeof renderMathInElement === 'function' && typeof katex !== 'undefined') {
                clearInterval(timer);
                renderMathInElement(document.body, {
                    delimiters: [
                        {left: '$$', right: '$$', display: true},  
                        {left: '$', right: '$', display: false},    
                        {left: '\\(', right: '\\)', display: false},
                        {left: '\\[', right: '\\]', display: true}
                    ],
                    throwOnError : false
                });
            }
            if (attempts > 50) {
                clearInterval(timer);
            }
        }, 100);
    }
    </script>
    <?php
}
add_action('wp_footer', 'lita_markdown_inject_katex_assets', 99);
add_action('footer', 'lita_markdown_inject_katex_assets', 99);

/**
 * 占位符隔离与纯文本生命周期保护清洗算法
 * 保护大段普通文本中的代码说明不被破坏，同时平滑剥离 Quill 格式标签
 */
 function lita_markdown_clean_quill_html($html_content) {
    // 1. 统一并规范化基础换行符，防止平台换行符不一致产生拼合 Bug
    $text = str_replace(array("\r\n", "\r"), "\n", $html_content);
    $code_blocks = [];
    $table_blocks = []; // 用于存储受保护的表格块

    // 2. 隔离 <pre> 代码块
    $text = preg_replace_callback('/<pre[^>]*>(.*?)<\/pre>/is', function($matches) use (&$code_blocks) {
        $code_content = $matches[1];
        
        // 提取语言类型
        $language = 'plain';
        if (preg_match('/class=["\'](?:[^"\']*?\b)?language-(\w+)/i', $matches[0], $lang_match)) {
            $language = $lang_match[1];
        }
        
        // 仅仅移去内部可能残余的 <code> 标签
        $code_content = preg_replace('/<\/?code[^>]*>/i', '', $code_content);
        
        // 将代码块内的 HTML 实体安全解码为最原始的字符
        $code_content = html_entity_decode($code_content, ENT_QUOTES, 'UTF-8');
        $code_content = str_replace(array("\r\n", "\r"), "\n", $code_content);
        
        // 生成纯文本占位符，封存标准的 Markdown 代码块语法
        $placeholder = '__LITAMDCODEBLOCK' . count($code_blocks) . '__';
        $code_blocks[$placeholder] = "\n\n```" . $language . "\n" . $code_content . "\n```\n\n";
        
        return $placeholder;
    }, $text);

    // 3. 处理其他块级标签，将其闭合标签转换为双换行符
    $text = preg_replace('/<\/p>/i', "\n\n", $text);
    $text = preg_replace('/<br\s*\/?>/i', "\n", $text);
    $text = preg_replace('/<\/div>/i', "\n\n", $text);
    $text = preg_replace('/<hr[^>]*>/i', "\n\n---\n\n", $text);

    // ======= 核心优化：提前净化所有 HTML 格式标签（如 <p> 等） =======
    // 确保在此步骤之后，表格内部不再残存任何富文本编辑器的底层标签
    $text = strip_tags($text);

    // ======= 核心优化：提前还原普通区域的 HTML 实体 =======
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    
    // 清理特殊不换行空格
    $text = str_replace(['&nbsp;', '&#160;', "\xC2\xA0"], ' ', $text);  

    // ======= 核心优化：在纯净文本上合并并隔离表格 =======
    // 1. 压缩表格行之间被 Quill 引入的多余空行
    while (preg_match('/([^\n]*\|[^\n]*)\n\n+([^\n]*\|[^\n]*)/', $text)) {
        $text = preg_replace('/([^\n]*\|[^\n]*)\n\n+([^\n]*\|[^\n]*)/', "$1\n$2", $text);
    }

    // 2. 提取连续表格块，进行隔离保护
    $text = preg_replace_callback('/(?:^|\n)([^\n]*\|[^\n]*(?:\n[^\n]*\|[^\n]*)+)/', function($matches) use (&$table_blocks) {
        $placeholder = '__LITAMDTABLEBLOCK' . count($table_blocks) . '__';
        $table_blocks[$placeholder] = "\n\n" . $matches[1] . "\n\n";
        return "\n\n" . $placeholder . "\n\n";
    }, $text);
    // =============================================================

    // 步骤 7：只转换独立存在的破折号控制字符为标准分割线 '---'
    $text = preg_replace('/(?<![^\s])(?:&mdash;|—|&#45;&#45;&#45;|---+)(?![^\s])/', '---', $text);
    
    // 步骤 8：强制将所有单独存在的 --- 进行换行规范化，确保其独立成行
    $text = preg_replace('/([^\n])---([^\n])/', "$1\n---\n$2", $text);
    $text = preg_replace('/^---([^\n])/', "---\n$1", $text);
    $text = preg_replace('/([^\n])---$/', "$1\n---", $text);
    
    // 步骤 9：规范化多个换行，将三个以上的多余换行折叠为两个
    $text = preg_replace('/\n{3,}/', "\n\n", $text);

    // ======= 核心还原：依次还原被保护的表格块和代码块 =======
    if (!empty($table_blocks)) {
        $text = str_replace(array_keys($table_blocks), array_values($table_blocks), $text);
    }
    
    if (!empty($code_blocks)) {
        $text = str_replace(array_keys($code_blocks), array_values($code_blocks), $text);
    }

    return $text;
}
/*
 function lita_markdown_clean_quill_html($html_content) {
    // 统一并规范化基础换行符，防止平台换行符不一致产生拼合 Bug
    $text = str_replace(array("\r\n", "\r"), "\n", $html_content);
    $code_blocks = [];

    // 步骤 1：第一步，在清除任何 HTML 格式标签前，先将正文中真正的 <pre> 代码块整体提取并安全隔离
    // 这能确保代码块内的原始尖括号、实体、PHP 标签在后续清洗中绝对不被剥离
    $text = preg_replace_callback('/<pre[^>]*>(.*?)<\/pre>/is', function($matches) use (&$code_blocks) {
        $code_content = $matches[1];
        
        // 提取语言类型
        $language = 'plain';
        if (preg_match('/class=["\'](?:[^"\']*?\b)?language-(\w+)/i', $matches[0], $lang_match)) {
            $language = $lang_match[1];
        }
        
        // 仅仅移去内部可能残余的 <code> 标签
        $code_content = preg_replace('/<\/?code[^>]*>/i', '', $code_content);
        
        // 将代码块内的 HTML 实体安全解码为最原始的字符
        $code_content = html_entity_decode($code_content, ENT_QUOTES, 'UTF-8');
        $code_content = str_replace(array("\r\n", "\r"), "\n", $code_content);
        
        // 生成纯文本占位符，封存标准的 Markdown 代码块语法
        $placeholder = '__LITAMDCODEBLOCK' . count($code_blocks) . '__';
        $code_blocks[$placeholder] = "\n\n```" . $language . "\n" . $code_content . "\n```\n\n";
        
        return $placeholder;
    }, $text);

    // 步骤 2：处理其他块级标签，将其闭合标签转换为双换行符
    // 物理建立 Markdown 块（Paragraph/Heading）之间的双行空隙，确保 ATX 标题行不被后续普通段落合并
    $text = preg_replace('/<\/p>/i', "\n\n", $text);
    $text = preg_replace('/<br\s*\/?>/i', "\n", $text);
    $text = preg_replace('/<\/div>/i', "\n\n", $text);
    $text = preg_replace('/<hr[^>]*>/i', "\n\n---\n\n", $text);

    // 步骤 3：现在可以极安全地删除富文本编辑器产生的所有剩余 HTML 格式标签了
    // 此时，普通文本里用户作为教学说明输入的 &lt;script&gt; 完好无损，被占位符保护的代码块也完好无损
    $text = strip_tags($text);

    // 步骤 4：在 strip_tags 执行完毕后，我们再对普通区域文本进行 html_entity_decode 还原！
    // 此时将 &lt;script&gt; 还原为 <script> 已经绝对安全，因为危险的 strip_tags 已经执行过了
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    
    // 步骤 5：恢复被隔离保护的代码块
    if (!empty($code_blocks)) {
        $text = str_replace(array_keys($code_blocks), array_values($code_blocks), $text);
    }

    // 步骤 6：处理特殊不换行空格
    $text = str_replace(['&nbsp;', '&#160;', "\xC2\xA0"], ' ', $text);  

    // 步骤 7：只转换独立存在的破折号控制字符为标准分割线 '---'
    $text = preg_replace('/(?<![^\s])(?:&mdash;|—|&#45;&#45;&#45;|---+)(?![^\s])/', '---', $text);
    
    // 步骤 8：强制将所有单独存在的 --- 进行换行规范化，确保其独立成行
    $text = preg_replace('/([^\n])---([^\n])/', "$1\n---\n$2", $text);
    $text = preg_replace('/^---([^\n])/', "---\n$1", $text);
    $text = preg_replace('/([^\n])---$/', "$1\n---", $text);
    
    // 步骤 9：规范化多个换行，将三个以上的多余换行折叠为两个
    $text = preg_replace('/\n{3,}/', "\n\n", $text);
    
    return $text;
}
*/
/**
 * 基于行状态机的高解析度 Markdown 解析引擎
 */
class LitaStatefulMarkdownParser {
	
  public static function parse($text) {
        if (empty(trim($text))) {
            return '';
        }

        $math_blocks = [];
		
	     // ======= 核心优化：优先提取并隔离“单行块级公式” (如 "  $$ E=mc^2 $$") =======
        // 采用 /m (多行模式)，限制在单行内匹配，不加 /s (允许点匹配换行) 以免跨行错配
        $text = preg_replace_callback('/^[ \t]*\$\$(.+?)\$\$[ \t]*$/m', function($matches) use (&$math_blocks) {
            $content = trim($matches[1]);
            // 过滤空公式或纯反斜杠
            if ($content === '' || preg_match('/^[\\\\\\s]+$/', $content)) {
                return $matches[0];
            }
            $placeholder = 'LITADBLOCKMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return "\n\n" . $placeholder . "\n\n";
        }, $text);

        // 1. 提取并隔离双 $ 多行块级公式 (要求 $$ 必须独占一行)
        $text = preg_replace_callback('/(?:\n|^)\$\$\r?\n(.*?)\r?\n\$\$(?=\n|$)/s', function($matches) use (&$math_blocks) {
            $content = trim($matches[1]);
            if ($content === '' || preg_match('/^[\\\\\\s]+$/', $content)) {
                return "\n\n<span>$$</span>\n" . $matches[1] . "\n<span>$$</span>\n\n";
            }
            $placeholder = 'LITADBLOCKMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return "\n\n" . $placeholder . "\n\n";
        }, $text);

        // 1.2 提取并隔离 \[ ... \] 块级公式
        $text = preg_replace_callback('/\\\\\[(.*?)\\\\\]/s', function($matches) use (&$math_blocks) {
            $content = trim($matches[1]);
            if ($content === '' || preg_match('/^[\\\\\\s]+$/', $content)) {
                return '<span>\[</span>' . $matches[1] . '<span>\]</span>';
            }
            $placeholder = 'LITADBLOCKMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return "\n\n" . $placeholder . "\n\n";
        }, $text);

        // 2. 提取并隔离单 $ 行内公式
        $text = preg_replace_callback('/(?<!\\\\)\$(?!\s)([^\$\n]+?)(?<!\s)(?<!\\\\)\$/', function($matches) use (&$math_blocks) {
            $content = trim($matches[1]);
            if ($content === '' || preg_match('/^[\\\\\\s]+$/', $content)) {
                return '<span>$</span>' . $matches[1] . '<span>$</span>';
            }
            $placeholder = 'LITAILINEMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return $placeholder;
        }, $text);

        // 2.2 提取并隔离 \( ... \) 行内公式
        $text = preg_replace_callback('/\\\\\((.*?)\\\\\)/s', function($matches) use (&$math_blocks) {
            $content = trim($matches[1]);
            if ($content === '' || preg_match('/^[\\\\\\s]+$/', $content)) {
                return '<span>\(</span>' . $matches[1] . '<span>\)</span>';
            }
            $placeholder = 'LITAILINEMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return $placeholder;
        }, $text);	
		
/*        
       // 1. 提取并隔离双 $ 块级公式 (要求 $$ 必须独占一行，前后有换行符限制)
        $text = preg_replace_callback('/(?:\n|^)\$\$\r?\n(.*?)\r?\n\$\$(?=\n|$)/s', function($matches) use (&$math_blocks) {
            $placeholder = 'LITADBLOCKMATH' . count($math_blocks);
            // 保存时去掉前后的占位换行，只保留公式主体
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return "\n\n" . $placeholder . "\n\n";
        }, $text);

        // 1.2 提取并隔离 \[ ... \] 块级公式
        $text = preg_replace_callback('/\\\\\[(.*?)\\\\\]/s', function($matches) use (&$math_blocks) {
            $placeholder = 'LITADBLOCKMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return "\n\n" . $placeholder . "\n\n";
        }, $text);

        // 2. 提取并隔离单 $ 行内公式 (要求 $ 紧贴字符，前后不能有空格)
        $text = preg_replace_callback('/\$(?!\s)([^\$\n]+?)(?<!\s)\$/', function($matches) use (&$math_blocks) {
            $placeholder = 'LITAILINEMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return $placeholder;
        }, $text);

        // 2.2 提取并隔离 \( ... \) 行内公式
        $text = preg_replace_callback('/\\\\\((.*?)\\\\\)/s', function($matches) use (&$math_blocks) {
            $placeholder = 'LITAILINEMATH' . count($math_blocks);
            $math_blocks[$placeholder] = str_replace(['<', '>'], ['&lt;', '&gt;'], $matches[0]);
            return $placeholder;
        }, $text);
*/
        $text = str_replace(array("\r\n", "\r"), "\n", $text);
        $lines = explode("\n", $text);

        $html = '';
        $currentBlock = null; 
        $codeLanguage = '';
        $accumulator = [];

        foreach ($lines as $idx => $line) {
            $trimmed = trim($line);

            // --- 状态：多行代码块 ---
            if ($currentBlock === 'code') {
                if (preg_match('/^```/', $trimmed)) {
                    $code_content = htmlspecialchars(implode("\n", $accumulator), ENT_QUOTES, 'UTF-8');
                    $html .= '<pre><code class="language-' . htmlspecialchars($codeLanguage) . '">' . $code_content . '</code></pre>' . "\n";
                    $accumulator = [];
                    $currentBlock = null;
                } else {
                    $accumulator[] = $line;
                }
                continue;
            }

            if (preg_match('/^```(\w*)/', $trimmed, $matches)) {
                $html .= self::closeBlock($currentBlock, $accumulator);
                $currentBlock = 'code';
                $codeLanguage = $matches[1] ?: 'plain';
                $accumulator = [];
                continue;
            }

            // --- 状态：空行处理 ---
            if ($trimmed === '') {
                if ($currentBlock !== null) {
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $currentBlock = null;
                    $accumulator = [];
                }
                continue;
            }

            // --- 状态：Setext 格式标题检测 ---
            if ($currentBlock === 'paragraph' && count($accumulator) > 0) {
                if (preg_match('/^={3,}$/', $trimmed)) {
                    $headingContent = array_pop($accumulator);
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $html .= "<h1>" . self::parseInline($headingContent) . "</h1>\n";
                    $currentBlock = null;
                    $accumulator = [];
                    continue;
                } elseif (preg_match('/^-{3,}$/', $trimmed)) {
                    $headingContent = array_pop($accumulator);
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $html .= "<h2>" . self::parseInline($headingContent) . "</h2>\n";
                    $currentBlock = null;
                    $accumulator = [];
                    continue;
                }
            }

            // --- 状态：水平分割线检测 ---
            $is_hr = false;
            $temp_line = str_replace(array(' ', "\t"), '', $trimmed);
            $first_char = $temp_line[0] ?? '';
            if (($first_char === '-' || $first_char === '*' || $first_char === '_') && 
                strlen($temp_line) >= 3 && 
                strspn($temp_line, $first_char) === strlen($temp_line)) {
                $is_hr = true;
            }

            if (!$is_hr && preg_match('/^(?:&mdash;|&#45;){3,}$/i', $trimmed)) {
                $is_hr = true;
            }

            if (!$is_hr && preg_match('/^[\p{Pd}]{3,}$/u', $trimmed)) {
                $is_hr = true;
            }

            if ($is_hr) {
                $html .= self::closeBlock($currentBlock, $accumulator);
                $currentBlock = null;
                $accumulator = [];
                $html .= "<hr style=\"border: 0; border-top: 1px solid rgba(0,0,0,0.15); margin: 20px 0;\" />\n";
                continue;
            }

            // --- 状态：ATX 格式标题行 ---
            if (preg_match('/^(#{1,6})[ \t]+(.*)$/', $trimmed, $matches)) {
                $html .= self::closeBlock($currentBlock, $accumulator);
                $currentBlock = null;
                $accumulator = [];
                
                $level = strlen($matches[1]);
                $headingContent = self::parseInline($matches[2]);
                $html .= "<h{$level}>{$headingContent}</h{$level}>\n";
                continue;
            }

            // --- 状态：引用块 ---
            if (preg_match('/^>[ \t]*(.*)$/', $trimmed, $matches)) {
                if ($currentBlock !== 'blockquote') {
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $currentBlock = 'blockquote';
                    $accumulator = [];
                }
                $accumulator[] = $matches[1];
                continue;
            }

            // --- 状态：GFM 规格表格分析 ---
            $next_line = $lines[$idx + 1] ?? '';
            if ($currentBlock === null && strpos($trimmed, '|') !== false && self::isTableDivider($next_line)) {
                $currentBlock = 'table';
                $accumulator = [$line];
                continue;
            }

            if ($currentBlock === 'table') {
                if (strpos($trimmed, '|') !== false) {
                    $accumulator[] = $line;
                    continue;
                } else {
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $currentBlock = null;
                    $accumulator = [];
                }
            }

            // --- 状态：层级感知列表 (List) 容器 ---
            if (preg_match('/^(\s*)([*+-]|\d+\.)[ \t]+(.*)$/', $line, $listMatches)) {
                if ($currentBlock !== 'list') {
                    $html .= self::closeBlock($currentBlock, $accumulator);
                    $currentBlock = 'list';
                    $accumulator = [];
                }
                $accumulator[] = $line;
                continue;
            } elseif ($currentBlock === 'list' && preg_match('/^(\s{2,})(.*)$/', $line)) {
                $accumulator[] = $line;
                continue;
            }

            // --- 状态：普通段落 ---
            if ($currentBlock !== 'paragraph') {
                $html .= self::closeBlock($currentBlock, $accumulator);
                $currentBlock = 'paragraph';
                $accumulator = [];
            }
            $accumulator[] = self::parseInline($trimmed);
        }

        if ($currentBlock !== null) {
            $html .= self::closeBlock($currentBlock, $accumulator);
        }

        // --- 核心还原：恢复被隔离的原始数学公式 ---
        if (!empty($math_blocks)) {
            $html = strtr($html, $math_blocks);
        }

        // 过滤不安全的 XSS 标签
        $html = preg_replace('/<(script|style|iframe)[^>]*>.*?<\/\\1>/is', '', $html);

        return $html;
    }

    private static function isTableDivider($line) {
        $trimmed = trim($line);
        if (!preg_match('/^\|?([\s:-]*\|[\s:-]*)+$/', $trimmed)) {
            return false;
        }
        $clean = str_replace(['|', '-', ':', ' ', "\t"], '', $trimmed);
        return $clean === '';
    }

    private static function closeBlock($type, $accumulator) {
        if (empty($accumulator)) {
            return '';
        }
        switch ($type) {
            case 'paragraph':
                return '<p>' . implode("<br>\n", $accumulator) . '</p>' . "\n";
            case 'blockquote':
                return self::compileBlockquote($accumulator);
            case 'list':
                return self::compileList($accumulator);
            case 'table':
                return self::compileTable($accumulator);
            default:
                return '';
        }
    }

    private static function compileBlockquote($lines) {
        $inner_text = implode("\n", $lines);
        return '<blockquote>' . self::parse($inner_text) . '</blockquote>' . "\n";
    }

    private static function compileTable($lines) {
        if (count($lines) < 2) return '';
        
        $header_line = array_shift($lines);
        $divider_line = array_shift($lines);
        
        $alignments = [];
        $cols = explode('|', trim($divider_line, '|'));
        foreach ($cols as $col) {
            $col = trim($col);
            $left = ($col[0] ?? '') === ':';
            $right = (substr($col, -1) === ':');
            if ($left && $right) $alignments[] = 'center';
            elseif ($right) $alignments[] = 'right';
            elseif ($left) $alignments[] = 'left';
            else $alignments[] = '';
        }
        
        $html = "<table>\n<thead>\n<tr>\n";
        
        $headers = explode('|', trim($header_line, '|'));
        foreach ($headers as $i => $h) {
            $align = isset($alignments[$i]) && $alignments[$i] ? ' style="text-align:' . $alignments[$i] . ';"' : '';
            $html .= "<th{$align}>" . self::parseInline(trim($h)) . "</th>\n";
        }
        $html .= "</tr>\n</thead>\n<tbody>\n";
        
        foreach ($lines as $line) {
            $html .= "<tr>\n";
            $cells = explode('|', trim($line, '|'));
            for ($i = 0; $i < count($headers); $i++) {
                $cell_val = isset($cells[$i]) ? trim($cells[$i]) : '';
                $align = isset($alignments[$i]) && $alignments[$i] ? ' style="text-align:' . $alignments[$i] . ';"' : '';
                $html .= "<td{$align}>" . self::parseInline($cell_val) . "</td>\n";
            }
            $html .= "</tr>\n";
        }
        
        $html .= "</tbody>\n</table>\n";
        return $html;
    }

    private static function compileList($lines) {
        $html = '';
        $stack = []; 
        
        foreach ($lines as $line) {
            if (preg_match('/^(\s*)([*+-]|\d+\.)[ \t]+(.*)$/', $line, $m)) {
                $indent = strlen($m[1]);
                $type = in_array($m[2], ['*', '+', '-']) ? 'ul' : 'ol';
                $content = self::parseInline($m[3]);
                
                $depth = count($stack);
                if ($depth === 0) {
                    $stack[] = ['type' => $type, 'indent' => $indent];
                    $html .= "<{$type}>\n<li>{$content}";
                } else {
                    $last = $stack[$depth - 1];
                    if ($indent > $last['indent']) {
                        $stack[] = ['type' => $type, 'indent' => $indent];
                        $html .= "\n<{$type}>\n<li>{$content}";
                    } elseif ($indent < $last['indent']) {
                        while (count($stack) > 1 && $indent < $stack[count($stack) - 1]['indent']) {
                            $closed = array_pop($stack);
                            $html .= "</li>\n</{$closed['type']}>";
                        }
                        $html .= "</li>\n<li>{$content}";
                    } else {
                        $html .= "</li>\n<li>{$content}";
                    }
                }
            }
        }
        
        while ($closed = array_pop($stack)) {
            $html .= "</li>\n</{$closed['type']}>\n";
        }
        
        return $html;
    }

    private static function parseInline($text) {
        // 先对纯文本段落（如代码说明、JS 说明）进行安全的 HTML 实体转义
        $text = htmlspecialchars($text, ENT_NOQUOTES, 'UTF-8');

        // 1. 行内代码匹配
        $text = preg_replace_callback('/`([^`]+)`/', function($matches) {
            return '<code>' . $matches[1] . '</code>';
        }, $text);

        // 2. 图片匹配：![alt](url "title")
        $text = preg_replace('/\!\[(.*?)\]\((.*?)(?:\s+["\'](.*?)["\'])?\)/', '<img src="$2" alt="$1" title="$3" style="max-width:100%; height:auto;" />', $text);
        
        // 3. 链接匹配：[text](url "title")
        $text = preg_replace('/\[(.*?)\]\((.*?)(?:\s+["\'](.*?)["\'])?\)/', '<a href="$2" title="$3" target="_blank">$1</a>', $text);
        
        // 4. 加粗与斜体（非贪婪匹配支持多重复合标记）
        $text = preg_replace('/(\*\*|__)(.*?)\1/s', '<strong>$2</strong>', $text);
        $text = preg_replace('/(\*|_)(.*?)\1/s', '<em>$2</em>', $text);
        
        // 5. GFM 规格删除线匹配
        $text = preg_replace('/~~(.*?)~~/s', '<del>$2</del>', $text);

        return $text;
    }
}

// 6. 后台编辑器界面集成
function lita_markdown_admin_footer_action() {
    $current_page = basename($_SERVER['PHP_SELF']);
    if ($current_page !== 'content.php') {
        return;
    }
    ?>
    <style>
    #lita-md-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.4);
        z-index: 99999;
        justify-content: center;
        align-items: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .lita-md-content {
        background: #fff;
        width: 90%;
        max-width: 650px;
        padding: 24px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        border: 1px solid #eee8e1;
    }
    .lita-md-header {
        font-size: 1.2rem;
        font-weight: 600;
        color: #4a9f6b;
        margin-bottom: 12px;
        border-bottom: 1px solid #eee8e1;
        padding-bottom: 8px;
    }
    .lita-md-textarea {
        width: 100%;
        height: 280px;
        padding: 12px;
        border: 1px solid #eee8e1;
        border-radius: 6px;
        font-family: monospace;
        font-size: 0.9rem;
        resize: vertical;
        outline: none;
        margin-bottom: 16px;
        color: #2c3e50;
    }
    .lita-md-textarea:focus {
        border-color: #4a9f6b;
        box-shadow: 0 0 0 3px rgba(74, 159, 107, 0.2);
    }
    .lita-md-footer {
        text-align: right;
        display: flex;
        justify-content: flex-end;
        gap: 12px;
    }
    .lita-md-btn {
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        font-size: 0.95rem;
        cursor: pointer;
        font-weight: 500;
        transition: background-color 0.2s;
    }
    .lita-md-btn-cancel {
        background: #eee8e1;
        color: #2c3e50;
    }
    .lita-md-btn-cancel:hover {
        background: #dcd7cd;
    }
    .lita-md-btn-insert {
        background: #4a9f6b;
        color: #fff;
    }
    .lita-md-btn-insert:hover {
        background: #367952;
    }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        let attempts = 0;
        const checkQuill = setInterval(() => {
            attempts++;
            if (window.quillInstance) {
                clearInterval(checkQuill);
                initMarkdownPlugin(window.quillInstance);
            }
            if (attempts > 50) {
                clearInterval(checkQuill);
            }
        }, 100);

        function initMarkdownPlugin(quill) {
            const toolbar = document.querySelector('.ql-toolbar');
            if (!toolbar) return;

            let formatsGroup = toolbar.querySelector('.ql-formats:last-child');
            if (!formatsGroup) {
                formatsGroup = document.createElement('span');
                formatsGroup.className = 'ql-formats';
                toolbar.appendChild(formatsGroup);
            }

            const mdButton = document.createElement('button');
            mdButton.type = 'button';
            mdButton.className = 'ql-markdown-btn';
            mdButton.title = '插入 Markdown 段落';
            mdButton.style.display = 'inline-flex';
            mdButton.style.alignItems = 'center';
            mdButton.style.justifyContent = 'center';
            mdButton.innerHTML = `
                <svg viewBox="0 0 24 24" style="width: 18px; height: 18px; fill: #444; transition: fill 0.2s;">
                    <path d="M20.53 2H3.47A1.47 1.47 0 002 3.47v17.06A1.47 1.47 0 003.47 22h17.06A1.47 1.47 0 0022 20.53V3.47A1.47 1.47 0 0020.53 2zM19 19h-2.18v-5.45L15 15.36l-1.82-1.81V19h-2.18V8.18h2.18l2.54 2.55 2.55-2.55H19zm-8.73-3.64H8.09V8.18H5.91V10h2.18v5.36H5.91V19h4.36z"/>
                </svg>
            `;
            formatsGroup.appendChild(mdButton);

            let modal = document.getElementById('lita-md-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'lita-md-modal';
                modal.innerHTML = `
                    <div class="lita-md-content">
                        <div class="lita-md-header">插入 Markdown 内容</div>
                        <textarea class="lita-md-textarea" id="lita-md-textarea-input" placeholder="在此输入 Markdown 格式的文字...&#10;支持标题 #、加粗 **、无序列表 -、代码块 \`\`\` 等"></textarea>
                        <div class="lita-md-footer">
                            <button class="lita-md-btn lita-md-btn-cancel" id="lita-md-cancel-btn" type="button">取消</button>
                            <button class="lita-md-btn lita-md-btn-insert" id="lita-md-insert-btn" type="button">插入</button>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
            }

            const textarea = document.getElementById('lita-md-textarea-input');
            const cancelBtn = document.getElementById('lita-md-cancel-btn');
            const insertBtn = document.getElementById('lita-md-insert-btn');

            mdButton.addEventListener('click', () => {
                modal.style.display = 'flex';
                textarea.focus();
            });

            cancelBtn.addEventListener('click', () => {
                modal.style.display = 'none';
                textarea.value = '';
            });

            insertBtn.addEventListener('click', () => {
                const mdText = textarea.value;
                if (mdText.trim()) {
                    const range = quill.getSelection(true);
                    
                    // 【物理隔绝回归】：顺应 Quill 容器天性，以最稳定的普通段落文本格式插入短代码
                    // 彻底避开 dangerouslyPasteHTML 对单行 <pre> 的物理拆分与损毁，由后端高精度的“隔离洗脑”算法完美还原。
                    const shortcode = '[markdown]\n' + mdText + '\n[/markdown]\n';
                    quill.insertText(range.index, shortcode);
                    quill.setSelection(range.index + shortcode.length);
                }
                modal.style.display = 'none';
                textarea.value = '';
            });
        }
    });
    </script>
    <?php
}
add_action('admin_footer', 'lita_markdown_admin_footer_action');