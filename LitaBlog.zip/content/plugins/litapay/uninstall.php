<?php
// if uninstall.php is not called by LitaBlog's core uninstall process, exit
if (!defined('ABSPATH') && !defined('SBP_UNINSTALL_PLUGIN')) {
// SBP_UNINSTALL_PLUGIN is a hypothetical constant LitaBlog might define when running uninstall.php
// If LitaBlog doesn't define such a constant, this check might need adjustment
// or rely solely on ABSPATH. For now, we assume LitaBlog defines something like this or
// that uninstall.php is only ever called by LitaBlog's plugin deletion process.
die;
}

// Manually include LitaBlog's config and core functions if not already loaded by LitaBlog's uninstall process.
// This path assumes LitaBlog's root is three levels up from the plugin's dir.
if (!defined('SITE_URL')) { // A simple check if config is loaded
if (file_exists(dirname(__FILE__) . '/../../../config.php')) {
require_once dirname(__FILE__) . '/../../../config.php';
} else {
die('LitaBlog config.php not found during LitaPay uninstall.');
}
}
if (!function_exists('get_db')) {
if (defined('ABSPATH') && file_exists(ABSPATH . 'includes/functions.php')) {
require_once ABSPATH . 'includes/functions.php';
} else {
die('LitaBlog functions.php not found during LitaPay uninstall.');
}
}
// Include the plugin's own DB schema for table names and uninstall function.
if (file_exists(dirname(__FILE__) . '/includes/db-schema.php')) {
require_once dirname(__FILE__) . '/includes/db-schema.php';
} else {
die('LitaPay db-schema.php not found during uninstall.');
}


// Call the function to drop plugin-specific tables
if (function_exists('litapay_uninstall_db_tables')) {
litapay_uninstall_db_tables();
}

// Delete options specific to this plugin
$db = get_db(); // Use LitaBlog's function

$options_to_delete = [
'litapay_version',
'litapay_currency_symbol',
'litapay_global_access_price',
'litapay_afdian_user_id',
'litapay_afdian_api_token',
'litapay_enable_afdian',
'litapay_enable_balance',
'litapay_enable_recharge_codes',
// Add any other options created by this plugin
];

try {
$stmt = $db->prepare("DELETE FROM options WHERE name = ?");
foreach ($options_to_delete as $option_name) {
$stmt->execute([$option_name]);
}
} catch (PDOException $e) {
error_log("LitaPay Uninstall Error (Deleting Options): " . $e->getMessage());
// Continue even if options deletion fails, to attempt deleting meta.
}


// Optional: Remove user meta related to the plugin
try {
// Be very careful with LIKE wildcards. Ensure the prefix is unique.
$stmt_user_meta = $db->prepare("DELETE FROM usermeta WHERE meta_key LIKE 'litapay_%'");
$stmt_user_meta->execute();
} catch (PDOException $e) {
error_log("LitaPay Uninstall Error (Deleting User Meta): " . $e->getMessage());
}

// Optional: Remove post meta related to the plugin
try {
$stmt_post_meta = $db->prepare("DELETE FROM postmeta WHERE meta_key LIKE 'litapay_%'");
$stmt_post_meta->execute();
} catch (PDOException $e) {
error_log("LitaPay Uninstall Error (Deleting Post Meta): " . $e->getMessage());
}
?>