<div class="litapay-user-center">
    <h3>欢迎, <?php echo e($_SESSION['username']); ?>!</h3>
    
    <div class="balance-card">
        <h4>我的余额</h4>
        <p class="balance-amount"><?php echo e($user_center_data['currency_symbol']); ?><span class="balance-value"><?php echo number_format($user_center_data['user_balance'], 2); ?></span></p>
    </div>

    <div class="recharge-card">
        <h4>余额充值</h4>
        <form id="user-center-recharge-form" method="post" data-ajaxurl="<?php echo e($user_center_data['ajax_url']); ?>">
            <input type="hidden" name="action" value="litapay_redeem_code">
            <input type="hidden" name="_ajax_csrf_token" value="<?php echo e($user_center_data['redeem_nonce']); ?>">
            <div class="form-group">
                <label for="recharge-code-input">输入充值码</label>
                <input type="text" id="recharge-code-input" name="recharge_code" placeholder="在此输入充值码" required>
            </div>
            <button type="submit" class="button">立即充值</button>
        </form>
        <div id="recharge-message-area" class="message-area"></div>
    </div>
    
    <?php // 可以在这里添加交易记录等其他模块 ?>
</div>