<?php
/**
* LitaPay Recharge Page Template (Standalone Fallback)
* This file is directly included when ?litapay_page=recharge is accessed.
*/

// --- START OF MODIFICATION ---
// File: content/plugins/litapay/public/templates/recharge-form.php

// --- 0. 基本安全检查和依赖 ---
if (!defined('LITAPAY_PLUGIN_DIR')) {
die('Access Denied');
}

// 尝试加载 LitaBlog 核心文件
if (!function_exists('get_option')) {
$litablog_root_guess = dirname(dirname(dirname(LITAPAY_PLUGIN_DIR)));
if (file_exists($litablog_root_guess . '/config.php')) {
require_once $litablog_root_guess . '/config.php';
}
if (defined('ABSPATH') && file_exists(ABSPATH . 'includes/functions.php')) {
require_once ABSPATH . 'includes/functions.php';
if (session_status() === PHP_SESSION_NONE) {
session_start();
}
} else {
error_log("LitaPay Recharge Page (Standalone): LitaBlog core functions could not be loaded.");
// Display a very basic error if core functions can't load
echo "<!DOCTYPE html><html><head><title>Error</title></head><body>Core functions loading failed. Cannot display recharge page.</body></html>";
exit;
}
}

// --- 1. 检查登录状态 ---
if (!is_logged_in()) {
$login_url = defined('SITE_URL') ? rtrim(SITE_URL, '/') . '/admin/login.php' : 'login.php';
$current_recharge_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$login_url_with_redirect = $login_url . '?redirect=' . urlencode($current_recharge_url);
// Output a simple HTML page for login prompt
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>请先登录 - 充值页面</title>
</head>
<body>
<div class="login-prompt">
<h1>操作需要登录</h1>
<p>请先登录您的账户才能进行充值操作。</p>
<p><a href="<?php echo htmlspecialchars($login_url_with_redirect); ?>">前往登录</a></p>
</div>
</body>
</html>
<?php
exit;
}

// --- 2. 获取必要的数据 ---
$user_id = $_SESSION['user_id'];
$recharge_template_data = [ // Prepare data for the template part
'current_user_balance' => function_exists('litapay_get_user_balance') ? litapay_get_user_balance($user_id) : 0.00,
'currency_symbol'      => get_option('litapay_currency_symbol', '¥'),
'ajax_url'             => defined('SITE_URL') ? rtrim(SITE_URL, '/') . '/ajax.php' : 'ajax.php',
'redeem_nonce'         => function_exists('generateCsrfToken') ? generateCsrfToken('litapay_redeem_code') : 'nonce_' . time(),
'enable_afdian_recharge' => function_exists('litapay_is_afdian_enabled') && litapay_is_afdian_enabled() && get_option('litapay_enable_afdian', '0') === '1',
'user_id'              => $user_id, // Pass user_id for Afdian link generation
];
$site_title = get_option('site_title', '我的网站');
$litapay_frontend_css_url = LITAPAY_PLUGIN_URL . 'public/assets/css/litapay-frontend.css';

// Attempt to load LitaBlog's admin.css for some basic styling for the standalone page
$admin_css_url = defined('SITE_URL') ? rtrim(SITE_URL, '/') . '/admin/admin.css' : '';

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>账户充值 - <?php echo htmlspecialchars($site_title); ?></title>
<?php // Load LitaPay's frontend CSS first ?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($litapay_frontend_css_url . '?v=' . filemtime(LITAPAY_PLUGIN_DIR . 'public/assets/css/litapay-frontend.css')); ?>">
<?php // Attempt to load admin.css for some basic styling, if LitaPay's CSS is not comprehensive enough for a standalone page ?>
<?php if ($admin_css_url && file_exists(ABSPATH . 'admin/admin.css')): ?>
<link rel="stylesheet" href="<?php echo htmlspecialchars($admin_css_url . '?v=' . filemtime(ABSPATH . 'admin/admin.css')); ?>">
<?php endif; ?>
</head>
<body>
<div class="litapay-recharge-standalone-wrapper">
<?php
// Include the unified template part
// Pass $recharge_template_data to it
include LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form-template.php';
?>
<a href="<?php echo defined('SITE_URL') ? htmlspecialchars(SITE_URL) : '/'; ?>" class="site-home-link">返回首页</a>
</div>
<?php // The JavaScript from recharge-form-template.php will handle AJAX ?>
</body>
</html>
<?php
// --- END OF MODIFICATION ---