<?php
// --- START OF MODIFICATION ---
// File: content/plugins/litapay/public/templates/recharge-form-template.php

if (!defined('ABSPATH')) exit;
// $recharge_template_data is expected to be passed to this template.
// It should include:
// 'ajax_url', 'redeem_nonce', 'current_user_balance', 'currency_symbol',
// 'enable_afdian_recharge', 'user_id' (for Afdian link)

$enable_recharge_codes = get_option('litapay_enable_recharge_codes', '1') === '1';

?>
<div class="litapay-recharge-form-shortcode-wrapper">
<h3>充值码充值</h3>

<div class="litapay-current-balance">
当前余额: <strong><?php echo e($recharge_template_data['currency_symbol']); ?><span class="litapay-current-balance-value"><?php echo number_format($recharge_template_data['current_user_balance'], 2); ?></span></strong>
</div>

<?php if ($enable_recharge_codes): ?>
<form id="litapay-recharge-code-form-<?php echo uniqid(); // Ensure unique ID if multiple forms on page ?>" class="litapay-recharge-code-form" method="POST" action="#" data-ajaxurl="<?php echo e($recharge_template_data['ajax_url']); ?>">
<input type="hidden" name="action" value="litapay_redeem_code">
<input type="hidden" name="_ajax_csrf_token" value="<?php echo e($recharge_template_data['redeem_nonce']); ?>">

<div class="form-group">
<label for="litapay_recharge_code_input-<?php echo uniqid(); ?>">输入充值码</label>
<input type="text" id="litapay_recharge_code_input-<?php echo uniqid(); ?>" name="recharge_code" class="form-control litapay_recharge_code_input_field" placeholder="请输入您的充值码" required>
</div>

<button type="submit" class="button btn-primary litapay-recharge-submit-btn">立即充值</button>
</form>
<div class="litapay-recharge-message-area" style="margin-top:15px; display: none;"></div>
<?php else: ?>
<p style="text-align:center; color: #777;">充值码功能未开启。</p>
<?php endif; ?>


<?php if ($enable_recharge_codes && $recharge_template_data['enable_afdian_recharge']): ?>
<div class="payment-method-separator"> 或 </div>
<?php endif; ?>

<?php if ($recharge_template_data['enable_afdian_recharge']): ?>
<div class="afdian-recharge-section" style="margin-top: <?php echo $enable_recharge_codes ? '0' : '20px'; ?>;">
<h3>爱发电充值</h3>
<p>金额将在爱发电平台自定义。</p>
<?php
$afdian_recharge_order_id = 'RECHARGE-' . ($recharge_template_data['user_id'] ?? 'unknown') . '-' . time();
$afdian_recharge_link = '';
if (class_exists('LitaPayAfdianAPI') && method_exists('LitaPayAfdianAPI', 'generate_payment_url')) {
$afdian_recharge_link = LitaPayAfdianAPI::generate_payment_url(
$afdian_recharge_order_id,
0,
'LitaBlog账户充值 (用户ID: ' . ($recharge_template_data['user_id'] ?? 'unknown') . ')'
);
}
?>
<?php if ($afdian_recharge_link): ?>
<a href="<?php echo htmlspecialchars($afdian_recharge_link); ?>" target="_blank" class="button">
前往爱发电充值
</a>
<p>提示：充值后，系统将通过Webhook自动更新您的余额。</p>
<?php else: ?>
<p style="text-align:center; color: #c00;">爱发电充值链接生成失败，请检查插件配置或联系管理员。</p>
<?php endif; ?>
</div>
<?php endif; ?>
</div>

<script>
// Encapsulate script to avoid conflicts if this template is included multiple times
(function() {
// Find all recharge forms on the page (in case of multiple shortcodes)
document.querySelectorAll('.litapay-recharge-code-form').forEach(function(rechargeForm) {
const messageArea = rechargeForm.nextElementSibling; // Assuming message area is immediately after form
const balanceValueEl = document.querySelector('.litapay-current-balance-value'); // Assume only one balance display on page for simplicity

if (rechargeForm && messageArea) {
rechargeForm.addEventListener('submit', function(e) {
e.preventDefault();
messageArea.style.display = 'none';
messageArea.className = 'litapay-recharge-message-area'; // Reset classes

const submitButton = rechargeForm.querySelector('.litapay-recharge-submit-btn');
const originalButtonText = submitButton.textContent;
submitButton.disabled = true;
submitButton.textContent = '处理中...';

const formData = new FormData(rechargeForm);
const ajaxUrl = rechargeForm.dataset.ajaxurl;

fetch(ajaxUrl, {
method: 'POST',
body: formData
// Headers for fetch POST are usually set automatically for FormData
// If CSRF is part of FormData, it's sent. If it needs to be a header, add it here.
})
.then(response => response.json())
.then(data => {
if (data.success) {
messageArea.textContent = data.message || '充值成功！';
messageArea.classList.add('success');
if (data.data && typeof data.data.new_balance !== 'undefined' && balanceValueEl) {
balanceValueEl.textContent = parseFloat(data.data.new_balance).toFixed(2);
}
const inputField = rechargeForm.querySelector('.litapay_recharge_code_input_field');
if(inputField) inputField.value = ''; // Clear the input field
} else {
messageArea.textContent = (data.data && data.data.message) ? data.data.message : (data.message || '充值失败，请重试。');
messageArea.classList.add('error');
}
})
.catch(error => {
console.error('Recharge Error:', error);
messageArea.textContent = '发生网络错误，请稍后再试。';
messageArea.classList.add('error');
})
.finally(() => {
messageArea.style.display = 'block';
submitButton.disabled = false;
submitButton.textContent = originalButtonText;
});
});
}
});
})();
</script>
<?php
// --- END OF MODIFICATION ---