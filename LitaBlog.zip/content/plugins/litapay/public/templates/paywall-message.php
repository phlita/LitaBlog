<?php
if (!defined('ABSPATH')) exit;
// $paywall_data is passed to this template, includes:
// 'price', 'post_id', 'currency_symbol', 'is_afdian_enabled',
// 'user_is_logged_in', 'login_url', 'ajax_url', 'purchase_nonce', 'current_user_balance'
?>
<div class="litapay-paywall">
<?php if ($paywall_data['price'] > 0): ?>
<p>付费可见：<strong><?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['price'], 2)); ?></strong></p>
<?php endif; ?>

<?php if ($paywall_data['user_is_logged_in']): ?>
<?php if (get_option('litapay_enable_balance', '1') === '1'): // Check if balance payment is enabled ?>
<button class="litapay-purchase-btn" 
data-postid="<?php echo e($paywall_data['post_id']); ?>" 
data-price="<?php echo e(number_format($paywall_data['price'], 2, '.', '')); // 发送格式化的价格 ?>"
data-nonce="<?php echo e($paywall_data['purchase_nonce']); ?>"
data-ajaxurl="<?php echo e($paywall_data['ajax_url']); ?>">
用余额
</button>
<?php endif; ?>

<?php if ($paywall_data['is_afdian_enabled']): // This checks LitaPay's specific Afdian enable option AND API keys
// Generate Afdian payment URL for this specific post/price
// This function now resides in litapay/includes/functions-afdian.php
$current_post_for_afdian = get_post($paywall_data['post_id']); // LitaBlog's function
$afdian_payment_url = LitaPayAfdianAPI::generate_payment_url(
'POSTID-' . $paywall_data['post_id'] . '-' . time(), // Unique order ID for Afdian
$paywall_data['price'],
$current_post_for_afdian['title'] ?? ('文章ID ' . $paywall_data['post_id'])
);
?>
<?php if ($afdian_payment_url): ?>
<a href="#" target="_blank" class="litapay-purchase-afdian-btn" 
data-ajaxurl="<?php echo e($paywall_data['ajax_url']); ?>" 
data-postid="<?php echo e($paywall_data['post_id']); ?>" 
data-price="<?php echo e(number_format($paywall_data['price'], 2, '.', '')); ?>" 
data-nonce="<?php echo e($paywall_data['create_afdian_order_nonce']); ?>" 
data-check-nonce="<?php echo e($paywall_data['check_order_status_nonce']); ?>">
爱发电
</a>
<?php else: ?>
<!-- Optional: Message if Afdian URL generation failed for this specific item -->
<?php endif; ?>
<?php endif; ?>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<p class="litapay-balance-info">
当前余额：<?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['current_user_balance'], 2)); ?>
<?php if ($paywall_data['current_user_balance'] < $paywall_data['price']): ?>
（余额不足）<a href="<?php echo rtrim(SITE_URL, '/'); ?>/?litapay_page=recharge">去充值</a>
<?php endif; ?>
</p>
<?php endif; ?>
<?php else: ?>
<p><a href="<?php echo e($paywall_data['login_url']); ?>">登录</a>后购买。</p>
<?php endif; ?>
<div class="litapay-message-area"></div>


<?php
// --- START: Add Global Purchase Button ---
if (
$paywall_data['user_is_logged_in'] &&
!$paywall_data['user_has_global_access'] && // User doesn't already have it
$paywall_data['global_access_price'] > 0     // Global purchase is enabled and has a price
) :
?>
<span class="payment-method-separator">或者，您可以选择购买全局阅读权限：</span>
<p>全局权限：<strong><?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['global_access_price'], 2)); ?></strong></p>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<button class="litapay-purchase-global-btn"
data-nonce="<?php echo e($paywall_data['purchase_global_nonce']); ?>"
data-ajaxurl="<?php echo e($paywall_data['ajax_url']); ?>">
用余额
</button>
<?php endif; ?>

<?php
if ($paywall_data['is_afdian_enabled']) :
// Generate Afdian payment URL for global access
$afdian_global_order_id = 'GLOBAL-' . $_SESSION['user_id'] . '-' . time();
$afdian_global_payment_url = LitaPayAfdianAPI::generate_payment_url(
$afdian_global_order_id,
$paywall_data['global_access_price'],
get_option('site_title', '本站') . '全局阅读权限' // Product title for Afdian
);
?>
<?php if ($afdian_global_payment_url): ?>
 <a href="#" target="_blank" class="litapay-purchase-afdian-btn"
       data-ajaxurl="<?php echo e($paywall_data['ajax_url']); ?>"
       data-postid="0" <?php // 使用 0 或 "global" 作为特殊标识 ?>
       data-price="<?php echo e(number_format($paywall_data['global_access_price'], 2, '.', '')); ?>"
       data-nonce="<?php echo e($paywall_data['create_afdian_order_nonce']); ?>"
       data-check-nonce="<?php echo e($paywall_data['check_order_status_nonce']); ?>">
        爱发电
    </a>
<?php endif; ?>
<?php endif; ?>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<p class="litapay-balance-info">
当前余额：<?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['current_user_balance'], 2)); ?>
<?php if ($paywall_data['current_user_balance'] < $paywall_data['global_access_price']): ?>
（余额不足）<a href="<?php echo litapay_get_recharge_page_url(); /* Use helper for recharge URL */ ?>">去充值</a>
<?php endif; ?>
</p>
<?php endif; ?>
<?php endif; ?>
<?php // --- END: Add Global Purchase Button --- ?>
</div>
