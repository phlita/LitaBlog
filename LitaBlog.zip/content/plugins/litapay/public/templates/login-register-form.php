<div class="litapay-auth-container">
    <div class="auth-tabs">
        <button class="tab-link active" data-tab="login">登录</button>
        <?php if ($login_form_data['registration_enabled']): ?>
            <button class="tab-link" data-tab="register">注册</button>
        <?php endif; ?>
    </div>

    <!-- 登录表单 -->
    <div id="login" class="auth-tab-content active">
        <form id="litapay-login-form" method="post">
            <input type="hidden" name="action" value="litapay_user_login">
            <input type="hidden" name="_ajax_csrf_token" value="<?php echo e($login_form_data['login_nonce']); ?>">
            <div class="form-group">
                <label for="login-username">用户名</label>
                <input type="text" id="login-username" name="username" required>
            </div>
            <div class="form-group">
                <label for="login-password">密码</label>
                <input type="password" id="login-password" name="password" required>
            </div>
            <button type="submit" class="button">登录</button>
        </form>
    </div>

    <!-- 注册表单 -->
    <?php if ($login_form_data['registration_enabled']): ?>
    <div id="register" class="auth-tab-content">
        <form id="litapay-register-form" method="post">
             <input type="hidden" name="action" value="litapay_user_register">
             <input type="hidden" name="_ajax_csrf_token" value="<?php echo e($login_form_data['register_nonce']); ?>">
             <div class="form-group">
                <label for="reg-username">用户名</label>
                <input type="text" id="reg-username" name="username" required>
            </div>
             <div class="form-group">
                <label for="reg-email">邮箱</label>
                <input type="email" id="reg-email" name="email" required>
            </div>
            <div class="form-group">
                <label for="reg-password">密码</label>
                <input type="password" id="reg-password" name="password" required>
            </div>
            <button type="submit" class="button">注册</button>
        </form>
    </div>
    <?php endif; ?>

    <div id="auth-message-area" class="message-area"></div>
</div>