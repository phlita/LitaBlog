document.addEventListener('DOMContentLoaded', function() {
    // --- Helper function for displaying messages ---
    function displayMessage(area, message, isSuccess) {
        if (area) {
            area.innerHTML = message; // Use innerHTML to render HTML content from backend
            area.className = 'litapay-message-area ' + (isSuccess ? 'success' : 'error');
            area.style.display = 'block'; // Ensure it's visible if hidden initially
        }
    }

    // --- Helper function to handle button state ---
    function setButtonState(button, disabled, text) {
        if (button) {
            button.disabled = disabled;
            button.textContent = text;
        }
    }

    // --- Event listener for purchase and global purchase buttons ---
    document.body.addEventListener('click', function(event) {
        const purchaseButton = event.target.closest('.litapay-purchase-btn');
        const globalPurchaseButton = event.target.closest('.litapay-purchase-global-btn');
        let action = '';
        let buttonToUpdate = null;
        let formData = new FormData();
        const paywallDiv = event.target.closest('.litapay-paywall');
        const messageArea = paywallDiv ? paywallDiv.querySelector('.litapay-message-area') : null;
        let originalButtonText = '';
        let ajaxUrl = '';
        let nonce = '';

        if (purchaseButton) {
            action = 'litapay_purchase_post_balance';
            buttonToUpdate = purchaseButton;
            originalButtonText = purchaseButton.textContent; // Capture original text before changing
            ajaxUrl = purchaseButton.dataset.ajaxurl;
            nonce = purchaseButton.dataset.nonce;
            const postId = purchaseButton.dataset.postid;
            const price = purchaseButton.dataset.price;

            if (!postId || !price || !nonce || !ajaxUrl) {
                displayMessage(messageArea, '错误：支付信息不完整 (单篇)，请刷新。', false);
                return;
            }
            formData.append('post_id', postId);
            formData.append('price_to_charge', price);
        } else if (globalPurchaseButton) {
            action = 'litapay_purchase_global_access_balance';
            buttonToUpdate = globalPurchaseButton;
            originalButtonText = globalPurchaseButton.textContent; // Capture original text
            ajaxUrl = globalPurchaseButton.dataset.ajaxurl;
            nonce = globalPurchaseButton.dataset.nonce;

            if (!nonce || !ajaxUrl) {
                displayMessage(messageArea, '错误：支付信息不完整 (全局)，请刷新。', false);
                return;
            }
        } else {
            return; // Not a LitaPay purchase button
        }
        
        event.preventDefault(); // Prevent default if it's an anchor acting as button

        formData.append('action', action);
        formData.append('_ajax_csrf_token', nonce); // LitaBlog AJAX CSRF token name

        setButtonState(buttonToUpdate, true, '处理中...');
        if (messageArea) {
             messageArea.textContent = (action === 'litapay_purchase_global_access_balance') ? '正在处理全局权限购买...' : '';
             messageArea.className = 'litapay-message-area'; // Reset class
             messageArea.style.display = 'block'; // Make sure it's visible
        }


        fetch(ajaxUrl, { method: 'POST', body: formData })
        .then(response => {
            // If the server sends a 403 (e.g. not logged in), it's a hard error for fetch
            // For business logic (200 OK with success:false), response.json() will proceed
            if (!response.ok && response.status === 403) { // Specifically handle 403 early
                 return response.json().then(errData => {
                    // Try to use message from 403 JSON if available
                    const msg = (errData && errData.data && errData.data.message) ? errData.data.message : `权限错误 (${response.status})。请检查登录状态。`;
                    throw new Error(msg);
                 });
            }
            return response.json(); // For 200 OK (success true/false) and other non-403 errors that might still be JSON
        })
        .then(data => {
            // data.success should exist if backend sends consistent JSON
            if (data && typeof data.success !== 'undefined') {
                const message = (data.data && data.data.message) ? data.data.message : (data.message || (data.success ? '操作成功！' : '操作失败！'));
                displayMessage(messageArea, message, data.success);

                if (data.success) {
                    setTimeout(() => { window.location.reload(); }, 1500);
                } else {
                    setButtonState(buttonToUpdate, false, originalButtonText);
                }
            } else {
                // Unexpected JSON structure from a 200 OK response
                console.error('LitaPay AJAX Error: Unexpected JSON structure.', data);
                displayMessage(messageArea, '收到意外的服务器响应格式。', false);
                setButtonState(buttonToUpdate, false, originalButtonText);
            }
        })
        .catch(error => { // Catches network errors, JSON parse errors, or explicitly thrown errors (like the 403 one)
            console.error('LitaPay AJAX Catch Error:', error);
            // error.message might contain the message from the 403 throw
            displayMessage(messageArea, error.message || '发生网络或脚本错误，请刷新或联系管理员。', false);
            setButtonState(buttonToUpdate, false, originalButtonText);
        });
    });

    // --- Recharge Code Redemption Logic ---
    // Assuming recharge forms might be added dynamically or multiple exist, use querySelectorAll
    const rechargeForms = document.querySelectorAll('.litapay-recharge-code-form'); // Use the class from your template

    rechargeForms.forEach(rechargeForm => {
        const messageArea = rechargeForm.nextElementSibling; // Common pattern: message area after form
        const submitButton = rechargeForm.querySelector('button[type="submit"]'); // More specific selector
        const originalButtonText = submitButton ? submitButton.textContent : '立即充值';
        const codeInput = rechargeForm.querySelector('input[name="recharge_code"]');
        const balanceDisplay = document.querySelector('.litapay-current-balance-value'); // Assuming one on the page

        rechargeForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const ajaxUrl = rechargeForm.dataset.ajaxurl;
            
            if (!codeInput || !codeInput.value.trim()) {
                displayMessage(messageArea, '请输入充值码。', false);
                return;
            }
            if (!ajaxUrl) {
                displayMessage(messageArea, '表单配置错误 (AJAX URL missing)。', false);
                return;
            }

            setButtonState(submitButton, true, '验证中...');
            if (messageArea) messageArea.style.display = 'none'; // Hide before new message

            const formData = new FormData(rechargeForm); // Action and CSRF should be in form via hidden inputs

            fetch(ajaxUrl, { method: 'POST', body: formData })
            .then(response => {
                if (!response.ok && response.status === 403) {
                     return response.json().then(errData => {
                        const msg = (errData && errData.data && errData.data.message) ? errData.data.message : `权限错误 (${response.status})。`;
                        throw new Error(msg);
                     });
                }
                return response.json();
            })
            .then(data => {
                if (data && typeof data.success !== 'undefined') {
                    const message = (data.data && data.data.message) ? data.data.message : (data.message || (data.success ? '充值成功！' : '充值失败！'));
                    displayMessage(messageArea, message, data.success);

                    if (data.success) {
                        if(codeInput) codeInput.value = ''; // Clear input
                        if (balanceDisplay && data.data && typeof data.data.new_balance !== 'undefined') {
                            balanceDisplay.textContent = parseFloat(data.data.new_balance).toFixed(2);
                        }
                    }
                } else {
                    console.error('LitaPay Recharge AJAX Error: Unexpected JSON structure.', data);
                    displayMessage(messageArea, '收到意外的服务器响应格式 (充值)。', false);
                }
                setButtonState(submitButton, false, originalButtonText);
            })
            .catch(error => {
                console.error('LitaPay Recharge AJAX Catch Error:', error);
                displayMessage(messageArea, error.message || '充值时发生网络或脚本错误。', false);
                setButtonState(submitButton, false, originalButtonText);
            });
        });
    });
	
	
	
    // --- Tab 切换逻辑 ---
    const authContainer = document.querySelector('.litapay-auth-container');
    if (authContainer) {
        const tabs = authContainer.querySelectorAll('.tab-link');
        const contents = authContainer.querySelectorAll('.auth-tab-content');

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                // Deactivate all
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));

                // Activate clicked
                tab.classList.add('active');
                const tabId = tab.dataset.tab;
                document.getElementById(tabId)?.classList.add('active');
            });
        });
    }

    // --- AJAX 表单提交通用函数 ---
    function handleFormSubmit(formId, messageAreaId, onSuccess) {
        const form = document.getElementById(formId);
        if (!form) return;

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const messageArea = document.getElementById(messageAreaId);
            const submitButton = form.querySelector('button[type="submit"]');
            const ajaxUrl = form.dataset.ajaxurl || 'ajax.php'; // Fallback to root ajax.php

            messageArea.textContent = '处理中...';
            messageArea.className = 'message-area processing';
            submitButton.disabled = true;

            fetch(ajaxUrl, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    messageArea.textContent = data.data?.message || data.message || '操作成功！';
                    messageArea.className = 'message-area success';
                    if (onSuccess) {
                        onSuccess(data);
                    }
                } else {
                    throw new Error(data.data?.message || data.error || '未知错误');
                }
            })
            .catch(error => {
                messageArea.textContent = '错误: ' + error.message;
                messageArea.className = 'message-area error';
            })
            .finally(() => {
                // Don't re-enable immediately on success if redirecting
                if (!onSuccess) {
                   submitButton.disabled = false;
                }
            });
        });
    }

    // --- 绑定登录表单 ---
    handleFormSubmit('litapay-login-form', 'auth-message-area', (data) => {
        // 登录成功后2秒刷新页面
        setTimeout(() => window.location.reload(), 1500);
    });

    // --- 绑定注册表单 ---
    handleFormSubmit('litapay-register-form', 'auth-message-area', (data) => {
        // 注册成功后清空表单，并提示用户去登录
        document.getElementById('litapay-register-form').reset();
        // 也许可以自动切换到登录tab
        document.querySelector('.tab-link[data-tab="login"]')?.click();
    });
    
    // --- 绑定用户中心充值表单 ---
    handleFormSubmit('user-center-recharge-form', 'recharge-message-area', (data) => {
        // 充值成功后更新余额显示
        const balanceValueEl = document.querySelector('.balance-value');
        if (balanceValueEl && data.data?.new_balance !== undefined) {
             balanceValueEl.textContent = parseFloat(data.data.new_balance).toFixed(2);
        }
        document.getElementById('user-center-recharge-form').reset();
        // 重新启用按钮
        document.querySelector('#user-center-recharge-form button').disabled = false;
    });


	
	
// (Inside your DOMContentLoaded event listener)
document.body.addEventListener('click', async function(event) {
    const afdianButton = event.target.closest('.litapay-purchase-afdian-btn');
    if (!afdianButton) return;

    event.preventDefault(); // Stop the default link navigation
    const paywallDiv = afdianButton.closest('.litapay-paywall');
    const messageArea = paywallDiv.querySelector('.litapay-message-area');
    
    // Get necessary data from the button/paywall
    const postId = afdianButton.dataset.postid; // Assuming you add this data attribute
    const price = afdianButton.dataset.price;
    const nonce = afdianButton.dataset.nonce; // A new nonce for this action
    const ajaxUrl = afdianButton.dataset.ajaxurl;
const checkNonce = afdianButton.dataset.checkNonce; 
    afdianButton.textContent = '准备中...';
    afdianButton.style.opacity = '0.7';
    messageArea.textContent = '';

    const formData = new FormData();
    formData.append('action', 'litapay_create_afdian_order'); // New AJAX action
    formData.append('post_id', postId);
    formData.append('price', price);
    formData.append('_ajax_csrf_token', nonce);

    try {
        const response = await fetch(ajaxUrl, { method: 'POST', body: formData });
        const data = await response.json();

        if (data.success && data.data.payment_url) {
            // Success! Redirect user to the Afdian payment page
window.open(data.data.payment_url, '_blank');
    // 2. 改变当前页面的UI
            paywallDiv.innerHTML = `
<h4>正在等待支付结果...</h4>
<p>请在新打开的窗口中完成支付。完成后此页面将自动刷新。</p>
<div class="spinner"></div> 
<p class="fallback-check" style="margin-top:1rem; font-size:0.8em;">
长时间无更新？<a href="content/plugins/litapay/check_order.php?order_id=${data.data.internal_order_id}" target="_blank">手动检查订单状态</a>
</p>
`; // 假设你有一个CSS spinner类

setTimeout(() => location.reload(), 60000);
setTimeout(() => location.reload(), 120000);
setTimeout(() => location.reload(), 360000);
        } else {
            // Handle error
            messageArea.textContent = data.data.message || '创建支付订单失败。';
            messageArea.className = 'litapay-message-area error';
            afdianButton.textContent = '爱发电支付';
            afdianButton.style.opacity = '1';
        }
    } catch (error) {
        console.error('Afdian order creation error:', error);
        messageArea.textContent = '网络错误，请稍后再试。';
        messageArea.className = 'litapay-message-area error';
        afdianButton.textContent = '爱发电支付';
        afdianButton.style.opacity = '1';
    }
});
	
 

});