
<?php
/**
* Plugin Name: Litapay
* Plugin URI: https://blog.lita.eu.org
* Description: Enables paid content sections, recharge codes, and Afdian payments for LitaBlog.
* Version: 1.0
* Author: 芙里塔
* Author URI: https://lita.eu.org
*/
error_log('LitaPay DEBUG: litapay.php loaded1.'); // 添加日志
if (!defined('ABSPATH')) exit; // Exit if accessed directly

define('LITAPAY_VERSION', '1.0.0');
define('LITAPAY_PLUGIN_DIR', __DIR__ . '/'); // Use __DIR__ for path
define('LITAPAY_PLUGIN_URL', rtrim(SITE_URL, '/') . '/content/plugins/litapay/'); // Construct URL based on SITE_URL
error_log('LitaPay: litapay.php loaded. LITAPAY_PLUGIN_DIR: ' . LITAPAY_PLUGIN_DIR);
// Include dependencies
require_once LITAPAY_PLUGIN_DIR . 'includes/db-schema.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-core.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-recharge.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-afdian.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/shortcodes.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/ajax-handlers.php';
// 调试：记录 db-schema.php 加载
error_log('LitaPay: db-schema.php included.');
if (is_admin()) { // Admin-only includes and hooks
require_once LITAPAY_PLUGIN_DIR . 'admin/admin-menu.php';
require_once LITAPAY_PLUGIN_DIR . 'admin/meta-boxes.php';
// Note: settings-page.php etc. are loaded via add_menu_page callback
}
error_log('LitaPay: Registering activation hook for: ' . __FILE__);
// Activation, Deactivation, Uninstall Hooks
register_activation_hook(__FILE__, 'litapay_activate');
register_deactivation_hook(__FILE__, 'litapay_deactivate');
// uninstall.php will be used for uninstallation.

/**
* Plugin Activation.
*/error_log('LitaPay: About to define litapay_activate function.'); 
function litapay_activate() {
error_log('LitaPay: litapay_activate function called.');
litapay_create_db_tables(); // From db-schema.php

// Add default options if any
update_option('litapay_version', LITAPAY_VERSION);
update_option('litapay_currency_symbol', '¥');
update_option('litapay_global_access_price', '99.00');
update_option('litapay_afdian_user_id', '');
update_option('litapay_afdian_api_token', '');
update_option('litapay_enable_afdian', '0'); // 0 for disabled, 1 for enabled
update_option('litapay_enable_balance', '1'); // Enable balance by default
update_option('litapay_enable_recharge_codes', '1'); // Enable recharge codes by default
// --- 新增：为新页面设置添加默认值 ---
update_option('litapay_login_page_id', 0); // 登录/注册页 ID
update_option('litapay_user_center_page_id', 0); // 用户中心页 ID
// --- 结束新增 ---
error_log('LitaPay: Default options updated.');
}

/**
* Plugin Deactivation.
*/
function litapay_deactivate() {
// Optional: actions on deactivation
}


/**
* Initialize plugin: hooks, shortcodes.
*/
function litapay_init() {
error_log('LitaPay DEBUG: litapay_init() CALLED.'); 
    // --- START: 新增代码 ---
    add_shortcode('litapay_user_center', 'litapay_user_center_shortcode_handler');
    add_shortcode('litapay_login_form', 'litapay_login_form_shortcode_handler');
    
    // 注册给未登录用户使用的 AJAX actions
    add_action('wp_ajax_nopriv_litapay_user_login', 'litapay_handle_ajax_login');
    add_action('wp_ajax_nopriv_litapay_user_register', 'litapay_handle_ajax_register');
    // --- END: 新增代码 ---

litapay_register_shortcodes(); // From shortcodes.php

// Register AJAX handlers
litapay_register_ajax_handlers(); // From ajax-handlers.php

// Frontend Assets
add_action('header', 'litapay_enqueue_frontend_styles');
add_action('wp_footer', 'litapay_enqueue_frontend_scripts'); // LitaBlog uses 'wp_footer'

// Admin Assets
add_action('admin_enqueue_scripts', 'litapay_enqueue_admin_scripts', 10, 1); // Priority, accepted_args
add_filter('the_content', 'litapay_filter_post_content', 20, 2);
}
add_action('init', 'litapay_init'); // LitaBlog's 'init' hook from includes/load.php


function litapay_enqueue_frontend_styles() {
error_log('LitaPay DEBUG: litapay_enqueue_frontend_styles() CALLED.'); 
wp_register_style(
'litapay-frontend-css',
LITAPAY_PLUGIN_URL . 'public/assets/css/litapay-frontend.css',
[], // Dependencies
LITAPAY_VERSION // Version
);
wp_enqueue_style('litapay-frontend-css');
error_log('LitaPay DEBUG: Registered & Enqueued litapay-frontend-css. URL: ' . LITAPAY_PLUGIN_URL . 'public/assets/css/litapay-frontend.css'); 
}

function litapay_enqueue_frontend_scripts() {
error_log('LitaPay DEBUG: litapay_enqueue_frontend_scripts() CALLED.'); 
wp_register_script(
'litapay-frontend-js',
LITAPAY_PLUGIN_URL . 'public/assets/js/litapay-frontend.js',
[], // Dependencies
LITAPAY_VERSION, // Version
true // In footer
);
wp_enqueue_script('litapay-frontend-js');
error_log('LitaPay DEBUG: Registered & Enqueued litapay-frontend-js. URL: ' . LITAPAY_PLUGIN_URL . 'public/assets/js/litapay-frontend.js'); // << ADD THIS

echo "ok";

}


/**
* Enqueue admin scripts and styles.
* $hook_suffix is provided by LitaBlog's admin_enqueue_scripts action.
*//*
function litapay_enqueue_admin_scripts($hook_suffix) {
$litapay_admin_pages = [
'admin_page_litapay-settings',
'admin_page_litapay-recharge-codes',
'admin_page_litapay-transactions',
// Add other LitaPay admin page hook suffixes here
];

// Check if current page is content editor or one of LitaPay's admin pages
$load_assets = false;
if (strpos($hook_suffix, 'content.php') === 0) { // For admin/content.php (post editor)
$load_assets = true;
} elseif (in_array($hook_suffix, $litapay_admin_pages)) {
$load_assets = true;
}

if ($load_assets) {
wp_register_style('litapay-admin-css', LITAPAY_PLUGIN_URL . 'admin/assets/css/litapay-admin.css', [], LITAPAY_VERSION);
wp_enqueue_style('litapay-admin-css');

wp_register_script('litapay-admin-js', LITAPAY_PLUGIN_URL . 'admin/assets/js/litapay-admin.js', [], LITAPAY_VERSION, true);
wp_enqueue_script('litapay-admin-js');
// Data for admin JS will be passed similarly to frontend if needed, or via data attributes.
}
}*/
function litapay_enqueue_admin_scripts($hook_suffix) {
error_log('LitaPay DEBUG: litapay_enqueue_admin_scripts() CALLED with hook_suffix: ' . $hook_suffix); // << ADD THIS

$litapay_admin_page_slugs = [
'litapay-main', // The slug for the main menu page
'litapay-settings',
'litapay-recharge-codes',
'litapay-transactions',
];

// Construct the expected hook suffixes for LitaPay pages
$litapay_hook_suffixes = [];
foreach ($litapay_admin_page_slugs as $slug) {
$litapay_hook_suffixes[] = 'admin.php_page_' . $slug;
}
error_log('LITAPAY_DEBUG: Expected admin hook suffixes: ' . print_r($litapay_hook_suffixes, true));
// Also include the content edit page for the meta box CSS/JS if needed
$load_assets = false;
if (strpos($hook_suffix, 'content.php') === 0) { // For admin/content.php (post editor)
$load_assets = true;
} elseif (in_array($hook_suffix, $litapay_hook_suffixes)) { // Check against LitaPay's admin pages
$load_assets = true;
}

if ($load_assets) {
error_log('LitaPay DEBUG: Admin assets WILL BE LOADED for ' . $hook_suffix); 
wp_register_style('litapay-admin-css', LITAPAY_PLUGIN_URL . 'admin/css/litapay-admin.css', [], LITAPAY_VERSION);
wp_enqueue_style('litapay-admin-css');
error_log('LitaPay DEBUG: Registered & Enqueued litapay-admin-css. URL: ' . LITAPAY_PLUGIN_URL . 'admin/css/litapay-admin.css'); // << ADD THIS



wp_register_script('litapay-admin-js', LITAPAY_PLUGIN_URL . 'admin/js/litapay-admin.js', [], LITAPAY_VERSION, true);
wp_enqueue_script('litapay-admin-js');
error_log('LitaPay DEBUG: Registered & Enqueued litapay-admin-js. URL: ' . LITAPAY_PLUGIN_URL . 'admin/js/litapay-admin.js');
}
}


// Webhook endpoint check (must be before any output or session start if not already started)
if (isset($_GET['litapay_webhook']) && $_GET['litapay_webhook'] === 'afdian') {
// This file will handle its own bootstrapping of config/functions
require_once LITAPAY_PLUGIN_DIR . 'includes/webhook-afdian.php';
exit;
}

// --- Modified Recharge Page Handling ---
if (isset($_GET['litapay_page']) && $_GET['litapay_page'] === 'recharge') {
$official_recharge_page_id = (int)get_option('litapay_official_recharge_page_id', 0);
$enable_standalone_recharge_page = get_option('litapay_enable_standalone_recharge_page', '1') === '1'; // Default enabled
$redirect_standalone_to_official = get_option('litapay_redirect_standalone_to_official', '0') === '1';

if ($official_recharge_page_id > 0 && $redirect_standalone_to_official) {
// 如果设置了官方页面并且启用了重定向，则重定向到官方页面
$official_page_url = Permalink::get_post_link($official_recharge_page_id); // LitaBlog's permalink function
if ($official_page_url) {
header('Location: ' . $official_page_url, true, 301); // Permanent redirect
exit;
} else {
// Official page ID is set but somehow couldn't get URL, fallback to standalone or error
// This case should be rare. For now, we can log and proceed to standalone if enabled.
error_log("LitaPay: Could not get permalink for official recharge page ID: " . $official_recharge_page_id);
if ($enable_standalone_recharge_page) {
require_once LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form.php';
exit;
} else {
// Neither official page URL found nor standalone enabled.
// Show a 404 or simple error message if LitaBlog's router doesn't handle it.
// For now, let's assume the router would catch it if we don't output anything.
// Or, you can explicitly send a 404 header:
if (!headers_sent()) { header("HTTP/1.0 404 Not Found"); }
echo "Recharge page not configured."; // Simple message
exit;
}
}
} elseif ($enable_standalone_recharge_page) {
// 如果启用了独立页面 (且不重定向或未设置官方页面)，则加载独立页面
require_once LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form.php';
exit;
} else {
// 如果独立页面被禁用，并且没有官方页面可以重定向，则视为未找到
// LitaBlog's router should ideally handle this by not matching this condition.
// If reached here, it means ?litapay_page=recharge was accessed but standalone is disabled.
// You could send a 404 or redirect to homepage.
if (!headers_sent()) { header("HTTP/1.0 404 Not Found"); }
// For a cleaner 404, let LitaBlog's main router handle it by not outputting here
// and ensuring the Router class has a 404 fallback.
// If you want a custom message:
echo "Recharge functionality via this link is currently disabled by the administrator.";
exit;
}
}
// --- End Modified Recharge Page Handling ---
/**
 * LitaPay 插件的权限过滤器.
 * 当插件激活时，禁止非管理员用户发帖.
 *
 * @param bool   $has_cap    原始的权限检查结果.
 * @param string $capability 正在被检查的权限.
 * @param string $user_role  当前用户的角色.
 * @return bool  修改后的权限检查结果.
 */
function litapay_disable_user_posting($has_cap, $capability, $user_role) {
    // 我们只关心 'publish_posts' 这个权限
    if ($capability === 'publish_posts') {
        // 如果用户不是管理员，强制返回 false，剥夺其发帖权限
        if ($user_role !== 'administrator') {
            return false;
        }
    }
    
    // 对于其他所有权限，返回原始的检查结果，不做干预
    return $has_cap;
}
add_filter('user_has_cap', 'litapay_disable_user_posting', 99, 3);



?>
