<?php
// File: content/plugins/litapay/check_order.php

// 加载 LitaBlog 核心环境
require_once dirname(dirname(dirname(__DIR__))) . '/config.php';
//require_once dirname(dirname(dirname(dirname(__DIR__)))) . '/config.php';
require_once ABSPATH . 'includes/load.php';

// 确保 litapay 插件的函数也被加载
require_once ABSPATH . 'content/plugins/litapay/litapay.php';

if (!is_logged_in()) {
    header('Location: ' . SITE_URL . '/admin/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}

$internal_order_id = $_GET['order_id'] ?? null;
$current_user_id = $_SESSION['user_id'];

if (!$internal_order_id) {
    die("无效的订单号。");
}

// 权限检查：确保当前用户是这个订单的所有者
$db = get_db();
$stmt_check_owner = $db->prepare("SELECT user_id FROM litapay_purchases WHERE transaction_id = ?");
$stmt_check_owner->execute([$internal_order_id]);
$order_owner_id = $stmt_check_owner->fetchColumn();

if ($order_owner_id != $current_user_id) {
     die("您无权查看此订单。");
}

// 调用核心验证函数
$result = LitaPayAfdianAPI::verify_and_update_order_status($internal_order_id);

// 根据结果显示不同页面
$post_id_to_redirect = $_GET['post_id'] ?? null;
$redirect_url = $post_id_to_redirect ? Permalink::get_post_link($post_id_to_redirect) : SITE_URL;

echo "<!DOCTYPE html><html><head><title>订单状态查询</title>";
echo "<style>body{font-family:sans-serif;text-align:center;padding-top:50px;}.message{padding:20px;border-radius:5px;max-width:400px;margin:0 auto;}.success{background:#d4edda;color:#155724;}.pending{background:#fff3cd;color:#856404;}.error{background:#f8d7da;color:#721c24;}</style>";
echo "</head><body>";

if ($result['status'] === 'paid') {
    echo "<div class='message success'><h1>支付成功！</h1><p>您的内容已解锁。</p><p><a href='{$redirect_url}'>返回文章</a> 或 <a href='" . SITE_URL . "'>返回首页</a></p></div>";
    echo "<script>setTimeout(function(){ window.location.href = '{$redirect_url}'; }, 3000);</script>";
} elseif ($result['status'] === 'unpaid') {
    echo "<div class='message pending'><h1>等待支付确认...</h1><p>系统尚未收到您的支付成功通知。如果您已支付，请稍后再试。</p><p>页面将在 10 秒后自动刷新重试。</p><p><a href='{$_SERVER['REQUEST_URI']}'>立即刷新</a> | <a href='" . SITE_URL . "'>返回首页</a></p></div>";
    echo "<meta http-equiv='refresh' content='10'>"; // 10秒后自动刷新
} else {
    echo "<div class='message error'><h1>查询失败</h1><p>{$result['message']}</p><p><a href='{$redirect_url}'>返回重试</a></p></div>";
}

echo "</body></html>";
exit;