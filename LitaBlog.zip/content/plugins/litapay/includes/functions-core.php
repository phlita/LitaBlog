<?php
if (!defined('ABSPATH')) exit; // LitaBlog's equivalent for security

/**
* Get user's LitaPay balance.
* Uses LitaBlog's get_user_meta.
*
* @param int $user_id
* @return float User's balance.
*/
function litapay_get_user_balance($user_id) {
if (!$user_id) return 0.00;
$balance = get_user_meta($user_id, 'litapay_balance', true); // true for single value
return $balance ? (float)$balance : 0.00;
}

/**
* Update user's LitaPay balance.
* Uses LitaBlog's update_user_meta.
*
* @param int $user_id
* @param float $new_balance
* @return bool True on success, false on failure.
*/
function litapay_update_user_balance($user_id, $new_balance) {
if (!$user_id) return false;
return update_user_meta($user_id, 'litapay_balance', (float)$new_balance);
}

/**
* Add an amount to user's balance.
*
* @param int $user_id
* @param float $amount_to_add
* @return bool True on success, false on failure.
*/
function litapay_add_to_user_balance($user_id, $amount_to_add) {
if (!$user_id || (float)$amount_to_add <= 0) return false;
$current_balance = litapay_get_user_balance($user_id);
$new_balance = $current_balance + (float)$amount_to_add;
return litapay_update_user_balance($user_id, $new_balance);
}

/**
* Get the price for a specific post.
* Uses LitaBlog's get_post_meta.
*
* @param int $post_id
* @return float Price of the post, or 0.00 if not set/free.
*/
function litapay_get_post_price($post_id) {
if (!$post_id) return 0.00;
$price = get_post_meta($post_id, 'litapay_post_price', true);
return $price ? (float)$price : 0.00;
}

/**
* Set the price for a specific post and mark if it requires payment.
* Uses LitaBlog's update_post_meta.
*
* @param int $post_id
* @param float $price
* @return bool True if price meta was updated, false otherwise.
*//*
function litapay_set_post_price($post_id, $price) {
if (!$post_id) return false;
$price_float = (float)$price;
// Mark if content requires payment based on price
update_post_meta($post_id, 'litapay_content_requires_payment', $price_float > 0 ? '1' : '0');
// Store the actual price
return update_post_meta($post_id, 'litapay_post_price', $price_float);
}*/
function litapay_set_post_price($post_id, $price) {
if (!$post_id) return false;
$price_float = (float)$price;

// 两个操作都要成功才返回 true
$payment_flag_updated = update_post_meta($post_id, 'litapay_content_requires_payment', $price_float > 0 ? '1' : '0');
$price_updated = update_post_meta($post_id, 'litapay_post_price', $price_float);

return $payment_flag_updated && $price_updated;
}



/**
* Check if a user has purchased a specific post.
*
* @param int $user_id
* @param int $post_id
* @return bool True if purchased, false otherwise.
*/
function litapay_user_has_purchased_post($user_id, $post_id) {
if (!$user_id || !$post_id) return false;
$db = get_db(); // LitaBlog's DB access
try {
$stmt = $db->prepare("SELECT COUNT(*) FROM litapay_purchases 
WHERE user_id = :user_id AND post_id = :post_id 
AND purchase_type = 'post' AND status = 'completed'");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchColumn() > 0;
} catch (PDOException $e) {
error_log("LitaPay DB Error (user_has_purchased_post): " . $e->getMessage());
return false;
}
}

/**
* Check if user has active global access (subscription-like).
*
* @param int $user_id
* @return bool True if has global access, false otherwise.
*/
function litapay_user_has_global_access($user_id) {
if (!$user_id) return false;

// Check time-based global access from user meta
$global_access_until = get_user_meta($user_id, 'litapay_global_access_until', true);
if ($global_access_until && (int)$global_access_until > time()) {
return true;
}

// Check permanent global access via purchases table (if a "global access product" was bought)
$db = get_db();
try {
$stmt = $db->prepare("SELECT COUNT(*) FROM litapay_purchases 
WHERE user_id = :user_id AND purchase_type = 'global_access_permanent' AND status = 'completed'");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchColumn() > 0;
} catch (PDOException $e) {
error_log("LitaPay DB Error (user_has_global_access - purchases check): " . $e->getMessage());
return false;
}
}

/**
* Grant global access to a user.
*
* @param int $user_id
* @param int $duration_days How many days of access. 0 for permanent (records in purchases table).
* @param float $amount_paid The amount paid for this global access (for record keeping).
* @param string $payment_method Method used.
* @param string|null $transaction_id External transaction ID.
* @return bool True on success.
*/
function litapay_grant_global_access($user_id, $duration_days = 0, $amount_paid = 0.00, $payment_method = 'manual_grant', $transaction_id = null) {
if (!$user_id) return false;

if ($duration_days > 0) {
$current_expiry = get_user_meta($user_id, 'litapay_global_access_until', true);
$start_time = ($current_expiry && (int)$current_expiry > time()) ? (int)$current_expiry : time();
$new_expiry = $start_time + ($duration_days * 86400);
$meta_updated = update_user_meta($user_id, 'litapay_global_access_until', $new_expiry);
if ($meta_updated) {
// Record this grant if an amount was associated (e.g., a subscription purchase)
litapay_record_purchase($user_id, null, 'global_access_timed', $amount_paid, $payment_method, $transaction_id);
}
return $meta_updated;
} else { // Permanent global access
return litapay_record_purchase($user_id, null, 'global_access_permanent', $amount_paid, $payment_method, $transaction_id);
}
}

/**
* Record a purchase transaction.
*
* @param int $user_id
* @param int|null $post_id NULL for non-post specific purchases like global access.
* @param string $type 'post', 'global_access_timed', 'global_access_permanent', 'recharge_via_afdian' etc.
* @param float $amount
* @param string $payment_method 'balance', 'afdian', 'recharge_code_redemption', 'manual_grant'
* @param string|null $transaction_id External transaction ID or internal reference.
* @param string $status 'completed', 'pending', 'failed'.
* @return bool True on success, false on failure.
*/
function litapay_record_purchase($user_id, $post_id, $type, $amount, $payment_method, $transaction_id = null, $status = 'completed') {
if (!$user_id) return false;
$db = get_db();
try {
$stmt = $db->prepare("INSERT INTO litapay_purchases 
(user_id, post_id, purchase_type, amount_paid, payment_method, transaction_id, status) 
VALUES (:user_id, :post_id, :type, :amount, :payment_method, :transaction_id, :status)");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':post_id', $post_id, $post_id === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
$stmt->bindValue(':type', $type, PDO::PARAM_STR);
$stmt->bindValue(':amount', (float)$amount, PDO::PARAM_STR); // SQLite stores REAL as TEXT often
$stmt->bindValue(':payment_method', $payment_method, PDO::PARAM_STR);
$stmt->bindValue(':transaction_id', $transaction_id, $transaction_id === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
$stmt->bindValue(':status', $status, PDO::PARAM_STR);
return $stmt->execute();
} catch (PDOException $e) {
error_log("LitaPay DB Error (record_purchase): " . $e->getMessage());
return false;
}
}

/**
* Process payment for a post using user balance.
*
* @param int $user_id
* @param int $post_id
* @return array ['success' => bool, 'message' => string]
*//*
function litapay_process_balance_payment_for_post($user_id, $post_id) {
if (!$user_id || !$post_id) return ['success' => false, 'message' => 'Invalid user or post ID.'];

$post_price = litapay_get_post_price($post_id);
if ($post_price <= 0) return ['success' => true, 'message' => 'This content is free.']; // Or error if price expected

$user_balance = litapay_get_user_balance($user_id);

if ($user_balance < $post_price) {
return ['success' => false, 'message' => '您的余额不足，请先充值。'];
}

$db = get_db();
try {
$db->beginTransaction();

$new_balance = $user_balance - $post_price;
if (!litapay_update_user_balance($user_id, $new_balance)) {
throw new Exception("Failed to update user balance meta.");
}

if (!litapay_record_purchase($user_id, $post_id, 'post', $post_price, 'balance', 'BAL-' . $user_id . '-' . $post_id . '-' . time())) {
throw new Exception("Failed to record purchase transaction.");
}

$db->commit();
return ['success' => true, 'message' => '购买成功！'];

} catch (Exception $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay Balance Payment Error (Post: {$post_id}, User: {$user_id}): " . $e->getMessage());
return ['success' => false, 'message' => '支付处理失败，请稍后再试。'];
}
}*/
/**
* Process payment for a post using user balance.
*
* @param int $user_id
* @param int $post_id
* @param float $price_to_charge The actual price being charged for this transaction
* @return array ['success' => bool, 'message' => string]
*/
function litapay_process_balance_payment_for_post($user_id, $post_id, $price_to_charge) { // <--- 修改函数签名
    if (!$user_id || !$post_id) return ['success' => false, 'message' => 'Invalid user or post ID.'];

    // $post_price = litapay_get_post_price($post_id); // <--- 不再使用这个来判断收费
    // 使用传入的 $price_to_charge
    if ($price_to_charge <= 0) {
         // 理论上，如果前端逻辑正确，price_to_charge 不会是0或负数，因为付费墙不会为免费内容显示
         return ['success' => false, 'message' => '购买价格无效。'];
    }

    $user_balance = litapay_get_user_balance($user_id);

    if ($user_balance < $price_to_charge) { // <--- 使用 $price_to_charge
        $recharge_url = litapay_get_recharge_page_url();
        $message = '您的余额不足';
        if ($recharge_url) {
            $message .= '，<a href="'.e($recharge_url).'">请先充值</a>。';
        } else {
            $message .= '，且充值功能未开启。';
        }
        return ['success' => false, 'message' => $message];
    }

    $db = get_db();
    try {
        $db->beginTransaction();

        $new_balance = $user_balance - $price_to_charge; // <--- 使用 $price_to_charge
        if (!litapay_update_user_balance($user_id, $new_balance)) {
            throw new Exception("Failed to update user balance meta.");
        }

        // 使用 $price_to_charge 记录购买
        if (!litapay_record_purchase($user_id, $post_id, 'post', $price_to_charge, 'balance', 'BAL-' . $user_id . '-' . $post_id . '-' . time())) {
            throw new Exception("Failed to record purchase transaction.");
        }

        $db->commit();
        return ['success' => true, 'message' => '购买成功！'];

    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("LitaPay Balance Payment Error (Post: {$post_id}, User: {$user_id}, Price: {$price_to_charge}): " . $e->getMessage());
        return ['success' => false, 'message' => '支付处理失败，请稍后再试。'];
    }
}


/**
* Check if Afdian payments are configured and enabled in LitaPay settings.
*
* @return bool
*/
function litapay_is_afdian_enabled() {
$enable_afdian = get_option('litapay_enable_afdian', '0'); // Get LitaPay specific setting
if ($enable_afdian !== '1') {
return false;
}
$afdian_user_id = get_option('litapay_afdian_user_id');
$afdian_api_token = get_option('litapay_afdian_api_token');
return !empty($afdian_user_id) && !empty($afdian_api_token);
}

/**
* Get LitaBlog's main AJAX handler URL.
*
* @return string
*/
function litapay_get_ajax_url() {
return rtrim(SITE_URL, '/') . '/ajax.php'; // LitaBlog's AJAX endpoint
}

/**
* Get the URL for the LitaPay recharge page.
* Prioritizes the admin-defined official recharge page if set.
* Falls back to the standalone ?litapay_page=recharge if enabled and no official page.
* Returns empty string if no recharge page is configured/enabled.
*
* @return string The recharge page URL or empty string.
*/
function litapay_get_recharge_page_url() {
$official_recharge_page_id = (int)get_option('litapay_official_recharge_page_id', 0);
$enable_standalone_recharge_page = get_option('litapay_enable_standalone_recharge_page', '1') === '1';

if ($official_recharge_page_id > 0) {
$official_page_url = Permalink::get_post_link($official_recharge_page_id);
if ($official_page_url) {
return $official_page_url;
}
// Fallback if official page ID is bad, but standalone is enabled
error_log("LitaPay: Bad official recharge page ID {$official_recharge_page_id}, falling back if standalone enabled.");
}

if ($enable_standalone_recharge_page) {
return rtrim(SITE_URL, '/') . '/?litapay_page=recharge';
}

return ''; // No recharge page configured or enabled
}


/**
* Process payment for global access using user balance.
*
* @param int $user_id
* @return array ['success' => bool, 'message' => string]
*/
function litapay_process_balance_payment_for_global_access($user_id) {
if (!$user_id) return ['success' => false, 'message' => '无效的用户ID。'];

$global_price = (float)get_option('litapay_global_access_price', '0');
if ($global_price <= 0) {
return ['success' => false, 'message' => '全局阅读权限当前不可购买。'];
}

if (litapay_user_has_global_access($user_id)) {
return ['success' => false, 'message' => '您已拥有全局阅读权限。'];
}

$user_balance = litapay_get_user_balance($user_id);

if ($user_balance < $global_price) {
return ['success' => false, 'message' => '您的余额不足，请先充值。'];
}

$db = get_db();
try {
$db->beginTransaction();

$new_balance = $user_balance - $global_price;
if (!litapay_update_user_balance($user_id, $new_balance)) {
throw new Exception("更新用户余额失败。");
}

// Grant global access (permanent by default, or make it configurable via another option)
// For simplicity, let's assume 'global_access_permanent' for now.
// Or use a timed duration if set, e.g., 365 days.
// $duration_days = (int)get_option('litapay_global_access_duration_days', 0); // 0 for permanent
$duration_days = 0; // For permanent access in this example

if (!litapay_grant_global_access($user_id, $duration_days, $global_price, 'balance', 'BAL-GLOBAL-' . $user_id . '-' . time())) {
throw new Exception("授予全局权限失败。");
}

$db->commit();
return ['success' => true, 'message' => '全局阅读权限购买成功！'];

} catch (Exception $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay Global Access Payment Error (User: {$user_id}): " . $e->getMessage());
return ['success' => false, 'message' => '全局权限购买处理失败，请稍后再试。'];
}
}


// --- 新增：获取登录/注册页面URL ---
/**
* 获取前端登录/注册页面的URL
* @return string URL
*/
function litapay_get_login_page_url() {
    $page_id = (int)get_option('litapay_login_page_id', 0);
    if ($page_id > 0) {
        $page_url = Permalink::get_post_link($page_id);
        if ($page_url) {
            return $page_url;
        }
    }
    // 回退到默认的后台登录页
    return rtrim(SITE_URL, '/') . '/admin/login.php';
}
// --- 结束新增 ---

// --- 新增：获取用户中心页面URL ---
/**
* 获取前端用户中心页面的URL
* @return string URL
*/
function litapay_get_user_center_page_url() {
    $page_id = (int)get_option('litapay_user_center_page_id', 0);
    if ($page_id > 0) {
        $page_url = Permalink::get_post_link($page_id);
        if ($page_url) {
            return $page_url;
        }
    }
    // 回退到默认的后台个人资料页
    return rtrim(SITE_URL, '/') . '/admin/profile.php';
}
// --- 结束新增 ---
?>
