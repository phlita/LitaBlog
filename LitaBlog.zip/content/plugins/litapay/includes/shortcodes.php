
<?php
if (!defined('ABSPATH')) exit;

function litapay_register_shortcodes() {
add_shortcode('litapay_paid', 'litapay_paid_content_shortcode_handler');
add_shortcode('litapay_recharge_form', 'litapay_recharge_form_shortcode_handler');
}

/**
* Handles the [litapay_paid] shortcode.
*/
function litapay_paid_content_shortcode_handler($atts, $content = null) {
// Access LitaBlog's global template data if available
// This is a bit of a hack. Ideally, the post ID should be passed to apply_filters('the_content', $content, $post_id)
// and then apply_filters should pass it to do_shortcode, which then passes to the handler.
// LitaBlog's current do_shortcode doesn't do this.
global $template_data_for_shortcodes_if_needed; // Hypothetical global if set by prepare_template_data
// For now, this won't be set.

$post_id = null;
// Try to get post_id from $template_data if it's available (e.g. directly in theme files)
// This is a workaround since LitaBlog's do_shortcode doesn't pass context.
// The MOST reliable way is if prepare_template_data could make $template_data globally accessible
// to shortcodes, or if do_shortcode was enhanced.
// Given the structure, for `the_content` filter, $main_object from index.php IS LitaBlog's current post.

// We rely on $main_object being available from LitaBlog's index.php context when 'the_content' is filtered.
global $main_object; // This is set in LitaBlog's index.php before prepare_template_data
// and apply_filters('the_content') is called within prepare_template_data.

if (isset($main_object['id']) && (isset($main_object['type']) && ($main_object['type'] === 'post' || $main_object['type'] === 'page'))) {
$post_id = $main_object['id'];
}

//if (!$post_id) {return '<!-- LitaPay: Error - Post ID not found for paid content shortcode. -->';}
// 用户友好的错误处理
function litapay_render_error($message, $show_support = true) {
$support_link = $show_support ? 
'<p><small>如果问题持续存在，请联系<a href="mailto:support@example.com">技术支持</a>。</small></p>' : '';

return sprintf(
'<div class="litapay-error" style="border:1px solid #f5c6cb;background:#f8d7da;color:#721c24;padding:12px;border-radius:4px;margin:10px 0;">
<strong>⚠️ %s</strong>
%s
</div>',
e($message),
$support_link
);
}

// 使用示例
if (!$post_id) {
return litapay_render_error('无法识别当前文章，请刷新页面重试');
}

if (!function_exists('litapay_get_post_price')) {
return litapay_render_error('付费功能组件缺失');
}


$default_atts = ['price' => null];
$atts = array_merge($default_atts, (array)$atts);
$shortcode_price = $atts['price'] !== null ? (float)$atts['price'] : null;

// If shortcode has a price, it overrides post meta for THIS block.
// If shortcode has no price, use post meta price.
// If post meta price is 0, but shortcode has no price, this block is considered part of a "whole post paid" scenario.
/*
$effective_price = $shortcode_price !== null ? $shortcode_price : litapay_get_post_price($post_id);
$is_entire_post_paid_scenario = ($shortcode_price === null && litapay_get_post_price($post_id) > 0);
if ($effective_price <= 0 && !$is_entire_post_paid_scenario) {
return do_shortcode($content); // Free block or free post
}*/
// 获取价格信息
$shortcode_price = isset($atts['price']) && is_numeric($atts['price']) ? (float)$atts['price'] : null;
$post_price = litapay_get_post_price($post_id);

// 明确的价格逻辑
if ($shortcode_price !== null) {
// 情况1: shortcode 指定了价格
$effective_price = $shortcode_price;
$payment_type = 'block'; // 单独付费块
} else {
// 情况2: shortcode 未指定价格，使用文章价格
$effective_price = $post_price;
$payment_type = $post_price > 0 ? 'post' : 'free'; // 整篇文章付费或免费
}

// 清晰的免费判断
if ($effective_price <= 0) {
return do_shortcode($content); // 确实免费的内容
}// 如果到这里，说明需要付费


$user_has_access = false;
if (is_logged_in()) {
$user_id = $_SESSION['user_id'];
if (is_admin() || litapay_user_has_global_access($user_id) || litapay_user_has_purchased_post($user_id, $post_id)) {
$user_has_access = true;
}
}




if ($user_has_access) {
return do_shortcode($content); // User has access
}

// User does not have access, show paywall
ob_start();

// --- START: Add global purchase info to paywall_data ---
$global_access_price = (float)get_option('litapay_global_access_price', '0'); // Get global price, default 0
$user_has_global_access = is_logged_in() ? litapay_user_has_global_access($_SESSION['user_id']) : false;
// --- END: Add global purchase info ---

// --- 修改：使用新的辅助函数获取登录URL ---
$login_url = litapay_get_login_page_url();
$login_url_with_redirect = $login_url . (strpos($login_url, '?') === false ? '?' : '&') . 'redirect=' . urlencode(Permalink::get_post_link($post_id));
// --- 结束修改 ---


$paywall_data = [
'price' => $effective_price,
'post_id' => $post_id,
'currency_symbol' => get_option('litapay_currency_symbol', '¥'),
'is_afdian_enabled' => litapay_is_afdian_enabled(),
'user_is_logged_in' => is_logged_in(),
'login_url' => $login_url_with_redirect, // --- 修改：使用新生成的带重定向的URL
'ajax_url' => litapay_get_ajax_url(),
'purchase_nonce' => generateCsrfToken('litapay_purchase_post_balance'),
 'create_afdian_order_nonce' => generateCsrfToken('litapay_create_afdian_order'),
  'check_order_status_nonce' => generateCsrfToken('litapay_check_local_order_status'),
'current_user_balance' => is_logged_in() ? litapay_get_user_balance($_SESSION['user_id']) : 0,

// --- NEW: Pass global purchase data ---
'global_access_price' => $global_access_price,
'user_has_global_access' => $user_has_global_access, // To decide if button should be shown
'purchase_global_nonce' => generateCsrfToken('litapay_purchase_global_access_balance'), // New nonce
// --- END: Pass global purchase data ---

];
include LITAPAY_PLUGIN_DIR . 'public/templates/paywall-message.php';
return ob_get_clean();
}


function litapay_recharge_form_shortcode_handler($atts, $content = null) {
if (!is_logged_in()) {
// --- 修改：使用新的辅助函数获取登录URL ---
$login_url = litapay_get_login_page_url();
$login_url_with_redirect = $login_url . (strpos($login_url, '?') === false ? '?' : '&') . 'redirect=' . urlencode($_SERVER['REQUEST_URI']);
return '<p>请先 <a href="' . e($login_url_with_redirect) . '">登录</a> 后才能充值。</p>';
// --- 结束修改 ---
}
ob_start();
$user_id = $_SESSION['user_id']; 
$recharge_template_data = [
'ajax_url' => litapay_get_ajax_url(),
'redeem_nonce' => generateCsrfToken('litapay_redeem_code'),
'current_user_balance' => litapay_get_user_balance($_SESSION['user_id']),
'currency_symbol' => get_option('litapay_currency_symbol', '¥'),
'enable_afdian_recharge' => function_exists('litapay_is_afdian_enabled') && litapay_is_afdian_enabled() && get_option('litapay_enable_afdian', '0') === '1',
'user_id'              => $user_id, // 传递 user_id 给模板

];
include LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form-template.php';
return ob_get_clean();
}


// content/plugins/litapay/includes/shortcodes.php
// (或者将此逻辑移到一个更合适的核心过滤函数中，比如 functions-core.php)

function litapay_filter_post_content($content_from_core, $post_id_from_filter = null) {
    // 首先，尝试获取当前文章的 ID
    // LitaBlog 的 apply_filters('the_content', $post_content, $main_object['id']); 会传递 post_id
    $post_id = $post_id_from_filter;

    // 如果 $post_id_from_filter 未传递（例如在某些不规范的调用中），
    // 尝试从全局 $main_object 获取（这依赖于 LitaBlog 的执行上下文）
    if (!$post_id) {
        global $main_object;
        if (isset($main_object['id']) && (isset($main_object['type']) && ($main_object['type'] === 'post' || $main_object['type'] === 'page'))) {
            $post_id = $main_object['id'];
        }
    }

    if (!$post_id) {
        // 如果仍然无法获取 post_id，则无法进行付费检查，直接返回原始内容
        // 也可以记录一个错误
        // error_log("LitaPay filter_post_content: Could not determine post ID.");
        return $content_from_core;
    }

    // 检查这篇文章是否设置了 Metabox 价格，并且需要付费
    $requires_payment_meta = get_post_meta($post_id, 'litapay_content_requires_payment', true);
    $effective_price_for_post = litapay_get_post_price($post_id); // 从 Metabox 获取价格

    // 只有当 Metabox 价格 > 0，且文章内容中 *不包含* [litapay_paid] 短代码时，
    // 才应用全局付费墙。如果包含短代码，则让短代码逻辑优先处理。
    if ($requires_payment_meta === '1' && $effective_price_for_post > 0 && strpos($content_from_core, '[litapay_paid') === false) {
        $user_has_access = false;
        if (is_logged_in()) {
            $user_id_for_check = $_SESSION['user_id'];
            if (is_admin() || litapay_user_has_global_access($user_id_for_check) || litapay_user_has_purchased_post($user_id_for_check, $post_id)) {
                $user_has_access = true;
            }
        }

        if (!$user_has_access) {
            // 用户无权访问，显示付费墙，并替换原始内容
            ob_start();
            // --- 修改：使用新的辅助函数获取登录URL ---
            $login_url_global = litapay_get_login_page_url();
            $login_url_with_redirect_global = $login_url_global . (strpos($login_url_global, '?') === false ? '?' : '&') . 'redirect=' . urlencode(Permalink::get_post_link($post_id));
            // --- 结束修改 ---
            $paywall_data = [
                'price' => $effective_price_for_post,
                'post_id' => $post_id,
                'currency_symbol' => get_option('litapay_currency_symbol', '¥'),
                'is_afdian_enabled' => litapay_is_afdian_enabled(),
                'user_is_logged_in' => is_logged_in(),
                'login_url' => $login_url_with_redirect_global, // --- 修改：使用新生成的URL
                'ajax_url' => litapay_get_ajax_url(),
                'purchase_nonce' => generateCsrfToken('litapay_purchase_post_balance'),
                'current_user_balance' => is_logged_in() ? litapay_get_user_balance($_SESSION['user_id']) : 0,
                'global_access_price' => (float)get_option('litapay_global_access_price', '0'),
                'user_has_global_access' => is_logged_in() ? litapay_user_has_global_access($_SESSION['user_id']) : false,
                'purchase_global_nonce' => generateCsrfToken('litapay_purchase_global_access_balance'),
            ];
            if (defined('LITAPAY_PLUGIN_DIR')) {
                include LITAPAY_PLUGIN_DIR . 'public/templates/paywall-message.php';
            }
            return ob_get_clean(); // 返回付费墙 HTML，替换原始 $content_from_core
        }
        // 如果用户有权访问，则继续执行下面的短代码处理（如果内容中有的话）
    }

    // --- 原有的短代码处理逻辑 ---
    // 检查内容中是否包含加密标记（这是 JSCrypt 的逻辑，LitaPay 应该只处理自己的付费墙）
    // LitaPay 的短代码处理应该在 `litapay_paid_content_shortcode_handler` 中完成。
    // `do_shortcode` 已经在 `prepare_template_data` 中执行过了。
    // `the_content` 过滤器通常在 `do_shortcode` *之后* 执行（取决于优先级）。
    // 因此，这里的 `$content_from_core` 可能已经是执行过短代码后的内容了。
    //
    // 如果 LitaPay 的 `[litapay_paid]` 短代码还没被处理，那么 `do_shortcode` 应该在这个过滤器之前，
    // 或者 LitaPay 自己在这个过滤器里处理自己的短代码（但不推荐，因为核心已经有 `do_shortcode`）。
    //
    // 假设 `do_shortcode` 在 `prepare_template_data` 中优先级高于 `the_content` 过滤器，
    // 那么这里的 `$content_from_core` 对于 `[litapay_paid]` 来说，要么已经被替换（如果用户有权限），
    // 要么就是付费墙本身（如果用户无权限）。
    //
    // 如果上面的全局付费墙逻辑已经替换了内容，那么这里的 `$content_from_core` 就是付费墙HTML，
    // 后续的 JSCrypt 逻辑不应该再对付费墙HTML进行操作。

    // JSCrypt 的逻辑应该有它自己的 `the_content` 过滤器，并注意优先级。
    // 这里我们只返回 LitaPay 处理后的内容（可能是原始内容，也可能是付费墙）。
    return $content_from_core;
}



/**
 * [litapay_login_form] 短代码处理函数
 * 显示登录/注册表单，或提示已登录。
 */
function litapay_login_form_shortcode_handler() {
    if (is_logged_in()) {
        // --- 修改：使用新的辅助函数获取用户中心URL ---
        $user_center_url = litapay_get_user_center_page_url();
        return '<div class="litapay-frontend-box">
                    <p>您已登录！</p>
                    <a href="' . e($user_center_url) . '" class="button">前往用户中心</a>
                </div>';
        // --- 结束修改 ---
    }
    
    // 使用输出缓冲来包含一个独立的模板文件，使代码更清晰
    ob_start();
    // 准备需要传递给模板的数据
    $login_form_data = [
        'ajax_url' => litapay_get_ajax_url(),
        'login_nonce' => generateCsrfToken('litapay_user_login'),
        'register_nonce' => generateCsrfToken('litapay_user_register'),
        'registration_enabled' => (get_option('enable_registration', '1') === '1'),
    ];
    // 包含模板文件
    include LITAPAY_PLUGIN_DIR . 'public/templates/login-register-form.php';
    return ob_get_clean();
}

/**
 * [litapay_user_center] 短代码处理函数
 * 显示用户中心面板。
 */
function litapay_user_center_shortcode_handler() {
    if (!is_logged_in()) {
        // --- 修改：使用新的辅助函数获取登录URL ---
        $login_url = litapay_get_login_page_url();
        // --- 结束修改 ---
        return '<div class="litapay-frontend-box">
                    <p>请先 <a href="' . e($login_url) . '">登录</a> 后查看用户中心。</p>
                </div>';
    }

    // 用户已登录，准备数据并显示用户中心
    ob_start();
    $user_id = $_SESSION['user_id'];
    // 准备数据
    $user_center_data = [
        'user_balance' => litapay_get_user_balance($user_id),
        'currency_symbol' => get_option('litapay_currency_symbol', '¥'),
        'ajax_url' => litapay_get_ajax_url(),
        'redeem_nonce' => generateCsrfToken('litapay_redeem_code'), // 复用已有的充值码 nonce
        // 在这里可以添加更多数据，例如查询用户的交易记录
        // 'transactions' => litapay_get_user_transactions($user_id, 5), // (需要新建这个函数)
    ];
    // 包含用户中心模板
    include LITAPAY_PLUGIN_DIR . 'public/templates/user-center-panel.php';
    return ob_get_clean();
}






?>
