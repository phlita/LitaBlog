<?php
if (!defined('ABSPATH')) exit;

function litapay_register_ajax_handlers() {
// For logged-in users
add_action('wp_ajax_litapay_purchase_post_balance', 'litapay_handle_ajax_purchase_post_balance');
add_action('wp_ajax_litapay_redeem_code', 'litapay_handle_ajax_redeem_code');
add_action('wp_ajax_litapay_purchase_global_access_balance', 'litapay_handle_ajax_purchase_global_access_balance');
add_action('wp_ajax_litapay_create_afdian_order', 'litapay_handle_ajax_create_afdian_order');
add_action('wp_ajax_litapay_check_local_order_status', 'litapay_handle_ajax_check_local_order_status');
// For non-logged-in users (if any actions were allowed, typically not for payments)
// add_action('wp_ajax_nopriv_some_public_action', 'callback_for_public_action');
}

/**
* AJAX Handler: Purchase post with balance.
* Uses LitaBlog's wp_send_json_success/error.
*/
function litapay_handle_ajax_purchase_post_balance() {
if (!is_logged_in()) {
wp_send_json_error(['message' => '请先登录。'], 403); // LitaBlog's AJAX response
 return; // 确保执行后退出
}

// CSRF check is done by LitaBlog's ajax.php if _ajax_csrf_token is passed and verified there.
// If LitaBlog's ajax.php doesn't auto-verify, we'd do it here:
/*
$nonce = $_POST['_ajax_csrf_token'] ?? ''; // Or however LitaBlog names it
$post_id_for_nonce = $_POST['post_id'] ?? '0';
if (!verifyCsrfToken($nonce, 'litapay_purchase_post_' . $post_id_for_nonce)) { // Action-specific nonce
wp_send_json_error(['message' => '安全验证失败。'], 403);
}
*/
// LitaBlog's ajax.php DOES perform CSRF if _ajax_csrf_token is present.

$user_id = $_SESSION['user_id'];
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
$price_to_charge = isset($_POST['price_to_charge']) ? filter_var($_POST['price_to_charge'], FILTER_VALIDATE_FLOAT) : null;
if (!$post_id) {
wp_send_json_error(['message' => '无效的文章ID。'], 400);
 return;
    }

    if ($price_to_charge === null || $price_to_charge === false) { // <--- 新增：校验价格
        // 如果价格为0，则也认为无效，因为付费墙不应该为0价格的商品提供付费按钮
        wp_send_json_error(['message' => '无效的购买价格。'], 400);
    return;
    }
$result = litapay_process_balance_payment_for_post($user_id, $post_id, $price_to_charge);
if ($result['success']) {
wp_send_json_success(['message' => $result['message']]);
} else {
wp_send_json_error(['message' => $result['message']], 400); // 400 for client-side correctable errors
}
}

function litapay_handle_ajax_purchase_global_access_balance() {
if (!is_logged_in()) {
wp_send_json_error(['message' => '请先登录。'], 403);
    return;
    }
// CSRF check (LitaBlog's ajax.php should handle it if _ajax_csrf_token is passed)
// For action-specific nonce check:
// $nonce = $_POST['_ajax_csrf_token'] ?? '';
// if (!verifyCsrfToken($nonce, 'litapay_purchase_global_access')) {
//     wp_send_json_error(['message' => '安全验证失败。'], 403);
// }

$user_id = $_SESSION['user_id'];
$result = litapay_process_balance_payment_for_global_access($user_id); // New function needed

if ($result['success']) {
wp_send_json_success(['message' => $result['message']]);
} else {
wp_send_json_error(['message' => $result['message']], 400);
}
}


/**
* AJAX Handler: Redeem recharge code.
*/
function litapay_handle_ajax_redeem_code() {
if (!is_logged_in()) {
wp_send_json_error(['message' => '请先登录。'], 403);
    return;
    }

// CSRF handled by LitaBlog's ajax.php

$user_id = $_SESSION['user_id'];
$code_string = isset($_POST['recharge_code']) ? trim($_POST['recharge_code']) : '';

if (empty($code_string)) {
wp_send_json_error(['message' => '充值码不能为空。'], 400);
    return;
    }

$result = litapay_redeem_recharge_code($user_id, $code_string);

if ($result['success']) {
wp_send_json_success([
'message' => $result['message'],
'new_balance' => $result['data']['new_balance'] ?? litapay_get_user_balance($user_id) // Send back new balance
]);
} else {
wp_send_json_error(['message' => $result['message']], 400);
}
}


/**
 * 处理前端AJAX登录请求
 */
function litapay_handle_ajax_login() {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        wp_send_json_error('用户名和密码不能为空。');
        return;
    }

    try {
        $db = get_db();
        $stmt = $db->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // 登录成功，设置 Session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            wp_send_json_success('登录成功！正在跳转...');
        } else {
            wp_send_json_error('用户名或密码错误。');
        }
    } catch (PDOException $e) {
        error_log("LitaPay AJAX Login Error: " . $e->getMessage());
        wp_send_json_error('数据库错误，请稍后重试。');
    }
}

/**
 * 处理前端AJAX注册请求
 */
function litapay_handle_ajax_register() {
    if (get_option('enable_registration', '1') !== '1') {
        wp_send_json_error('注册功能已关闭。');
        return;
    }
    
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // 复用 admin/register.php 的验证逻辑
    $errors = [];
    if (empty($username)) $errors[] = '用户名不能为空。';
    if (empty($password)) $errors[] = '密码不能为空。';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = '邮箱格式不正确。';

    if (!empty($errors)) {
        wp_send_json_error(implode(' ', $errors));
        return;
    }

    try {
        $db = get_db();
        // 检查用户名和邮箱是否已存在
        $stmt_check = $db->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt_check->execute([$username, $email]);
        if ($stmt_check->fetch()) {
            wp_send_json_error('用户名或邮箱已被使用。');
            return;
        }

        // 插入新用户
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt_insert = $db->prepare('INSERT INTO users (username, password, email, display_name, role) VALUES (?, ?, ?, ?, ?)');
        if ($stmt_insert->execute([$username, $hashed_password, $email, $username, 'user'])) {
            wp_send_json_success('注册成功！请使用新账号登录。');
        } else {
            wp_send_json_error('注册失败，请稍后重试。');
        }

    } catch (PDOException $e) {
        error_log("LitaPay AJAX Register Error: " . $e->getMessage());
        wp_send_json_error('数据库错误，请稍后重试。');
    }
}

/*
function litapay_handle_ajax_create_afdian_order() {
    if (!is_logged_in()) {
        wp_send_json_error(['message' => '请先登录。'], 403);
        return;
    }
    // CSRF check will be handled by LitaBlog's ajax.php
    
    $user_id = $_SESSION['user_id'];
    $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0.00;

    if (!$post_id || $price <= 0) {
        wp_send_json_error(['message' => '无效的商品或价格。'], 400);
        return;
    }

    // 1. 生成唯一的内部订单号
    $internal_order_id = 'LTPAY-' . time() . '-' . bin2hex(random_bytes(4));

    // 2. 在 litapay_purchases 表中创建 pending 订单
    $recorded = litapay_record_purchase(
        $user_id,
        $post_id,
        'post', // Purchase type
        $price,
        'afdian',
        $internal_order_id, // Store our unique ID in transaction_id for now
        'pending'           // CRITICAL: Set status to pending
    );

    if (!$recorded) {
        wp_send_json_error(['message' => '无法创建本地订单记录。'], 500);
        return;
    }

    // 3. 生成爱发电支付链接，将我们的内部订单号传过去
    $product = get_post($post_id);
    $product_title = $product ? $product['title'] : "商品 " . $post_id;

    $payment_url = LitaPayAfdianAPI::generate_payment_url(
        $internal_order_id, // Pass our unique ID as custom_order_id
        $price,
        $product_title
    );

    if ($payment_url) {
        wp_send_json_success(['payment_url' => $payment_url, 'internal_order_id' => $internal_order_id ]);
    } else {
        wp_send_json_error(['message' => '无法生成支付链接，请检查插件配置。'], 500);
    }
}*/
function litapay_handle_ajax_create_afdian_order() {
    if (!is_logged_in()) {
        wp_send_json_error(['message' => '请先登录。'], 403);
        return;
    }
    
    $user_id = $_SESSION['user_id'];
    $post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0; // 如果是全局购买，这里会是 0
    $price = isset($_POST['price']) ? (float)$_POST['price'] : 0.00;

    // --- 开始修改逻辑 ---
    $purchase_type = '';
    $product_title = '';

    if ($post_id > 0) { // 这是单篇文章购买
        $purchase_type = 'post';
        $product = get_post($post_id);
        if (!$product) {
            wp_send_json_error(['message' => '商品不存在。'], 404);
            return;
        }
        $product_title = $product['title'];
    } elseif ($post_id === 0 && $price > 0) { // 这是全局权限购买
        $purchase_type = 'global_access_permanent'; 
        $product_title = get_option('site_title', '本站') . '全局阅读权限';
    } else { // 无效请求
        wp_send_json_error(['message' => '无效的商品或价格。'], 400);
        return;
    }
    // --- 结束修改逻辑 ---
    
    $internal_order_id = 'LTPAY-' . time() . '-' . bin2hex(random_bytes(4));

    $recorded = litapay_record_purchase(
        $user_id,
        $post_id > 0 ? $post_id : null, // 如果是全局购买，post_id 存为 null
        $purchase_type,
        $price,
        'afdian',
        $internal_order_id,
        'pending'
    );

    if (!$recorded) {
        wp_send_json_error(['message' => '无法创建本地订单记录。'], 500);
        return;
    }

    $payment_url = LitaPayAfdianAPI::generate_payment_url(
        $internal_order_id,
        $price,
        $product_title // 使用动态生成的产品标题
    );

    if ($payment_url) {
        wp_send_json_success(['payment_url' => $payment_url, 'internal_order_id' => $internal_order_id ]);
    } else {
        wp_send_json_error(['message' => '无法生成支付链接，请检查插件配置。'], 500);
    }
}


function litapay_handle_ajax_check_local_order_status() {
    $order_id = $_POST['order_id'] ?? null;
    if (!$order_id) {
        wp_send_json_error(['message' => '缺少订单号。']);
    }
    
    $db = get_db();
    $stmt = $db->prepare("SELECT status FROM litapay_purchases WHERE transaction_id = ?");
    $stmt->execute([$order_id]);
    $status = $stmt->fetchColumn();
    
    if ($status) {
        wp_send_json_success(['status' => $status]);
    } else {
        wp_send_json_error(['message' => '未找到订单。']);
    }
}

// 这个接口只查询本地数据，理论上也可以开放给未登录用户，因为需要确切的订单ID，风险较低。
// add_action('wp_ajax_nopriv_litapay_check_local_order_status', 'litapay_handle_ajax_check_local_order_status');

?>