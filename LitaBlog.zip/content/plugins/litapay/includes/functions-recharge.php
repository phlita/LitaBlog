<?php
if (!defined('ABSPATH')) exit;

/**
* Generate a unique recharge code.
*
* @param int $length Length of the code.
* @return string The generated code.
*/
function litapay_generate_recharge_code_string($length = 16) {
$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
$char_length = strlen($characters);
$code = '';
for ($i = 0; $i < $length; $i++) {
$code .= $characters[random_int(0, $char_length - 1)];
}
return $code;
}

/**
* Create one or more recharge codes in the database.
*
* @param float $amount Value of each code.
* @param int $count Number of codes to generate.
* @param string|null $notes Admin notes for this batch.
* @return array List of successfully generated codes, or false on error.
*/
function litapay_create_recharge_codes($amount, $count = 1, $notes = null) {
if ((float)$amount <= 0 || (int)$count < 1) {
return false;
}
$db = get_db();
$generated_codes = [];

try {
$db->beginTransaction();
$stmt = $db->prepare("INSERT INTO litapay_recharge_codes (code, amount, notes) VALUES (:code, :amount, :notes)");

for ($i = 0; $i < $count; $i++) {
$new_code_string = '';
$is_unique = false;
$attempts = 0;
// Ensure code uniqueness before attempting insert
while (!$is_unique && $attempts < 10) { // Limit attempts to prevent infinite loop
$new_code_string = litapay_generate_recharge_code_string();
$check_stmt = $db->prepare("SELECT id FROM litapay_recharge_codes WHERE code = :code");
$check_stmt->bindValue(':code', $new_code_string, PDO::PARAM_STR);
$check_stmt->execute();
if ($check_stmt->fetchColumn() === false) {
$is_unique = true;
}
$attempts++;
}

if (!$is_unique) {
throw new Exception("Failed to generate a unique recharge code after {$attempts} attempts.");
}

$stmt->bindValue(':code', $new_code_string, PDO::PARAM_STR);
$stmt->bindValue(':amount', (float)$amount, PDO::PARAM_STR); // SQLite REAL stored as TEXT
$stmt->bindValue(':notes', $notes, $notes === null ? PDO::PARAM_NULL : PDO::PARAM_STR);

if ($stmt->execute()) {
$generated_codes[] = $new_code_string;
} else {
// This should ideally not happen due to the prior uniqueness check and transaction.
throw new Exception("Failed to insert recharge code: {$new_code_string}");
}
}
$db->commit();
return $generated_codes;

} catch (Exception $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay Recharge Code Creation Error: " . $e->getMessage());
return false;
}
}

/**
* Get a recharge code by its string.
*
* @param string $code_string
* @return array|false Code data or false if not found.
*/
function litapay_get_recharge_code_by_string($code_string) {
$db = get_db();
try {
$stmt = $db->prepare("SELECT * FROM litapay_recharge_codes WHERE code = :code");
$stmt->bindValue(':code', $code_string, PDO::PARAM_STR);
$stmt->execute();
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
error_log("LitaPay DB Error (get_recharge_code_by_string): " . $e->getMessage());
return false;
}
}

/**
* Redeem a recharge code for a user.
*
* @param int $user_id
* @param string $code_string
* @return array ['success' => bool, 'message' => string, 'data' => ['new_balance' => float (optional)]]
*/
function litapay_redeem_recharge_code($user_id, $code_string) {
if (!$user_id || empty(trim($code_string))) {
return ['success' => false, 'message' => '用户ID或充值码不能为空。'];
}

$code_data = litapay_get_recharge_code_by_string($code_string);

if (!$code_data) {
return ['success' => false, 'message' => '充值码无效或不存在。'];
}
if ((int)$code_data['status'] === 1) {
return ['success' => false, 'message' => '此充值码已被使用。'];
}
if ((int)$code_data['status'] === 2) {
return ['success' => false, 'message' => '此充值码已失效或被禁用。'];
}

$db = get_db();
try {
$db->beginTransaction();

// Mark code as used
$stmt_update_code = $db->prepare("UPDATE litapay_recharge_codes 
SET status = 1, used_by_user_id = :user_id, used_at = CURRENT_TIMESTAMP 
WHERE id = :code_id AND status = 0");
$stmt_update_code->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt_update_code->bindValue(':code_id', $code_data['id'], PDO::PARAM_INT);
$updated_rows = $stmt_update_code->execute();

// Check if the update actually changed a row (i.e., status was 0)
// LitaBlog DB wrapper doesn't directly give rowCount for execute,
// but for SQLite, execute() returns true on success for UPDATE even if no rows changed.
// We need to fetch again or rely on the initial status check.
// For simplicity, we'll assume the initial check was sufficient, or check rowCount from PDO directly if available.
// A more robust way would be if litapay_get_recharge_code_by_string also checkedattempts.
if (!$updated_rows) { // Or check changes(): if ($db->changes() == 0)
throw new Exception("充值码状态无法更新，可能已被他人同时兑换。");
}


// Add amount to user balance
if (!litapay_add_to_user_balance($user_id, (float)$code_data['amount'])) {
throw new Exception("更新用户余额失败。");
}

// Record this as a "purchase" or "transaction" for auditing
litapay_record_purchase(
$user_id,
null, // No post_id for recharge
'recharge_code_redemption',
(float)$code_data['amount'],
'recharge_code',
$code_data['code'] // Use the code itself as transaction_id
);

$db->commit();
$new_balance = litapay_get_user_balance($user_id);
return [
'success' => true, 
'message' => '充值成功！金额 ¥' . number_format((float)$code_data['amount'], 2) . ' 已添加到您的账户。',
'data' => ['new_balance' => $new_balance]
];

} catch (Exception $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay Recharge Code Redemption Error (User: {$user_id}, Code: {$code_string}): " . $e->getMessage());
return ['success' => false, 'message' => '充值处理失败：' . $e->getMessage()];
}
}

?>