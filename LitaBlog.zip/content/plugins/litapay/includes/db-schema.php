<?php
if (!defined('ABSPATH')) exit;

function litapay_create_db_tables() {
$db = get_db(); // LitaBlog's function to get PDO instance

$tables_sql = [
"CREATE TABLE IF NOT EXISTS litapay_recharge_codes (
id INTEGER PRIMARY KEY AUTOINCREMENT,
code TEXT UNIQUE NOT NULL,
amount REAL NOT NULL,
status INTEGER DEFAULT 0, -- 0: active, 1: used, 2: disabled
used_by_user_id INTEGER,
used_at DATETIME,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
notes TEXT,
FOREIGN KEY (used_by_user_id) REFERENCES users(id) ON DELETE SET NULL
);",
"CREATE INDEX IF NOT EXISTS idx_litapay_recharge_codes_code ON litapay_recharge_codes(code);",
"CREATE INDEX IF NOT EXISTS idx_litapay_recharge_codes_status ON litapay_recharge_codes(status);",

"CREATE TABLE IF NOT EXISTS litapay_purchases (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL,
post_id INTEGER,
purchase_type TEXT NOT NULL, -- 'post', 'global_access'
amount_paid REAL NOT NULL,
payment_method TEXT NOT NULL, -- 'balance', 'afdian'
transaction_id TEXT, -- Afdian order ID, or internal ref for balance
status TEXT DEFAULT 'completed', -- 'completed', 'pending', 'failed'
created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE SET NULL -- Assuming 'posts' table from LitaBlog core
);",
"CREATE INDEX IF NOT EXISTS idx_litapay_purchases_user_post ON litapay_purchases(user_id, post_id);",
"CREATE INDEX IF NOT EXISTS idx_litapay_purchases_type ON litapay_purchases(purchase_type);"
];

try {
$db->beginTransaction(); // Use transaction for table creation
foreach ($tables_sql as $sql) {
$db->exec($sql);
}
$db->commit();
return true;
} catch (PDOException $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay DB Table Creation Error: " . $e->getMessage());
return false;
}
}

function litapay_uninstall_db_tables() {
$db = get_db();
$tables_to_drop = [
'litapay_recharge_codes',
'litapay_purchases'
];
try {
$db->beginTransaction();
foreach ($tables_to_drop as $table) {
$db->exec("DROP TABLE IF EXISTS {$table};");
}
$db->commit();
return true;
} catch (PDOException $e) {
if ($db->inTransaction()) {
$db->rollBack();
}
error_log("LitaPay DB Table Deletion Error: " . $e->getMessage());
return false;
}
}
?>