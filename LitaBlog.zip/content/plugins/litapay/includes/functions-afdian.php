<?php
if (!defined('ABSPATH')) exit;

if (!defined('LITAPAY_LOG_FILE')) {
    define('LITAPAY_LOG_FILE', LITAPAY_PLUGIN_DIR . 'litapay_debug.log');
}
function litapay_log($message, $level = 'INFO') {
  $message_string = is_string($message) ? $message : print_r($message, true);
    $log_entry = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), $level, $message_string);
    
     // 如果想写入到特定文件，可以使用 file_put_contents(LOG_FILE_PATH, $log_entry, FILE_APPEND);
@file_put_contents(LITAPAY_LOG_FILE, $log_entry, FILE_APPEND | LOCK_EX);
}

// start 捕获并记录完整的请求信息
$request_log = "--- New Webhook Request Received ---\n";
$request_log .= "Request Time: " . date('Y-m-d H:i:s') . "\n";
$request_log .= "Request Method: " . ($_SERVER['REQUEST_METHOD'] ?? 'N/A') . "\n";
$request_log .= "Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "\n";
$request_log .= "Source IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";

// 获取所有请求头
$headers = [];
foreach ($_SERVER as $key => $value) {
    if (substr($key, 0, 5) == 'HTTP_') {
        $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
        $headers[$header] = $value;
    }
}
$request_log .= "Request Headers: \n" . print_r($headers, true) . "\n";

// 获取原始请求体
$raw_body = file_get_contents('php://input');
$request_log .= "Raw Request Body: \n" . $raw_body . "\n";
$request_log .= "--------------------------------------\n\n";
file_put_contents(LITAPAY_LOG_FILE, $request_log, FILE_APPEND | LOCK_EX);
//end

class LitaPayAfdianAPI {

const API_BASE_URL = 'https://afdian.com/api/open/';

private static function _get_afdian_user_id() {
return get_option('litapay_afdian_user_id', '');
}

private static function _get_afdian_api_token() {
return get_option('litapay_afdian_api_token', '');
}

/**
* Basic cURL request sender.
* If LitaBlog has its own, use that instead.
*/
private static function _send_request($url, $post_data = [], $method = 'POST') {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
curl_setopt($ch, CURLOPT_TIMEOUT, 45);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-type: application/json"]); // Afdian expects JSON
curl_setopt($ch, CURLOPT_USERAGENT, 'LitaPay-LitaBlog-Plugin/' . LITAPAY_VERSION);

// IMPORTANT: SSL verification. Should be true in production.
// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
// curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
// curl_setopt($ch, CURLOPT_CAINFO, ABSPATH . 'path/to/cacert.pem'); // If needed
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For dev only
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // For dev only


if (strtoupper($method) === 'POST') {
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($post_data) ? json_encode($post_data) : $post_data);
}

$response_body = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error_no = curl_errno($ch);
$curl_error_msg = curl_error($ch);
curl_close($ch);

if ($curl_error_no) {
error_log("LitaPay Afdian cURL Error for {$url}: [{$curl_error_no}] {$curl_error_msg}");
return false;
}
if ($http_code >= 400) {
error_log("LitaPay Afdian HTTP Error {$http_code} for {$url}. Response: " . substr($response_body, 0, 200));
}
return $response_body;
}


public static function query_order($params = ['page' => 1]) {
$user_id = self::_get_afdian_user_id();
$token = self::_get_afdian_api_token();

if (empty($user_id) || empty($token)) {
error_log("LitaPay Afdian Error: API credentials not configured.");
return ['ec' => 400, 'em' => 'Afdian API not configured.'];
}

$ts = time();
$params_json = json_encode($params);
$sign_str = $token . "params" . $params_json . "ts" . $ts . "user_id" . $user_id;
$sign = md5($sign_str);

$request_body = [
'user_id' => $user_id,
'params'  => $params_json,
'ts'      => $ts,
'sign'    => $sign
];

$response_raw = self::_send_request(self::API_BASE_URL . 'query-order', $request_body, 'POST');
if ($response_raw === false) {
return ['ec' => 500, 'em' => 'Failed to connect to Afdian API.'];
}

$response = json_decode($response_raw, true);
if (json_last_error() !== JSON_ERROR_NONE) {
error_log("LitaPay Afdian Error: Invalid JSON response from query-order. Raw: " . $response_raw);
return ['ec' => 500, 'em' => 'Invalid API response.'];
}
return $response;
}

/**
* Generates a payment URL for Afdian.
* For LitaPay, we use custom_order_id to link back to our system.
* The price from LitaPay post will be used to find a matching or "custom amount" plan on Afdian.
* This is a simplified model. Real Afdian integration might need specific plan_id mapping.
*
* @param string $litapay_order_id Our internal order ID (can be post ID, or a generated one).
* @param float $amount The amount to pay.
* @param string $product_title Title of the product for remark.
* @return string|false Afdian payment URL or false on failure.
*/
public static function generate_payment_url($litapay_order_id, $amount, $product_title) {
$afdian_creator_user_id = self::_get_afdian_user_id(); // Creator's Afdian User ID for "custom amount"
// Default Afdian plan_id (for "打赏型" or if no better match found)
// This plan_id should ideally be a "自定义金额" (custom amount) plan on Afdian.
$default_afdian_plan_id_for_payment = get_option('litapay_afdian_default_plan_id_for_purchase');

if (empty($afdian_creator_user_id)) {
error_log("LitaPay Afdian Error: Creator User ID for Afdian not set in LitaPay settings.");
return false;
}

// Construct Afdian payment URL
// For posts, it's usually better to create a "custom amount" sponsorship.
// We'll use the Afdian creator's user_id for the main link.
// The `plan_id` can be for a specific "custom amount" plan if you have one,
// or can be omitted if Afdian allows direct custom amount sponsorship to a user_id.
// Afdian's /order/create endpoint often uses `plan_id` OR `user_id` + `custom_price`.
// Let's assume we use a "custom amount" approach linked to the creator.

$payment_url = "https://afdian.com/order/create";
$params = [
//'user_id'         => $afdian_creator_user_id, // The creator receiving payment
 'plan_id'      => $default_afdian_plan_id_for_payment, // Optional, if you have a specific "pay for post" plan
'custom_order_id' => $litapay_order_id,     // Our internal reference
//'total_amount'    => number_format($amount, 2, '.', ''), // Amount as string "10.00"
'remark'          => $product_title . ' (Order: ' . $litapay_order_id . ')', // Optional remark
// 'product_type' => 0, // 0 for virtual good/sponsorship, which fits post purchase
'month' => '1'
];

// If you have a specific "custom amount" plan on Afdian, you'd use its plan_id:
// unset($params['user_id']);
// $params['plan_id'] = $your_custom_amount_plan_id;
// $params['custom_price'] = number_format($amount, 2, '.', '');


return $payment_url . '?' . http_build_query($params);
}

/**
* Handles an Afdian webhook notification.
* @param array $webhook_data Decoded JSON data from Afdian.
* @return bool True if processed successfully (even if order not updated), false on critical error.
*/
/*
public static function handle_webhook($webhook_data) {
if (!isset($webhook_data['ec']) || $webhook_data['ec'] != 200 || 
!isset($webhook_data['data']['order']['status']) || $webhook_data['data']['order']['status'] != 2) { // Status 2 is 'finished' (paid)
error_log("LitaPay Afdian Webhook: Non-successful or non-order event received. EC: " . ($webhook_data['ec'] ?? 'N/A'));
return true; // Acknowledge receipt, but don't process further
}

$afdian_order = $webhook_data['data']['order'];
$local_order_id = $afdian_order['custom_order_id'] ?? null;
if (empty($local_order_id) && !empty($afdian_order['remark'])) {
// Try to extract from remark if custom_order_id is empty
// This is a fallback, custom_order_id is preferred.
if (preg_match('/Order:\s*([a-zA-Z0-9_-]+)/', $afdian_order['remark'], $matches)) {
$local_order_id = $matches[1];
}
}

if (empty($local_order_id)) {
error_log("LitaPay Afdian Webhook: Could not determine LitaPay Order ID from webhook. Afdian OutTradeNo: " . ($afdian_order['out_trade_no'] ?? 'N/A'));
return true; // Acknowledge, but can't process
}

$db = get_db();
// Check if this purchase type exists
$purchase_entry = $db->prepare("SELECT * FROM litapay_purchases WHERE transaction_id = ? AND payment_method = 'afdian'");
$purchase_entry->execute([$afdian_order['out_trade_no']]);
if ($purchase_entry->fetch()) {
error_log("LitaPay Afdian Webhook: Transaction ID {$afdian_order['out_trade_no']} already processed.");
return true; // Already processed
}


// Find user by matching local_order_id to a post and then that post's potential pending purchase
// This logic is tricky because the webhook is for a *payment*, not directly for a *post purchase attempt*.
// We need to find the user and the content they intended to buy with this payment.
// The `custom_order_id` should ideally encode this. For simplicity, let's assume `custom_order_id`
// IS the `post_id` the user intended to buy, or a unique ID for a "global access" purchase.

// Scenario 1: custom_order_id IS the post_id
$post_id_candidate = $local_order_id;
$post_price_on_afdian = (float)($afdian_order['total_amount'] ?? 0); // Price paid on Afdian

// Who is the user? This is the hardest part without a session.
// Afdian webhooks don't inherently know LitaBlog user IDs.
// Possible strategies:
// 1. User ID in custom_order_id (e.g., "postid_userid") - Requires careful generation.
// 2. Email matching (if Afdian provides buyer email and LitaBlog users have unique emails).
// For now, let's assume the payment is for a *post*, and we log it against the post.
// Associating with a user is more complex without more info in custom_order_id.

// Let's assume custom_order_id IS post_id for this example.
$post_to_unlock_id = $post_id_candidate;
$post_price_local = litapay_get_post_price($post_to_unlock_id);

// Sanity check: does amount paid match expected post price?
// This can be tricky with dynamic pricing or "sponsorships".
// if ($post_price_local > 0 && abs($post_price_on_afdian - $post_price_local) > 0.01) {
//     error_log("LitaPay Afdian Webhook: Amount mismatch for Post ID {$post_to_unlock_id}. Paid: {$post_price_on_afdian}, Expected: {$post_price_local}");
//     // Decide how to handle: maybe flag for review, or proceed if it's a "pay what you want" model.
// }

// PROBLEM: We don't know the LitaBlog $user_id from the webhook directly.
// A common solution is to have the user initiate the Afdian payment from *within* LitaBlog.
// When they click "Pay with Afdian", LitaBlog creates a PENDING purchase record in `litapay_purchases`
// with the LitaBlog user_id, post_id, and a UNIQUE `transaction_id` (e.g., "LTPAY-timestamp-rand").
// This UNIQUE `transaction_id` is then passed to Afdian as `custom_order_id`.
// The webhook then uses `custom_order_id` to find the PENDING record and update its status to 'completed'.

// Let's adapt to this improved flow:
// The webhook's $local_order_id is the UNIQUE transaction_id generated by LitaPay.

$stmt_find_pending = $db->prepare("SELECT * FROM litapay_purchases 
WHERE transaction_id = :transaction_id 
AND payment_method = 'afdian' 
AND status = 'pending'");
$stmt_find_pending->bindValue(':transaction_id', $local_order_id, PDO::PARAM_STR);
$stmt_find_pending->execute();
$pending_purchase = $stmt_find_pending->fetch(PDO::FETCH_ASSOC);

if ($pending_purchase) {
// Found a matching pending purchase. Update it.
$stmt_update = $db->prepare("UPDATE litapay_purchases 
SET status = 'completed', amount_paid = :amount_paid_afdian, transaction_id = :afdian_out_trade_no 
WHERE id = :pending_purchase_id");
$stmt_update->bindValue(':amount_paid_afdian', $post_price_on_afdian, PDO::PARAM_STR);
$stmt_update->bindValue(':afdian_out_trade_no', $afdian_order['out_trade_no'], PDO::PARAM_STR); // Store Afdian's order no.
$stmt_update->bindValue(':pending_purchase_id', $pending_purchase['id'], PDO::PARAM_INT);

if ($stmt_update->execute()) {
error_log("LitaPay Afdian Webhook: Successfully updated pending purchase ID {$pending_purchase['id']} (LitaPay Order: {$local_order_id}) to completed. Afdian OutTradeNo: {$afdian_order['out_trade_no']}.");

// If it was a 'global_access' purchase, update user meta
if ($pending_purchase['purchase_type'] === 'global_access_timed' || $pending_purchase['purchase_type'] === 'global_access_permanent') {
// Duration should have been stored in the pending purchase or determined by plan
// For simplicity, let's assume a fixed duration or permanent based on a setting
$global_access_duration_days = ($pending_purchase['purchase_type'] === 'global_access_permanent') ? 0 : (int)get_option('litapay_afdian_global_access_duration_days', 30);
litapay_grant_global_access($pending_purchase['user_id'], $global_access_duration_days);
}

// Add amount to user balance if this payment was for a general "recharge" via Afdian
if ($pending_purchase['purchase_type'] === 'recharge_via_afdian') {
litapay_add_to_user_balance($pending_purchase['user_id'], $post_price_on_afdian);
}

return true;
} else {
error_log("LitaPay Afdian Webhook: DB Error updating pending purchase ID {$pending_purchase['id']}. LitaPay Order: {$local_order_id}. Afdian OutTradeNo: {$afdian_order['out_trade_no']}.");
}
} else {
error_log("LitaPay Afdian Webhook: No matching PENDING LitaPay purchase found for transaction_id (custom_order_id): {$local_order_id}. Afdian OutTradeNo: {$afdian_order['out_trade_no']}. This might be a direct payment to Afdian not initiated via LitaPay, or a duplicate webhook.");
// Optionally, you could create a new purchase record here if you want to handle direct Afdian sponsorships
// But you'd need a way to map it to a LitaBlog user and content.
}
return true; // Acknowledge webhook, even if no local action taken for unmatched.
}*/

// (Inside LitaPayAfdianAPI class)
public static function handle_webhook($webhook_data) {
    // 1. 强制执行签名验证 (安全第一！)
    $secret = get_option('litapay_afdian_webhook_secret');
    $received_signature = $_SERVER['HTTP_X_AFDIAN_SIGNATURE'] ?? '';
    $raw_body = file_get_contents('php://input');

    if (!empty($secret)) { // Only verify if a secret is configured
        if (empty($received_signature)) {
            error_log("LitaPay Webhook Error: Signature missing from Afdian request.");
            return false; // Or http_response_code(401) and exit
        }
        $expected_signature = md5($secret . $raw_body); // Check afdian docs for exact algo
        if (!hash_equals($expected_signature, $received_signature)) {
            error_log("LitaPay Webhook Error: Invalid signature.");
            return false; // Or http_response_code(403) and exit
        }
    }
    
    // 2. 解析数据并检查是否为成功的订单通知
    if (!isset($webhook_data['ec']) || $webhook_data['ec'] != 200 || !isset($webhook_data['data']['order'])) {
		error_log($webhook_data);
        return true; // Not a successful order event, but acknowledge it
    }
    $afdian_order = $webhook_data['data']['order'];
    if ($afdian_order['status'] != 2) { // 2 = paid
        return true; // Not a paid order, acknowledge it
    }

    // 3. 提取我们的内部订单号 (custom_order_id)
    $internal_order_id = $afdian_order['custom_order_id'] ?? null;
    if (empty($internal_order_id)) {
        error_log("LitaPay Webhook: custom_order_id is missing from payload.");
        return true;
    }

    $db = get_db();
    try {
        $db->beginTransaction();

        // 4. 查找匹配的 PENDING 订单
        $stmt_find = $db->prepare("SELECT * FROM litapay_purchases WHERE transaction_id = :internal_id AND status = 'pending'");
        $stmt_find->execute([':internal_id' => $internal_order_id]);
        $pending_purchase = $stmt_find->fetch(PDO::FETCH_ASSOC);

        if (!$pending_purchase) {
            error_log("LitaPay Webhook: Received notification for unknown or already processed order: " . $internal_order_id);
            $db->rollBack();
            return true; // Acknowledge, do nothing
        }

        // 5. (可选但推荐) 验证金额
        $expected_amount = (float)$pending_purchase['amount_paid'];
        $paid_amount = (float)$afdian_order['total_amount'];
if ($paid_amount < $expected_amount) {
    // 金额不足
    litapay_add_to_user_balance($pending_purchase['user_id'], $paid_amount);
    return ['success' => false, 'message' => '支付金额不足，已存入您的余额。', 'status' => 'failed'];
} else {
    // 金额足够或超出
    if ($paid_amount > $expected_amount) {
        // 处理超出的部分
        litapay_add_to_user_balance($pending_purchase['user_id'], $paid_amount - $expected_amount);
    }
}
        // 6. 更新订单状态为 "completed"
        $stmt_update = $db->prepare("UPDATE litapay_purchases 
            SET status = 'completed', transaction_id = :afdian_trade_no 
            WHERE id = :purchase_id AND status = 'pending'"); // Atomic update
        $stmt_update->execute([
            ':afdian_trade_no' => $afdian_order['out_trade_no'], // Now store the REAL afdian trade no
            ':purchase_id' => $pending_purchase['id']
        ]);

        if ($stmt_update->rowCount() === 0) {
            // Another process might have updated it in the meantime (race condition)
            throw new Exception("Order status was changed concurrently.");
        } 
        
        // 7. 执行授权/充值逻辑 (如果适用)
        if ($pending_purchase['purchase_type'] === 'recharge_via_afdian') {
            litapay_add_to_user_balance($pending_purchase['user_id'], $paid_amount);
        }// --- 新增处理分支 ---
    elseif ($pending_purchase['purchase_type'] === 'global_access_permanent') {
        // 调用开通全局权限的函数
        litapay_grant_global_access($pending_purchase['user_id'], 0); // 0 代表永久
    }
    elseif ($pending_purchase['purchase_type'] === 'global_access_timed') {
        // (未来扩展) 如果有带时限的全局权限
        $duration = 30; // 假设30天，或从订单中获取
        litapay_grant_global_access($pending_purchase['user_id'], $duration);
    }
    // --- 结束新增 ---
        // 对于 'post' 购买，数据库记录本身就代表了权限。
        
        $db->commit();
        return true;

    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("LitaPay Webhook Processing Error: " . $e->getMessage());
        return false;
    }
}

// --- START OF MODIFICATION ---
/**
 * 主动查询并更新单个 LitaPay 订单的状态。
 * 这是整个备选方案的核心函数。
 *
 * @param string $internal_order_id LitaPay 内部生成的唯一订单号 (e.g., 'LTPAY-xxxx')
 * @return array ['success' => bool, 'message' => string, 'status' => 'paid'|'unpaid'|'error']
 */
 /*
public static function verify_and_update_order_status($internal_order_id) {
    $db = get_db();

    // 1. 检查本地订单状态
    $stmt_check = $db->prepare("SELECT * FROM litapay_purchases WHERE transaction_id = :internal_id AND payment_method = 'afdian'");
    $stmt_check->execute([':internal_id' => $internal_order_id]);
    $local_purchase = $stmt_check->fetch(PDO::FETCH_ASSOC);

    if (!$local_purchase) {
        return ['success' => false, 'message' => '本地订单记录不存在。', 'status' => 'error'];
    }

    // 如果本地已经是 'completed' 状态，直接返回成功，无需查询
    if ($local_purchase['status'] === 'completed') {
        return ['success' => true, 'message' => '订单已确认支付。', 'status' => 'paid'];
    }

    // 2. 调用 Afdian API 查询
    // 我们需要一个函数来查询订单，这里我们直接使用 LitaPay 已有的 `query_order` 函数
    // 但请注意，我们需要分页查询，直到找到订单或查完指定页数
    $max_pages_to_check = (int)get_option('api_order_query_max_pages', 5); // 从设置中读取，或者硬编码
    $found_on_api = false;
    $api_order_data = null;
    
    for ($page = 1; $page <= $max_pages_to_check; $page++) {
        $api_response = self::query_order(['page' => $page, 'per_page' => 50]); // 假设每页50条
        if ($api_response && isset($api_response['ec']) && $api_response['ec'] == 200 && !empty($api_response['data']['list'])) {
            foreach ($api_response['data']['list'] as $order_from_api) {
                // 通过 custom_order_id 匹配
                if (isset($order_from_api['custom_order_id']) && $order_from_api['custom_order_id'] === $internal_order_id) {
                    // 找到订单了！
                    if ($order_from_api['status'] == 2) { // 状态2表示已支付
                        $found_on_api = true;
                        $api_order_data = $order_from_api;
                    }
                    break 2; // 跳出内外两层循环
                }
            }
            if (count($api_response['data']['list']) < 50) {
                break; // 如果当前页不满，说明是最后一页了，无需继续
            }
        } else {
            // API 查询失败或没有订单了
            break;
        }
    }

    // 3. 如果在 API 找到已支付订单，则更新本地数据库
    if ($found_on_api && $api_order_data) {
        try {
            $db->beginTransaction();

            // 使用 Webhook 中类似的逻辑来更新订单
            $stmt_update = $db->prepare("
                UPDATE litapay_purchases 
                SET status = 'completed', 
                    transaction_id = :afdian_trade_no, -- 用爱发电的单号覆盖我们临时的内部单号
                    amount_paid = :amount_paid_afdian -- 以爱发电实际支付金额为准
                WHERE id = :purchase_id AND status = 'pending'
            ");

            $stmt_update->execute([
                ':afdian_trade_no' => $api_order_data['out_trade_no'],
                ':amount_paid_afdian' => (float)$api_order_data['total_amount'],
                ':purchase_id' => $local_purchase['id']
            ]);

            // 如果是充值类型的购买，需要给用户加余额
            if ($local_purchase['purchase_type'] === 'recharge_via_afdian') {
                litapay_add_to_user_balance($local_purchase['user_id'], (float)$api_order_data['total_amount']);
            }
            // 其他类型的购买（如全局权限）也应在此处处理

            $db->commit();
            return ['success' => true, 'message' => '订单状态已从API同步为“已支付”。', 'status' => 'paid'];

        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            error_log("LitaPay verify_and_update_order_status DB Error: " . $e->getMessage());
            return ['success' => false, 'message' => '数据库更新失败。', 'status' => 'error'];
        }
    }

    // 4. 如果没找到，返回未支付状态
    return ['success' => true, 'message' => '订单仍为未支付状态。', 'status' => 'unpaid'];
}*/

// --- 开始修改 ---



    public static function verify_and_update_order_status($internal_order_id) {
        litapay_log("Verifying order status for internal_order_id: {$internal_order_id}");
        
        $db = get_db();

        // 1. 检查本地订单状态
        $stmt_check = $db->prepare("SELECT * FROM litapay_purchases WHERE transaction_id = :internal_id AND payment_method = 'afdian'");
        $stmt_check->execute([':internal_id' => $internal_order_id]);
        $local_purchase = $stmt_check->fetch(PDO::FETCH_ASSOC);

        if (!$local_purchase) {
            litapay_log("Order '{$internal_order_id}' not found in local database.", 'WARNING');
            return ['success' => false, 'message' => '本地订单记录不存在。', 'status' => 'error'];
        }

        litapay_log("Local order '{$internal_order_id}' found. Status: {$local_purchase['status']}. User ID: {$local_purchase['user_id']}.");

        if ($local_purchase['status'] === 'completed') {
            litapay_log("Order '{$internal_order_id}' is already marked as 'completed'. No action needed.");
            return ['success' => true, 'message' => '订单已确认支付。', 'status' => 'paid'];
        }

        // 2. 调用 Afdian API 查询
        $max_pages_to_check = (int)get_option('api_order_query_max_pages', 5);
        $found_on_api = false;
        $api_order_data = null;
        
        litapay_log("Querying Afdian API for order '{$internal_order_id}'. Max pages to check: {$max_pages_to_check}.");

        for ($page = 1; $page <= $max_pages_to_check; $page++) {
            $api_response = self::query_order(['page' => $page, 'per_page' => 50]);
 // ！！！新增日志记录！！！
    // 将API返回的原始JSON数据记录下来，无论成功与否
    $raw_response_for_log = json_encode($api_response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    litapay_log("Afdian API response for page {$page}: " . $raw_response_for_log, 'DEBUG');
    // ！！！新增结束！！！
            if (!$api_response || !isset($api_response['ec'])) {
                litapay_log("Afdian API call failed or returned invalid format for page {$page}.", 'ERROR');
                break; // API 调用失败，停止查询
            }

            if ($api_response['ec'] != 200) {
                litapay_log("Afdian API returned error for page {$page}. EC: {$api_response['ec']}, EM: {$api_response['em']}", 'WARNING');
                break; // API 返回错误，停止查询
            }
            
            if (empty($api_response['data']['list'])) {
                litapay_log("No more orders found on Afdian API at page {$page}. Stopping search.");
                break; // 没有更多订单了，停止查询
            }

            foreach ($api_response['data']['list'] as $order_from_api) {
                if (isset($order_from_api['custom_order_id']) && $order_from_api['custom_order_id'] === $internal_order_id) {
                    litapay_log("Found matching order on Afdian API. Afdian out_trade_no: {$order_from_api['out_trade_no']}, Status: {$order_from_api['status']}");
                    if ($order_from_api['status'] == 2) { // 2 = 已支付
                        $found_on_api = true;
                        $api_order_data = $order_from_api;
                    }
                    break 2; // 已找到订单（无论支付与否），跳出内外两层循环
                }
            }
        }

        // 3. 如果在 API 找到已支付订单，则更新本地数据库
        if ($found_on_api && $api_order_data) {
        // 验证从API获取的支付金额是否与本地记录的预期金额匹配
        $expected_amount = (float)$local_purchase['amount_paid'];
        $paid_amount = (float)$api_order_data['total_amount'];

if ($paid_amount < $expected_amount) {
    // 金额不足
    litapay_add_to_user_balance($local_purchase['user_id'], $paid_amount);
    return ['success' => false, 'message' => '支付金额不足，已存入您的余额。', 'status' => 'failed'];
} else {
    // 金额足够或超出
    if ($paid_amount > $expected_amount) {
        // 处理超出的部分
        litapay_add_to_user_balance($local_purchase['user_id'], $paid_amount - $expected_amount);
    }

}
        // --- [金额验证结束] ---
            litapay_log("Paid order '{$internal_order_id}' confirmed on API. Proceeding to update local DB.");
            try {
                $db->beginTransaction();

                $stmt_update = $db->prepare("
                    UPDATE litapay_purchases 
                    SET status = 'completed', 
                        transaction_id = :afdian_trade_no,
                        amount_paid = :amount_paid_afdian 
                    WHERE id = :purchase_id AND status = 'pending'
                ");
                $stmt_update->execute([
                    ':afdian_trade_no' => $api_order_data['out_trade_no'],
                    ':amount_paid_afdian' => (float)$api_order_data['total_amount'],
                    ':purchase_id' => $local_purchase['id']
                ]);
                
                if ($stmt_update->rowCount() === 0) {
                    // 这可能发生在并发请求中，另一个进程刚刚更新了它。是正常情况，但也值得记录。
                    litapay_log("Attempted to update order '{$internal_order_id}', but its status was no longer 'pending'. (rowcount=0)", 'WARNING');
                } else {
					
    $purchase_type = $local_purchase['purchase_type'];
            $user_id_to_fulfill = $local_purchase['user_id'];
            $paid_amount_for_fulfill = (float)$api_order_data['total_amount'];

            litapay_log("Fulfilling order '{$internal_order_id}' of type '{$purchase_type}' for user {$user_id_to_fulfill}.");

            if ($purchase_type === 'recharge_via_afdian') {
                litapay_add_to_user_balance($user_id_to_fulfill, $paid_amount_for_fulfill);
            } elseif ($purchase_type === 'global_access_permanent') {
                litapay_grant_global_access($user_id_to_fulfill, 0); // 0 for permanent
            } elseif ($purchase_type === 'global_access_timed') {
                // Future logic for timed access
                $duration = 30; // Example
                litapay_grant_global_access($user_id_to_fulfill, $duration);
            }
					
                  /*   if ($local_purchase['purchase_type'] === 'recharge_via_afdian') {
                        $recharge_amount = (float)$api_order_data['total_amount'];
                        litapay_log("Processing 'recharge_via_afdian' for user {$local_purchase['user_id']}. Amount: {$recharge_amount}");
                        litapay_add_to_user_balance($local_purchase['user_id'], $recharge_amount);
                    }*/
                }
                
                $db->commit();
                litapay_log("Successfully updated order '{$internal_order_id}' to 'completed' in local DB.", 'SUCCESS');
                return ['success' => true, 'message' => '订单状态已从API同步为“已支付”。', 'status' => 'paid'];

            } catch (Exception $e) {
                if ($db->inTransaction()) $db->rollBack();
                // ！！！原有的日志记录已很棒，我们用新函数包装一下！！！
                litapay_log("DB transaction failed while updating order '{$internal_order_id}': " . $e->getMessage(), 'CRITICAL');
                return ['success' => false, 'message' => '数据库更新失败。', 'status' => 'error'];
            }
        }

        // 4. 如果没找到，返回未支付状态
        litapay_log("Order '{$internal_order_id}' was not found as paid on Afdian API. Current status remains 'pending'.");
        return ['success' => true, 'message' => '订单仍为未支付状态。', 'status' => 'unpaid'];
    }

// --- 结束修改 ---


}
?>