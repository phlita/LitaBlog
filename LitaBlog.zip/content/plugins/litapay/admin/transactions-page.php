<?php
// This file is included by the callback function in admin-menu.php
if (!defined('ABSPATH') || !is_admin()) {
echo '<p>非法访问。</p>';
return;
}

$db = get_db();
$currency_symbol = get_option('litapay_currency_symbol', '¥');

// Pagination
$current_page = isset($_GET['paged']) ? max(1, (int)$_GET['paged']) : 1;
$items_per_page = 20;
$offset = ($current_page - 1) * $items_per_page;

// Filters (Example: by user, by type)
$filter_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : null;
$filter_purchase_type = isset($_GET['purchase_type']) ? sanitize_text_field($_GET['purchase_type']) : '';

$where_clauses = [];
$params = [];

if ($filter_user_id) {
$where_clauses[] = "p.user_id = :user_id";
$params[':user_id'] = $filter_user_id;
}
if (!empty($filter_purchase_type)) {
$where_clauses[] = "p.purchase_type = :purchase_type";
$params[':purchase_type'] = $filter_purchase_type;
}

$where_sql = "";
if (!empty($where_clauses)) {
$where_sql = " WHERE " . implode(" AND ", $where_clauses);
}

$total_items_stmt = $db->prepare("SELECT COUNT(*) 
FROM litapay_purchases p
LEFT JOIN users u ON p.user_id = u.id
LEFT JOIN posts po ON p.post_id = po.id" . $where_sql);
$total_items_stmt->execute($params);
$total_items = $total_items_stmt->fetchColumn();

$purchases_stmt = $db->prepare("SELECT p.*, u.username as user_username, po.title as post_title 
FROM litapay_purchases p
LEFT JOIN users u ON p.user_id = u.id
LEFT JOIN posts po ON p.post_id = po.id
{$where_sql} 
ORDER BY p.created_at DESC 
LIMIT :limit OFFSET :offset");
$params_with_limit = array_merge($params, [
':limit' => $items_per_page,
':offset' => $offset
]);
foreach($params_with_limit as $key => $val) {
$purchases_stmt->bindValue($key, $val, is_int($val) ? PDO::PARAM_INT : PDO::PARAM_STR);
}
$purchases_stmt->execute();
$transactions = $purchases_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php display_flash_message(); ?>

<div class="litapay-admin-section">
<h3>交易记录</h3>

<form method="GET" action="admin.php" class="form-inline" style="margin-bottom: 1rem;">
<input type="hidden" name="page" value="litapay-transactions">
<div class="form-group">
<label for="filter_user_id_input">用户ID:</label>
<input type="number" id="filter_user_id_input" name="user_id" value="<?php echo e($filter_user_id ?: ''); ?>" class="form-control" style="width:100px;">
</div>
<div class="form-group">
<label for="filter_purchase_type_select">类型:</label>
<select id="filter_purchase_type_select" name="purchase_type" class="form-control">
<option value="">全部</option>
<option value="post" <?php selected($filter_purchase_type, 'post'); ?>>文章购买</option>
<option value="global_access_timed" <?php selected($filter_purchase_type, 'global_access_timed'); ?>>全局限时</option>
<option value="global_access_permanent" <?php selected($filter_purchase_type, 'global_access_permanent'); ?>>全局永久</option>
<option value="recharge_code_redemption" <?php selected($filter_purchase_type, 'recharge_code_redemption'); ?>>充值码兑换</option>
<option value="recharge_via_afdian" <?php selected($filter_purchase_type, 'recharge_via_afdian'); ?>>爱发电充值</option>
</select>
</div>
<button type="submit" class="button">筛选</button>
<a href="admin.php?page=litapay-transactions" class="button btn-secondary">重置</a>
</form>

<table class="admin-table">
<thead>
<tr>
<th>ID</th>
<th>用户</th>
<th>类型</th>
<th>内容/目标</th>
<th>金额</th>
<th>支付方式</th>
<th>交易ID/参考</th>
<th>状态</th>
<th>日期</th>
</tr>
</thead>
<tbody>
<?php if (empty($transactions)): ?>
<tr><td colspan="9" style="text-align:center;">没有交易记录。</td></tr>
<?php else: ?>
<?php foreach ($transactions as $tx): ?>
<tr>
<td><?php echo $tx['id']; ?></td>
<td><?php echo e($tx['user_username'] ?: ('ID: ' . $tx['user_id'])); ?></td>
<td><?php echo e(ucwords(str_replace('_', ' ', $tx['purchase_type']))); ?></td>
<td>
<?php
if ($tx['post_id']) {
echo '文章: ' . e($tx['post_title'] ?: ('ID ' . $tx['post_id']));
} elseif ($tx['purchase_type'] === 'recharge_code_redemption') {
echo '充值码: ' . e($tx['transaction_id']);
} else {
echo 'N/A';
}
?>
</td>
<td><?php echo e($currency_symbol . number_format($tx['amount_paid'], 2)); ?></td>
<td><?php echo e(ucfirst($tx['payment_method'])); ?></td>
<td><?php echo e($tx['transaction_id'] ?: 'N/A'); ?></td>
<td>
<span class="status-badge <?php echo $tx['status'] === 'completed' ? 'status-active' : ($tx['status'] === 'pending' ? 'status-pending' : 'status-cancelled'); ?>">
<?php echo e(ucfirst($tx['status'])); ?>
</span>
</td>
<td><?php echo date('Y-m-d H:i', strtotime($tx['created_at'])); ?></td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
<?php
$pagination_params_tx = ['page' => 'litapay-transactions'];
if ($filter_user_id) $pagination_params_tx['user_id'] = $filter_user_id;
if (!empty($filter_purchase_type)) $pagination_params_tx['purchase_type'] = $filter_purchase_type;
echo get_paginations($current_page, $total_items, $items_per_page, $pagination_params_tx);
?>
</div>