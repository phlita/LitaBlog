<?php
// This file is included by the callback function in admin-menu.php
if (!defined('ABSPATH') || !is_admin()) {
echo '<p>非法访问。</p>';
return;
}

$db = get_db(); // LitaBlog's DB access

// --- Handle Form Submissions for Recharge Codes ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// Basic CSRF Check (could be more specific if multiple forms on one page)
if (!isset($_POST['litapay_recharge_csrf']) || !verifyCsrfToken($_POST['litapay_recharge_csrf'], 'litapay_admin_recharge_codes')) {
set_flash_message('安全验证失败，请重试。', 'error');
} else {
if (isset($_POST['litapay_generate_codes'])) {
$count = isset($_POST['generate_count']) ? (int)$_POST['generate_count'] : 0;
$amount = isset($_POST['generate_amount']) ? filter_var($_POST['generate_amount'], FILTER_VALIDATE_FLOAT) : 0.00;
$notes = isset($_POST['generate_notes']) ? sanitize_text_field($_POST['generate_notes']) : null;

if ($count > 0 && $count <= 100 && $amount !== false && $amount > 0) {
$generated = litapay_create_recharge_codes($amount, $count, $notes); // From functions-recharge.php
if ($generated && count($generated) > 0) {
set_flash_message(count($generated) . ' 个充值码已成功生成。', 'success');
// Optionally display generated codes here or store them for display
$_SESSION['litapay_last_generated_codes'] = $generated;
} else {
set_flash_message('生成充值码失败，请检查日志。', 'error');
}
} else {
set_flash_message('无效的生成数量或金额。数量必须在1-100之间，金额必须大于0。', 'error');
}
} elseif (isset($_POST['litapay_add_manual_code'])) {
$manual_code = isset($_POST['manual_code_string']) ? trim(sanitize_text_field($_POST['manual_code_string'])) : '';
$manual_amount = isset($_POST['manual_code_amount']) ? filter_var($_POST['manual_code_amount'], FILTER_VALIDATE_FLOAT) : 0.00;
$manual_notes = isset($_POST['manual_code_notes']) ? sanitize_text_field($_POST['manual_code_notes']) : null;

if (!empty($manual_code) && strlen($manual_code) >= 8 && $manual_amount !== false && $manual_amount > 0) {
if (litapay_get_recharge_code_by_string($manual_code)) {
set_flash_message('错误：充值码 "' . e($manual_code) . '" 已存在。', 'error');
} else {
// Use the single code generation part of litapay_create_recharge_codes or a dedicated function
$db->beginTransaction();
$stmt_manual = $db->prepare("INSERT INTO litapay_recharge_codes (code, amount, notes) VALUES (:code, :amount, :notes)");
$stmt_manual->bindValue(':code', $manual_code, PDO::PARAM_STR);
$stmt_manual->bindValue(':amount', $manual_amount, PDO::PARAM_STR);
$stmt_manual->bindValue(':notes', $manual_notes, $manual_notes === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
if($stmt_manual->execute()){
$db->commit();
set_flash_message('手动添加充值码 "' . e($manual_code) . '" 成功。', 'success');
} else {
$db->rollBack();
set_flash_message('手动添加充值码失败。', 'error');
}
}
} else {
set_flash_message('手动添加充值码失败：代码必须至少8位，金额必须大于0。', 'error');
}
} elseif (isset($_POST['litapay_delete_code']) && isset($_POST['code_id'])) {
$code_id_to_delete = (int)$_POST['code_id'];
$stmt_delete = $db->prepare("DELETE FROM litapay_recharge_codes WHERE id = ?");
if ($stmt_delete->execute([$code_id_to_delete])) {
set_flash_message('充值码已删除。', 'success');
} else {
set_flash_message('删除充值码失败。', 'error');
}
} elseif (isset($_POST['litapay_disable_code']) && isset($_POST['code_id'])) {
$code_id_to_disable = (int)$_POST['code_id'];
$stmt_disable = $db->prepare("UPDATE litapay_recharge_codes SET status = 2 WHERE id = ? AND status = 0"); // Only disable active codes
if ($stmt_disable->execute([$code_id_to_disable])) {
set_flash_message('充值码已禁用。', 'success');
} else {
set_flash_message('禁用充值码失败（可能已被使用或已禁用）。', 'error');
}
}
}
header('Location: admin.php?page=litapay-recharge-codes');
exit;
}


// --- Display Logic ---
$currency_symbol = get_option('litapay_currency_symbol', '¥');

// Pagination for recharge codes
$current_page = isset($_GET['paged']) ? max(1, (int)$_GET['paged']) : 1;
$codes_per_page = 20; // Or from options
$offset = ($current_page - 1) * $codes_per_page;

// Filters
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$search_code = isset($_GET['search_code']) ? trim(sanitize_text_field($_GET['search_code'])) : '';

$where_clauses = [];
$params = [];

if ($filter_status !== '' && in_array($filter_status, ['0', '1', '2'])) {
$where_clauses[] = "rc.status = :status";
$params[':status'] = (int)$filter_status;
}
if (!empty($search_code)) {
$where_clauses[] = "code LIKE :search_code";
$params[':search_code'] = '%' . $search_code . '%';
}

$where_sql = "";
if (!empty($where_clauses)) {
$where_sql = " WHERE " . implode(" AND ", $where_clauses);
}

//$total_codes_stmt = $db->prepare("SELECT COUNT(*) FROM litapay_recharge_codes" . $where_sql);
$total_codes_stmt = $db->prepare("SELECT COUNT(*) FROM litapay_recharge_codes rc LEFT JOIN users u ON rc.used_by_user_id = u.id" . $where_sql);
$total_codes_stmt->execute($params);
$total_codes = $total_codes_stmt->fetchColumn();

$codes_stmt = $db->prepare("SELECT rc.*, u.username as used_by_username 
FROM litapay_recharge_codes rc
LEFT JOIN users u ON rc.used_by_user_id = u.id 
{$where_sql} 
ORDER BY rc.created_at DESC 
LIMIT :limit OFFSET :offset");
$params_with_limit = array_merge($params, [
':limit' => $codes_per_page,
':offset' => $offset
]);
foreach($params_with_limit as $key => $val) { // Bind values with correct types
$codes_stmt->bindValue($key, $val, is_int($val) ? PDO::PARAM_INT : PDO::PARAM_STR);
}
$codes_stmt->execute();
$recharge_codes = $codes_stmt->fetchAll(PDO::FETCH_ASSOC);

$last_generated_codes = $_SESSION['litapay_last_generated_codes'] ?? null;
unset($_SESSION['litapay_last_generated_codes']);

?>
<?php display_flash_message(); // LitaBlog's flash message display ?>

<?php if ($last_generated_codes): ?>
<div class="alert alert-info">
<h4>上次生成的充值码:</h4>
<textarea readonly rows="5" class="form-control" style="font-family: monospace;"><?php
foreach ($last_generated_codes as $g_code) { echo e($g_code) . "\n"; }
?></textarea>
</div>
<?php endif; ?>


<div class="litapay-admin-section">
<h3>生成充值码</h3>
<form method="POST" action="admin.php?page=litapay-recharge-codes" class="form-inline">
<input type="hidden" name="litapay_recharge_csrf" value="<?php echo generateCsrfToken('litapay_admin_recharge_codes'); ?>">
<div class="form-group">
<label for="generate_count">数量:</label>
<input type="number" id="generate_count" name="generate_count" value="10" min="1" max="100" class="form-control" style="width: 80px;" required>
</div>
<div class="form-group">
<label for="generate_amount">单个金额 (<?php echo e($currency_symbol); ?>):</label>
<input type="number" id="generate_amount" name="generate_amount" value="10.00" min="0.01" step="0.01" class="form-control" style="width: 100px;" required>
</div>
<div class="form-group">
<label for="generate_notes">备注 (可选):</label>
<input type="text" id="generate_notes" name="generate_notes" class="form-control" placeholder="例如：双十一活动">
</div>
<button type="submit" name="litapay_generate_codes" class="button btn-primary">生成</button>
</form>
</div>

<div class="litapay-admin-section">
<h3>手动添加单个充值码</h3>
<form method="POST" action="admin.php?page=litapay-recharge-codes" class="form-inline">
<input type="hidden" name="litapay_recharge_csrf" value="<?php echo generateCsrfToken('litapay_admin_recharge_codes'); ?>">
<div class="form-group">
<label for="manual_code_string">充值码:</label>
<input type="text" id="manual_code_string" name="manual_code_string" class="form-control" required minlength="8">
</div>
<div class="form-group">
<label for="manual_code_amount">金额 (<?php echo e($currency_symbol); ?>):</label>
<input type="number" id="manual_code_amount" name="manual_code_amount" min="0.01" step="0.01" class="form-control" style="width: 100px;" required>
</div>
<div class="form-group">
<label for="manual_code_notes">备注 (可选):</label>
<input type="text" id="manual_code_notes" name="manual_code_notes" class="form-control">
</div>
<button type="submit" name="litapay_add_manual_code" class="button btn-secondary">添加</button>
</form>
</div>


<div class="litapay-admin-section">
<h3>充值码列表</h3>
<form method="GET" action="admin.php" class="form-inline" style="margin-bottom: 1rem;">
<input type="hidden" name="page" value="litapay-recharge-codes">
<div class="form-group">
<label for="search_code_input">搜索充值码:</label>
<input type="text" id="search_code_input" name="search_code" value="<?php echo e($search_code); ?>" class="form-control">
</div>
<div class="form-group">
<label for="filter_status_select">状态:</label>
<select id="filter_status_select" name="filter_status" class="form-control">
<option value="">全部</option>
<option value="0" <?php selected($filter_status, '0'); ?>>未使用</option>
<option value="1" <?php selected($filter_status, '1'); ?>>已使用</option>
<option value="2" <?php selected($filter_status, '2'); ?>>已禁用</option>
</select>
</div>
<button type="submit" class="button">筛选</button>
</form>

<table class="admin-table">
<thead>
<tr>
<th>ID</th>
<th>充值码</th>
<th>金额</th>
<th>状态</th>
<th>使用者</th>
<th>创建日期</th>
<th>使用日期</th>
<th>备注</th>
<th>操作</th>
</tr>
</thead>
<tbody>
<?php if (empty($recharge_codes)): ?>
<tr><td colspan="9" style="text-align:center;">没有找到充值码。</td></tr>
<?php else: ?>
<?php foreach ($recharge_codes as $code): ?>
<tr>
<td><?php echo $code['id']; ?></td>
<td><code><?php echo e($code['code']); ?></code></td>
<td><?php echo e($currency_symbol . number_format($code['amount'], 2)); ?></td>
<td>
<?php
if ($code['status'] == 0) echo '<span class="status-badge status-active">未使用</span>';
elseif ($code['status'] == 1) echo '<span class="status-badge status-archived">已使用</span>';
else echo '<span class="status-badge status-cancelled">已禁用</span>';
?>
</td>
<td><?php echo e($code['used_by_username'] ?: 'N/A'); ?></td>
<td><?php echo date('Y-m-d H:i', strtotime($code['created_at'])); ?></td>
<td><?php echo $code['used_at'] ? date('Y-m-d H:i', strtotime($code['used_at'])) : 'N/A'; ?></td>
<td><?php echo e($code['notes'] ?: 'N/A'); ?></td>
<td>
<form method="POST" action="admin.php?page=litapay-recharge-codes&paged=<?php echo $current_page; ?>" style="display:inline;" onsubmit="return confirm('确定操作吗？');">
<input type="hidden" name="litapay_recharge_csrf" value="<?php echo generateCsrfToken('litapay_admin_recharge_codes'); ?>">
<input type="hidden" name="code_id" value="<?php echo $code['id']; ?>">
<?php if ($code['status'] == 0): // Only allow disabling active codes ?>
<button type="submit" name="litapay_disable_code" class="button btn-warning button-sm">禁用</button>
<?php endif; ?>
<button type="submit" name="litapay_delete_code" class="button btn-danger button-sm">删除</button>
</form>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
<?php
// LitaBlog's pagination function
$pagination_params_for_url = ['page' => 'litapay-recharge-codes'];
if ($filter_status !== '') $pagination_params_for_url['filter_status'] = $filter_status;
if (!empty($search_code)) $pagination_params_for_url['search_code'] = $search_code;
echo get_paginations($current_page, $total_codes, $codes_per_page, $pagination_params_for_url);
?>
</div>

<style>
.litapay-admin-section { margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px solid var(--border-color); }
.litapay-admin-section:last-child { border-bottom: none; }
.form-inline .form-group { margin-right: 1rem; margin-bottom: 0.5rem; display: inline-flex; align-items: center; }
.form-inline .form-group label { margin-right: 0.5rem; margin-bottom: 0; }
.form-inline .form-control { width: auto; display: inline-block; }
</style>