
<?php
// --- START OF MODIFICATION ---
// File: content/plugins/litapay/admin/settings-page.php

if (!defined('ABSPATH') || !is_admin()) {
echo '<p>非法访问。</p>';
return;
}

// --- Handle Settings Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['litapay_save_settings'])) {
if (!isset($_POST['litapay_settings_csrf']) || !verifyCsrfToken($_POST['litapay_settings_csrf'], 'litapay_admin_settings')) {
set_flash_message('安全验证失败，请重试。', 'error');
} else {
$options_to_save = [
'litapay_currency_symbol'       => sanitize_text_field($_POST['litapay_currency_symbol'] ?? '¥'),
'litapay_global_access_price'   => filter_var($_POST['litapay_global_access_price'] ?? '99.00', FILTER_VALIDATE_FLOAT),
'litapay_enable_balance'        => isset($_POST['litapay_enable_balance']) ? '1' : '0',
'litapay_enable_recharge_codes' => isset($_POST['litapay_enable_recharge_codes']) ? '1' : '0',
'litapay_enable_afdian'         => isset($_POST['litapay_enable_afdian']) ? '1' : '0',
'litapay_afdian_user_id'        => sanitize_text_field($_POST['litapay_afdian_user_id'] ?? ''),
'litapay_afdian_api_token'      => sanitize_text_field($_POST['litapay_afdian_api_token'] ?? ''),
'litapay_afdian_default_plan_id_for_purchase' => sanitize_text_field($_POST['litapay_afdian_default_plan_id_for_purchase'] ?? ''),
'litapay_afdian_webhook_secret' => sanitize_text_field($_POST['litapay_afdian_webhook_secret'] ?? ''),

// New options for recharge page
'litapay_official_recharge_page_id' => isset($_POST['litapay_official_recharge_page_id']) ? (int)$_POST['litapay_official_recharge_page_id'] : 0,
'litapay_enable_standalone_recharge_page' => isset($_POST['litapay_enable_standalone_recharge_page']) ? '1' : '0',
'litapay_redirect_standalone_to_official' => isset($_POST['litapay_redirect_standalone_to_official']) ? '1' : '0',

// --- 新增：保存登录页和用户中心页设置 ---
'litapay_login_page_id' => isset($_POST['litapay_login_page_id']) ? (int)$_POST['litapay_login_page_id'] : 0,
'litapay_user_center_page_id' => isset($_POST['litapay_user_center_page_id']) ? (int)$_POST['litapay_user_center_page_id'] : 0,
// --- 结束新增 ---

];

if ($options_to_save['litapay_global_access_price'] === false || $options_to_save['litapay_global_access_price'] < 0) {
$options_to_save['litapay_global_access_price'] = '99.00';
set_flash_message('全局访问价格无效，已重置。', 'warning');
}

$all_saved = true;
foreach ($options_to_save as $name => $value) {
if (!update_option($name, $value)) {
$all_saved = false;
}
}

if ($all_saved) {
set_flash_message('LitaPay 设置已保存。', 'success');
} else {
set_flash_message('部分设置保存失败，请检查。', 'error');
}
}
header('Location: admin.php?page=litapay-settings');
exit;
}

// Get current settings for display
$currency_symbol       = get_option('litapay_currency_symbol', '¥');
$global_access_price   = number_format((float)get_option('litapay_global_access_price', '99.00'), 2, '.', '');
$enable_balance        = get_option('litapay_enable_balance', '1') === '1';
$enable_recharge_codes = get_option('litapay_enable_recharge_codes', '1') === '1';
$enable_afdian         = get_option('litapay_enable_afdian', '0') === '1';
$afdian_user_id        = get_option('litapay_afdian_user_id', '');
$afdian_api_token      = get_option('litapay_afdian_api_token', '');
$afdian_default_plan_id = get_option('litapay_afdian_default_plan_id_for_purchase', '');
$afdian_webhook_secret = get_option('litapay_afdian_webhook_secret', '');
$litapay_webhook_url   = rtrim(SITE_URL, '/') . '/?litapay_webhook=afdian';

// New options
$all_pages_for_select = get_posts(['type' => 'page', 'status' => 'publish', 'limit' => -1, 'orderby' => 'title', 'order' => 'ASC']);
$current_recharge_page_id = (int)get_option('litapay_official_recharge_page_id', 0);
$enable_standalone_recharge_page = get_option('litapay_enable_standalone_recharge_page', '1') === '1'; // Default to enabled for backward compatibility
$redirect_standalone_to_official = get_option('litapay_redirect_standalone_to_official', '0') === '1';

// --- 新增：获取登录页和用户中心页当前设置 ---
$current_login_page_id = (int)get_option('litapay_login_page_id', 0);
$current_user_center_page_id = (int)get_option('litapay_user_center_page_id', 0);
// --- 结束新增 ---

?>

<?php display_flash_message(); ?>

<form method="POST" action="admin.php?page=litapay-settings" class="litapay-settings-form">
<input type="hidden" name="litapay_settings_csrf" value="<?php echo generateCsrfToken('litapay_admin_settings'); ?>">

<h3>基本设置</h3>
<!-- ... (existing basic settings: currency, global access price) ... -->
<div class="form-group">
<label for="litapay_currency_symbol">货币符号</label>
<input type="text" id="litapay_currency_symbol" name="litapay_currency_symbol" value="<?php echo e($currency_symbol); ?>" class="form-control" />
<p class="description">例如：¥, $</p>

<label for="litapay_global_access_price">全局阅读权限价格</label>
<input type="number" id="litapay_global_access_price" name="litapay_global_access_price" value="<?php echo e($global_access_price); ?>" min="0.00" step="0.01" class="form-control" style="width: 100px;">
<p class="description">用户购买此权限后，可查看所有付费内容。设为0则禁用全局购买。</p>
</div>

<h3>支付方式</h3>
<!-- ... (existing payment method toggles: balance, recharge codes, afdian) ... -->
<div class="form-group">
<label>
<input type="checkbox" name="litapay_enable_balance" value="1" <?php checked($enable_balance, true, true); ?>>
启用余额支付
</label>
<p class="description">允许用户使用账户余额购买内容。</p>
</div>
<div class="form-group">
<label>
<input type="checkbox" name="litapay_enable_recharge_codes" value="1" <?php checked($enable_recharge_codes, true, true); ?>>
启用充值码
</label>
<p class="description">允许用户使用充值码为账户余额充值。禁用后，充值码输入表单将不显示。</p>
</div>
<div class="form-group">
<label>
<input type="checkbox" name="litapay_enable_afdian" value="1" <?php checked($enable_afdian, true, true); ?>>
启用爱发电支付/充值
</label>
<p class="description">允许用户通过爱发电平台进行支付或充值。</p>
</div>


<div id="litapay-afdian-settings" style="<?php echo $enable_afdian ? '' : 'display:none;'; ?>">
<h4>爱发电 API 设置</h4>
<!-- ... (existing Afdian settings) ... -->
<div class="form-group">
<label for="litapay_afdian_user_id">爱发电 User ID</label>
<input type="text" id="litapay_afdian_user_id" name="litapay_afdian_user_id" value="<?php echo e($afdian_user_id); ?>" class="form-control">
<p class="description">您的爱发电用户ID (user_id)，可在爱发电开发者后台查看。</p>
</div>
<div class="form-group">
<label for="litapay_afdian_api_token">爱发电 API Token (Key)</label>
<input type="text" id="litapay_afdian_api_token" name="litapay_afdian_api_token" value="<?php echo e($afdian_api_token); ?>" class="form-control">
<p class="description">您的爱发电接口密钥 (token)，可在爱发电开发者后台查看。</p>
</div>
<div class="form-group">
<label for="litapay_afdian_default_plan_id_for_purchase">爱发电默认支付方案ID (可选)</label>
<input type="text" id="litapay_afdian_default_plan_id_for_purchase" name="litapay_afdian_default_plan_id_for_purchase" value="<?php echo e($afdian_default_plan_id); ?>" class="form-control">
<p class="description">如果希望用户通过爱发电购买文章时默认跳转到您爱发电上的特定“自定义金额”发电方案，请填写其 Plan ID。否则，将尝试直接向您的用户ID发起自定义金额支付。</p>
</div>
<div class="form-group">
<label for="litapay_afdian_webhook_secret">爱发电 Webhook 签名密钥 (可选)</label>
<input type="text" id="litapay_afdian_webhook_secret" name="litapay_afdian_webhook_secret" value="<?php echo e($afdian_webhook_secret); ?>" class="form-control">
<p class="description">如果您在爱发电开发者后台设置了Webhook的签名密钥，请填入此处以验证回调安全性。</p>
</div>
<div class="form-group">
<label>您的 LitaPay Webhook 接收地址</label>
<input type="text" value="<?php echo e($litapay_webhook_url); ?>" class="form-control" readonly>
<p class="description">请将此地址配置到您爱发电开发者后台的 Webhook 设置中。</p>
</div>
</div>

<hr> <?php // Separator for new section ?>
<?php // --- 修改：将充值页面设置和新增的页面设置整合到一个区域 --- ?>
<h3>页面设置</h3>

<div class="form-group">
<label for="litapay_official_recharge_page_id">选择官方充值页面 (推荐)</label>
<select id="litapay_official_recharge_page_id" name="litapay_official_recharge_page_id" class="form-control">
<option value="0">-- 不指定 (将使用下方独立链接或不提供充值入口) --</option>
<?php if (!empty($all_pages_for_select)): ?>
<?php foreach ($all_pages_for_select as $page_item): ?>
<option value="<?php echo $page_item['id']; ?>" <?php selected($current_recharge_page_id, $page_item['id'], true); ?>>
<?php echo e($page_item['title']); ?> (ID: <?php echo $page_item['id']; ?>)
</option>
<?php endforeach; ?>
<?php endif; ?>
</select>
<p class="description">
选择一个您已创建并已添加 <code>[litapay_recharge_form]</code> 短代码的“页面”作为主要的充值入口。
<br>插件内部链接（如余额不足时的提示）将指向此页面。
</p>
</div>

<div class="form-group">
<label>
<input type="checkbox" id="litapay_enable_standalone_recharge_page" name="litapay_enable_standalone_recharge_page" value="1" <?php checked($enable_standalone_recharge_page, true, true); ?>>
启用独立充值链接 (<code>/?litapay_page=recharge</code>)
</label>
<p class="description">勾选此项，用户将可以通过上述特定URL访问一个独立的充值表单页面。此页面作为未指定“官方充值页面”时的回退选项。</p>
</div>

<div class="form-group" id="litapay_redirect_standalone_setting" style="<?php echo ($current_recharge_page_id > 0 && $enable_standalone_recharge_page) ? '' : 'display:none;'; ?>">
<label>
<input type="checkbox" name="litapay_redirect_standalone_to_official" value="1" <?php checked($redirect_standalone_to_official, true, true); ?>>
当访问独立充值链接时，自动重定向到上方选择的“官方充值页面”
</label>
<p class="description">如果同时启用了独立链接并选择了官方充值页面，勾选此项可以统一用户体验。</p>
</div>

<?php // --- 新增：登录/注册页面设置 --- ?>
<div class="form-group">
<label for="litapay_login_page_id">选择登录/注册页面</label>
<select id="litapay_login_page_id" name="litapay_login_page_id" class="form-control">
<option value="0">-- 不指定 (将使用默认后台登录页) --</option>
<?php if (!empty($all_pages_for_select)): ?>
<?php foreach ($all_pages_for_select as $page_item): ?>
<option value="<?php echo $page_item['id']; ?>" <?php selected($current_login_page_id, $page_item['id'], true); ?>>
<?php echo e($page_item['title']); ?> (ID: <?php echo $page_item['id']; ?>)
</option>
<?php endforeach; ?>
<?php endif; ?>
</select>
<p class="description">
选择一个您已创建并已添加 <code>[litapay_login_form]</code> 短代码的“页面”作为主要的登录/注册入口。
<br>付费墙的“请先登录”链接将指向此页面。
</p>
</div>
<?php // --- 结束新增 --- ?>

<?php // --- 新增：用户中心页面设置 --- ?>
<div class="form-group">
<label for="litapay_user_center_page_id">选择用户中心页面</label>
<select id="litapay_user_center_page_id" name="litapay_user_center_page_id" class="form-control">
<option value="0">-- 不指定 (将使用默认后台个人资料页) --</option>
<?php if (!empty($all_pages_for_select)): ?>
<?php foreach ($all_pages_for_select as $page_item): ?>
<option value="<?php echo $page_item['id']; ?>" <?php selected($current_user_center_page_id, $page_item['id'], true); ?>>
<?php echo e($page_item['title']); ?> (ID: <?php echo $page_item['id']; ?>)
</option>
<?php endforeach; ?>
<?php endif; ?>
</select>
<p class="description">
选择一个您已创建并已添加 <code>[litapay_user_center]</code> 短代码的“页面”作为用户中心。
</p>
</div>
<?php // --- 结束新增 --- ?>
<?php // --- 结束页面设置区域 --- ?>

<script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
var afdianToggle = document.querySelector('input[name="litapay_enable_afdian"]');
var afdianSettingsDiv = document.getElementById('litapay-afdian-settings');
if (afdianToggle && afdianSettingsDiv) {
afdianToggle.addEventListener('change', function() {
afdianSettingsDiv.style.display = this.checked ? 'block' : 'none';
});
}

// New JS for redirect option visibility
var officialPageSelect = document.getElementById('litapay_official_recharge_page_id');
var enableStandaloneCheckbox = document.getElementById('litapay_enable_standalone_recharge_page');
var redirectSettingDiv = document.getElementById('litapay_redirect_standalone_setting');

function toggleRedirectSettingVisibility() {
if (redirectSettingDiv && officialPageSelect && enableStandaloneCheckbox) {
if (parseInt(officialPageSelect.value, 10) > 0 && enableStandaloneCheckbox.checked) {
redirectSettingDiv.style.display = 'block';
} else {
redirectSettingDiv.style.display = 'none';
}
}
}
if (officialPageSelect) officialPageSelect.addEventListener('change', toggleRedirectSettingVisibility);
if (enableStandaloneCheckbox) enableStandaloneCheckbox.addEventListener('change', toggleRedirectSettingVisibility);
toggleRedirectSettingVisibility(); // Initial check
});
</script>

<div class="form-group">
<button type="submit" name="litapay_save_settings" class="button btn-primary">保存设置</button>
</div>
</form>
<?php
