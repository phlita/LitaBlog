<?php
if (!defined('ABSPATH')) exit;
error_log('LitaPay DEBUG: admin/admin-menu.php loaded2.');
/**
* Register LitaPay Admin Menu Pages.
* Uses LitaBlog's add_menu_page and add_submenu_page.
*/
function litapay_register_admin_menus() {
error_log('LitaPay DEBUG: litapay_register_admin_menus() CALLED.');
add_menu_page(
'LitaPay 设置',                  // Page Title
'LitaPay',                       // Menu Title
'manage_options',                // Capability (LitaBlog uses 'is_admin()' for this)
'litapay-main',                  // Menu Slug (for the top-level, often same as first submenu)
'litapay_render_settings_page',  // Function to display page content
LITAPAY_PLUGIN_URL . 'admin/images/icon.svg', // Optional Icon URL (create this SVG)
75                               // Position (adjust as needed)
);

// Submenu: Settings (can be the same as the main page or a different one)
add_submenu_page(
'litapay-main',                  // Parent Slug
'LitaPay 常规设置',             // Page Title
'常规设置',                     // Menu Title
'manage_options',
'litapay-settings',              // Submenu Slug
'litapay_render_settings_page'   // Callback function
);

// Submenu: Recharge Codes
add_submenu_page(
'litapay-main',
'LitaPay 充值码管理',
'充值管理',
'manage_options',
'litapay-recharge-codes',
'litapay_render_recharge_codes_page'
);

// Submenu: Transactions
add_submenu_page(
'litapay-main',
'LitaPay 交易记录',
'交易记录',
'manage_options',
'litapay-transactions',
'litapay_render_transactions_page'
);
}
add_action('admin_menu', 'litapay_register_admin_menus'); // LitaBlog's hook for adding admin menus
error_log('LitaPay DEBUG (admin-menu.php after add_action): $GLOBALS[wp_actions][admin_menu] = ' . print_r($GLOBALS['wp_actions']['admin_menu'] ?? "NOT SET OR EMPTY", true));
/**
* Callback function to render the Settings page.
* The actual HTML/PHP for the page will be in settings-page.php.
*/
function litapay_render_settings_page() {
// Basic capability check again (belt and suspenders)
if (!is_admin()) { // LitaBlog's function
echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
return;
}
require_once LITAPAY_PLUGIN_DIR . 'admin/settings-page.php';
}

/**
* Callback function to render the Recharge Codes page.
*/
function litapay_render_recharge_codes_page() {
if (!is_admin()) {
echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
return;
}
require_once LITAPAY_PLUGIN_DIR . 'admin/recharge-codes-page.php';
}

/**
* Callback function to render the Transactions page.
*/
function litapay_render_transactions_page() {
if (!is_admin()) {
echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
return;
}
require_once LITAPAY_PLUGIN_DIR . 'admin/transactions-page.php';
}

// Placeholder for icon.svg:
// Create a simple SVG icon (e.g., a coin or dollar sign) and save it as
// litapay/admin/assets/images/icon.svg
// Example:
// <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
//   <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v2h-2v-2zm0 4h2v6h-2v-6z"/>
// </svg>
// Save this content as icon.svg in the specified path.
?>