document.addEventListener('DOMContentLoaded', function() {
// Quill Button for [litapay_paid] shortcode
if (typeof Quill !== 'undefined' && document.getElementById('editor-container') && window.quillInstance) {
const quill = window.quillInstance;
const litapayButton = document.createElement('button');
litapayButton.setAttribute('type', 'button');
litapayButton.innerHTML = '💰';
litapayButton.title = '插入付费内容块';
litapayButton.classList.add('ql-formats-button'); // For styling

litapayButton.addEventListener('click', function() {
const range = quill.getSelection(true);
const selectedText = quill.getText(range.index, range.length);
const promptPrice = prompt("请输入此付费内容块的价格 (例如 5.00)。\n如果希望此块使用文章全局价格，请留空或输入0。", "0.00");

let priceAttribute = "";
if (promptPrice !== null) { // User didn't cancel prompt
const price = parseFloat(promptPrice);
if (!isNaN(price) && price > 0) {
priceAttribute = ` price="${price.toFixed(2)}"`;
} else if (promptPrice.trim() !== "" && (isNaN(price) || price <= 0)) {
alert("输入的价格无效。将使用文章全局价格或默认为免费（如果未设置全局价）。");
}
} else {
// User cancelled prompt, do nothing or insert without price
return; 
}

let shortcodeText;
if (selectedText.length > 0) {
shortcodeText = `[litapay_paid${priceAttribute}]${selectedText}[/litapay_paid]`;
quill.deleteText(range.index, range.length);
quill.insertText(range.index, shortcodeText, 'user');
quill.setSelection(range.index + shortcodeText.length, 0);
} else {
shortcodeText = `[litapay_paid${priceAttribute}]此处填写付费内容[/litapay_paid]`;
quill.insertText(range.index, shortcodeText, 'user');
const placeholderText = '此处填写付费内容';
const openTag = `[litapay_paid${priceAttribute}]`;
quill.setSelection(range.index + openTag.length, placeholderText.length);
}
});

const quillToolbar = document.querySelector('.ql-toolbar.ql-snow'); // LitaBlog's toolbar selector
if (quillToolbar) {
let customGroup = quillToolbar.querySelector('.ql-formats.ql-litapay-group');
if (!customGroup) {
customGroup = document.createElement('span');
customGroup.classList.add('ql-formats', 'ql-litapay-group'); // Use a specific class for the group
// Append to an existing group or as a new group
const firstGroup = quillToolbar.querySelector('.ql-formats');
if (firstGroup) {
quillToolbar.insertBefore(customGroup, firstGroup.nextSibling); // Insert after the first group
} else {
quillToolbar.appendChild(customGroup);
}
}
customGroup.appendChild(litapayButton);
} else {
console.warn('LitaPay: Quill toolbar (.ql-toolbar.ql-snow) not found.');
}
}

// Toggle for Afdian settings visibility on settings page
const afdianToggle = document.querySelector('input[name="litapay_enable_afdian"]');
const afdianSettingsDiv = document.getElementById('litapay-afdian-settings');
if (afdianToggle && afdianSettingsDiv) {
function toggleAfdianSettings() {
afdianSettingsDiv.style.display = afdianToggle.checked ? 'block' : 'none';
}
afdianToggle.addEventListener('change', toggleAfdianSettings);
toggleAfdianSettings(); // Initial state
}
});