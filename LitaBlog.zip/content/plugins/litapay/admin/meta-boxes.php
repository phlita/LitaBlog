<?php
if (!defined('ABSPATH')) exit;

/**
* Render the LitaPay price meta box content directly.
* This function is hooked to LitaBlog's 'do_meta_boxes' action.
*
* @param string $post_type The type of post being edited (e.g., 'post', 'page').
* @param string $context   The context where the meta box is displayed (e.g., 'normal', 'side'). LitaBlog passes 'normal'.
* @param array  $post_data The current post data array (LitaBlog's $item_data from content.php).
*/
function litapay_render_price_meta_box_content($post_type, $context, $post_data) {
// We are only interested in the 'normal' context for LitaBlog's current structure.
if ($context !== 'normal') {
return;
}

// Only show for 'post' and 'page' types, or others if LitaPay supports them.
if (!in_array($post_type, ['post', 'page'])) {
return;
}

// Nonce for security, though save_post should also verify its own nonce from the main form.
// However, LitaBlog's main form in admin/content.php does not have a clear nonce.
// For meta box specific actions via AJAX (not used here), a nonce would be critical.
// Since this is part of the main post form, we rely on LitaBlog's overall form security (if any).
// For added safety, we could add a LitaPay-specific nonce here if desired.

$post_id = isset($post_data['id']) ? (int)$post_data['id'] : null;
$current_price = '0.00'; // Default to free
$is_paid_content_active = false; // Default

if ($post_id) {
$current_price = litapay_get_post_price($post_id); // From LitaPay's functions-core.php
$is_paid_content_active_meta = get_post_meta($post_id, 'litapay_content_requires_payment', true);
if ($is_paid_content_active_meta === '1') {
$is_paid_content_active = true;
}
}
// Format price for display
$current_price_display = number_format((float)$current_price, 2, '.', '');

$currency_symbol = get_option('litapay_currency_symbol', '¥');
?>
<div class="form-group litapay-meta-box-section"> <?php // LitaBlog's admin CSS class for form groups ?>
<h4>LitaPay 付费内容设置</h4>

<label for="litapay_post_price" style="display:inline-block; margin-right: 5px;">
<strong>文章价格:</strong> <?php echo e($currency_symbol); ?>
</label>
<input type="number" id="litapay_post_price" name="litapay_post_price" 
value="<?php echo e($current_price_display); ?>" 
min="0.00" step="0.01" class="form-control" 
style="display:inline-block; width: auto; max-width: 100px; vertical-align: middle;"
placeholder="0.00">

<p class="description" style="margin-top: 5px;">
为整篇文章设置付费阅读价格。如果价格大于0，整篇文章（或未使用短代码保护的部分）将需要付费。
<br>您也可以在文章内容中使用 <code>[litapay_paid price="X.XX"]受保护内容[/litapay_paid]</code> 短代码来为特定部分设置价格，短代码中的价格优先。
<br>如果文章中使用了无价格的 <code>[litapay_paid]内容[/litapay_paid]</code> 短代码，则此处的文章价格将应用于该部分。
<br>设为0或留空表示整篇文章（或未使用短代码标价的部分）免费。
</p>
</div>
<?php
}
// Hook into LitaBlog's meta box rendering action
add_action('do_meta_boxes', 'litapay_render_price_meta_box_content', 10, 3);


/**
* Save LitaPay meta box data when a post is saved.
* Hooked to LitaBlog's 'save_post' action.
*
* @param int   $post_id             The ID of the post being saved.
* @param array $post_data_submitted All $_POST data submitted from admin/content.php form.
*/
function litapay_save_price_meta_data($post_id, $post_data_submitted) {
// LitaBlog's admin/content.php doesn't have a clear nonce for the main form.
// Ideally, there should be one. For now, we proceed with the save.
// A plugin-specific nonce could be added to litapay_render_price_meta_box_content and checked here.

if (isset($_POST['litapay_post_price'])) {
// Sanitize the input price
$price_input = $_POST['litapay_post_price'];
if ($price_input === '' || $price_input === null) {
$price = 0.00; // Treat empty as free
} else {
$price = filter_var($price_input, FILTER_VALIDATE_FLOAT);
if ($price === false || $price < 0) {
$price = 0.00; // Invalid input, default to free
}
}
// Use LitaPay's function to set the post price and associated meta
litapay_set_post_price($post_id, $price);
} else {
// If the field isn't submitted (e.g., checkbox unchecked if it were one),
// it implies no change or a default. For a price field, if it's not there,
// we might assume it means "free" or "no change to existing price".
// Since litapay_set_post_price handles the 'litapay_content_requires_payment' meta,
// it's better to explicitly save 0 if the field is not present, assuming it was intentionally cleared.
// However, text/number inputs are usually always present if the form is submitted.
// If an existing post had a price and the field was REMOVED from HTML (e.g. by JS error),
// this logic wouldn't clear the price. This is generally fine.
}
}
// Hook into LitaBlog's post saving action
add_action('save_post', 'litapay_save_price_meta_data', 10, 2);
?>