<?php
/**
* Plugin Name: JSCrypt
* Description: 使用 CryptoJS 库加密、解密文章和页面内容。
* Plugin URI: https://blog.lita.eu.org/
* Version: 1.0
* Author: 芙里塔
* Author URI: https://space.bilibili.com/3546703747615466
*/

// --- 1. 加载 CryptoJS 库 ---

/**
* 在前端和后端页脚加载 CryptoJS 库
* @return string Script tag or error comment
*/
function jscrypt_enqueue_crypto_script() {
// 确认常量是否定义
if (!defined('ABSPATH') || !defined('SITE_URL')) {
error_log("JSCrypt Error: ABSPATH or SITE_URL not defined.");
return '<!-- JSCrypt Error: Required constants not defined -->';
}

$cryptojs_url = rtrim(SITE_URL, '/') . '/content/plugins/jscrypt/crypto-js.min.js';
$cryptojs_path = ABSPATH . 'content/plugins/jscrypt/crypto-js.min.js';

if (file_exists($cryptojs_path)) {
// 返回脚本标签让 do_plugin_action 输出
echo '<script src="' . htmlspecialchars($cryptojs_url) . '?ver=4.1.1" id="cryptojs-lib"></script>';
} else {
error_log("JSCrypt Error: crypto-js.min.js not found at " . $cryptojs_path);
return '<!-- JSCrypt Error: crypto-js.min.js not found -->';
}
}
// 注册到前端和后端页脚
add_action('wp_footer', 'jscrypt_enqueue_crypto_script');
add_action('admin_footer', 'jscrypt_enqueue_crypto_script');


// --- 2. 加载后台编辑器按钮的 JS ---

/**
* 在后台页脚加载编辑器按钮的 JS (jscrypt-admin.js)
* !! 移除了页面判断，脚本将在所有执行 admin_footer 的页面加载 !!
* !! jscrypt-admin.js 内部会检查编辑器工具栏是否存在 !!
* @return string Script tag or error comment
*/
function jscrypt_enqueue_admin_script() {
// 再次确认常量
if (!defined('ABSPATH') || !defined('SITE_URL')) {
// 这个错误不应该发生，因为上面的函数也会检查
return '<!-- JSCrypt Admin Error: Required constants not defined -->';
}

$admin_script_url = rtrim(SITE_URL, '/') . '/content/plugins/jscrypt/jscrypt-admin.js';
$admin_script_path = ABSPATH . 'content/plugins/jscrypt/jscrypt-admin.js';

if (file_exists($admin_script_path)) {
// 使用 defer 确保 DOM 解析后执行，并且理论上会在 cryptojs-lib 之后执行（浏览器通常按顺序）
// 或者考虑将两个脚本合并加载，或者使用更复杂的依赖管理
echo '<script src="' . htmlspecialchars($admin_script_url) . '?ver=1.3" defer id="jscrypt-admin-script"></script>';
} else {
error_log("JSCrypt Error: jscrypt-admin.js not found at " . $admin_script_path);
return '<!-- JSCrypt Error: jscrypt-admin.js not found -->';
}
}
// 注册到后端页脚
add_action('admin_footer', 'jscrypt_enqueue_admin_script');


// --- 3. 处理前端内容解密 ---
// (这部分代码保持不变)
/**
* 过滤文章内容，查找加密块，替换为占位符，并附加解密所需 HTML 和 JS。
* @param string $content 原始文章内容
* @return string 修改后的内容
*/
function jscrypt_filter_post_content($content) {
// 检查内容中是否包含加密标记
if (stripos($content, '[encrypted]') !== false) {
$pattern = '/\[encrypted\](.*?)\[\/encrypted\]/s';
preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);
$encrypted_data_for_js = [];

foreach ($matches as $index => $match) {
$encrypted_content_base64 = trim($match[1]);
if (!empty($encrypted_content_base64)) {
// 检查是否是有效的 Base64 (可选，增加健壮性)
// if (base64_encode(base64_decode($encrypted_content_base64, true)) === $encrypted_content_base64) {
$placeholder = "<div class='encrypted-content' data-index='{$index}'>***内含密文***</div>";
// 替换时更精确，避免部分替换问题（虽然正则通常能处理）
$content = str_replace($match[0], $placeholder, $content);
$encrypted_data_for_js[$index] = $encrypted_content_base64;
// } else {
//    // 无效的 Base64 数据，可以选择跳过或显示错误
//    error_log("JSCrypt Warning: Invalid Base64 data found in content block " . ($index + 1));
//}
}
}

if (!empty($encrypted_data_for_js)) {
// 确保 json_encode 成功
$json_encrypted_contents = json_encode(array_values($encrypted_data_for_js), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if ($json_encrypted_contents === false) {
error_log("JSCrypt Error: Failed to JSON encode encrypted data.");
return $content; // 编码失败，返回原始内容
}

// 解密提示框 HTML (保持不变)
$decrypt_html = '
<div id="cryptojs-decrypt-prompt">
<input type="password" id="cryptojs-password" placeholder="请输入密码" />
<button type="button" onclick="cryptojs_decrypt()">解密</button>
<p id="cryptojs-message" style="color: red; margin-top: 10px; font-size: 0.9em;"></p>
</div>';

// 前端解密 JS (保持不变)
$decrypt_js = "
<script>
// 1. 总是定义加密内容数据和解密函数，使其在全局作用域可用
var encryptedContents = " . $json_encrypted_contents . ";

function cryptojs_decrypt() {
// 2. 在函数被调用时（即用户点击按钮时）才检查 CryptoJS
if (typeof CryptoJS === 'undefined') {
console.error('JSCrypt Error: CryptoJS library not loaded for decryption when button clicked.');
var messageElement = document.getElementById('cryptojs-message');
if(messageElement) messageElement.textContent = '错误：解密库加载失败！请刷新页面重试。';
// 或者更友好地提示用户库可能正在加载
var promptDiv = document.getElementById('cryptojs-decrypt-prompt');
if(promptDiv) promptDiv.innerHTML = '<p style=\"color:red;\">错误：解密库加载失败！</p>';
return; // 阻止进一步执行
}

var passwordInput = document.getElementById('cryptojs-password');
var password = passwordInput.value;
var messageElement = document.getElementById('cryptojs-message');
messageElement.textContent = ''; // 清空旧消息

if (!password) {
messageElement.textContent = '请输入密码!';
if(passwordInput) passwordInput.focus();
return;
}

var allDecrypted = true;
var firstErrorIndex = -1;

encryptedContents.forEach(function(encryptedBase64, index) {
var placeholder = document.querySelector(\".encrypted-content[data-index='\" + index + \"']\");
if (!placeholder) {
console.warn('JSCrypt: Placeholder ' + index + ' not found.');
return; // continue to next iteration
}
try {
var decrypted = CryptoJS.AES.decrypt(encryptedBase64, password);
var decryptedText = decrypted.toString(CryptoJS.enc.Utf8);

if (!decryptedText) { throw new Error('Decryption failed (empty result)'); }

var parsed = new DOMParser().parseFromString(decryptedText, 'text/html');
placeholder.innerHTML = ''; 
Array.from(parsed.body.childNodes).forEach(node => {
placeholder.appendChild(node.cloneNode(true));
});
placeholder.classList.remove('encrypted-content');
placeholder.style.border = 'none'; placeholder.style.padding = '0';
placeholder.style.color = '';
} catch (error) {
console.error('JSCrypt: Decryption error for block ' + (index + 1) + ':', error.message, error);
allDecrypted = false;
if (firstErrorIndex === -1) firstErrorIndex = index + 1;
placeholder.innerHTML = '***解密失败***'; placeholder.style.color = 'red';
placeholder.style.border = '1px dashed red'; placeholder.style.padding = '10px';
}
});

if (allDecrypted) {
var promptElement = document.getElementById('cryptojs-decrypt-prompt');
if (promptElement) promptElement.remove();
} else {
messageElement.textContent = '部分内容解密失败 (可能是密码错误，第一个失败的块是第 ' + firstErrorIndex + ' 个)';
if(passwordInput) passwordInput.focus();
}
}

// 添加 Enter 键监听 (可选, 但用户体验好)
document.addEventListener('DOMContentLoaded', function() {
var pwInput = document.getElementById('cryptojs-password');
if (pwInput) {
pwInput.addEventListener('keypress', function(event) {
if (event.key === 'Enter') {
event.preventDefault();
cryptojs_decrypt(); // 调用全局定义的函数
}
});
}
});
</script>
";
$content .= $decrypt_html . $decrypt_js;
}
}
return $content;
}
// 注册内容过滤钩子
add_filter('the_content', 'jscrypt_filter_post_content');

?>