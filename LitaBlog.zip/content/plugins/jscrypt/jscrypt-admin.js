// jscrypt-admin.js (改进版)
document.addEventListener('DOMContentLoaded', function() {
// 确保 CryptoJS 库已加载
if (typeof CryptoJS === 'undefined') {
console.error("JSCrypt Admin Error: CryptoJS library not loaded before admin script.");
return;
}

// 等待 Quill 实例准备好
// content.php 中的 Quill 实例名为 'quill'



// 方案二：更稳妥的方式是 content.php 在 Quill 初始化后触发一个自定义事件，
// 或者 jscrypt-admin.js 轮询检查 Quill 是否已初始化。
// 这里使用轮询作为示例，但自定义事件更好。
let attempts = 0;
const maxAttempts = 10;
const interval = setInterval(function() {
const editorContainer = document.getElementById('editor-container');
// Quill 将其实例存储在 DOM 元素的 __quill 属性中 (非官方 API，但常用)
// 或者如果 content.php 将 quill 赋给了全局变量，可以直接检查它
if (editorContainer && editorContainer.__quill) {
clearInterval(interval);
initializeJSCryptButtons(editorContainer.__quill); // 将 Quill 实例传递过去
} else if (typeof window.quillInstance !== 'undefined') { // 假设 content.php 设置了 window.quillInstance
clearInterval(interval);
initializeJSCryptButtons(window.quillInstance);
}
else {
attempts++;
if (attempts >= maxAttempts) {
clearInterval(interval);
console.error("JSCrypt Admin Error: Quill instance could not be found after multiple attempts.");
}
}
}, 500); // 每 500ms 检查一次

});

function initializeJSCryptButtons(quillInstance) {
if (!quillInstance) {
console.error("JSCrypt Admin Error: Quill instance is not available.");
return;
}

const toolbar = quillInstance.getModule('toolbar');
if (!toolbar || !toolbar.container) {
console.error("JSCrypt Admin Error: Quill toolbar container not found.");
return;
}

const quillToolbarElement = toolbar.container; // 这是 Quill 生成的工具栏 DOM 元素

// --- 创建 加密 (Enc) 按钮 ---
const encryptButton = document.createElement('button');
encryptButton.type = 'button';
encryptButton.title = '加密选中内容';
encryptButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-lock"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'; // 使用 Quill 类似的 SVG 图标结构
// 你可以自定义 SVG 或使用文字
// encryptButton.textContent = 'Enc';
// encryptButton.style.fontWeight = 'bold';
// encryptButton.style.color = 'red'; // 样式最好通过 admin.css 控制
encryptButton.classList.add('ql-jscrypt-encrypt'); // 添加自定义类以便 CSS 控制

encryptButton.onclick = function() { jscrypt_encrypt_quill_selection(quillInstance); };

// --- 创建 解密 (Dec) 按钮 ---
const decryptButton = document.createElement('button');
decryptButton.type = 'button';
decryptButton.title = '解密选中内容';
decryptButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-unlock"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>';
// decryptButton.textContent = 'Dec';
// decryptButton.style.fontWeight = 'bold';
// decryptButton.style.color = 'green';
decryptButton.classList.add('ql-jscrypt-decrypt');

decryptButton.onclick = function() { jscrypt_decrypt_quill_selection(quillInstance); };

// --- 插入按钮到 Quill 工具栏 ---
// Quill 工具栏按钮通常分组在 <span class="ql-formats"> 中
// 我们可以创建一个新的 ql-formats span 来放我们的按钮
const customFormatSpan = document.createElement('span');
customFormatSpan.classList.add('ql-formats');
customFormatSpan.appendChild(encryptButton);
customFormatSpan.appendChild(decryptButton);

quillToolbarElement.appendChild(customFormatSpan); // 将自定义组附加到工具栏

console.log("JSCrypt admin buttons added to Quill toolbar.");
}

// --- 使用 Quill API 的加密函数 ---
function jscrypt_encrypt_quill_selection(quill) {
const range = quill.getSelection(); // 获取 Quill 的选区
if (!range || range.length === 0) {
alert('请先在编辑器中选中需要加密的文本内容！');
return;
}
const selectedText = quill.getText(range.index, range.length);
if (!selectedText) {
alert('选中的内容不能为空！');
return;
}

const password = prompt("请输入加密密码：", "");
if (!password) {
alert("密码不能为空！");
return;
}

try {
const encryptedData = CryptoJS.AES.encrypt(selectedText, password);
const encryptedString = encryptedData.toString();
const replacementText = `[encrypted]${encryptedString}[/encrypted]`;

// 使用 Quill API 替换内容
quill.deleteText(range.index, range.length); // 删除原文
quill.insertText(range.index, replacementText, { 'jscrypt-block': true }); // 插入加密块，可以加个属性方便识别
quill.setSelection(range.index + replacementText.length); // 将光标移到最后
} catch (error) {
console.error("JSCrypt encryption error:", error);
alert("加密时出错，请查看浏览器控制台。");
}
quill.focus();
}

// --- 使用 Quill API 的解密函数 ---
function jscrypt_decrypt_quill_selection(quill) {
const range = quill.getSelection();
if (!range || range.length === 0) {
alert('请先在编辑器中选中需要解密的 [encrypted]...[/encrypted] 内容块！');
return;
}
const selectedText = quill.getText(range.index, range.length).trim();

if (!selectedText.startsWith('[encrypted]') || !selectedText.endsWith('[/encrypted]')) {
alert('选中的内容格式不正确，请确保选中完整的 "[encrypted]...[/encrypted]" 块。');
return;
}
const encryptedString = selectedText.substring('[encrypted]'.length, selectedText.length - '[/encrypted]'.length);
if (!encryptedString) {
alert('加密内容为空！');
return;
}

const password = prompt("请输入解密密码：", "");
if (!password) {
alert("密码不能为空！");
return;
}

try {
const decryptedData = CryptoJS.AES.decrypt(encryptedString, password);
const decryptedText = decryptedData.toString(CryptoJS.enc.Utf8);
if (!decryptedText) {
alert("解密失败！可能是密码错误或内容已损坏。");
return;
}

quill.deleteText(range.index, range.length);
quill.insertText(range.index, decryptedText);
quill.setSelection(range.index + decryptedText.length);
} catch (error) {
console.error("JSCrypt decryption error:", error);
alert("解密时出错，可能是内容格式问题或库错误。请查看浏览器控制台。");
}
quill.focus();
}