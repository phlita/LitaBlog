<!DOCTYPE html>
<html lang="en"> <?php // TODO: Add dynamic lang attribute if available ?>
<head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
<?php
// Generate dynamic title
$page_title = isset($template_data['site_title']) ? e($template_data['site_title']) : 'My Blog';
if (isset($template_data['request_type'])) {
if ($template_data['request_type'] === 'single' && isset($template_data['post']['title'])) {
$page_title = e($template_data['post']['title']) . ' | ' . $page_title;
} elseif (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
$page_title = $template_data['archive_title'] . ' | ' . $page_title;
} elseif ($template_data['request_type'] === '404') {
$page_title = 'Page Not Found | ' . $page_title;
}
// Add other conditions (search, author) if needed
}
echo $page_title;
?>
</title>
<link rel="stylesheet" href="<?php echo isset($template_data['theme_url']) ? e($template_data['theme_url']) : ''; ?>/style.css" />
<?php if (isset($template_data['request_type']) && $template_data['request_type'] === 'single'): ?>
    <link rel="canonical" href="<?php echo Permalink::get_post_link($template_data['post']['id']); ?>" />
<?php endif; ?>
<?php echo do_action('header'); ?>
</head>
<body><div class="container">
<header class="site-header">

<h1 class="site-title">
<a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>"><?php echo e($template_data['site_title']); ?></a>
</h1>

<p class="site-description"><?php echo e($template_data['site_description']); ?></p>


<nav class="main-navigation">
<ul>
<?php foreach ($template_data['nav_menu'] as $menu_item) : ?>
<li><a href="<?php echo isset($menu_item['url']) ? e($menu_item['url']) : '#'; ?>"><?php echo isset($menu_item['name']) ? e($menu_item['name']) : ''; ?></a></li>
<?php endforeach; ?>
</ul>
</nav>

</header>

