<footer class="site-footer">
<?php echo date('Y'); ?> &copy; <?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : 'Your Blog Name'; ?> 

<?php if(isset($template_data['is_admin']) && $template_data['is_admin']): ?>
` <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/">管理</a>
<?php elseif(isset($template_data['is_logged_in']) && $template_data['is_logged_in']): ?>
<?php // Maybe add profile link for non-admin users? ?>
<?php else: ?>
` <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/login.php">登录</a>
<?php endif; ?>

<?php echo do_action('footer'); ?>
</footer>
   <!-- 轻量级返回顶部按钮 -->
    <div id="back-to-top" title="返回顶部">
        <svg viewBox="0 0 24 24" width="20" height="24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="19" x2="12" y2="5"></line>
            <polyline points="5 12 12 5 19 12"></polyline>
        </svg>
    </div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('back-to-top');

    // 监控页面滚动
    window.addEventListener('scroll', function() {
        // 滚动超过一个屏幕高度（约 600 像素）后显示按钮
        if (window.pageYOffset > 1000) {
            btn.classList.add('show');
        } else {
            btn.classList.remove('show');
        }
    });

    // 平滑滚动回顶部
    btn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
</script>	
</div>
<?php echo do_action('wp_footer'); ?>



<?php 
// 权限判断：仅当用户已登录，且拥有发文权限时，才向前端注入这段代码
if (is_logged_in() && current_user_can('publish_posts')): 
?>
<!-- LitaBlog 前台悬浮闪电发文 UI (纯前端防脏数据解析版 + 智能换行修复) -->
<style>
#lita-qp-fab {
position: fixed; bottom: 30px; right: 30px; width: 54px; height: 54px;
background: #4a9f6b; border-radius: 50%; box-shadow: 0 4px 12px rgba(74, 159, 107, 0.3);
display: flex; align-items: center; justify-content: center; cursor: pointer;
z-index: 999998; transition: 0.2s; border: none; outline: none; padding: 0;
}
#lita-qp-fab:hover { transform: scale(1.05); background: #367952; }
#lita-qp-fab:active { transform: scale(0.95); }

#lita-qp-overlay {
position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5);
z-index: 999999; opacity: 0; visibility: hidden; transition: 0.3s;
display: flex; align-items: flex-end; justify-content: center;
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}
#lita-qp-overlay.lita-qp-active { opacity: 1; visibility: visible; }

#lita-qp-modal {
width: 100%; max-width: 600px; background: #fff;
border-radius: 20px 20px 0 0; padding: 20px;
transform: translateY(100%); transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
box-shadow: 0 -10px 40px rgba(0,0,0,0.15);
}
#lita-qp-overlay.lita-qp-active #lita-qp-modal { transform: translateY(0); }

#lita-qp-modal input, #lita-qp-modal textarea {
width: 100%; border: none; outline: none; background: transparent;
color: #333; font-family: inherit; margin: 0; padding: 0;
}
#lita-qp-modal input { font-size: 1.2rem; font-weight: bold; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
#lita-qp-modal input::placeholder { color: #ccc; }
#lita-qp-modal textarea { font-size: 1rem; line-height: 1.6; height: 160px; resize: none; margin-bottom: 15px; }
#lita-qp-modal textarea::placeholder { color: #aaa; }

#lita-qp-actions { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #eee; padding-top: 15px; }

.lita-qp-btn { border: none; padding: 8px 18px; border-radius: 20px; font-size: 0.9rem; font-weight: 500; cursor: pointer; transition: 0.2s; }
.lita-qp-btn-close { background: #f1f3f5; color: #666; }
.lita-qp-btn-submit { background: #4a9f6b; color: white; }
.lita-qp-btn-submit:disabled { background: #a5d8b9; cursor: not-allowed; }

@media (min-width: 768px) {
#lita-qp-overlay { align-items: center; }
#lita-qp-modal { border-radius: 12px; transform: scale(0.9); opacity: 0; }
#lita-qp-overlay.lita-qp-active #lita-qp-modal { transform: scale(1); opacity: 1; }
#lita-qp-fab { bottom: 50px; right: 50px; }
}
    #back-to-top {
        bottom: 100px !important; 
        right: 36px !important;   
    }
    @media (min-width: 768px) {
        #back-to-top {
            bottom: 120px !important; 
            right: 56px !important;   
        }
    }
</style>

<!-- 悬浮按钮 -->
<button id="lita-qp-fab" aria-label="快捷发文">
<svg viewBox="0 0 24 24" width="26" height="26" fill="#fff"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
</button>

<!-- 弹窗遮罩 -->
<div id="lita-qp-overlay">
<div id="lita-qp-modal" onclick="event.stopPropagation();">
<form id="lita-qp-form">
<input type="text" id="lita-qp-title" placeholder="标题 (留空则自动提取正文)" autocomplete="off">
<textarea id="lita-qp-content" placeholder="此刻的想法... (直接敲回车换行)" required></textarea>

<div id="lita-qp-actions">
<span style="font-size: 0.8rem; color: #999;">⚡️ 灵感来了</span>
<div>
<button type="button" class="lita-qp-btn lita-qp-btn-close" id="lita-qp-close">取消</button>
<button type="submit" class="lita-qp-btn lita-qp-btn-submit" id="lita-qp-submit">立即发布</button>
</div>
</div>
</form>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
const fab = document.getElementById('lita-qp-fab');
const overlay = document.getElementById('lita-qp-overlay');
const closeBtn = document.getElementById('lita-qp-close');
const form = document.getElementById('lita-qp-form');
const submitBtn = document.getElementById('lita-qp-submit');
const titleInput = document.getElementById('lita-qp-title');
const contentInput = document.getElementById('lita-qp-content');

const toggleModal = (show) => {
if (show) {
overlay.classList.add('lita-qp-active');
setTimeout(() => contentInput.focus(), 100);
} else {
overlay.classList.remove('lita-qp-active');
}
};

fab.addEventListener('click', () => toggleModal(true));
closeBtn.addEventListener('click', () => toggleModal(false));
overlay.addEventListener('click', () => toggleModal(false));

form.addEventListener('submit', function(e) {
e.preventDefault();

let rawContent = contentInput.value.trim();
let title = titleInput.value.trim();

if (!rawContent) return;
if (!title) {
title = rawContent.replace(/<[^>]+>/g, '').substring(0, 15);
if(rawContent.length > 15) title += '...';
}

submitBtn.disabled = true;
submitBtn.innerText = '发布中...';

/* ========================================================
核心优化：将纯文本智能转换为后端 Quill 兼容的 HTML 格式
这样不依赖 MD 插件，前端渲染也会有完美的段落和换行！
======================================================== */
let htmlContent = rawContent
// 1. 防 XSS，将文本中的 HTML 标签转义
.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
// 2. 以两个或以上的回车作为分割点，划分段落
.split(/\n\n+/)
// 3. 将单回车转为 <br>，并用 <p> 标签包裹每个段落
.map(p => '<p>' + p.replace(/\n/g, '<br>') + '</p>')
.join('');

const formData = new FormData();
formData.append('title', title);
formData.append('content', htmlContent); // 发送处理好的 HTML
formData.append('status', 'publish');
formData.append('item_type', 'post');

fetch('<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : SITE_URL; ?>/admin/content.php?ajax=1', {
method: 'POST',
body: formData,
headers: {
'X-Requested-With': 'XMLHttpRequest'
}
})
.then(res => res.text()) // 兼容脏数据解析
.then(htmlText => {
let data = null;
try {
const jsonStr = htmlText.substring(htmlText.lastIndexOf('{'));
data = JSON.parse(jsonStr);
} catch (err) {
throw new Error("服务端返回异常");
}

if (data && data.success) {
form.reset();
toggleModal(false);
window.location.reload(); 
} else {
alert(data && data.message ? data.message : '发布失败，请检查填写内容。');
}
})
.catch(err => {
alert('发布未完成，请检查网络或刷新页面。');
console.error(err);
})
.finally(() => {
submitBtn.disabled = false;
submitBtn.innerText = '立即发布';
});
});
});
</script>
<?php endif; ?>	


</body></html>