<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
?>
<?php require_once __DIR__ . '/header.php'; // Header uses $template_data ?>

<div class="main-wrapper">
<main class="content-area">
<main class="site-main">
<div class="container">
<?php
// Display archive title if available (for category/tag pages)
if (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
echo '<h1 class="archive-title">' . e($template_data['archive_title']) . '</h1>'; // 使用 e() 转义
} 
?>

<div class="posts-wrapper">
<div class="posts-content"> <?php // Main content area ?>
<?php if (isset($template_data['posts']) && !empty($template_data['posts'])): ?>
<div class="posts-list">
<?php foreach ($template_data['posts'] as $post): // Loop through posts from $template_data ?>
<article class="post" id="post-<?php echo $post['id']; ?>">
<h3 class="post-title">
<a href="<?php echo Permalink::get_post_link($post['id']); ?>">
<?php echo e($post['title']); ?>
</a>
</h3>
<div class="post-meta">
<span class="post-date">
<?php echo $post['formatted_date']; ?>
</span>
</div>
</article>
<?php endforeach; ?>
</div><!-- .posts-list -->
<?php
if (isset($template_data['pagination'])) {
echo $template_data['pagination'];
}
?>
<?php else: // No posts found ?>
<p>暂无更新，敬请期待！</p>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/sidebar.php'; // Sidebar uses $template_data ?>
</div>
</div>
</main>
</main>
</div>
<?php require_once __DIR__ . '/footer.php'; // Footer uses $template_data ?>