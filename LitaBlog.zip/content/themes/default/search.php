<?php 
// content/themes/default/search.php (或在 index.php 中增加判断)
require_once __DIR__ . '/header.php';
?>
<div class="main-wrapper">
    <main class="content-area">
        <main class="site-main">
            <div class="container">
                <header class="archive-header">
                    <h1 class="archive-title">搜索结果： "<?php echo e($template_data['search_query'] ?? ''); ?>"</h1>
                    <?php if (empty($template_data['posts'])): ?>
                        <p>抱歉，没有找到与 "<?php echo e($template_data['search_query'] ?? ''); ?>" 相关的内容。</p>
                    <?php endif; ?>
                </header>

                <?php if (isset($template_data['posts']) && !empty($template_data['posts'])): ?>
                    <div class="posts-list">
                        <?php foreach ($template_data['posts'] as $post_item): // 使用 $post_item 避免与全局 $post 冲突 ?>
                            <article class="post" id="post-<?php echo $post_item['id']; ?>">
                                <h3 class="post-title">
                                    <a href="<?php echo Permalink::get_post_link($post_item['id']); ?>">
                                        <?php echo e($post_item['title']); ?>
                                    </a>
                                </h3>
                                <div class="post-meta">
                                    <span class="post-date">
                                        <?php echo e($post_item['formatted_date'] ?? ''); // 使用格式化后的日期 ?>
                                    </span>
                                    <?php // 可以考虑在这里高亮搜索词 ?>
                                </div>
                                <div class="post-excerpt">
                                    <?php
                                    // 生成摘要并高亮关键词
                                    $excerpt_text = !empty($post_item['excerpt']) ? $post_item['excerpt'] : strip_tags($post_item['content']);
                                    $limit = 150; // 摘要长度
                                    if (mb_strlen($excerpt_text, 'UTF-8') > $limit) {
                                        $excerpt_text = mb_substr($excerpt_text, 0, $limit, 'UTF-8') . '...';
                                    }
                                    // 高亮关键词 (简单实现)
                                    $search_query_for_highlight = $template_data['search_query'] ?? '';
                                    if (!empty($search_query_for_highlight)) {
                                        $excerpt_text = preg_replace(
                                            '/(' . preg_quote(e($search_query_for_highlight), '/') . ')/i',
                                            '<mark>$1</mark>',
                                            e($excerpt_text) // 先转义再高亮
                                        );
                                    } else {
                                        $excerpt_text = e($excerpt_text);
                                    }
                                    echo '<p>' . $excerpt_text . '</p>'; // 输出允许 <mark> 标签
                                    ?>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div><!-- .posts-list -->
                    <?php
                    if (isset($template_data['pagination'])) {
                        echo $template_data['pagination'];
                    }
                    ?>
                <?php endif; ?>
            </div>
        </main>
    </main>
    <?php require_once __DIR__ . '/sidebar.php'; ?>
</div>
<?php
require_once __DIR__ . '/footer.php';