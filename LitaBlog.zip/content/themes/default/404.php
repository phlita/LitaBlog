<?php
/**
 * The template for displaying 404 pages (Not Found).
 */
require_once __DIR__ . '/header.php';
?>
<section class="error-404 not-found">
    <header class="page-header">
        <h1 class="page-title">Oops! That page can’t be found.</h1>
    </header><!-- .page-header -->
    <div class="page-content">
        <p>
            <?php
            echo isset($template_data['error_message']) ? e($template_data['error_message']) : 'It looks like nothing was found at this location. Maybe try one of the links below or a search?';
            ?>
        </p>
        <?php // Optional: Add a search form here if search is implemented ?>
        <?php /* get_search_form(); */ ?>
        <p>Or, return to the <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>">homepage</a>.</p>
    </div><!-- .page-content -->
</section><!-- .error-404 -->
<?php require_once __DIR__ . '/footer.php'; ?>