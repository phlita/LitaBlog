<?php require_once __DIR__ . '/header.php'; ?>

<div class="error-404-content">
    <h1>404</h1>
    <p>没有找到相关记忆或是那一天的日记。</p>
    <p style="margin-top: 20px;">
        <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>">返回主页</a>
    </p>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>