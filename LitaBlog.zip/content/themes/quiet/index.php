<?php require_once __DIR__ . '/header.php'; ?>

<main class="diary-timeline-wrapper">
<?php if (isset($template_data['archive_title']) && !empty($template_data['archive_title'])): ?>
<h2 style="font-family: var(--font-serif); font-size: 1.25rem; font-weight: normal; margin-bottom: 35px; color: var(--color-accent);">
<?php echo e($template_data['archive_title']); ?>
</h2>
<?php endif; ?>

<?php if (isset($template_data['posts']) && !empty($template_data['posts'])): ?>
<div class="diary-rows-container">
<?php 
$last_date = ''; 
foreach ($template_data['posts'] as $post): 
$local_dt = new DateTime($post['iso_datetime']); 
$current_date = $local_dt->format('Y.m.d');
$is_same_day = ($current_date === $last_date);
$last_date = $current_date;
?>

<div class="diary-row-item <?php echo $is_same_day ? 'is-same-day' : 'is-new-day'; ?>">

<div class="diary-meta-date">
<?php if (!$is_same_day): ?>
<span class="date-text"><?php echo $current_date; ?></span>
<?php else: ?>
<!-- 同一天时，渲染一个纯净、无占位干扰的极简标识符 -->
<span class="date-dot-connector"></span>
<?php endif; ?>
</div>

<div class="diary-meta-time">
<?php echo $local_dt->format('H:i'); ?>
</div>

<!-- 自适应的标题列 -->
<div class="diary-title-cell">
<a href="<?php echo Permalink::get_post_link($post['id']); ?>">
<?php echo e($post['title']); ?>
</a>
</div>
</div>
<?php endforeach; ?>
</div>

<?php if (isset($template_data['pagination'])) { echo $template_data['pagination']; } ?>

<?php else: ?>
<p style="text-align: center; color: var(--color-text-muted); padding: 50px 0; font-family: var(--font-serif);">纸张空白。今天有什么想法要写下吗？</p>
<?php endif; ?>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>