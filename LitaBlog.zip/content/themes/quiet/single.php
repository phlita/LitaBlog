<?php require_once __DIR__ . '/header.php'; ?>

<?php if (isset($template_data['post']) && !empty($template_data['post'])): ?>
    <?php $post = $template_data['post']; ?>
    <main class="single-post-content">
        <article>
            <header class="single-post-header">
                <div class="single-post-time">
                    <!-- 全方位视觉突出写下该日记的时间 -->
                 <?php 
    $local_dt = new DateTime($post['iso_datetime']);
    echo $local_dt->format('Y年m月d日 · H点i分'); 
    ?>
                </div>
                <h1 class="single-post-title"><?php echo e($post['title']); ?></h1>
            </header>
            
            <div class="entry-content">
                <?php echo $post['content']; // 渲染日记内容（支持富文本/短代码） ?>
            </div>
        </article>
    </main>

    <!-- 极简设计评论部分 -->
    <?php if (isset($template_data['enable_comments']) && $template_data['enable_comments']): ?>
        <section class="comments-area" id="comments">
            <h3 class="comments-title">
                <?php echo count($template_data['comments']); ?> 个想法
            </h3>
            
            <?php if (!empty($template_data['comments'])): ?>
                <ol class="comment-list">
                    <?php foreach ($template_data['comments'] as $comment): ?>
                        <li class="comment" id="comment-<?php echo $comment['id']; ?>">
                            <div class="comment-meta">
                                <span class="comment-author-name"><?php echo e($comment['author_name']); ?></span>
                                <span class="comment-time"><?php echo date('Y-m-d H:i', strtotime($comment['created'])); ?></span>
                            </div>
                            <div class="comment-content">
                                <p><?php echo nl2br(e($comment['content'])); ?></p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ol>
            <?php endif; ?>

            <div id="respond" class="comment-respond">
                <form action="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/includes/comments.php" method="post" class="comment-form">
                    <p class="logged-in-as" style="margin-bottom: 10px;">
                        <?php if (isset($template_data['is_logged_in']) && $template_data['is_logged_in']): ?>
                            发表想法: <strong><?php echo e($template_data['current_user']['username']); ?></strong>
                        <?php else: ?>
                            发表想法 (匿名):
                        <?php endif; ?>
                    </p>
                    <textarea name="content" rows="4" placeholder="在此写下您的回复..." required></textarea>
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                    <button type="submit" class="submit">提交想法</button>
                </form>
            </div>
        </section>
    <?php endif; ?>

<?php else: ?>
    <p>日记未找到。</p>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>