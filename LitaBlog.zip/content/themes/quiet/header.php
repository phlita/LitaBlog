<?php
// Load theme-specific functions if they exist
if (file_exists(__DIR__ . '/functions.php')) {
    require_once __DIR__ . '/functions.php';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php
        $page_title = isset($template_data['site_title']) ? e($template_data['site_title']) : 'Quiet';
        if (isset($template_data['request_type'])) {
            if ($template_data['request_type'] === 'single' && isset($template_data['post']['title'])) {
                $page_title = e($template_data['post']['title']) . ' - ' . $page_title;
            } elseif (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
                $page_title = e($template_data['archive_title']) . ' - ' . $page_title;
            }
        }
        echo $page_title;
    ?></title>
    <link rel="stylesheet" href="<?php echo e($template_data['theme_url'] ?? ''); ?>/style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <?php do_action('header'); ?>
</head>
<body>
<div class="site-container">
    <header class="site-header">
        <div class="site-title">
            <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>">
                <?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : 'Quiet'; ?>
            </a>
        </div>
        <?php if (isset($template_data['site_description']) && !empty($template_data['site_description'])): ?>
            <p class="site-description"><?php echo e($template_data['site_description']); ?></p>
        <?php endif; ?>

        <!-- 极简菜单模块 -->
        <?php if (isset($template_data['nav_menu']) && is_array($template_data['nav_menu']) && !empty($template_data['nav_menu'])) : ?>
            <nav class="site-navigation">
                <ul>
                    <?php foreach ($template_data['nav_menu'] as $menu_item) : ?>
                        <li><a href="<?php echo isset($menu_item['url']) ? e($menu_item['url']) : '#'; ?>"><?php echo isset($menu_item['name']) ? e($menu_item['name']) : ''; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </header>