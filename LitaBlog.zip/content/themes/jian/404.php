<?php
/**
* The template for displaying 404 pages (Not Found) in Jian theme
* (Jian 主题中用于显示 404 页面未找到的模板)
*/
require_once __DIR__ . '/header.php'; // Include header
require_once __DIR__ . '/sidebar.php'; // Include sidebar (包含侧边栏) ?>
<main class="main-content error-404 not-found" id="main">
<header class="page-header">
<h1 class="page-title">:( 页面丢失了</h1>
</header><!-- .page-header -->
<div class="page-content">
<p>
<?php
// Display custom error message from $template_data if exists, otherwise default
// (如果 $template_data 中存在自定义错误消息则显示，否则显示默认消息)
echo isset($template_data['error_message']) ? e($template_data['error_message']) : '抱歉，您要寻找的页面似乎不在这里。也许您可以尝试返回首页或进行搜索？';
?>
</p>
<?php // Optional: Add a search form here if search functionality is implemented
// (可选：如果实现了搜索功能，在此添加搜索表单)
/*
<form role="search" method="get" class="search-form" action="<?php echo e($template_data['site_url'] ?? '/'); ?>">
<label>
<span class="screen-reader-text">搜索：</span>
<input type="search" class="search-field" placeholder="输入关键词..." value="" name="s" title="搜索：" />
</label>
<input type="submit" class="search-submit" value="搜索" />
</form>
*/
?>
<p style="margin-top: 2em;">
<a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>" class="button">返回首页</a>
<?php // Simple button style (add to style.css if needed) ?>
<style>.button { display: inline-block; padding: 0.6em 1.2em; background: var(--color-button-bg); color: var(--color-button-text); border-radius: var(--border-radius); text-decoration: none; transition: background-color 0.2s ease;} .button:hover{ background: var(--color-button-hover-bg); text-decoration: none;}</style>
</p>
</div><!-- .page-content -->
</main><!-- .main-content -->
<?php // No sidebar needed usually on 404 pages (404 页面通常不需要侧边栏) ?>
<?php require_once __DIR__ . '/footer.php'; // Include footer ?>