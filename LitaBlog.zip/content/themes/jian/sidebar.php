<?php
/**
* The Sidebar for Jian theme containing the main widget area
* (Jian 主题的侧边栏，包含主要小工具区域)
*/
// Check if widgets data exists and is not empty
// (检查小工具数据是否存在且不为空)
if (isset($template_data['widgets']) && is_array($template_data['widgets']) && !empty($template_data['widgets'])) :
?>
<aside class="sidebar" id="secondary">
<?php foreach ($template_data['widgets'] as $widget) : ?>
<section class="widget widget-<?php echo isset($widget['type']) ? e($widget['type']) : 'text'; ?>" id="widget-<?php echo isset($widget['id']) ? $widget['id'] : sanitize_title_with_dashes($widget['title'] ?? 'untitled'); // Generate an ID ?>">
<?php if (isset($widget['title']) && !empty($widget['title'])) : ?>
<h3 class="widget-title"><?php echo e($widget['title']); ?></h3>
<?php endif; ?>
<div class="widget-content">
<?php
$content = isset($widget['content']) ? $widget['content'] : '';
$type = isset($widget['type']) ? $widget['type'] : 'text';
if ($type === 'text') {
echo nl2br(e($content)); // Escape text content and add line breaks (转义文本内容并添加换行)
} elseif ($type === 'html') {
echo $content; // Output HTML content directly (assumed safe) (直接输出HTML内容 - 假设是安全的)
} else {
// Handle potential future widget types here (在此处理未来可能的小工具类型)
// Maybe execute a function based on type? (或许根据类型执行一个函数？)
// Example: if ($type === 'recent_posts') { display_recent_posts_widget($content); }
echo e($content); // Default to escaped text (默认使用转义文本)
}
?>
</div><!-- .widget-content -->
</section><!-- .widget -->
<?php endforeach; ?>
</aside><!-- .sidebar -->
<?php
// Optional: Add a placeholder or message if no widgets are configured
// (可选：如果没有配置小工具，添加占位符或消息)
// else:
// echo '<aside class="sidebar" id="secondary"><p>侧边栏没有内容。</p></aside>';
endif;
?>
<?php
// Helper function to generate widget ID (if needed and not already provided)
// (辅助函数，用于生成小工具ID（如果需要且未提供）)
if (!function_exists('sanitize_title_with_dashes')) {
function sanitize_title_with_dashes($title) {
$title = strip_tags($title);
// Preserve escaped octets.
$title = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '---$1---', $title);
// Remove percent signs that are not part of an octet.
$title = str_replace('%', '', $title);
// Restore octets.
$title = preg_replace('|---([a-fA-F0-9][a-fA-F0-9])---|', '%$1', $title);
if (function_exists('transliterator_transliterate')) {
$title = transliterator_transliterate('Any-Latin; Latin-ASCII', $title);
}
$title = strtolower($title);
$title = preg_replace('/&.+?;/', '', $title); // kill entities
$title = preg_replace('/[^%a-z0-9 _-]/', '', $title);
$title = preg_replace('/\s+/', '-', $title);
$title = preg_replace('|-+|', '-', $title);
$title = trim($title, '-');
return $title;
}
}
?>