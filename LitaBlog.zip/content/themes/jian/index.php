<?php
/**
* The main template file for Jian theme (Index and Archives)
* (Jian 主题的主模板文件 - 首页和归档页)
*/
require_once __DIR__ . '/header.php'; // Include header (包含页眉)
// Get date format once to avoid calling get_option in loop (获取一次日期格式，避免在循环中调用 get_option)
$date_format = get_option('date_format', 'Y年m月d日');
?>
<?php require_once __DIR__ . '/sidebar.php'; // Include sidebar (包含侧边栏) ?>
<main class="main-content" id="main">
<?php
// Display archive title if available (for category/tag pages)
// (如果可用，显示归档标题 - 用于分类/标签页)
if (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
echo '<header class="archive-header"><h1 class="archive-title">' . e($template_data['archive_title']) . '</h1></header>';
}
?>
<?php
// Check if posts array exists and is not empty
// (检查文章数组是否存在且不为空)
if (isset($template_data['posts']) && is_array($template_data['posts']) && !empty($template_data['posts'])):
?>
<div class="posts-list">
<?php foreach ($template_data['posts'] as $post): // Loop through posts (循环文章) ?>
<article class="post-item" id="post-<?php echo $post['id']; ?>">
<header class="post-header">
<h2 class="post-title">
<a href="<?php echo Permalink::get_post_link($post['id']); ?>">
<?php echo e($post['title']); ?>
</a>
</h2>
<div class="post-meta">
<span class="post-date">
<time datetime="<?php echo date('c', strtotime($post['created'])); ?>">
<?php echo e($post['formatted_date']); ?>
</time>
</span>

<?php // Display categories if available (如果分类信息可用则显示)
if(isset($post['categories']) && !empty($post['categories'])): ?>
<span class="post-categories">
分类 / <?php $cat_links = []; foreach ($post['categories'] as $cat): ?>
<?php $cat_links[] = '<a href="' . e($template_data['site_url'] ?? '') . '/?category=' . urlencode($cat['slug']) . '">' . e($cat['name']) . '</a>'; ?>
<?php endforeach; echo implode(', ', $cat_links); ?>
</span>
<?php endif; ?>
</div><!-- .post-meta -->
</header>

</article><!-- .post-item -->
<?php endforeach; ?>
</div><!-- .posts-list -->
<?php
// Display pagination if available (如果分页信息可用则显示)
if (isset($template_data['pagination']) && !empty($template_data['pagination'])) {
echo '<nav class="pagination">';
// Assuming $template_data['pagination'] contains the full HTML string
// (假设 $template_data['pagination'] 包含完整的 HTML 字符串)
echo $template_data['pagination'];
echo '</nav>';
}
?>
<?php else: // No posts found (未找到文章) ?>
<div class="no-posts-found">
<p>这里空空如也，似乎还没有内容发布呢！</p>
<?php // Maybe add a search form link or homepage link here (或许在这里添加搜索表单链接或首页链接) ?>
</div>
<?php endif; ?>
</main><!-- .main-content -->

<?php require_once __DIR__ . '/footer.php'; // Include footer (包含页脚) ?>