<?php
/**
* Theme Header for Jian
* (Jian 主题的页眉文件)
*/
?>
<!DOCTYPE html>
<html lang="zh-CN"> <?php // TODO: Add dynamic lang attribute if possible (添加动态语言属性) ?>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
<?php
// Generate dynamic title (生成动态标题)
$page_title = isset($template_data['site_title']) ? e($template_data['site_title']) : '简博客';
if (isset($template_data['request_type'])) {
if ($template_data['request_type'] === 'single' && isset($template_data['post']['title'])) {
$page_title = e($template_data['post']['title']) . ' - ' . $page_title;
} elseif (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
$page_title = e($template_data['archive_title']) . ' - ' . $page_title;
} elseif ($template_data['request_type'] === '404') {
$page_title = '页面未找到 - ' . $page_title;
}
// Add other conditions (search, author etc.) if needed (如果需要，添加其他条件)
}
echo $page_title;
?>
</title>
<link rel="stylesheet" href="<?php echo isset($template_data['theme_url']) ? e($template_data['theme_url']) : ''; ?>/style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); // Basic cache busting (基本缓存清除) ?>">
<?php // Add hook for plugins to add header content (插件添加头部内容的钩子) ?>
<?php do_action('header'); 
wp_print_head_scripts_and_styles();
?>
</head>
<body class="<?php echo isset($template_data['request_type']) ? 'page-type-' . e($template_data['request_type']) : ''; ?>"> <?php // Add body class based on request type (根据请求类型添加 body class) ?>
<div class="site-container">
<header class="site-header">
<div class="header-inner">
<div class="site-branding">
<?php if (isset($template_data['site_title']) && !empty($template_data['site_title'])) : ?>
<?php // Use H1 only on homepage for SEO, otherwise use a paragraph (仅在首页使用 H1 以优化 SEO，其他页面使用段落) ?>
<?php if (isset($template_data['request_type']) && $template_data['request_type'] === 'home'): ?>
<h1 class="site-title"><a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>"><?php echo e($template_data['site_title']); ?></a></h1>
<?php else: ?>
<p class="site-title"><a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>"><?php echo e($template_data['site_title']); ?></a></p>
<?php endif; ?>
<?php endif; ?>
<?php if (isset($template_data['site_description']) && !empty($template_data['site_description'])) : ?>
<p class="site-description"><?php echo e($template_data['site_description']); ?></p>
<?php endif; ?>
</div><!-- .site-branding -->
<?php if (isset($template_data['nav_menu']) && is_array($template_data['nav_menu']) && !empty($template_data['nav_menu'])) : ?>
<nav class="main-navigation">
<ul>
<?php foreach ($template_data['nav_menu'] as $menu_item) : ?>
<li><a href="<?php echo isset($menu_item['url']) ? e($menu_item['url']) : '#'; ?>"><?php echo isset($menu_item['name']) ? e($menu_item['name']) : ''; ?></a></li>
<?php endforeach; ?>
</ul>
</nav><!-- .main-navigation -->
<?php endif; ?>
</div><!-- .header-inner -->
</header><!-- .site-header -->
<div class="site-content-wrapper">
<?php // Main content and sidebar will go in here (主内容和侧边栏将放在这里) ?>