<?php require_once __DIR__ . '/header.php'; ?>

<main class="main-content">
    <?php if (isset($template_data['archive_title']) && !empty($template_data['archive_title'])): ?>
        <h2 style="font-family: var(--font-serif); font-size: 1.25rem; font-weight: normal; margin-bottom: 2rem; color: var(--accent-color);">
            <?php echo e($template_data['archive_title']); ?>
        </h2>
    <?php endif; ?>

    <?php if (isset($template_data['posts']) && !empty($template_data['posts'])): ?>
        <div class="timeline-container">
            <?php 
            $last_date = ''; 
            $group_opened = false;

            foreach ($template_data['posts'] as $post): 
                $local_dt = new DateTime($post['iso_datetime']); 
                $current_date = $local_dt->format('Y年m月d日');
                $is_same_day = ($current_date === $last_date);

                if (!$is_same_day) {
                    if ($group_opened) {
                        echo '</div>'; // 关闭前一个天的群组
                    }
                    $last_date = $current_date;
                    $group_opened = true;
                    // 输出新的一天的卡片头部
                    echo '<div class="day-group">';
                    echo '<div class="day-header">' . e($current_date) . '</div>';
                }
            ?>
                <div class="timeline-item">
                    <div class="item-time">
                        <?php echo $local_dt->format('H:i'); ?>
                    </div>
                    <div class="item-title">
                        <a href="<?php echo Permalink::get_post_link($post['id']); ?>">
                            <?php echo e($post['title']); ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if ($group_opened) { echo '</div>'; } // 闭合最后一个群组 ?>
        </div>

        <?php if (isset($template_data['pagination'])) { echo $template_data['pagination']; } ?>

    <?php else: ?>
        <p style="text-align: center; color: var(--text-muted); padding: 4rem 0; font-family: var(--font-serif);">
            <?php echo ($template_data['request_type'] === 'search') ? '未找到匹配的日志记忆。' : '纸张空白，暂无更新。'; ?>
        </p>
    <?php endif; ?>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>