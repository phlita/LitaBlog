<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php
        $page_title = isset($template_data['site_title']) ? e($template_data['site_title']) : 'Blog';
        if (isset($template_data['request_type'])) {
            if (($template_data['request_type'] === 'single' || $template_data['request_type'] === 'page') && isset($template_data['post']['title'])) {
                $page_title = e($template_data['post']['title']) . ' - ' . $page_title;
            } elseif (isset($template_data['archive_title']) && !empty($template_data['archive_title'])) {
                $page_title = e($template_data['archive_title']) . ' - ' . $page_title;
            } elseif ($template_data['request_type'] === '404') {
                $page_title = '404 - ' . $page_title;
            }
        }
        echo $page_title;
    ?></title>
    <link rel="stylesheet" href="<?php echo isset($template_data['theme_url']) ? e($template_data['theme_url']) : ''; ?>/style.css?v=1.0">
    <?php echo do_action('header'); ?>
</head>
<body>
<div class="site-container">

    <header class="site-header">
        <h1 class="site-title">
            <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>">
                <?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : 'Zenith'; ?>
            </a>
        </h1>
        <?php if (!empty($template_data['site_description'])): ?>
            <p class="site-description"><?php echo e($template_data['site_description']); ?></p>
        <?php endif; ?>

        <?php if (!empty($template_data['nav_menu'])): ?>
            <nav class="main-navigation">
                <ul>
                    <?php foreach ($template_data['nav_menu'] as $menu_item) : ?>
                        <li><a href="<?php echo isset($menu_item['url']) ? e($menu_item['url']) : '#'; ?>"><?php echo isset($menu_item['name']) ? e($menu_item['name']) : ''; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </header>