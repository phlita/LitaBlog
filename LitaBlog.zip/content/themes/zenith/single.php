<?php require_once __DIR__ . '/header.php'; ?>

<?php if (isset($template_data['post']) && !empty($template_data['post'])): ?>
    <?php $post = $template_data['post']; ?>
    <main class="main-content">
        <article class="single-post">
            <header class="single-post-header">
                <h1 class="single-post-title"><?php echo e($post['title']); ?></h1>
                <?php if ($template_data['request_type'] !== 'page'): ?>
                    <div class="single-post-meta">
                        发布于 <?php echo e($post['formatted_datetime']); ?>
                    </div>
                <?php endif; ?>
            </header>
            
            <div class="entry-content">
                <?php echo $post['content']; ?>
            </div>
            
            <?php if ($template_data['request_type'] !== 'page'): ?>
                <div style="margin-top: 3rem;">
                    <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>" style="font-size: 0.85rem; color: var(--text-muted); border:none;">
                        &larr; 返回时间线
                    </a>
                </div>
            <?php endif; ?>
        </article>
    </main>

    <!-- 极简评论系统 -->
    <?php if (isset($template_data['enable_comments']) && $template_data['enable_comments']): ?>
        <section class="comments-area" id="comments">
            <h3 class="comments-title">
                <span class="comment-count"><?php echo count($template_data['comments']); ?></span> 个想法
            </h3>
            
            <ol class="comment-list">
                <?php if (!empty($template_data['comments'])): ?>
                    <?php foreach ($template_data['comments'] as $comment): ?>
                        <li class="comment" id="comment-<?php echo $comment['id']; ?>">
                            <div class="comment-meta">
                                <span class="comment-author-name"><?php echo e($comment['author_name']); ?></span>
                                <div>
                                    <span class="comment-time"><?php echo e($comment['formatted_datetime']); ?></span>
                                    <?php if ($template_data['is_admin']): ?>
                                        <a href="#" class="delete-comment" data-comment-id="<?php echo $comment['id']; ?>" style="color: var(--accent-color); margin-left: 8px; border:none; font-size:0.75rem;">删除</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="comment-content">
                                <p><?php echo nl2br(e($comment['content'])); ?></p>
                            </div>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ol>

            <div id="respond" class="comment-respond">
                <form action="<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>" method="post" id="commentform" class="comment-form">
                    <p class="logged-in-as" style="font-size:0.85rem; margin-bottom: 0.8rem;">
                        <?php if ($template_data['is_logged_in'] && isset($template_data['current_user'])) : ?>
                            发表想法: <strong><?php echo e($template_data['current_user']['username']); ?></strong>
                        <?php else : ?>
                            发表想法 (匿名):
                        <?php endif; ?>
                    </p>
                    <textarea id="comment" name="content" rows="4" placeholder="写下您的共鸣或想法..." required></textarea>
                    
                    <p class="form-submit">
                        <input name="submit" type="submit" id="submit" class="submit" value="提交想法">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>" id="comment_post_ID">
                        <?php if (function_exists('csrf_token_field')) echo csrf_token_field(); ?>
                    </p>
                    <div id="comment-status" style="display: none; margin-top: 10px; font-size: 0.85rem; color: var(--text-muted);">
                        正在递交中，请稍候...
                    </div>
                </form>
            </div>
        </section>

        <!-- AJAX 评论交互驱动 -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const commentForm = document.getElementById('commentform');
            if (commentForm) {
                commentForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const statusDiv = document.getElementById('comment-status');
                    const submitBtn = document.getElementById('submit');

                    statusDiv.style.display = 'block';
                    submitBtn.disabled = true;
                    submitBtn.value = '提交中...';

                    const formData = new FormData(commentForm);
                    const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

                    fetch(commentUrl, {
                        method: 'POST',
                        body: formData,
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    })
                    .then(response => {
                        if (!response.ok) { throw new Error('网络响应异常'); }
                        return response.json();
                    })
                    .then(data => {
                        statusDiv.style.display = 'none';
                        submitBtn.disabled = false;
                        submitBtn.value = '提交想法';

                        if (data.success) {
                            const contentVal = document.getElementById('comment').value;
                            document.getElementById('comment').value = '';

                            let authorName = 'Anonymous';
                            <?php if ($template_data['is_logged_in'] && isset($template_data['current_user'])) : ?>
                                authorName = '<?php echo e($template_data['current_user']['username']); ?>';
                            <?php endif; ?>

                            const now = new Date();
                            const formattedDate = now.getFullYear() + '-' + ('0' + (now.getMonth() + 1)).slice(-2) + '-' + ('0' + now.getDate()).slice(-2) + ' ' + ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2);

                            const newCommentHtml = `
                                <li class="comment new-comment" style="animation: highlight 2.5s ease;">
                                    <div class="comment-meta">
                                        <span class="comment-author-name">\${escapeHtml(authorName)}</span>
                                        <span class="comment-time">\${formattedDate}</span>
                                    </div>
                                    <div class="comment-content">
                                        <p>\${escapeHtml(contentVal).replace(/\\n/g, '<br>')}</p>
                                    </div>
                                </li>
                            `;

                            const commentList = document.querySelector('.comment-list');
                            if (commentList) {
                                commentList.insertAdjacentHTML('beforeend', newCommentHtml);
                                const countEl = document.querySelector('.comment-count');
                                if (countEl) {
                                    countEl.textContent = parseInt(countEl.textContent, 10) + 1;
                                }
                                document.querySelector('.new-comment').scrollIntoView({ behavior: 'smooth', block: 'center' });
                            }
                        } else {
                            alert(data.error || '想法递交失败');
                        }
                    })
                    .catch(error => {
                        statusDiv.style.display = 'none';
                        submitBtn.disabled = false;
                        submitBtn.value = '提交想法';
                        alert('网络错误，请稍后重试');
                    });
                });
            }

            // 处理后台管理员删除评论
            document.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('delete-comment')) {
                    e.preventDefault();
                    if (confirm('确定要删除这条想法吗？')) {
                        const commentId = e.target.getAttribute('data-comment-id');
                        const commentElement = document.getElementById('comment-' + commentId);

                        const formData = new FormData();
                        formData.append('action', 'delete');
                        formData.append('comment_id', commentId);

                        const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

                        fetch(commentUrl, {
                            method: 'POST',
                            body: formData,
                            headers: { 'X-Requested-With': 'XMLHttpRequest' }
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                if (commentElement) {
                                    commentElement.style.opacity = '0';
                                    setTimeout(() => {
                                        commentElement.remove();
                                        const countEl = document.querySelector('.comment-count');
                                        if (countEl) {
                                            countEl.textContent = Math.max(0, parseInt(countEl.textContent, 10) - 1);
                                        }
                                    }, 300);
                                }
                            } else {
                                alert(data.error || '删除失败');
                            }
                        });
                    }
                }
            });

            function escapeHtml(text) {
                const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
                return text.replace(/[&<>"']/g, m => map[m]);
            }
        });
        </script>
        <style>
        @keyframes highlight {
            0% { background-color: rgba(22, 163, 74, 0.1); }
            100% { background-color: transparent; }
        }
        </style>
    <?php endif; ?>

<?php else: ?>
    <main class="main-content">
        <p style="text-align: center; padding: 4rem 0;">未找到相关页面。</p>
    </main>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>