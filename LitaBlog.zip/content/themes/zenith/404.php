<?php require_once __DIR__ . '/header.php'; ?>

<main role="main" style="text-align: center; padding: 6rem 0;" class="main-content">
    <h1 style="font-family: var(--font-serif); font-size: 3rem; font-weight: normal; margin-bottom: 1rem; color: var(--accent-color);">404</h1>
    <p style="color: var(--text-muted); margin-bottom: 2rem; font-family: var(--font-serif);">没有找到你需要的记忆或记录。</p>
    <p>
        <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>" style="font-size: 0.9rem;">
            回到起点
        </a>
    </p>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>