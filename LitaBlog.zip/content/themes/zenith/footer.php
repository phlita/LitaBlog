<footer class="site-footer">
<p><?php echo date('Y'); ?> &copy;  <?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : ''; ?>
			<?php if(isset($template_data['is_admin']) && $template_data['is_admin']): ?>
· <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/">管理</a>
<?php elseif(isset($template_data['is_logged_in']) && $template_data['is_logged_in']): ?>
<?php // Maybe add profile link for non-admin users? ?>
<?php else: ?>
· <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/login.php">登录</a>
<?php endif; ?>

</p>
<p style="font-size:0.75rem; margin-top:5px; opacity:0.6;">Powered by LitaBlog</p>
</footer>

    <!-- 轻量级返回顶部按钮 -->
    <div id="back-to-top" title="返回顶部">
        <svg viewBox="0 0 24 24" width="20" height="24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="19" x2="12" y2="5"></line>
            <polyline points="5 12 12 5 19 12"></polyline>
        </svg>
    </div>

</div> <!-- .site-container -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('back-to-top');

    // 监控页面滚动
    window.addEventListener('scroll', function() {
        // 滚动超过一个屏幕高度（约 600 像素）后显示按钮
        if (window.pageYOffset > 4000) {
            btn.classList.add('show');
        } else {
            btn.classList.remove('show');
        }
    });

    // 平滑滚动回顶部
    btn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});
</script>

<?php echo do_action('footer'); ?>
<?php echo do_action('wp_footer'); ?>
</body>
</html>