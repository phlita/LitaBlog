<?php require_once __DIR__ . '/header.php'; ?>

<main role="main" style="text-align: center; padding: 4rem 0;" class="main-content">
    <h1 style="font-size: 2rem; margin-bottom: 1rem;">404</h1>
    <p style="color: var(--color-text-muted); margin-bottom: 2rem;">未找到相关更新记录或页面。</p>
    <p>
        <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>" style="font-size: 0.9rem;">
            返回首页列表
        </a>
    </p>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>