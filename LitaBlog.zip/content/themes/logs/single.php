<?php require_once __DIR__ . '/header.php'; ?>

<main role="main" class="main-content">
    <?php if (isset($template_data['post']) && !empty($template_data['post'])) : ?>
        <?php $post = $template_data['post']; ?>
        
        <article class="single-post">
            <header class="single-post-header">
                <h1 class="single-post-title"><?php echo e($post['title']); ?></h1>
                <div class="single-post-date">发布于 <?php echo e($post['formatted_date']); ?></div>
            </header>
<button type="button" class="lita-pdf-btn" onclick="window.print();">
    <svg viewBox="0 0 24 24" width="16" height="16" style="fill:currentColor; margin-right:6px; vertical-align:middle;">
        <path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/>
    </svg>
    保存为 PDF
</button>
            <div class="entry-content">
                <?php echo $post['content']; ?>
            </div>
            
            <div style="margin-top: 3rem;">
                <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : '/'; ?>" style="font-size: 0.85rem; color: var(--color-text-muted);">
                    &larr; 返回更新列表
                </a>
            </div>
        </article>

    <?php else: ?>
        <p>日志不存在或已被删除。</p>
    <?php endif; ?>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>