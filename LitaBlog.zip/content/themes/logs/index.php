<?php require_once __DIR__ . '/header.php'; ?>

<main role="main" class="main-content">
<?php if (isset($template_data['posts']) && !empty($template_data['posts'])): ?>

<div class="changelog-list">
<?php 
$last_date = ''; 
foreach ($template_data['posts'] as $post): 
$local_dt = new DateTime($post['iso_datetime']); 
$current_date = $local_dt->format('Y.m.d');
$is_same_day = ($current_date === $last_date);
$last_date = $current_date;
?>
<div class="changelog-row <?php echo $is_same_day ? 'is-same-day' : 'is-new-day'; ?>">


<div class="changelog-time">
<?php if (!$is_same_day): ?>
<?php echo $current_date; ?>
<?php else: ?>
<!-- 同天显示占位符保持对齐 -->
<span style="opacity:0;"><?php echo $current_date; ?></span>
<?php endif; ?>
</div>


<div class="changelog-time">
<?php echo $local_dt->format('H:i'); ?>
</div>


<div class="changelog-title">
<a class="changelog-title-link" href="<?php echo Permalink::get_post_link($post['id']); ?>">
<?php echo e($post['title']); ?>
</a>
</div>
</div>
<?php endforeach; ?>
</div>

<?php
if (isset($template_data['pagination'])) {
echo $template_data['pagination'];
}
?>
<?php else: ?>
<p style="color: var(--color-text-muted);">暂无更新记录。</p>
<?php endif; ?>
</main>

<?php require_once __DIR__ . '/footer.php'; ?>