<?php
define('DOING_AJAX', true); // Define a constant to indicate an AJAX request

// 1. Load Core Environment
// These paths assume ajax.php is in the root. Adjust if placed elsewhere.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/load.php'; // This should start session, load DB, functions, plugins

// Helper functions for JSON responses (add to functions.php or keep here)
if (!function_exists('wp_send_json_success')) {
function wp_send_json_success($data = null, $status_code = null) {
$response = ['success' => true];
if (isset($data)) {
$response['data'] = $data;
}
if (null !== $status_code) {
http_response_code($status_code);
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
exit; // Important to stop further execution
}
}
if (!function_exists('wp_send_json_error')) {
function wp_send_json_error($data = null, $status_code = null) {
$response = ['success' => false];
if (isset($data)) {
// If $data is a string, wrap it in a 'message' key for consistency
if (is_string($data)) {
$response['data'] = ['message' => $data];
} else {
$response['data'] = $data;
}
}
if (null !== $status_code) {
http_response_code($status_code);
} else {
// Default to 500 if an error occurred but no specific code was given,
// unless success is explicitly false and data implies a client error (like 400 for validation)
if (!isset($response['data']['code']) || $response['data']['code'] < 400 || $response['data']['code'] >= 500) {
// http_response_code(500); // Commented out, let handler decide or default to 200 with error payload
}
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
exit; // Important
}
}
if (!function_exists('has_action')) {
function has_action($hook_name, $callback_to_check = false) {
global $wp_actions; // Assuming $wp_actions is your global array for actions
if (!isset($wp_actions[$hook_name])) {
return false;
}
if (false === $callback_to_check) {
return true; // Action hook exists
}
// Check for specific callback (more complex, might not be needed for basic AJAX handler)
// This would involve iterating through priorities and callbacks in $wp_actions[$hook_name]
return true; // Simplified for now: if hook_name exists, assume it's usable
}
}



// 2. Basic Security and Action Check
if (empty($_REQUEST['action'])) {
wp_send_json_error(['message' => 'No action specified.'], 400); // Bad Request
}
$action = sanitize_text_field($_REQUEST['action']); // Sanitize the action name

// 3. CSRF Token Verification (for POST requests or critical GET requests)
// It's good practice to require CSRF for most AJAX actions changing state.
// For GET requests that only fetch data, CSRF might be optional but consider other security.
$perform_csrf_check = true; // Default to true
// Example: Allow some GET actions without CSRF if they are public data fetches
// $public_get_actions = ['get_public_stats'];
// if ($_SERVER['REQUEST_METHOD'] === 'GET' && in_array($action, $public_get_actions)) {
//    $perform_csrf_check = false;
// }

if ($perform_csrf_check) {
$csrf_token = $_REQUEST['_ajax_csrf_token'] ?? ''; // Expect token in _ajax_csrf_token
if (!verifyCsrfToken($csrf_token, $action, true)) { // Action-specific nonce, one-time use
wp_send_json_error(['message' => 'Security check failed (CSRF). Please refresh and try again.'], 403); // Forbidden
}
}


// 4. Execute Hooks
// Hooks for logged-in users: "wp_ajax_{$action}"
// Hooks for non-logged-in users: "wp_ajax_nopriv_{$action}"

$hook_to_fire = 'wp_ajax_' . $action;
if (!is_logged_in() && has_action('wp_ajax_nopriv_' . $action)) { // has_action is a helper needed
$hook_to_fire = 'wp_ajax_nopriv_' . $action;
} elseif (!is_logged_in()) {
// If only logged-in action exists and user is not logged in
wp_send_json_error(['message' => 'You must be logged in to perform this action.'], 403);
} elseif (!has_action($hook_to_fire)) {
wp_send_json_error(['message' => 'Specified AJAX action not found.'], 404); // Not Found
}

// Fire the action
// The hooked function is expected to call wp_send_json_success() or wp_send_json_error() and then die().
do_action($hook_to_fire);

// If the hook didn't call wp_die or exit, send a generic error.
wp_send_json_error(['message' => 'AJAX handler did not complete correctly.'], 500); // Internal Server Error



// --- END OF FILE ajax.php --- ?>