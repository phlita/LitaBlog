<?php
/**
* Front-end entry point (Simplified)
*/

// 1. Check installation status
if (!file_exists(dirname(__FILE__) . '/config.php')) {
if (!headers_sent()) {
header('Location: admin/install.php');
} else {
exit('Blog not installed. Please run install.php');
}
exit;
}

// 2. Bootstrap (loads config, functions including prepare_template_data(), classes, db, plugins)
require_once dirname(__FILE__) . '/includes/load.php';

// 3. Initialize Router and get results
$router = new Router();

$request_type = $router->get_request_type();
$template_file_name = $router->get_template();
$main_object = $router->get_main_object();
// --- 插入这里的调试代码 ---
 //var_dump($request_type, $template_file_name, $main_object);

// --- 结束调试代码 ---
// 4. "Load" / Prepare data for the template by calling the helper function
//    This step now feels more like "loading" specific data based on the route.
$template_data = prepare_template_data($request_type, $main_object);

// 4.1. Handle potential 404 override from prepare_template_data
//      If prepare_template_data determined it's a 404 (e.g., post not found),
//      update the template file name accordingly.
if ($template_data['request_type'] === '404' && $template_file_name !== '404.php') {
$template_file_name = '404.php';
// Ensure 404 header is set (prepare_template_data already tried, but good to double check)
if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
}


// 5. Determine full theme file path
$theme_name = get_option('current_theme', 'default');
$theme_file = ABSPATH . '/content/themes/' . $theme_name . '/' . $template_file_name;

// 在 index.php
$template_data = apply_filters('before_render_template_data', $template_data, $template_file_name);
do_action('before_render_template_action', $template_file_name, $template_data); // 如果还需要纯动作
//do_action('before_render_template', $template_file_name, $template_data);
// 6. Load theme template (the $template_data array is available inside)
if (file_exists($theme_file)) {
require_once $theme_file;
} else {
// Fallback logic (same as before)
if ($template_file_name === '404.php') {
die('Error: 404 template not found in theme "' . htmlspecialchars($theme_name) . '".');
} else {
$fallback_template = ABSPATH . '/content/themes/' . $theme_name . '/index.php';
if(file_exists($fallback_template)) {
require_once $fallback_template; // $template_data is still available here
} else {
die('Error: Required template "' . htmlspecialchars($template_file_name) . '" and fallback "index.php" not found in theme "' . htmlspecialchars($theme_name) . '".');
}
}
}