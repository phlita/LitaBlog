<?php
/**
* Front-end entry point (Simplified)
*/
// A-7 修复：错误显示改为"调试模式才开启"，避免生产环境泄露路径/SQL/配置。
// ⚠️ 调试开关已统一（2026-09-16）：全站唯一开关 = **config.php 里的 DEBUG**
//   （旧注释写的 LITABLOG_DEBUG 全站从未被定义过 ✗、已废弃；includes/load.php 里保留了兼容映射）。
// 此处 config.php 还没加载，**读不到 DEBUG**，所以这一行只能设"生产默认值"（fail-safe 先关回显）；
// 真正的判定在 includes/load.php（那时 config 已加载，DEBUG=true 才会把回显打开）。
ini_set('display_errors', '0');
error_reporting(E_ALL);   // 仍上报到日志便于排障；是否回显由上一行 + load.php 决定

// P1-A:前台入口收窄内存上限(只降不升到 128M)。
// 共享主机 RAM 账本 = memory_limit × 并发 PHP 进程;若 php.ini 默认 256/512M,
// 高并发时单请求即可吃满整个配额。前台无大内存场景(造数 1024M 仅在 test001.php 独立入口)。
// 仅当上限高于 128M 才降低,绝不超过主机默认(避免违反主机限制)。
$ml = trim((string)ini_get('memory_limit'));
if ($ml !== '' && $ml !== '-1' && stripos($ml, 'G') === false) {
    $ml_num = (int)$ml;
    if (strtoupper(substr($ml, -1)) === 'M' && $ml_num > 128) {
        @ini_set('memory_limit', '128M');
    }
}
unset($ml, $ml_num);

// C-1 / C-2 修复：静态资源拦截层。
// 阻止通过 Web 直接访问敏感目录/文件（数据库、上传目录、备份、日志等），
// 这些目录此前仅靠 .htaccess 保护（仅 Apache 有效，nginx/IIS/PHP 内置服务器完全忽略），
// 导致 content/database/blog.db（密码哈希/密钥）与 content/uploads/* 可被任意下载。
(function () {
    $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    if ($path === null || $path === false) $path = $uri;
    $path = rawurldecode($path);
    $lower = strtolower($path);

    // 1) 禁止访问的目录前缀
    $deny_dirs = [
        '/content/database/',        // C-1：SQLite 数据库（密码哈希/密钥）
        '/content/uploads/cloud/',   // C-2：网盘文件（cloud-drive 插件的 direct_url 会绕过密码保护，
                                     //      必须禁止直链访问，强制走 ?cloud_download=ID&token=xxx 鉴权路由）
                                     //      注意：只禁 cloud/ 子目录，避免误伤 uploads 下的公开资源
                                     //      （文章配图、头像等应保持可访问）
        '/includes/',                // 核心代码目录
        '/admin/views/',             // 后台视图模板
        '/content/cache/',           // 整页缓存 HTML（2026-09-13 实测可被匿名列举）
                                     //   注意：本层只在请求进到 index.php 时才生效；
                                     //   content/cache 是真实目录，Apache 会直接出目录列表，
                                     //   因此真正的拦截靠 content/cache/.htaccess（已随安装器创建），
                                     //   这里只是给 nginx/IIS/PHP 内置服务器补一层。
    ];
    foreach ($deny_dirs as $dir) {
        if (strpos($lower, $dir) === 0) {
            http_response_code(403);
            exit('403 Forbidden');
        }
    }

    // 2) 禁止访问的敏感文件后缀（含备份/数据库/日志）
    if (preg_match('/\.(db|sql|sqlite|sqlite3|bak|old|swp|log|ini|conf|env)$/i', $lower)) {
        http_response_code(403);
        exit('403 Forbidden');
    }

    // 3) 404 快速短路（P0-1）：带扩展名的疑似静态文件 → 立即 404。
    //    防垃圾路径扫描器/坏链接每个请求都烧全套 PHP 渲染（Entry/CPU 账本）。
    //    豁免（2026-09-09，与固定链接功能对齐）：①前台入口自身 /index.php；
    //    ②数字/文章式伪静态形态（mod_rewrite 重写进本文件时 REQUEST_URI 仍保留
    //      /1.html 原始形态，不豁免会与固定链接直接冲突）。豁免路径交 Router 判定
    //    真实 200/404（越界文章 ~4ms 全栈 404，不缓存，有界可接受）。
    //    其余真实存在的静态资源仍由 Apache 直出，PHP 不会走到这里。
    $is_permalink_shape = preg_match('#^/\d{1,6}\.html$#', $path) || preg_match('#^/post/\d{1,6}$#', $path);
    if (!$is_permalink_shape && $path !== '/index.php'
        && preg_match('/\.(php5?|php7|html?|htm|css|js|mjs|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|eot|txt|xml|pdf|zip)$/i', $lower)) {
        http_response_code(404);
        exit('404 Not Found');
    }
})();

// 1. Check installation status
if (!file_exists(dirname(__FILE__) . '/config.php')) {
if (!headers_sent()) {
header('Location: admin/install.php');
} else {
exit('Blog not installed. Please run install.php');
}
exit;
}

// E-1 整页缓存拦截:匿名 GET 命中即直出静态 HTML(readfile,不进框架/session/SQL)
// 放在 load.php 之前,缓存命中时连 config/session/数据库连接全部跳过。
require_once dirname(__FILE__) . '/includes/page_cache.php';
pc_serve();

// 2. Bootstrap (loads config, functions including prepare_template_data(), classes, db, plugins)
require_once dirname(__FILE__) . '/includes/load.php';

// 3. Initialize Router and get results
$router = new Router();

$request_type = $router->get_request_type();
$template_file_name = $router->get_template();
$main_object = $router->get_main_object();

$template_data = prepare_template_data($request_type, $main_object);


if ($template_data['request_type'] === '404' && $template_file_name !== '404.php') {
$template_file_name = '404.php';
// Ensure 404 header is set (prepare_template_data already tried, but good to double check)
// H-1 修复：改用 http_response_code(404)，避免 HTTP/1.0 硬编码导致状态码异常
if (!headers_sent()) { http_response_code(404); }
}


// 5. Determine full theme file path
$theme_name = get_option('current_theme', 'default');
$theme_file = ABSPATH . '/content/themes/' . $theme_name . '/' . $template_file_name;

// 在 index.php
$template_data = apply_filters('before_render_template_data', $template_data, $template_file_name);
do_action('before_render_template_action', $template_file_name, $template_data); // 如果还需要纯动作
//do_action('before_render_template', $template_file_name, $template_data);
// E-2 开始渲染缓冲:GET 请求开启,渲染结束经 pc_store() 原子落盘
$pc_render_cache = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET';
$pc_request_type = isset($template_data['request_type']) ? (string)$template_data['request_type'] : '';
if ($pc_render_cache) { ob_start(); }

// 6. Load theme template (the $template_data array is available inside)
if (file_exists($theme_file)) {
require_once $theme_file;
} else {
// Fallback logic (same as before)
if ($template_file_name === '404.php') {
die('Error: 404 template not found in theme "' . htmlspecialchars($theme_name) . '".');
} else {
$fallback_template = ABSPATH . '/content/themes/' . $theme_name . '/index.php';
if(file_exists($fallback_template)) {
require_once $fallback_template; // $template_data is still available here
} else {
die('Error: Required template "' . htmlspecialchars($template_file_name) . '" and fallback "index.php" not found in theme "' . htmlspecialchars($theme_name) . '".');
}
}
}

// E-3 渲染完成:落盘缓存(pc_store 内部二次校验 200/非404/匿名GET,失败静默跳过)
if (!empty($pc_render_cache) && function_exists('pc_store')) {
    pc_store($pc_request_type);
}