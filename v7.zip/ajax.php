<?php
define('DOING_AJAX', true);

// A-1 修复：config.php 顶部有 `if (!defined('CORE')) exit('Direct access not allowed.')` 守卫，
// 而 CORE 由 includes/load.php 定义；原顺序先 require config.php 后 load.php，导致 CORE 未定义
// → 所有 AJAX 请求返回 403 纯文本 → 前端 response.json() 失败（评论/购买/插件交互全部失效）。
// 此处在 require config.php 之前定义 CORE，与 load.php 保持一致。
if (!defined('CORE')) {
    define('CORE', true);
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/load.php';

if (!function_exists('wp_send_json_success')) {
function wp_send_json_success($data = null, $status_code = null) {
$response = ['success' => true];
if (isset($data)) {
$response['data'] = $data;
}
if (null !== $status_code) {
http_response_code($status_code);
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
exit;
}
}

if (!function_exists('wp_send_json_error')) {
function wp_send_json_error($data = null, $status_code = null) {
$response = ['success' => false];
if (isset($data)) {
if (is_string($data)) {
$response['data'] = ['message' => $data];
} else {
$response['data'] = $data;
}
}
if (null !== $status_code) {
http_response_code($status_code);
}
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response);
exit;
}
}

if (!function_exists('has_action')) {
function has_action($hook_name, $callback_to_check = false) {
global $wp_actions;
if (!isset($wp_actions[$hook_name])) {
return false;
}
return true;
}
}

if (empty($_REQUEST['action'])) {
wp_send_json_error(['message' => 'No action specified.'], 400);
}

$action = sanitize_text_field($_REQUEST['action'] ?? '');
$perform_csrf_check = true;

if ($perform_csrf_check) {
$csrf_token = $_REQUEST['_ajax_csrf_token'] ?? $_POST['csrf_token'] ?? '';
// Fixed Logic: Disabled one-time destruction for AJAX CSRF to prevent race conditions on concurrent requests
if (!verifyCsrfToken($csrf_token, $action, false)) {
wp_send_json_error(['message' => 'Security check failed (CSRF). Please refresh and try again.'], 403);
}
}

$hook_to_fire = 'wp_ajax_' . $action;
if (!is_logged_in() && has_action('wp_ajax_nopriv_' . $action)) {
$hook_to_fire = 'wp_ajax_nopriv_' . $action;
} elseif (!is_logged_in()) {
wp_send_json_error(['message' => 'You must be logged in to perform this action.'], 403);
} elseif (!has_action($hook_to_fire)) {
wp_send_json_error(['message' => 'Specified AJAX action not found.'], 404);
}

do_action($hook_to_fire);
wp_send_json_error(['message' => 'AJAX handler did not complete correctly.'], 500);
?>