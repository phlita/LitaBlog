<?php
// admin/login.php
if (!file_exists(dirname(__FILE__) . '/../config.php')) {
    header('Location: install.php');
    exit;
}
require_once dirname(__FILE__) . '/../includes/load.php';

if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$registration_enabled = (get_option('enable_registration', '0') === '1');
$error = null;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !isset($_SESSION['pending_2fa_user_id'])) {
    session_regenerate_id(true);
}

// 处理返回上一步：清除 2FA 挂起状态，重新展示普通登录
if (isset($_GET['action']) && $_GET['action'] === 'cancel_2fa') {
    unset($_SESSION['pending_2fa_user_id']);
    unset($_SESSION['pending_remember_me']);
unset($_SESSION['pending_2fa_time']);
unset($_SESSION['2fa_attempts']);
    header('Location: login.php');
    exit;
}


if (!empty($_SESSION['pending_2fa_user_id'])) {
    // 如果挂起超过 5 分钟，自动清除
    $pending_time = $_SESSION['pending_2fa_time'] ?? 0;
    if ($pending_time > 0 && (time() - $pending_time) > 300) {
        unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_remember_me'], $_SESSION['pending_2fa_time'], $_SESSION['2fa_attempts']);
        // 重定向到登录页
        header('Location: login.php');
        exit;
    }
}

// 检测当前是否处于 2FA 验证挂起状态
$show_2fa = !empty($_SESSION['pending_2fa_user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // ========================================================
    // 阶段二：用户正在提交 2FA 动态码
    // ========================================================
    if (isset($_POST['otp_code'])) {
        if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'admin_login_2fa')) {
            $error = '安全令牌验证失败，请刷新页面重试。';
        } else {
            $otp_code = trim($_POST['otp_code'] ?? '');
            $pending_user_id = $_SESSION['pending_2fa_user_id'] ?? null;

            if (!$pending_user_id) {
                $error = '登录会话已过期，请重新登录。';
                $show_2fa = false;
            } else {
                require_once dirname(__FILE__) . '/../includes/totp.php';
                $secret = get_user_meta($pending_user_id, 'two_factor_secret', true);
				// 高效防爆破：Session 级错误计数
                $_SESSION['2fa_attempts'] = ($_SESSION['2fa_attempts'] ?? 0) + 1;
                if ($_SESSION['2fa_attempts'] > 5) {
                    unset($_SESSION['pending_2fa_user_id'], $_SESSION['2fa_attempts']);
                    $error = '错误次数过多，请重新输入密码。';
                    $show_2fa = false;
                } else {
                if (LitaTOTP::verifyCode($secret, $otp_code)) {
					unset($_SESSION['2fa_attempts']); // 验证成功清空计数
                    // 2FA 验证通过，获取用户信息
                    $user = get_user($pending_user_id);
                    session_regenerate_id(true);
                    // 确立正式登录状态
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    unset($_SESSION['pending_2fa_user_id']);
unset($_SESSION['pending_2fa_time']);
                    // ========================================================
                    // 补全自动登录 Cookie 逻辑 (继承自原版并延迟到此写入)
                    // ========================================================
                    $remember_days = isset($_SESSION['pending_remember_me']) ? (int)$_SESSION['pending_remember_me'] : 0;
                    unset($_SESSION['pending_remember_me']);

                    // 时长白名单与秒数统一取自 litablog_remember_options/seconds(functions.php)
                    if (array_key_exists($remember_days, litablog_remember_options())) {
                        $seconds = litablog_remember_seconds($remember_days);
                        $expires = time() + $seconds;

                        $selector = bin2hex(random_bytes(12));
                        $validator = bin2hex(random_bytes(24));

                        setcookie('lita_remember', $selector . ':' . $validator, [
                            'expires' => $expires,
                            'path' => '/',
                            'domain' => '', 
                            'secure' => $is_secure,
                            'httponly' => true,
                            'samesite' => 'Lax' 
                        ]);

                        // D-1 修复：2FA 登录的 Remember Me 也写入独立表（与直接登录、自动登录一致）
                        // E-3 修复：不再在读路径裸跑 DDL，统一走守卫式自愈入口（同 load.php）
                        litablog_ensure_remember_tokens_schema();
                        $stmt_rm = $db->prepare(
                            "DELETE FROM remember_tokens WHERE user_id = :uid
                             AND selector NOT IN (
                                SELECT selector FROM remember_tokens
                                WHERE user_id = :uid ORDER BY expires DESC LIMIT 4
                             )"
                        );
                        $stmt_rm->execute([':uid' => $user['id']]);
                        $stmt_tk = $db->prepare(
                            "INSERT OR REPLACE INTO remember_tokens (selector, user_id, hashed_validator, expires)
                             VALUES (:sel, :uid, :hv, :exp)"
                        );
                        $stmt_tk->execute([
                            ':sel' => $selector,
                            ':uid' => $user['id'],
                            ':hv'  => hash('sha256', $validator),
                            ':exp' => $expires
                        ]);
                    }

                    header('Location: index.php');
                    exit;
                } else {
                    $error = '动态验证码错误，请重新输入。';
                    $show_2fa = true;
                }}
            }
        }
    } 
    // ========================================================
    // 阶段一：用户正在提交正常的账号密码
    // ========================================================
    else {
        if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'admin_login')) {
            $error = '安全令牌验证失败，请刷新页面重试。';
        } else {
           // $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
			//FILTER_SANITIZE_STRING 自 PHP 8.1 起已被废弃，在更高版本中会被移除。
			//使用系统内置的 sanitize_text_field 代替。
			$username = sanitize_text_field($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (!$username || !$password) {
                $error = '请填写所有字段';
            } else {
                try {
                    $db = get_db();
                    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
                    $now = time();
                    $window_time = 900; 
                    $max_attempts = 5;  

                    // 自动建表 (爆破防御日志)
                    $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ip TEXT NOT NULL,
                        username TEXT NOT NULL,
                        attempt_time INTEGER NOT NULL
                    )");

                    // 爆破统计
                    $stmt_count = $db->prepare("
                        SELECT COUNT(*) FROM login_attempts 
                        WHERE (ip = :ip OR username = :username) AND attempt_time > :time_limit
                    ");
                    $stmt_count->execute([
                        ':ip' => $ip,
                        ':username' => $username,
                        ':time_limit' => $now - $window_time
                    ]);
                    $failed_count = (int)$stmt_count->fetchColumn();

                    if ($failed_count >= $max_attempts) {
                        $error = '尝试登录失败次数过多，该 IP 或账号已被临时限制。请在 15 分钟后再试。';
                    } else {
                        $stmt = $db->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
                        $stmt->execute([$username]);
                        $user = $stmt->fetch(PDO::FETCH_ASSOC);

                        if ($user && password_verify($password, $user['password'])) {
                            // 密码正确，清理失败限制记录
                            $stmt_clear = $db->prepare("DELETE FROM login_attempts WHERE ip = :ip OR username = :username");
                            $stmt_clear->execute([':ip' => $ip, ':username' => $username]);

                            // 校验是否开启了 2FA
                            $two_factor_secret = get_user_meta($user['id'], 'two_factor_secret', true);

                            if (!empty($two_factor_secret)) {
                                // 开启了 2FA：暂存 Remember Me 选择并进入 2FA 阶段
                                $_SESSION['pending_remember_me'] = isset($_POST['remember_me']) ? (int)$_POST['remember_me'] : 0;
                                $_SESSION['pending_2fa_user_id'] = $user['id'];
								$_SESSION['pending_2fa_time'] = time();
                                $show_2fa = true;
                            } else {
								session_regenerate_id(true);
                                // 未开启 2FA：直接确立正式 Session
                                $_SESSION['user_id'] = $user['id'];
                                $_SESSION['username'] = $user['username'];
                                $_SESSION['role'] = $user['role'];

                                // 直接登录的 Remember Me Cookie 流程
                                // 时长白名单与秒数统一取自 litablog_remember_options/seconds(functions.php)
                                $remember_days = isset($_POST['remember_me']) ? (int)$_POST['remember_me'] : 0;
                                if (array_key_exists($remember_days, litablog_remember_options())) {
                                    $seconds = litablog_remember_seconds($remember_days);
                                    $expires = time() + $seconds;
                                    $selector = bin2hex(random_bytes(12));
                                    $validator = bin2hex(random_bytes(24));

                                    setcookie('lita_remember', $selector . ':' . $validator, [
                                        'expires' => $expires,
                                        'path' => '/',
                                        'domain' => '', 
                                        'secure' => $is_secure,
                                        'httponly' => true,
                                        'samesite' => 'Lax' 
                                    ]);

                                    // D-1 修复：写入独立表 remember_tokens（与 load.php 自动登录一致），
                                    // 每用户保留最近 4 个活跃 token（加新的一条共 5 个），超出的删除。
                                    // E-3 修复：DDL 移出读路径，统一走守卫式自愈入口
                                    litablog_ensure_remember_tokens_schema();
                                    $stmt_rm = $db->prepare(
                                        "DELETE FROM remember_tokens WHERE user_id = :uid
                                         AND selector NOT IN (
                                            SELECT selector FROM remember_tokens
                                            WHERE user_id = :uid ORDER BY expires DESC LIMIT 4
                                         )"
                                    );
                                    $stmt_rm->execute([':uid' => $user['id']]);
                                    $stmt_tk = $db->prepare(
                                        "INSERT OR REPLACE INTO remember_tokens (selector, user_id, hashed_validator, expires)
                                         VALUES (:sel, :uid, :hv, :exp)"
                                    );
                                    $stmt_tk->execute([
                                        ':sel' => $selector,
                                        ':uid' => $user['id'],
                                        ':hv'  => hash('sha256', $validator),
                                        ':exp' => $expires
                                    ]);
                                }

                                header('Location: index.php');
                                exit;
                            }
                        } else {
                            // 登录失败：记录并提示
                            // D-6 修复：插入前清理超过爆破窗口期（15 分钟）的旧记录。
                            // 原实现只在登录成功时清理（:183 附近），失败记录会无限堆积 ——
                            // 被持续爆破的账号/IP 会在 login_attempts 中留下海量行，
                            // 既拖慢每次登录的失败次数查询，也让表无意义膨胀。
                            $stmt_clean = $db->prepare("DELETE FROM login_attempts WHERE attempt_time < :cutoff");
                            $stmt_clean->execute([':cutoff' => $now - $window_time]);

                            $stmt_log = $db->prepare("
                                INSERT INTO login_attempts (ip, username, attempt_time) 
                                VALUES (:ip, :username, :attempt_time)
                            ");
                            $stmt_log->execute([
                                ':ip' => $ip,
                                ':username' => $username,
                                ':attempt_time' => $now
                            ]);

                            $remaining = $max_attempts - ($failed_count + 1);
                            if ($remaining > 0) {
                                $error = '用户名或密码无效。您还拥有 ' . $remaining . ' 次尝试机会。';
                            } else {
                                $error = '尝试登录失败次数过多，该 IP 或账号已被锁定，请 15 分钟后再试。';
                            }
                        }
                    }
                } catch (PDOException $e) {
                    error_log('User Registration Database Exception: ' . $e->getMessage());
                    $error = '数据库操作失败，请联系管理员或稍后重试。';
                }
            }
        }
    }
}

// 调度渲染登录页面
include dirname(__FILE__) . '/views/login.php';