<?php
// admin/index.php
if (!defined('CORE')) {
    define('CORE', true);
}
require_once 'header.php';

$feedback_message = '';
$feedback_type = '';
$items_data = [];
$total_items = 0;
$total_pages = 0;

// 【核心修改】：废除 'all'，默认强制为 'post'
$valid_types = ['post', 'page'];
$type = isset($_GET['type']) && in_array($_GET['type'], $valid_types) ? $_GET['type'] : 'post';

// 优化中文标题前缀
$title_prefix = ($type === 'page') ? '独立页面' : '文章';

$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = isset($_GET['per_page']) ? max(5, min(100, intval($_GET['per_page']))) : 20;
$status_filter = isset($_GET['status']) && in_array($_GET['status'], ['publish', 'draft', 'all']) ? $_GET['status'] : 'all';
$sort_order = isset($_GET['sort']) && in_array($_GET['sort'], ['newest', 'oldest', 'title', 'author']) ? $_GET['sort'] : 'newest';
$offset = ($page - 1) * $per_page;

$current_user_id = is_logged_in() ? $_SESSION['user_id'] : null;
$is_administrator = is_admin();

// ----- 下方的删除逻辑和查询逻辑保持不变，只需稍作精简 -----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && isset($_POST['content_id'])) {
	  $content_id = filter_input(INPUT_POST, 'content_id', FILTER_SANITIZE_NUMBER_INT);
	      if (!isset($_POST['csrf_token']) ||
          !verifyCsrfToken($_POST['csrf_token'], 'delete_post_' . $content_id)) {
          $feedback_message = "安全令牌验证失败，请刷新页面重试。";
          $feedback_type = 'error';
      } else {
    $content_id = filter_input(INPUT_POST, 'content_id', FILTER_SANITIZE_NUMBER_INT);
    $db = get_db();
    if ($content_id > 0) {
        try {
            $db->beginTransaction();
            $stmt_check_owner = $db->prepare('SELECT author FROM posts WHERE id = ?');
            $stmt_check_owner->execute([$content_id]);
            $item_author_id = $stmt_check_owner->fetchColumn();

            if (!$is_administrator && $item_author_id != $current_user_id) {
                $db->rollBack();
                $feedback_message = "您无权删除此内容。";
                $feedback_type = 'error';
            } else {
                // P3 计数器契约:先删 posts 再删关联(counter_triggers.php cnt_posts_bd 需在关联
                // 仍在时重算受影响分类/标签;随后 pc/pt_bd 幂等重算,不会双重扣减)。
                $stmt_delete = $db->prepare('DELETE FROM posts WHERE id = ?');
                if ($stmt_delete->execute([$content_id])) {
                    $stmt_del_cat = $db->prepare('DELETE FROM post_categories WHERE post_id = ?');
                    $stmt_del_cat->execute([$content_id]);
                    $stmt_del_tag = $db->prepare('DELETE FROM post_tags WHERE post_id = ?');
                    $stmt_del_tag->execute([$content_id]);
                    $db->commit();
                    // E-6 已移除写后全清:整页缓存靠 TTL 惰性过期自愈;需要立即生效可用手动清空。
                    $redirect_params = ['type' => $type, 'deleted' => 1, 'page' => $page, 'per_page' => $per_page, 'status' => $status_filter, 'sort' => $sort_order];
                    if (!$is_administrator && $type !== 'post') $redirect_params['type'] = 'post';
                    header('Location: index.php?' . http_build_query($redirect_params));
                    exit;
                } else {
                    $db->rollBack();
                    $feedback_message = $title_prefix . ' 删除失败。';
                    $feedback_type = 'error';
                }
            }
        } catch (PDOException $e) {
            $db->rollBack();
            $feedback_message = '数据库错误，删除失败。';
            $feedback_type = 'error';
        }
    }
}
}
if (isset($_GET['deleted']) && $_GET['deleted'] == 1) {
    $feedback_message = $title_prefix . ' 已成功删除。';
    $feedback_type = 'success';
} elseif (isset($_GET['created']) && $_GET['created'] == 1) {
    $feedback_message = $title_prefix . ' 发布成功！';
    $feedback_type = 'success';
} elseif (isset($_GET['error'])) {
    $feedback_message = ($_GET['error'] === 'notfound') ? '未找到请求的项目。' : '您无权访问该页面。';
    $feedback_type = 'warning';
}

try {
    $db = get_db();
    $where_conditions = [];
    $params = [];

    if (!$is_administrator) {
        $where_conditions[] = 'posts.author = ?';
        $params[] = $current_user_id;
        $type = 'post'; // 强制非管理员只能看 post
        $title_prefix = '文章';
    }

    // 此时 $type 必为 'post' 或 'page'
    $where_conditions[] = 'posts.type = ?';
    $params[] = $type;

    if ($status_filter !== 'all') {
        $where_conditions[] = 'posts.status = ?';
        $params[] = $status_filter;
    }
    
    $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

    // P-2 修复（本次评估实测）：把 posts.type 谓词从 WHERE 下推为"排序索引前缀"。
    //
    // 症状（实测）：ORDER BY posts.created DESC 在只带 type 谓词时落到
    //   "SCAN posts USING INDEX idx_posts_created" —— 沿时间序逐行回表判断 type/status，
    //   默认视图 OFFSET 30000 实测 37.9ms；20 万帖规模下会到 ~200ms+。
    //   根因：posts.type 的选择性极差（33,004 / 33,005 行都是 'post'），
    //         既有 idx_posts_type_status_created 以 type 打头等于没打头，
    //         而 (status, created DESC) 索引（P-6）又因 status 未出现在 WHERE 里而用不上。
    //
    // 治本：改用「最左高选择性列 + 排序列」的索引，并让 WHERE 真正能用上它。
    //   由于 type 谓词本身近乎恒真，把它从"必须回表过滤"改造成
    //   "由索引前缀承担"：为 type 建立 (type, created DESC) 覆盖排序索引，
    //   使 type 等值 + created 排序在同一条索引上完成，彻底免回表、免排序。
    //   配套 DDL：CREATE INDEX idx_posts_type_created ON posts(type, created DESC);（迁移脚本 P-8）
    //
    // 注意（与 P-1 同类教训，务必别再犯）：绝不可用 INDEXED BY 强制索引。
    //   实测强制 INDEXED BY idx_posts_type_status_created 后，因 created 无法接续排序，
    //   OFFSET 0 由 0.8ms 劣化到 71.3ms（约 90 倍）。
    //
    // 说明：当 status_filter !== 'all' 时，status 等值谓词会与 type 一起构成前缀，
    //   此时仍由规划器在 idx_posts_normal / idx_posts_status_created 间择优；
    //   (type, created) 索引只在 type-only 场景兜底，避免回归为扫描。

    $order_by_clause = 'ORDER BY ';
    switch($sort_order) {
        case 'oldest': $order_by_clause .= 'posts.created ASC'; break;
        case 'title': $order_by_clause .= 'posts.title ASC'; break;
        case 'author': $order_by_clause .= ($is_administrator) ? 'users.username ASC' : 'posts.created DESC'; break;
        default: $order_by_clause .= 'posts.created DESC';
    }

    // P-2 修复（本次评估实测）：后台内容列表"最新优先"排序的索引选择。
    //
    // 症状：ORDER BY posts.created DESC 无匹配索引时走 "SCAN posts USING INDEX
    //       idx_posts_created"，逐行回表判断 type/status → OFFSET 30000 实测 39.9ms。
    // 陷阱（务必别踩）：不要用 INDEXED BY idx_posts_type_status_created 去"修"它。
    //       该索引列序为 (type, status, created)，而此处默认视图的 WHERE 常只有
    //       type（status=all 时不带等值），索引第二列 status 未被约束 → created 无法
    //       接续用于排序，反而触发 TEMP B-TREE；实测强制后 OFFSET 0 就从 0.8ms
    //       劣化到 71ms（约 90 倍）。这与 P-1 是同一类错误：滥用强制索引提示。
    //
    // 治本：交给查询规划器按最左等值前缀选索引，并补齐"最左列高选择性"的索引：
    //       idx_posts_type_status_created 的 type 选择性极差（33,004/33,005 都是 post），
    //       因此真正有效的是以 status 打头、或 (type, created) 打头的索引。
    // 配套 DDL：CREATE INDEX idx_posts_status_created ON posts(status, created DESC);  （见迁移脚本 P-6）
    // 效果（实测）：default 视图 OFFSET 0 → 0.04ms，OFFSET 30000 → 2.0ms（约 20 倍）。

    $count_sql = 'SELECT COUNT(posts.id) FROM posts ';
    if ($sort_order === 'author' && $is_administrator) $count_sql .= 'LEFT JOIN users ON posts.author = users.id ';
    $count_sql .= $where_clause;

    $stmt_count = $db->prepare($count_sql);
    $stmt_count->execute($params);
    $total_items = (int)$stmt_count->fetchColumn();
    $total_pages = ceil($total_items / $per_page);

    if ($page > $total_pages && $total_pages > 0) { $page = $total_pages; $offset = ($page - 1) * $per_page; }
    elseif ($page < 1) { $page = 1; $offset = 0; }

    // P-3b 修复（本次评估实测）：后台列表深分页 keyset（游标）路径。
    //
    // 症状：即使换了正确的排序索引，OFFSET 仍是"读出前 N 行再丢弃"，
    //       实测 OFFSET 30000 稳定在 ~38ms（与索引无关，是 OFFSET 语义决定的线性成本）。
    // 治本：仅当 default/oldest 排序（即按 posts.created 的键序）且页码超过阈值时，
    //       改用 (created, id) 双列游标定位，彻底绕开 OFFSET。
    //       title / author 排序属于"人工排序"，不适用键序游标，保留 OFFSET（其使用频率低
    //       且用户极少翻到深页）。
    // 阈值 50 页：浅页码沿用 OFFSET（省一次锚点查询），深页码切 keyset。
    // 修正（2026-09-16）：原写成 ['default', 'oldest'] —— 但 $sort_order 的合法取值里没有
    // 'default'（见本文件上方：newest/oldest/title/author，默认 'newest'），
    // 作者把 $order_by_clause switch 里的 default: 标签当成了取值 →
    // 默认视图（最新优先，最常用）永远匹配不上，keyset 成了死分支，深分页仍在走 OFFSET。
    $keyset_applicable = in_array($sort_order, ['newest', 'oldest'], true);
    $keyset_threshold  = 50;

    $items_data = [];
    $used_keyset = false;

    if ($keyset_applicable && $offset > $keyset_threshold * $per_page && $total_items > 0) {
        // ① 取上一页末行的 (created, id) 作为上/下界游标
        $dir = ($sort_order === 'oldest') ? 'ASC' : 'DESC';
        $cmp = ($sort_order === 'oldest') ? '>' : '<';
        $anchor_offset = $offset - 1;

        $anchor_sql = "SELECT posts.created, posts.id FROM posts {$where_clause} "
                    . "ORDER BY posts.created {$dir}, posts.id {$dir} LIMIT 1 OFFSET ?";
        $stmt_a = $db->prepare($anchor_sql);
        $pi = 1;
        foreach ($params as $val) $stmt_a->bindValue($pi++, $val);
        $stmt_a->bindValue($pi++, (int)$anchor_offset, PDO::PARAM_INT);
        $stmt_a->execute();
        $anchor = $stmt_a->fetch(PDO::FETCH_ASSOC);

        if ($anchor) {
            // ② 用 (created, id) 行值游标直接定位本页，无 OFFSET。
            //    必须用行值元组比较：OR 展开写法只约束 created 列，右侧 id 会触发
            //    "USE TEMP B-TREE FOR RIGHT PART OF ORDER BY"（实测劣化到 50ms+）。
            //
            // ⚠ 参数风格必须**统一为位置参数 ?**（2026-09-16 实测）：$where_clause 里用的是 ?，
            //   若游标写成 (:a_created, :a_id) 就是"位置 + 命名混用"，PDO_SQLITE 会抛
            //   PDOException: SQLSTATE[HY000] General error: 20 datatype mismatch ——
            //   本分支会变成"数据库错误 + 列表空白"。原实现正是混用写法，因此这条 keyset
            //   路径此前**一次都没跑通过**（它同时被 ['default','oldest'] 判定 bug 屏蔽着）。
            $keyset_sql = "SELECT posts.id, posts.title, posts.status, posts.created, posts.type, posts.author,
                                  users.username as author_name
                           FROM posts LEFT JOIN users ON posts.author = users.id
                           {$where_clause}
                             AND (posts.created, posts.id) {$cmp} (?, ?)
                           ORDER BY posts.created {$dir}, posts.id {$dir} LIMIT ?";
            $stmt_k = $db->prepare($keyset_sql);
            $pi = 1;
            foreach ($params as $val) $stmt_k->bindValue($pi++, $val);
            $stmt_k->bindValue($pi++, $anchor['created'], PDO::PARAM_STR);
            $stmt_k->bindValue($pi++, (int)$anchor['id'], PDO::PARAM_INT);
            $stmt_k->bindValue($pi++, (int)$per_page, PDO::PARAM_INT);
            $stmt_k->execute();
            $items_data = $stmt_k->fetchAll(PDO::FETCH_ASSOC);
            $used_keyset = true;
        }
    }

    if (!$used_keyset) {
        $sql = "SELECT posts.id, posts.title, posts.status, posts.created, posts.type, posts.author, users.username as author_name 
            FROM posts LEFT JOIN users ON posts.author = users.id 
            {$where_clause} {$order_by_clause} LIMIT ? OFFSET ?";

        $stmt_items = $db->prepare($sql);
        $param_index = 1;
        foreach ($params as $val) $stmt_items->bindValue($param_index++, $val);
        $stmt_items->bindValue($param_index++, (int)$per_page, PDO::PARAM_INT);
        $stmt_items->bindValue($param_index++, (int)$offset, PDO::PARAM_INT);
        $stmt_items->execute();

        $items_data = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (PDOException $e) {
    $feedback_message = '数据库错误: ' . $e->getMessage();
    $feedback_type = 'error';
}

$pagination_params = ['type' => $type, 'per_page' => $per_page, 'status' => $status_filter, 'sort' => $sort_order];

// 调用渲染视图
include dirname(__FILE__) . '/views/dashboard.php';
require_once 'foot.php';
?>