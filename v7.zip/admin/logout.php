<?php
require_once dirname(__FILE__) . '/../includes/load.php';

// H-3 修复：退出必须携带有效的 CSRF token，无 token 一律拒绝。
//
// 原实现：GET 取 token，且"无 token 的直接访问仍然执行退出（用户体验优先）"
// → `<img src="/admin/logout.php">` 即可强制任意用户（含管理员）登出（CSRF）。
//
// 现方案：要求有效 token（GET/POST 皆可），CSRF 校验失败直接终止、不做降级。
//   安全性：`<img>`/`<script>` 等跨站载体无法携带 token，强制登出攻击失效。
//   兼容性：admin/header.php 的"安全退出"链接与主题中的登出链接均已带
//           ?csrf_token=...（generateCsrfToken('user_logout')），无需改动，
//           避免强制 POST 导致第三方主题登出功能失效。
$token = $_REQUEST['csrf_token'] ?? '';
if (empty($token) || !verifyCsrfToken($token, 'user_logout', false)) {
    http_response_code(403);
    die('安全验证失败，请从后台菜单点击退出。');
}

// 清理持久化 Remember Cookie
if (isset($_COOKIE['lita_remember'])) {
    $parts = explode(':', $_COOKIE['lita_remember'], 2);
    if (count($parts) === 2) {
        $selector = $parts[0];
        try {
            $db = get_db();
            // D-1 修复：独立表按 selector 主键 O(1) 删除。
            // 原实现全表扫描 usermeta、逐用户反序列化比对（登出也 O(全体用户)），
            // 50 万用户时登出请求同样缓慢。
            $stmt = $db->prepare("DELETE FROM remember_tokens WHERE selector = :sel");
            $stmt->execute([':sel' => $selector]);
        } catch (Exception $e) {
            error_log("Error clearing token on logout: " . $e->getMessage());
        }
    }
    setcookie('lita_remember', '', time() - 3600, '/');
}

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}

session_destroy();
header('Location: ../');
exit;