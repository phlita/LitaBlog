<!-- START OF FILE admin/views/profile.php -->
<?php defined('CORE') || die('Direct access not allowed.'); ?>
<div class="desktop-header">
<h1>账号资料</h1>
</div>

<!-- Refactored safe feedback alert to prevent reflected XSS (Mitigates V-06) -->
<?php if (!empty($feedback_message)): ?>
<div class="alert alert-<?php echo $feedback_type === 'success' ? 'success' : 'danger'; ?>">
<?php if (is_array($feedback_message)): ?>
<ul style="margin: 0; padding-left: 20px; list-style-type: disc;">
<?php foreach ($feedback_message as $msg): ?>
<li><?php echo e($msg); ?></li>
<?php endforeach; ?>
</ul>
<?php else: ?>
<?php echo e($feedback_message); ?>
<?php endif; ?>
</div>
<?php endif; ?>

<!-- 1. 基本资料卡片 -->
<div class="card" style="margin-bottom: 25px;">
<h3 style="margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px; display: flex; justify-content: space-between;">
<span>📝 基本信息</span>
<span style="font-size: 0.8rem; font-weight: normal; color: #888; background: var(--warm-bg); padding: 2px 8px; border-radius: 10px;">
级别: <?php echo isset($user_data_for_form['role']) ? e(ucfirst($user_data_for_form['role'])) : 'N/A'; ?>
</span>
</h3>

<form method="post" action="profile.php">
<?php csrf_token_field('update_profile'); ?>
<input type="hidden" name="action" value="update_profile">

<div class="form-group">
<label for="username">系统账号名</label>
<input type="text" id="username" name="username" value="<?php echo e($user_data_for_form['username'] ?? ''); ?>" required>
<p style="font-size: 0.8rem; color: #888; margin-top: 5px;">用于登录系统的唯一凭证。</p>
</div>

<div class="form-group">
<label for="display_name">前台显示昵称</label>
<input type="text" id="display_name" name="display_name" value="<?php echo e($user_data_for_form['display_name'] ?? ''); ?>" required>
<p style="font-size: 0.8rem; color: #888; margin-top: 5px;">在文章作者或评论区展示的名字。</p>
</div>

<div class="form-group">
<label for="email">联络邮箱</label>
<input type="email" id="email" name="email" value="<?php echo e($user_data_for_form['email'] ?? ''); ?>" required>
</div>

<button type="submit" class="btn btn-primary" style="width: 100%;">更新基本资料</button>
</form>
</div>

<!-- 2. 密码修改卡片 -->
<div class="card">
<h3 style="margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px; color: var(--danger-color);">
🔒 安全与密码
</h3>

<form method="post" action="profile.php">
<?php csrf_token_field('change_password'); ?>
<input type="hidden" name="action" value="change_password">

<div class="form-group">
<label for="current_password">验证当前密码</label>
<input type="password" id="current_password" name="current_password" placeholder="请输入现在的密码" required>
</div>

<div class="form-group">
<label for="new_password">设置新密码</label>
<input type="password" id="new_password" name="new_password" placeholder="输入新的复杂密码" required>
</div>

<div class="form-group">
<label for="confirm_password">再次确认新密码</label>
<input type="password" id="confirm_password" name="confirm_password" placeholder="重复输入一次" required>
</div>

<button type="submit" class="btn btn-outline" style="width: 100%; border-color: var(--danger-color); color: var(--danger-color);">修改密码</button>
</form>
</div>

<!-- 3. 双重身份验证 (2FA) 绑定管理面板 -->
<div class="card" style="margin-top: 25px;">
<h3 style="margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
🛡️ 双重身份验证 (2FA)
</h3>

<?php 
$two_factor_secret = get_user_meta($user_data_for_form['id'], 'two_factor_secret', true);
$temp_secret = $_SESSION['temp_2fa_secret'] ?? '';
?>

<?php if (!empty($two_factor_secret)): ?>
<div style="background: rgba(74, 159, 107, 0.05); border: 1px solid var(--primary-green); padding: 15px; border-radius: var(--radius-sm); margin-bottom: 20px;">
<p style="color: var(--primary-green); font-weight: 600; font-size: 1.05rem; display: flex; align-items: center; gap: 8px;">
<span>🔒 系统已启用两步验证 (2FA) 保护</span>
</p>
<p style="font-size: 0.85rem; color: #666; margin-top: 8px;">您的账号正处于高级别安全保护下。每次在未登录设备上登入时，都必须输入您的动态密码。</p>
</div>

<form method="post" action="profile.php">
<?php csrf_token_field('disable_2fa'); ?>
<input type="hidden" name="action" value="disable_2fa">

<div class="form-group">
<label for="password_confirm" style="color: var(--danger-color);">请输入当前登录密码以关闭验证：</label>
<input type="password" id="password_confirm" name="password_confirm" placeholder="验证您的登录密码" required>
</div>
<button type="submit" class="btn btn-danger" style="width: 100%;">
关闭双重身份验证
</button>
</form>

<?php else: ?>
<?php if (empty($temp_secret)): ?>
<p style="color: #666; font-size: 0.9rem; margin-bottom: 20px;">两步验证能够让您的账户更加安全。即使密码被不慎泄露，攻击者在没有您的物理设备时也无法完成登录。</p>
<form method="post" action="profile.php">
<?php csrf_token_field('setup_2fa'); ?>
<input type="hidden" name="action" value="setup_2fa">
<button type="submit" class="btn btn-primary" style="width: 100%;">
⚙️ 开启双重身份验证 (2FA)
</button>
</form>

<?php else: ?>
<?php 
require_once dirname(__FILE__) . '/../../includes/totp.php';
$qr_uri = LitaTOTP::getQrCodeUrl($user_data_for_form['username'], $temp_secret, 'LitaBlog');
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" integrity="sha512-CNgIRecGo7nphbeZ04Sc13ka07paqdeTu0WR1IM4kNcpmBAUSHSQX0FslNhTDadL4O5SAGapGt4FodqL8My0mA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<div style="background: var(--warm-bg); border: 1px solid var(--border-color); padding: 20px; border-radius: var(--radius-sm); margin-bottom: 20px;">
<p style="font-weight: 600; margin-bottom: 12px;">1. 请使用您的双重验证 APP 扫描下方二维码：</p>
<div style="text-align: center; margin-bottom: 15px; background: #fff; padding: 15px; display: inline-block; border: 1px solid #ddd; border-radius: 4px;">
<div id="qrcode" style="display: inline-block;"></div>
</div>

<p style="font-weight: 600; margin-top: 10px; margin-bottom: 5px;">2. 无法扫码？也可以在 APP 中手动添加以下密钥：</p>
<code style="display: block; background: #fff; padding: 10px; text-align: center; font-size: 1.15rem; font-weight: bold; border-radius: var(--radius-sm); border: 1px dashed #ccc; letter-spacing: 0.1em; color: var(--accent-color);">
<?php echo e($temp_secret); ?>
</code>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
var qrContainer = document.getElementById('qrcode');
if (!qrContainer) return;
if (typeof QRCode === 'undefined') {
qrContainer.innerHTML = '<p style="color:red;font-size:0.85rem;">二维码生成组件加载失败，请刷新页面重试。</p>';
return;
}
try {
new QRCode(qrContainer, {
text: <?php echo json_encode($qr_uri); ?>,
width: 200,
height: 200,
colorDark: "#000000",
colorLight: "#ffffff",
correctLevel: QRCode.CorrectLevel.H
});
} catch(e) {
qrContainer.innerHTML = '<p style="color:red;font-size:0.85rem;">二维码绘制失败</p>';
}
});
</script>

<form method="post" action="profile.php">
<?php csrf_token_field('confirm_2fa'); ?>
<input type="hidden" name="action" value="confirm_2fa">

<div class="form-group">
<label for="otp_code">3. 请输入 APP 中当前生成的 6 位动态验证码：</label>
<input type="text" id="otp_code" name="otp_code" pattern="[0-9]{6}" maxlength="6" required autofocus autocomplete="off" style="text-align: center; letter-spacing: 0.3em; font-size: 1.1rem; font-weight: bold;">
</div>

<button type="submit" class="btn btn-primary" style="width: 100%;">
✅ 确认并绑定双重验证
</button>
</form>

<div style="text-align: center; margin-top: 15px;">
<form method="post" action="profile.php" style="display: inline;">
<?php csrf_token_field('cancel_2fa'); ?> 
<input type="hidden" name="action" value="cancel_2fa">
<button type="submit" style="background: none; border: none; color: #888; font-size: 0.85rem; text-decoration: none; cursor: pointer; padding: 0; font-family: inherit;">
取消绑定
</button>
</form>
</div>
<?php endif; ?>
<?php endif; ?>
</div>
<!-- END OF FILE admin/views/profile.php -->