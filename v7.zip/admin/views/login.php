<!-- START OF FILE admin/views/login.php -->
<?php defined('CORE') || die('Direct access not allowed.'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<title>登录 · <?php echo get_option('site_title', 'LitaBlog'); ?></title>
<link rel="stylesheet" href="admin.css" />
<style>
    body {
        padding: 20px;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: var(--warm-bg);
    }
    .login-wrapper {
        width: 100%;
        max-width: 400px;
    }
    .login-card {
        background: var(--warm-card-bg);
        border-radius: var(--radius-md);
        padding: 30px;
        box-shadow: 0 10px 25px var(--shadow-color);
    }
    .login-header { text-align: center; margin-bottom: 30px; }
    .login-header h1 { color: var(--primary-green); font-size: 1.8rem; font-weight: 700; margin-bottom: 5px; }
    .login-header p { color: #888; font-size: 0.9rem; }
    .login-links { text-align: center; margin-top: 20px; font-size: 0.9rem; color: #888; }
</style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">
        <div class="login-header">
            <h1>LitaBlog</h1>
            <p><?php echo $show_2fa ? '请输入动态验证码以确立安全登录' : '欢迎回来，请登录您的账户'; ?></p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['registered']) && $_GET['registered'] == 1): ?>
            <div class="alert alert-success">注册成功！请使用新账号登录。</div>
        <?php endif; ?>

        <?php if ($show_2fa): ?>
            <!-- ======================================================== -->
            <!-- 阶段二：2FA 动态码提交表单 -->
            <!-- ======================================================== -->
            <form method="post">
                <?php csrf_token_field('admin_login_2fa'); ?>
                <div class="form-group">
                    <label for="otp_code">🔓 双重验证动态码</label>
                    <input type="text" id="otp_code" name="otp_code" placeholder="输入 6 位数字" pattern="[0-9]{6}" maxlength="6" required autofocus autocomplete="off" style="letter-spacing: 0.5em; text-align: center; font-size: 1.25rem;">
                    <p style="font-size: 0.8rem; color: #888; margin-top: 5px; text-align: center;">请在手机双重验证 APP 中查看动态码</p>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 1.1rem; border-radius: var(--radius-sm); margin-top: 10px;">
                    验 证 登 录
                </button>
            </form>
            <div style="text-align: center; margin-top: 15px;">
                <a href="login.php?action=cancel_2fa" style="font-size: 0.9rem; color: var(--primary-green); text-decoration: none;">&larr; 返回输入密码</a>
            </div>

        <?php else: ?>
            <!-- ======================================================== -->
            <!-- 阶段一：正常的用户名和密码登录表单 -->
            <!-- ======================================================== -->
            <form method="post">
                <?php csrf_token_field('admin_login'); ?>
                <div class="form-group">
                    <label for="username">账号</label>
                    <input type="text" id="username" name="username" placeholder="请输入用户名" required autofocus>
                </div>
                <div class="form-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" name="password" placeholder="请输入密码" required>
                </div>
                <div class="form-group">
                    <label for="remember_me">保持登录状态</label>
                    <select id="remember_me" name="remember_me">
                        <?php foreach (litablog_remember_options() as $rm_days => $rm_label): ?>
                            <option value="<?php echo (int)$rm_days; ?>"<?php echo ((int)$rm_days === 366) ? ' selected' : ''; ?>><?php echo htmlspecialchars($rm_label); ?></option>
                        <?php endforeach; ?>
                        <option value="0">仅本次会话</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 12px; font-size: 1.1rem; border-radius: var(--radius-sm); margin-top: 10px;">
                    登 录
                </button>
            </form>
            <div class="login-links">
                <?php if ($registration_enabled): ?>
                    <a href="register.php">注册账号</a> &nbsp;·&nbsp; 
                <?php endif; ?>
                <a href="../">返回首页</a>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
<!-- END OF FILE admin/views/login.php -->