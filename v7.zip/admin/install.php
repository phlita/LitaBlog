<?php
// admin/install.php
define('CORE', true);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['install_token'])) {
    $_SESSION['install_token'] = bin2hex(random_bytes(32));
}
if (file_exists(dirname(__FILE__) . '/../config.php')) {http_response_code(403);
die('博客已经安装！如需重新安装，请手动删除根目录下的 config.php 文件。');
}

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field($str) {
        $str = strip_tags($str);
        $str = htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
        return trim($str);
    }
}

// 检查数据库中的安装标记
$db_dir = dirname(__FILE__) . '/../content/database/';
if (is_dir($db_dir)) {
$db_files = glob($db_dir . '*.db');
foreach ($db_files as $db_file) {
try {
$test_db = new PDO('sqlite:' . $db_file);
$test_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 查询安装标记
$stmt = $test_db->query("SELECT value FROM options WHERE name = 'system_installed'");
$row = $stmt->fetch();

if ($row && $row['value'] === '1') {
http_response_code(403);
die('检测到已安装的数据库！如需重新安装，请删除 content/database/ 目录下的数据库文件。');
}
} catch (PDOException $e) {
// 数据库文件损坏或表不存在，允许重新安装
continue;
}
}
}


$recommend_status = "推荐 PHP 7.4+ 当前 " . PHP_VERSION;
$sqlite_status = "";
if (!extension_loaded('pdo_sqlite')) { 
$sqlite_status = "pdo_sqlite 未启用 安装不了"; 
} else {
if (!extension_loaded('sqlite3')) { 
$sqlite_status = "sqlite3 未启用 pdo_sqlite 启用 将就"; 
}
}

// P0-4:opcache 检测提示(生产共享主机上 PHP 字节码缓存的 CPU 收益 3-5 倍)
$opcache_status = '';
if (function_exists('opcache_get_status')) {
    $st = @opcache_get_status(false);
    $opcache_enabled = !empty($st['opcache_enabled']);
    $opcache_status = $opcache_enabled
        ? 'opcache 已开启(推荐, PHP 字节码缓存, CPU 开销下降)'
        : 'opcache 未开启 — 在 php.ini 启用(zend_extension=opcache 且 opcache.enable=1)';
} else {
    $opcache_status = 'opcache 扩展未安装 — 独立环境建议安装';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	 // 验证令牌
    $submitted_token = $_POST['install_token'] ?? '';
    if (empty($submitted_token) || $submitted_token !== ($_SESSION['install_token'] ?? '')) {
        die('安全验证失败，请重新提交表单！');
    }
    // ========== CSRF 验证结束 ==========
//$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
$username = sanitize_text_field($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

$is_install_secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
|| (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
|| (($_SERVER['HTTP_CF_VISITOR'] ?? '') === '{"scheme":"https"}');
$protocol = $is_install_secure ? 'https://' : 'http://';
//$host = $_SERVER['HTTP_HOST'];
$host = preg_replace('/[^a-zA-Z0-9.:-]/', '', $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME']);
$path = str_replace('\\', '/', dirname(dirname($_SERVER['REQUEST_URI'])));
$site_url = rtrim($protocol . $host . $path, '/');

if (!$username || !$password) {
die('请填写所有必填字段');
}

$dirs = [
'../content',
'../content/themes',
'../content/plugins',
'../content/uploads',
'../content/database'
];

foreach ($dirs as $dir) {
if (!file_exists(dirname(__FILE__) . '/' . $dir)) {
mkdir(dirname(__FILE__) . '/' . $dir, 0755, true);
}
}

try {
$db_name = 'blog_' . bin2hex(random_bytes(8)) . '.db';
$db_file = dirname(__FILE__) . '/../content/database/' . $db_name;
$db = new PDO('sqlite:' . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$tables = [
"CREATE TABLE IF NOT EXISTS posts (
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT NOT NULL,
content TEXT,
author INTEGER,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP,
status TEXT DEFAULT 'draft',
type TEXT DEFAULT 'post',
slug TEXT NOT NULL UNIQUE,
excerpt TEXT,
sticky_order INTEGER DEFAULT 0,
FOREIGN KEY (author) REFERENCES users(id) ON DELETE SET NULL
)",
"CREATE INDEX IF NOT EXISTS idx_posts_type_status_created ON posts (type, status, created)",
"CREATE TABLE IF NOT EXISTS postmeta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
post_id INTEGER NOT NULL,
meta_key TEXT,
meta_value TEXT,
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_postmeta_post_id ON postmeta (post_id)",
"CREATE INDEX IF NOT EXISTS idx_postmeta_meta_key ON postmeta (meta_key)",
"CREATE TABLE IF NOT EXISTS users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT UNIQUE NOT NULL,
password TEXT NOT NULL,
email TEXT UNIQUE NOT NULL,
display_name TEXT NOT NULL,
status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive', 'banned')),
created DATETIME DEFAULT CURRENT_TIMESTAMP,
role TEXT DEFAULT 'administrator'
)",
"CREATE TABLE IF NOT EXISTS usermeta (
meta_id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL,
meta_key TEXT,
meta_value TEXT,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_usermeta_user_id ON usermeta (user_id)",
"CREATE INDEX IF NOT EXISTS idx_usermeta_meta_key ON usermeta (meta_key)",
"CREATE TABLE IF NOT EXISTS options (
name TEXT PRIMARY KEY,
value TEXT
)",
"CREATE TABLE IF NOT EXISTS categories (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE,
parent_id INTEGER DEFAULT 0,
description TEXT
)",
"CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug)",
"CREATE TABLE IF NOT EXISTS post_categories (
post_id INTEGER,
category_id INTEGER,
PRIMARY KEY (post_id, category_id),
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_post_categories_category ON post_categories(category_id)",
"CREATE TABLE IF NOT EXISTS tags (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE
)",
"CREATE INDEX IF NOT EXISTS idx_tags_slug ON tags(slug)",
"CREATE TABLE IF NOT EXISTS post_tags (
post_id INTEGER,
tag_id INTEGER,
PRIMARY KEY (post_id, tag_id),
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
)",
"CREATE INDEX IF NOT EXISTS idx_post_tags_tag ON post_tags(tag_id)",
"CREATE TABLE IF NOT EXISTS plugins (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT NOT NULL,
slug TEXT NOT NULL UNIQUE,
description TEXT,
version TEXT NOT NULL,
author TEXT,
author_url TEXT,
plugin_uri TEXT,
status TEXT DEFAULT 'inactive',
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP
)",
"CREATE INDEX IF NOT EXISTS idx_plugins_slug ON plugins(slug)",
"CREATE INDEX IF NOT EXISTS idx_plugins_status ON plugins(status)", 
"CREATE TABLE IF NOT EXISTS comments (
id INTEGER PRIMARY KEY AUTOINCREMENT,
post_id INTEGER NOT NULL,
user_id INTEGER,
author TEXT,
email TEXT,
content TEXT NOT NULL,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
status TEXT DEFAULT 'pending',
FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)",
"CREATE INDEX IF NOT EXISTS idx_comments_post_status_created ON comments (post_id, status, created)",
"CREATE INDEX IF NOT EXISTS idx_comments_status ON comments(status)",
"CREATE TABLE IF NOT EXISTS sidebar_widgets (
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT,
type TEXT NOT NULL,
content TEXT,
`order` INTEGER DEFAULT 0,
created DATETIME DEFAULT CURRENT_TIMESTAMP,
modified DATETIME DEFAULT CURRENT_TIMESTAMP
)",
"CREATE INDEX IF NOT EXISTS idx_sidebar_widgets_order ON sidebar_widgets (`order`)",
"CREATE INDEX IF NOT EXISTS idx_posts_author ON posts (author)",

// ===== v8 性能优化索引（P-1/P-2/P-3/P-3b 配套，与 03-迁移与工具/migration-indexes.sql 一致）=====
// 为什么必须写进安装器：索引活在数据库文件里，不随代码走。v8 只改了查询写法，
// 若安装器不建这些索引，新装/重装出来的站点是「新查询 + 旧索引」——实测置顶查询
// 反而从 v7 的 26.7ms 劣化到 71.3ms（退化成 USE TEMP B-TREE FOR ORDER BY）。
// 全部 IF NOT EXISTS，可重复执行；对已装站点也无害（存量站点仍需跑一次迁移脚本）。
// 关键约束：4 个排序索引的尾列必须与 ORDER BY 同向 DESC，否则规划器会报
// "USE TEMP B-TREE FOR RIGHT PART OF ORDER BY"，实测劣化到 50ms+。
// 另：login_attempts 原先只在 admin/login.php 的读路径懒建表（这里补建，否则下面两个
// login_attempts 索引会因表不存在而执行失败；login.php 里那段 CREATE TABLE 保留作老库兜底）。
"CREATE TABLE IF NOT EXISTS login_attempts (
id INTEGER PRIMARY KEY AUTOINCREMENT,
ip TEXT NOT NULL,
username TEXT NOT NULL,
attempt_time INTEGER NOT NULL
)",
"CREATE INDEX IF NOT EXISTS idx_login_attempts_ip_time ON login_attempts (ip, attempt_time)",
"CREATE INDEX IF NOT EXISTS idx_login_attempts_user_time ON login_attempts (username, attempt_time)",
// E-3 配套：remember_tokens（原先只在 load.php 首访与 admin/login.php 登录路径懒建，
// 现在安装即建好；守卫标志不预设，首次调用 litablog_ensure_remember_tokens_schema() 时再落）
"CREATE TABLE IF NOT EXISTS remember_tokens (
selector TEXT PRIMARY KEY,
user_id INTEGER NOT NULL,
hashed_validator TEXT NOT NULL,
expires INTEGER NOT NULL
)",
"CREATE INDEX IF NOT EXISTS idx_remember_tokens_user ON remember_tokens (user_id)",
"CREATE INDEX IF NOT EXISTS idx_remember_tokens_expires ON remember_tokens (expires)",
"CREATE INDEX IF NOT EXISTS idx_posts_sticky ON posts (sticky_order, created DESC) WHERE sticky_order > 0",
"CREATE INDEX IF NOT EXISTS idx_posts_normal ON posts (type, status, created DESC, id DESC) WHERE sticky_order = 0",
"CREATE INDEX IF NOT EXISTS idx_posts_created ON posts (created DESC, id DESC)",
"CREATE INDEX IF NOT EXISTS idx_posts_type_created ON posts (type, created DESC, id DESC)",
// E-4 配套：后台「按标题排序」原先无任何可用索引 → 48ms（TEMP B-TREE，2 万帖规模）。
// (type, title) 让 type 等值 + title 排序同索引完成；status 过滤仍在索引上回表判定，无需额外索引。
"CREATE INDEX IF NOT EXISTS idx_posts_type_title ON posts (type, title)",
"CREATE INDEX IF NOT EXISTS idx_posts_status_created ON posts (status, created DESC)",
"CREATE INDEX IF NOT EXISTS idx_comments_status_created ON comments (status, created DESC)",
"CREATE INDEX IF NOT EXISTS idx_post_categories_post_category ON post_categories (post_id, category_id)",
"CREATE INDEX IF NOT EXISTS idx_post_tags_post_tag ON post_tags (post_id, tag_id)",
"ANALYZE",
];

foreach ($tables as $sql) {
$db->exec($sql);
}

// ===== E-1 搜索索引(中文 2-gram)+ E-2 计数器触发器(建表与触发器集中定义,install 共用)=====
// 注意:这里建表+建触发器。全新安装(0 帖)之后发帖由触发器自动维护,无需回填;
// 若把「已有数据的库」接入本功能(旧库/导入),请运行 help/scripts/db_search_index_backfill.php
// 与 db_counter_backfill.php 做存量回填(backfill 内含建列与重算,幂等)。
$search_defs = @require_once dirname(__FILE__) . '/../includes/search_triggers.php';
if (is_array($search_defs)) {
foreach ($search_defs[0] as $ddl) { // 表 DDL
try { $db->exec($ddl); } catch (Exception $e) { error_log("search index ddl error: " . $e->getMessage()); }
}
foreach ($search_defs[1] as $tsql) { // 触发器
try { $db->exec($tsql); } catch (Exception $e) { error_log("search trigger error: " . $e->getMessage()); }
}
}

// E-2 计数器:先确保计数列存在(SQLite ALTER 无 IF NOT EXISTS,需 PRAGMA 探测后幂等加列)。
// 注意顺序:必须先加列、再建触发器 —— 否则 INSERT post_categories 即触发 cnt_pc_ai 引用不存在列 → no such column。
foreach ([['categories', 'post_count', 'post_count INTEGER NOT NULL DEFAULT 0'],
['tags', 'post_count', 'post_count INTEGER NOT NULL DEFAULT 0']] as $cc) {
$has_col = false;
foreach ($db->query("PRAGMA table_info({$cc[0]})") as $ci) {
if ($ci['name'] === $cc[1]) { $has_col = true; break; }
}
if (!$has_col) {
try { $db->exec("ALTER TABLE {$cc[0]} ADD COLUMN {$cc[2]}"); }
catch (Exception $e) { error_log("counter add column {$cc[0]}.{$cc[1]} error: " . $e->getMessage()); }
}
}
$counter_defs = @require_once dirname(__FILE__) . '/../includes/counter_triggers.php';
if (is_array($counter_defs)) {
foreach ($counter_defs as $tsql) {
try { $db->exec($tsql); } catch (Exception $e) { error_log("counter trigger error: " . $e->getMessage()); }
}
}

$stmt = $db->prepare('INSERT INTO users (username, password, email, display_name, role) VALUES (?, ?, ?, ?, ?)');
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
$stmt->execute([$username, $hashed_password, $email, $username, 'administrator']);

$default_options = [
['site_title', '小博客'],
['site_description', 'Lita web hosting'],
['admin_email', 'hi@lita.eu.org'],
['current_theme', 'default'],
['posts_per_page', '10'],
['date_format', 'Y-m-d'],
['time_format', 'H:i:s'],
['nav_menu', '[]'],
['enable_comments', '0'],
['enable_registration', '0'],
['site_timezone', 'Asia/Shanghai']
];
$stmt = $db->prepare('INSERT INTO options (name, value) VALUES (?, ?)');
foreach ($default_options as $option) {
$stmt->execute($option);
}
// 安装锁 - 标记系统已安装
$db->exec("INSERT OR REPLACE INTO options (name, value) VALUES ('system_installed', '1')");
$default_widgets = [
[
'title' => '芙里塔',
'type' => 'text',
'content' => '芙摇别素月，塔影待星归。',
'order' => 1
]
];

$stmt = $db->prepare('INSERT INTO sidebar_widgets (title, type, content, `order`) VALUES (?, ?, ?, ?)');
foreach ($default_widgets as $widget) {
$stmt->execute([$widget['title'], $widget['type'], $widget['content'], $widget['order']]);
}

if (!file_exists(dirname(__FILE__) . '/../config.php')) {
$config_sample = file_get_contents(dirname(__FILE__) . '/../config-sample.php');
$auth_key = bin2hex(random_bytes(32));
$secure_auth_key = bin2hex(random_bytes(32));

$config = str_replace(
["define('SITE_URL', '');", "define('AUTH_KEY', '');", "define('SECURE_AUTH_KEY', '');", "define('DB_FILE', ABSPATH . 'content/database/blog.db');"],
["define('SITE_URL', '" . $site_url . "');", "define('AUTH_KEY', '" . $auth_key . "');", "define('SECURE_AUTH_KEY', '" . $secure_auth_key . "');", "define('DB_FILE', ABSPATH . 'content/database/" . $db_name . "');"],
$config_sample
);

if (!file_put_contents(dirname(__FILE__) . '/../config.php', $config)) {
die('无法创建配置文件');
}
chmod($db_file, 0600);
}

// 在 admin/install.php 创建数据库目录后写入防护文件：
$db_htaccess = dirname(__FILE__) . '/../content/database/.htaccess';
if (!file_exists($db_htaccess)) {
    file_put_contents($db_htaccess, "Require all denied\n");
}

// 整页缓存目录防护（2026-09-13 补）：page_cache.php 头部注释一直声称该文件存在，
// 实际缺失 —— 匿名可直接列出 /content/cache/ 并猜名读取缓存 HTML。
// 缓存命中由 PHP readfile() 输出（includes/page_cache.php），不依赖 Apache 静态直出，
// 因此这里可以彻底拒绝 web 直访。与 index.php 的 deny_dirs 构成双层防护。
$cache_dir = dirname(__FILE__) . '/../content/cache';
if (!is_dir($cache_dir)) { @mkdir($cache_dir, 0755, true); }
$cache_htaccess = $cache_dir . '/.htaccess';
if (!file_exists($cache_htaccess)) {
    file_put_contents($cache_htaccess,
        "Options -Indexes\n"
        . "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
        . "<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n");
}


header('Location: ../admin/login.php');
exit;

} catch (PDOException $e) {
    error_log('Installation Database Error: ' . $e->getMessage());
    die('数据库建立失败，请检查数据库文件夹写入权限或查看本地错误日志。');
}
}

// 调度安装页面视图
include dirname(__FILE__) . '/views/install.php';