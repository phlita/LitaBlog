<?php
// admin/settings.php
require_once 'header.php';
do_action('admin_init_settings');
if (!is_admin()) {
header('Location: index.php?type=post&error=adminonly');
exit;
}

$feedback_message = '';
$feedback_type = '';
$current_settings = [];

$managed_settings = [
'site_title'        => ['default' => 'My Lita Blog', 'type' => 'text'],
'site_description'  => ['default' => 'Just another Lita Blog', 'type' => 'text'],
'posts_per_page'    => ['default' => 10, 'type' => 'number'],
'date_format'       => ['default' => 'Y-m-d', 'type' => 'text'],
'time_format'       => ['default' => 'H:i', 'type' => 'text'],
'permalink_type'    => ['default' => Permalink::TYPE_DEFAULT, 'type' => 'radio'],
'enable_comments'   => ['default' => '1', 'filter' => null, 'type' => 'checkbox'],
'enable_registration' => ['default' => '0', 'filter' => null, 'type' => 'checkbox'],
'site_timezone'     => ['default' => 'Asia/Shanghai', 'type' => 'select']
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	 if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'admin_settings')) {
        $feedback_message = '安全令牌验证失败，请重试。';
        $feedback_type = 'error';
    } else {
$settings_to_save = [];
$validation_errors = [];

foreach ($managed_settings as $name => $config) {
if ($config['type'] === 'checkbox') {
$settings_to_save[$name] = isset($_POST[$name]) ? '1' : '0';
}
}

foreach ($managed_settings as $name => $config) {
if ($config['type'] !== 'checkbox') {
/*
if (isset($_POST[$name])) {
if ($config['filter']) {
$settings_to_save[$name] = filter_input(INPUT_POST, $name, $config['filter']);
} else {
$settings_to_save[$name] = $_POST[$name];
}
} else {
$settings_to_save[$name] = $config['default'];
}*/
if (isset($_POST[$name])) {
    if ($config['type'] === 'number') {
        $settings_to_save[$name] = filter_var(
            $_POST[$name],
            FILTER_VALIDATE_INT,
            FILTER_NULL_ON_FAILURE
        );

        if ($settings_to_save[$name] === null) {
            $settings_to_save[$name] = 0;
        }

    } else {
        $settings_to_save[$name] = sanitize_text_field($_POST[$name]);
    }
} else {
    $settings_to_save[$name] = $config['default'];
}

}

if ($name === 'posts_per_page' && (int)$settings_to_save[$name] < 1) {
$validation_errors[] = 'Posts Per Page must be at least 1.';
$settings_to_save[$name] = $config['default'];
}
if ($name === 'permalink_type' && !in_array($settings_to_save[$name], [Permalink::TYPE_DEFAULT, Permalink::TYPE_NUMERIC, Permalink::TYPE_POST])) {
$validation_errors[] = 'Invalid Permalink Structure selected.';
$settings_to_save[$name] = $config['default'];
}
if ($name === 'site_timezone') {
if (!in_array($settings_to_save[$name], DateTimeZone::listIdentifiers(DateTimeZone::ALL))) {
$validation_errors[] = '选择的时区无效。';
$settings_to_save[$name] = $config['default'];
}
}
}

global $wp_settings_fields;
$settings_page_slug_for_plugins = 'general_settings'; 

if (isset($wp_settings_fields[$settings_page_slug_for_plugins])) {
foreach ($wp_settings_fields[$settings_page_slug_for_plugins] as $section_id => $fields_in_section) {
foreach ($fields_in_section as $field_id => $field_data) {
$option_name = $field_id;
$field_type = $field_data['args']['type'] ?? 'text';

if (isset($_POST[$option_name])) {
$value_from_post = $_POST[$option_name];
if ($field_type === 'checkbox') {
$value_to_save = '1';
} elseif (is_array($value_from_post)) {
$value_to_save = $value_from_post;
} else {
$value_to_save = sanitize_text_field($value_from_post);
}
update_option($option_name, $value_to_save);
} elseif ($field_type === 'checkbox') {
update_option($option_name, '0');
}
}
}
}

if (!empty($validation_errors)) {
$feedback_message = "Settings save failed: <br>" . implode('<br>', $validation_errors);
$feedback_type = 'error';
$current_settings = $settings_to_save; 
} else {
try {
$db = get_db();
$db->beginTransaction();
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
$all_saved = true;
foreach ($settings_to_save as $name => $value) {
if (!$stmt->execute([$name, $value])) {
$all_saved = false;
break;
}
}

if ($all_saved) {
$db->commit();
// 统一缓存层:本页主保存路径直接 SQL 写 options(批量事务),不经 update_option,
// 必须显式失效 options_full 快照,否则后台\"保存成功\"后前台最长 60s 读旧值
// （2026-09-16 升级：改用统一助手，连请求内静态数组一起失效）
if (function_exists('litablog_options_cache_invalidate')) { litablog_options_cache_invalidate(); }
// 2026-09-16 同步 v10：本页保存的是 enable_comments / current_theme / posts_per_page 等
// 会整体改变页面输出的选项 → 整页缓存（TTL 自愈）必须显式清，否则匿名访客最长 TTL 内看到旧页面。
if (function_exists('litablog_purge_page_cache')) { litablog_purge_page_cache(); }
$feedback_message = 'Settings updated successfully.';
$feedback_type = 'success';
litablog_generate_rewrite_rules($settings_to_save['permalink_type']);
} else {
$db->rollBack();
$feedback_message = 'Settings save failed (database execution error).';
$feedback_type = 'error';
$current_settings = $settings_to_save;
}
} catch (PDOException $e) {
$db->rollBack();
$feedback_message = 'Settings save failed: Database error.';
$feedback_type = 'error';
$current_settings = $settings_to_save;
}
}
}
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || $feedback_type === 'success') {
$setting_names = array_keys($managed_settings);
$placeholders = rtrim(str_repeat('?,', count($setting_names)), ',');

$db = get_db();
$stmt = $db->prepare("SELECT name, value FROM options WHERE name IN ($placeholders)");
$stmt->execute($setting_names);
$all_options_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

$all_options = [];
foreach ($all_options_raw as $row) {
$all_options[$row['name']] = $row['value'];
}

foreach ($managed_settings as $name => $config) {
$current_settings[$name] = $all_options[$name] ?? $config['default'];
}
}

// 调度系统设置视图
include dirname(__FILE__) . '/views/settings.php';
require_once 'foot.php';