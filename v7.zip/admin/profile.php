<?php
// admin/profile.php
require_once 'header.php';

$feedback_message = [];
$feedback_type = '';
$user_data_for_form = [];
$current_user_id = $_SESSION['user_id'] ?? null;

if (!$current_user_id) {
header('Location: login.php'); 
exit;
}

$initial_user_data = get_user($current_user_id);
if (!$initial_user_data) {
header('Location: logout.php'); 
exit;
}
$user_data_for_form = $initial_user_data;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
$errors = [];

if ($_POST['action'] === 'update_profile') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'update_profile')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
$new_username = trim(sanitize_text_field($_POST['username'] ?? ''));
$new_display_name = trim(sanitize_text_field($_POST['display_name'] ?? ''));
$new_email = trim(sanitize_email_field($_POST['email'] ?? ''));

$user_data_for_form['username'] = $new_username;
$user_data_for_form['display_name'] = $new_display_name;
$user_data_for_form['email'] = $new_email;

if (empty($new_username)) $errors[] = '用户名不能为空。';
if (empty($new_display_name)) $errors[] = '显示名称不能为空。';
if (empty($new_email)) {
$errors[] = '电子邮箱不能为空。';
} elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
$errors[] = '电子邮箱格式不正确。';
}

if (empty($errors)) {
try {
$db = get_db();
$stmt_check = $db->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ? LIMIT 1');
$stmt_check->execute([$new_username, $new_email, $current_user_id]);
if ($stmt_check->fetch()) {
$errors[] = '用户名或电子邮箱已被其他用户使用。';
}

if (empty($errors)) {
$stmt_update = $db->prepare('UPDATE users SET username = ?, display_name = ?, email = ? WHERE id = ?');
if ($stmt_update->execute([$new_username, $new_display_name, $new_email, $current_user_id])) {
$feedback_message = '用户资料更新成功。';
$feedback_type = 'success';
if ($new_username !== $initial_user_data['username']) {
$_SESSION['username'] = $new_username;
}
$user_data_for_form = get_user($current_user_id);
} else {
$errors[] = '资料更新失败，数据库执行错误。';
}
}
} catch (PDOException $e) {
error_log('Profile update error: ' . $e->getMessage()); // Mitigates V-22
$errors[] = '系统数据库操作失败，请重试。';
}
}
}
} 

elseif ($_POST['action'] === 'change_password') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'change_password')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
$current_password = $_POST['current_password'] ?? '';
$new_password = $_POST['new_password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
$errors[] = '所有密码字段均为必填项。';
} elseif ($new_password !== $confirm_password) {
$errors[] = '新密码和确认密码不匹配。';
} else {
try {
$db = get_db();
$stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
$stmt->execute([$current_user_id]);
$stored_hash = $stmt->fetchColumn();

if ($stored_hash && password_verify($current_password, $stored_hash)) {
$new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
$stmt_update = $db->prepare('UPDATE users SET password = ? WHERE id = ?');

if ($stmt_update->execute([$new_password_hash, $current_user_id])) {
$feedback_message = '密码更新成功。';
$feedback_type = 'success';
$user_data_for_form = $initial_user_data;
} else {
$errors[] = '密码更新失败，数据库错误。';
}
} else {
$errors[] = '当前密码不正确。';
}
} catch (PDOException $e) {
error_log('Profile password change error: ' . $e->getMessage()); // Mitigates V-22
$errors[] = '系统数据库操作失败，请重试。';
}
}
}
}

// Fixed Security: Enhanced 2FA action stream with strict CSRF protection
elseif ($_POST['action'] === 'setup_2fa') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'setup_2fa')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
require_once dirname(__FILE__) . '/../includes/totp.php';
$_SESSION['temp_2fa_secret'] = LitaTOTP::generateSecret();
$feedback_message = '2FA 密钥已生成。请在下方使用扫码或手动输入，并在确认后输入 6 位验证码以完成绑定。';
$feedback_type = 'success';
}
}

elseif ($_POST['action'] === 'confirm_2fa') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'confirm_2fa')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
$code = trim($_POST['otp_code'] ?? '');
$secret = $_SESSION['temp_2fa_secret'] ?? '';
require_once dirname(__FILE__) . '/../includes/totp.php';

if (!empty($secret) && LitaTOTP::verifyCode($secret, $code)) {
update_user_meta($current_user_id, 'two_factor_secret', $secret);
unset($_SESSION['temp_2fa_secret']);
$feedback_message = '双重验证（2FA）绑定成功！安全策略已启用，下次登录生效。';
$feedback_type = 'success';
$user_data_for_form = get_user($current_user_id);
} else {
$errors[] = '验证码错误，请重新输入。请确认您的手机系统时间与服务器已保持同步。';
}
}
}

elseif ($_POST['action'] === 'disable_2fa') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'disable_2fa')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
$password_confirm = $_POST['password_confirm'] ?? '';
$db = get_db();
$stmt = $db->prepare('SELECT password FROM users WHERE id = ?');
$stmt->execute([$current_user_id]);
$stored_hash = $stmt->fetchColumn();

if ($stored_hash && password_verify($password_confirm, $stored_hash)) {
delete_user_meta($current_user_id, 'two_factor_secret');
$feedback_message = '双重验证（2FA）已成功关闭。';
$feedback_type = 'success';
$user_data_for_form = get_user($current_user_id);
} else {
$errors[] = '密码验证失败，无法关闭双重验证。';
}
}
}

elseif ($_POST['action'] === 'cancel_2fa') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'cancel_2fa')) {
$errors[] = '安全令牌验证失败，请重试。';
} else {
if (isset($_SESSION['temp_2fa_secret'])) {
unset($_SESSION['temp_2fa_secret']);
}
header('Location: profile.php');
exit;
}
}

// If validation failed, pass raw errors as array to prevent Reflex XSS (Mitigates V-06)
if (!empty($errors)) {
$feedback_message = $errors;
$feedback_type = 'error';
}
}

include dirname(__FILE__) . '/views/profile.php';
require_once 'foot.php';
?>