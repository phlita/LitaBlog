<?php
/**
 * Plugin Name: Cloud Drive (网盘插件)
 * Plugin URI: https://lita.eu.org/
 * Description: 文件网盘系统。支持后台上传管理、[download] 短代码插入文章（图片/音频/视频自动内嵌展示，其余生成下载卡片）、编辑器工具栏上传按钮、Agent API 供 AI 上传/下载文件。支持文件密码保护。
 * Version: 2.1
 * Author: Lita
 */

if (!defined('ABSPATH')) exit;

define('CLOUD_DRIVE_DIR', __DIR__ . '/');
define('CLOUD_DRIVE_STORAGE', ABSPATH . 'content/uploads/cloud/');
define('CLOUD_DRIVE_URL', rtrim(SITE_URL, '/') . '/content/uploads/cloud/');

// =========================================================================
// 1. 建表 + 创建存储目录（幂等；激活与每次加载都会调用，防 DB 重建后丢表）
// =========================================================================
function cloud_drive_ensure_schema() {
    if (!defined('ABSPATH')) return;
    try {
        $db = get_db();
        $db->exec("CREATE TABLE IF NOT EXISTS cloud_files (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            filename    TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            filepath    TEXT NOT NULL,
            filesize    INTEGER DEFAULT 0,
            mime_type   TEXT DEFAULT 'application/octet-stream',
            download_count INTEGER DEFAULT 0,
            description TEXT DEFAULT '',
            password    TEXT DEFAULT '',
            uploader_id INTEGER DEFAULT 0,
            created     DATETIME DEFAULT CURRENT_TIMESTAMP,
            modified    DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // 兼容旧版：尝试添加 password 字段（已存在则忽略）
        try { $db->exec("ALTER TABLE cloud_files ADD COLUMN password TEXT DEFAULT ''"); } catch (Exception $e) {}
    } catch (Throwable $e) {
        return; // DB 未就绪等场景静默跳过,不阻塞站点
    }

    if (!is_dir(CLOUD_DRIVE_STORAGE)) {
        @mkdir(CLOUD_DRIVE_STORAGE, 0755, true);
        cloud_drive_write_storage_htaccess();
        @file_put_contents(CLOUD_DRIVE_STORAGE . 'index.php', '<?php // Silence');
    }
}

/**
 * 网盘模式开关(get_option('cloud_drive_mode'),默认 '0'):
 *   0 = 直链省资源模式:无密码文件走 Apache 静态直出(0 PHP 进程/Entry Process),
 *       下载计数用微型 204 beacon;密码文件仍强制走保护路由。
 *   1 = 完整保护模式:全部下载经 token 校验 + 密码表单 + 爆破锁定(PHP readfile)。
 * 说明:token/HMAC 本身是微秒级,真正的服务器负担是大文件 readfile 占住 PHP 进程——
 * 直链模式优化的就是这一项。
 */
function cloud_drive_direct_mode() {
    if (!function_exists('get_option')) return false; // 极早期调用(无 options):按保护模式写盘(fail-safe)
    return get_option('cloud_drive_mode', '0') !== '1';
}

/** 按模式写存储目录 .htaccess(切换模式时同步改写):直链模式放开静态访问但禁列目录+禁 PHP */
function cloud_drive_write_storage_htaccess() {
    if (cloud_drive_direct_mode()) {
        $rules = "Options -Indexes\n"
               . "<FilesMatch \"\\.(php|phtml|phar|pht|cgi|pl)\$\">\n"
               . "Require all denied\n"
               . "</FilesMatch>\n";
    } else {
        $rules = "# Block direct web access to cloud-drive files.\n"
               . "# Must download via authenticated router: ?cloud_download=ID&token=xxx (PHP readfile, unaffected).\n"
               . "# Complements index.php intercept layer (which covers nginx / PHP builtin server).\n"
               . "Options -Indexes\n"
               . "Require all denied\n";
    }
    @file_put_contents(CLOUD_DRIVE_STORAGE . '.htaccess', $rules);
}

function cloud_drive_activate() {
    cloud_drive_ensure_schema();
}
register_activation_hook(__FILE__, 'cloud_drive_activate');

// 加载即自愈：DB 可能被重建/拷贝而丢表(见 09-08:active 状态随库带入但表从未建)。
// 在 init 前先确保表存在——仅当表缺失才执行 CREATE(幂等),成本可忽略。
try {
    $cd_db = get_db();
    $cd_has = (int)$cd_db->query("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='cloud_files'")->fetchColumn();
    if (!$cd_has) cloud_drive_ensure_schema();
} catch (Throwable $e) {
    // 静默:get_db 不可用(如安装页早期)时不阻塞
}

// =========================================================================
// 2. 注册短代码 + 内容过滤器
// =========================================================================
/**
 * 生成文件下载令牌(全站唯一实现,M-2 统一 HMAC)。
 * 修复说明:此前生成端 6 处用 md5($id.$stored_name)、校验端单独改成 hash_hmac,
 * 导致「校验端与生成端算法不一致」→ 所有下载链接 403。现统一收敛到本函数。
 */
function cloud_token($file_id, $stored_name) {
    return hash_hmac('sha256', (int)$file_id . '|' . $stored_name, AUTH_KEY);
}

/** M-3 统一净化:剥离引号/CRLF,生成双段 Content-Disposition 头(Agent API 与前端路由共用,杜绝双实现漂移) */
function cloud_safe_disposition($filename) {
    $safe_fn = str_replace(['"', "\r", "\n"], '', (string)$filename);
    return 'attachment; filename="' . $safe_fn . '"; filename*=UTF-8\'\'' . rawurlencode((string)$filename);
}

/** mime_type 用户可控,下载直出 Content-Type 前做白名单字符净化(非法回落 octet-stream) */
function cloud_safe_mime($mime) {
    return preg_match('/^[\w.\/+-]{1,100}$/', (string)$mime) ? (string)$mime : 'application/octet-stream';
}

// ── 内嵌媒体（图片/音频/视频直接展示）────────────────────────────────────────
/**
 * 媒体类型判定：编辑器按钮、短代码渲染、AJAX 列表共用同一判据，
 * 避免「编辑器认为是视频、前端按文件下载」的两套判断漂移。
 */
function cloud_drive_media_type($filename, $mime = '') {
    $ext  = strtolower(pathinfo((string)$filename, PATHINFO_EXTENSION));
    $mime = strtolower((string)$mime);
    if (strpos($mime, 'image/') === 0 || in_array($ext, ['jpg','jpeg','png','gif','webp','svg','bmp','avif','ico'], true)) return 'image';
    if (strpos($mime, 'audio/') === 0 || in_array($ext, ['mp3','wav','flac','aac','ogg','oga','m4a','opus','wma'], true)) return 'audio';
    if (strpos($mime, 'video/') === 0 || in_array($ext, ['mp4','webm','ogv','mov','m4v','mkv','avi'], true)) return 'video';
    return 'file';
}

/**
 * 播放/展示要正确的 Content-Type：DB 里的 mime 来自浏览器上报，可能是空或 octet-stream，
 * 此时按扩展名兜底，否则 <video>/<audio> 会拒绝播放。
 */
function cloud_drive_effective_mime($file) {
    $mime = cloud_safe_mime($file['mime_type'] ?? '');
    if ($mime !== 'application/octet-stream') return $mime;
    $map = [
        'jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','webp'=>'image/webp',
        'svg'=>'image/svg+xml','avif'=>'image/avif','bmp'=>'image/bmp',
        'mp3'=>'audio/mpeg','wav'=>'audio/wav','flac'=>'audio/flac','aac'=>'audio/aac','ogg'=>'audio/ogg',
        'oga'=>'audio/ogg','m4a'=>'audio/mp4','opus'=>'audio/ogg',
        'mp4'=>'video/mp4','webm'=>'video/webm','ogv'=>'video/ogg','mov'=>'video/quicktime','m4v'=>'video/mp4','mkv'=>'video/x-matroska',
    ];
    $ext = strtolower(pathinfo((string)($file['filename'] ?? ''), PATHINFO_EXTENSION));
    return $map[$ext] ?? $mime;
}

/**
 * 资源访问地址（下载与内嵌共用一个入口，不额外开直链旁路）：
 *   $inline=false → 下载地址（强制 attachment + 计数）
 *   $inline=true  → 内嵌地址（Content-Disposition: inline，供 <img>/<audio>/<video>）
 * 直链省资源模式下无密码文件仍给静态直链（Apache 直出，0 PHP 进程，且原生支持 Range）。
 */
function cloud_drive_stream_url($file, $inline = false) {
    if ($inline && empty($file['password']) && cloud_drive_direct_mode()) {
        return CLOUD_DRIVE_URL . $file['filepath'];
    }
    $url = SITE_URL . '?cloud_download=' . (int)$file['id'] . '&token=' . cloud_token($file['id'], $file['stored_name']);
    return $inline ? $url . '&inline=1' : $url;
}

/** 解析 [download id=3 mode=embed] 属性（兼容 id=3 / id="3" / id='3'；mode 可省略） */
function cloud_drive_shortcode_atts($raw) {
    $atts = ['id' => 0, 'mode' => 'auto'];
    if (preg_match('/\bid\s*=\s*["\']?(\d+)/i', (string)$raw, $m)) { $atts['id'] = (int)$m[1]; }
    if (preg_match('/\bmode\s*=\s*["\']?([a-z]+)/i', (string)$raw, $m)) { $atts['mode'] = strtolower($m[1]); }
    return $atts;
}

/**
 * 渲染内嵌媒体（图片/音频/视频），带文件名、体积与「下载」入口。
 *
 * ⚠ 关键约束：短代码在 prepare_template_data() 里由 do_shortcode() 展开，
 * 展开结果随后会经过核心净化器 litablog_purify_html()（the_content, priority 9，白名单机制）。
 * 所以这里**只能产出白名单内的标签与属性**，否则会被静默破坏：
 *   - figure / figcaption 不在白名单 → 净化器用「纯文本」替换整个标签，里面的
 *     img/audio/video/a 一并销毁 → 前端只剩「文件名 体积 下载」的文字，链接与播放器全丢。
 *   - 白名单内可用：div、span、a(href/title/target/class/style)、img(src/alt/title/class/style/width/height)、
 *     audio(src/controls/preload/class)、video(src/controls/width/height/poster/preload/class)。
 *   - loading / decoding / playsinline 等属性默认会被剥离（已同步加入核心白名单）。
 */
function cloud_drive_render_media($file, $type, $label = '') {
    $src     = cloud_drive_stream_url($file, true);
    $dl      = cloud_drive_stream_url($file, false);
    $caption = ($label !== '' && $label !== null) ? $label : $file['filename'];
    $ext     = strtoupper((string)pathinfo($file['filename'], PATHINFO_EXTENSION));

    if ($type === 'audio') {
        $media = '<audio class="cloud-media-el" controls preload="metadata" src="' . e($src) . '"></audio>';
    } elseif ($type === 'video') {
        $media = '<video class="cloud-media-el" controls preload="metadata" playsinline src="' . e($src) . '"></video>';
    } else {
        $media = '<img class="cloud-media-el" src="' . e($src) . '" alt="' . e($caption) . '" loading="lazy" decoding="async">';
    }

    return '<div class="cloud-media cloud-media-' . e($type) . '">' . $media
        . '<div class="cloud-media-bar">'
        . '<span class="cloud-media-name">' . e($caption) . '</span>'
        . '<span class="cloud-media-meta">' . cloud_format_filesize($file['filesize'])
        . ($ext !== '' ? ' · ' . e($ext) : '') . '</span>'
        . '<a class="cloud-media-dl" href="' . e($dl) . '" target="_blank" rel="noopener">下载</a>'
        . '</div></div>';
}

/**
 * 流式输出（下载与内嵌共用）：支持 HTTP Range。
 * 视频拖动进度条依赖 206 分段响应，否则每次 seek 都要重下整个文件。
 */
function cloud_drive_stream_file($path, $mime, $filename, $inline = false) {
    $size    = (int)@filesize($path);
    $safe_fn = str_replace(['"', "\r", "\n"], '', (string)$filename);

    header('Content-Type: ' . $mime);
    if ($inline) {
        header('Content-Disposition: inline; filename="' . $safe_fn . '"');
        header('Cache-Control: private, max-age=3600');
    } else {
        // M-3：统一走 cloud_safe_disposition()（与 Agent API 共用，杜绝双实现漂移）
        header('Content-Disposition: ' . cloud_safe_disposition($filename));
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
    header('Accept-Ranges: bytes');

    $start = 0;
    $end   = $size > 0 ? $size - 1 : 0;
    $range = $_SERVER['HTTP_RANGE'] ?? '';
    if ($range !== '' && preg_match('/bytes=(\d*)-(\d*)/', $range, $m)) {
        if ($m[1] === '' && $m[2] !== '') {
            $start = max(0, $size - (int)$m[2]);              // bytes=-N（末尾 N 字节）
        } else {
            $start = (int)$m[1];
            if ($m[2] !== '') { $end = min((int)$m[2], $size - 1); }
        }
        if ($size <= 0 || $start > $end || $start >= $size) {  // 越界 → 416
            http_response_code(416);
            header('Content-Range: bytes */' . $size);
            exit;
        }
        http_response_code(206);
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    header('Content-Length: ' . max(0, $end - $start + 1));

    $fp = @fopen($path, 'rb');
    if (!$fp) { exit; }
    if ($start > 0) { fseek($fp, $start); }
    $remain = $end - $start + 1;
    while ($remain > 0 && !feof($fp)) {
        $chunk = fread($fp, (int)min(65536, $remain));
        if ($chunk === false || $chunk === '') { break; }
        echo $chunk;
        $remain -= strlen($chunk);
        if (connection_status() !== CONNECTION_NORMAL) { break; }
        @ob_flush();
        @flush();
    }
    fclose($fp);
    exit;
}
function cloud_drive_init() {
    add_shortcode('download', 'cloud_drive_download_shortcode');
    add_filter('before_render_template_data', 'cloud_drive_pre_markdown_process', 5);
    add_filter('the_content', 'cloud_drive_process_download_shortcode', 30);
}
add_action('init', 'cloud_drive_init');

function cloud_drive_pre_markdown_process($template_data) {
    if (empty($template_data['post']['content'])) return $template_data;
    $content = $template_data['post']['content'];
    $content = cloud_drive_replace_download_shortcodes($content);
    $template_data['post']['content'] = $content;
    return $template_data;
}

function cloud_drive_process_download_shortcode($content) {
    // 已是渲染结果（下载卡片或内嵌媒体）且不再含短代码 → 跳过二次处理
    if (strpos($content, '[download') === false
        && (strpos($content, 'cloud-download-box') !== false || strpos($content, 'cloud-media') !== false)) {
        return $content;
    }
    return cloud_drive_replace_download_shortcodes($content);
}

function cloud_drive_replace_download_shortcodes($content) {
    // 已是渲染结果（下载卡片或内嵌媒体）且不再含短代码 → 跳过二次处理
    if (strpos($content, '[download') === false
        && (strpos($content, 'cloud-download-box') !== false || strpos($content, 'cloud-media') !== false)) {
        return $content;
    }
    return preg_replace_callback('/\[download\s+([^\]]*)\](?:(.*?)\[\/download\])?/s', function($matches) {
        $atts = cloud_drive_shortcode_atts($matches[1]);
        $custom_text = !empty($matches[2]) ? trim($matches[2]) : null;
        return cloud_drive_download_shortcode($atts, $custom_text);
    }, $content);
}

// Agent API 拦截器（顶层直接注册）
add_action('init', 'cloud_drive_agent_api_interceptor', 2);

// =========================================================================
// 3. Agent API 拦截器
// =========================================================================
function cloud_drive_agent_api_interceptor() {
    $api_type = $_GET['agent_api'] ?? '';
    if ($api_type !== 'files') return;

    if (ob_get_level() > 0) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Authorization, Content-Type');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

    $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (empty($auth_header) && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        $auth_header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    preg_match('/Bearer\s(\S+)/', $auth_header, $matches);
    $provided_token = $matches[1] ?? '';
    // 传输回退(免费主机常态):mod_fcgid/LiteSpeed/CGI 常丢弃 Authorization 头,
    // 支持 X-API-Key 头与 ?apikey= 参数作为等效凭据(凭据本身仍是同一个 key)
    if ($provided_token === '') {
        $provided_token = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['apikey'] ?? '';
    }

    $admin_key = get_option('lita_agent_api_key_admin', '');
    $comment_key = get_option('lita_agent_api_key_comment', '');

    $api_role = '';
    if (!empty($admin_key) && $provided_token === $admin_key) $api_role = 'admin';
    elseif (!empty($comment_key) && $provided_token === $comment_key) $api_role = 'bot';
    else cloud_api_response(401, '认证失败：无效的 API Key。');

    $method = $_SERVER['REQUEST_METHOD'];

    try {
        if ($method === 'POST' && isset($_GET['action']) && $_GET['action'] === 'upload') {
            if ($api_role !== 'admin') cloud_api_response(403, '权限不足：仅 Admin Key 可上传文件');
            cloud_api_handle_upload();
        } elseif ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'download') {
            cloud_api_handle_download((int)($_GET['id'] ?? 0));
        } elseif ($method === 'GET' && isset($_GET['action']) && $_GET['action'] === 'list') {
            cloud_api_handle_list();
        } elseif ($method === 'DELETE' && isset($_GET['id'])) {
            if ($api_role !== 'admin') cloud_api_response(403, '权限不足：仅 Admin Key 可删除文件');
            cloud_api_handle_api_delete((int)$_GET['id']);
        } else {
            cloud_api_response(405, 'Method Not Allowed 或缺少 action 参数');
        }
    } catch (Exception $e) {
        cloud_api_response(500, '服务器内部错误：' . $e->getMessage());
    }
}

// --- Agent API: 文件上传 (支持密码) ---
function cloud_api_handle_upload() {
    $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
    $password = '';

    if (strpos($content_type, 'multipart/form-data') !== false) {
        if (empty($_FILES['file'])) cloud_api_response(400, '未检测到文件，请使用 file 字段上传');
        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) cloud_api_response(400, '上传错误码：' . $file['error']);
        $original_name = basename($file['name']);
        $tmp_path = $file['tmp_path'] ?? $file['tmp_name'];
        $mime_type = $file['type'] ?: 'application/octet-stream';
        $description = $_POST['description'] ?? '';
        $password = $_POST['password'] ?? '';
    } else {
        $input = json_decode(file_get_contents('php://input'), true);
        if (empty($input['filename']) || empty($input['data'])) {
            cloud_api_response(400, '缺少 filename 或 data 字段（data 为 Base64 编码内容）');
        }
        $original_name = basename(sanitize_text_field($input['filename']));
        $description = $input['description'] ?? '';
        $mime_type = $input['mime_type'] ?? 'application/octet-stream';
        $password = $input['password'] ?? '';

        $decoded = base64_decode($input['data'], true);
        if ($decoded === false) cloud_api_response(400, 'Base64 解码失败');

        $tmp_path = tempnam(sys_get_temp_dir(), 'cloud_');
        file_put_contents($tmp_path, $decoded);
    }

    // 密码哈希（空密码则不设保护）
    $password_hash = '';
    if (!empty($password)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
    }

    $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $dangerous_exts = ['php', 'php3', 'php4', 'php5', 'phtml', 'pht', 'phps', 'cgi', 'pl', 'asp', 'aspx', 'jsp', 'sh', 'bash', 'htaccess'];
    if (in_array($ext, $dangerous_exts)) {
        @unlink($tmp_path);
        cloud_api_response(403, '出于安全考虑，禁止上传此类型文件：.' . $ext);
    }

    $stored_name = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . ($ext ?: 'bin');
    $relative_path = date('Y/m/');
    $full_dir = CLOUD_DRIVE_STORAGE . $relative_path;
    if (!is_dir($full_dir)) @mkdir($full_dir, 0755, true);

    $dest_path = $full_dir . $stored_name;
    if (!move_uploaded_file($tmp_path, $dest_path)) {
        if (!rename($tmp_path, $dest_path)) {
            @unlink($tmp_path);
            cloud_api_response(500, '文件保存失败');
        }
    }

    $filesize = filesize($dest_path);
    $filepath = $relative_path . $stored_name;

    $db = get_db();
    $stmt = $db->prepare('INSERT INTO cloud_files (filename, stored_name, filepath, filesize, mime_type, description, password, uploader_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $admin_id = $_SESSION['user_id'] ?? 0;
    if ($stmt->execute([$original_name, $stored_name, $filepath, $filesize, $mime_type, $description, $password_hash, $admin_id])) {
        $file_id = $db->lastInsertId();
        $resp = [
            'id'        => (int)$file_id,
            'filename'  => $original_name,
            'filesize'  => $filesize,
            'mime_type' => $mime_type,
            'has_password' => !empty($password_hash),
            'download_url' => SITE_URL . '?cloud_download=' . $file_id . '&token=' . cloud_token($file_id, $stored_name),
            'shortcode' => '[download id=' . $file_id . ']'
        ];
        cloud_api_response(201, '上传成功', $resp);
    } else {
        @unlink($dest_path);
        cloud_api_response(500, '数据库写入失败');
    }
}

// --- Agent API: 文件下载 (支持密码验证) ---
function cloud_api_handle_download($file_id) {
    if ($file_id <= 0) cloud_api_response(400, '缺少文件 ID');

    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM cloud_files WHERE id = ?');
    $stmt->execute([$file_id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$file) cloud_api_response(404, '文件不存在');

    $full_path = ABSPATH . 'content/uploads/cloud/' . $file['filepath'];
    if (!file_exists($full_path)) cloud_api_response(404, '文件已丢失');

    // 密码验证：从 POST body 或 query 参数获取
    if (!empty($file['password'])) {
        $input = json_decode(file_get_contents('php://input'), true) ?: [];
        $provided_pw = $input['password'] ?? $_GET['password'] ?? '';
        if (empty($provided_pw) || !password_verify($provided_pw, $file['password'])) {
            cloud_api_response(403, '此文件需要密码才能下载', [
                'require_password' => true,
                'file_id' => $file_id
            ]);
        }
    }

    $db->prepare('UPDATE cloud_files SET download_count = download_count + 1 WHERE id = ?')->execute([$file_id]);

    if (isset($_GET['mode']) && $_GET['mode'] === 'url') {
        $token = cloud_token($file_id, $file['stored_name']);
        $direct = CLOUD_DRIVE_URL . $file['filepath'];
        $protected = !empty($file['password']) || !cloud_drive_direct_mode();
        cloud_api_response(200, '下载链接', [
            'id' => $file_id,
            'filename' => $file['filename'],
            'has_password' => !empty($file['password']),
            'download_url' => $protected
                ? SITE_URL . '?cloud_download=' . $file_id . '&token=' . $token
                : $direct,
            // 直链模式下直链真实可用;保护模式下被存储目录 .htaccess 拒绝,返回 null 避免误导
            'direct_url' => $protected ? null : $direct,
            'filesize' => $file['filesize']
        ]);
        return;
    }

    header('Content-Type: ' . cloud_safe_mime($file['mime_type']));
    header('Content-Disposition: ' . cloud_safe_disposition($file['filename']));
    header('Content-Length: ' . $file['filesize']);
    header('Cache-Control: no-cache');
    readfile($full_path);
    exit;
}

// --- Agent API: 文件列表 (显示密码状态) ---
function cloud_api_handle_list() {
    $db = get_db();
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = min(100, max(1, (int)($_GET['per_page'] ?? 20)));
    $offset = ($page - 1) * $per_page;

    $search = $_GET['search'] ?? '';
    $where = '';
    $params = [];
    if (!empty($search)) {
        $where = "WHERE filename LIKE ?";
        $params[] = '%' . $search . '%';
    }

    $count_stmt = $db->prepare("SELECT COUNT(*) FROM cloud_files $where");
    $count_stmt->execute($params);
    $total = (int)$count_stmt->fetchColumn();

    $stmt = $db->prepare("SELECT * FROM cloud_files $where ORDER BY created DESC LIMIT ? OFFSET ?");
    $params[] = $per_page;
    $params[] = $offset;
    $stmt->execute($params);
    $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $result = [];
    foreach ($files as $f) {
        $token = cloud_token($f['id'], $f['stored_name']);
        $result[] = [
            'id'          => (int)$f['id'],
            'filename'    => $f['filename'],
            'filesize'    => (int)$f['filesize'],
            'mime_type'   => $f['mime_type'],
            'download_count' => (int)$f['download_count'],
            'description' => $f['description'],
            'has_password' => !empty($f['password']),
            'download_url' => SITE_URL . '?cloud_download=' . $f['id'] . '&token=' . $token,
            'shortcode'   => '[download id=' . $f['id'] . ']',
            'created'     => $f['created']
        ];
    }

    cloud_api_response(200, '文件列表', [
        'total' => $total,
        'page'  => $page,
        'per_page' => $per_page,
        'files' => $result
    ]);
}

// --- Agent API: 删除文件 ---
function cloud_api_handle_api_delete($file_id) {
    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM cloud_files WHERE id = ?');
    $stmt->execute([$file_id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$file) cloud_api_response(404, '文件不存在');

    $full_path = ABSPATH . 'content/uploads/cloud/' . $file['filepath'];
    if (file_exists($full_path)) @unlink($full_path);

    $db->prepare('DELETE FROM cloud_files WHERE id = ?')->execute([$file_id]);
    cloud_api_response(200, '删除成功', ['id' => $file_id]);
}

function cloud_api_response($status_code, $message, $data = null) {
    http_response_code($status_code);
    $response = ['code' => $status_code, 'message' => $message];
    if ($data !== null) $response['data'] = $data;
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// 直链模式下载计数 beacon:单条原子自增后立即 204 退出(每次下载 1 个微请求,不吞下载带宽)
function cloud_drive_count_beacon() {
    if (!isset($_GET['cd_count'])) return;
    $id = (int)$_GET['cd_count'];
    if ($id > 0) {
        try {
            get_db()->prepare('UPDATE cloud_files SET download_count = download_count + 1 WHERE id = ?')->execute([$id]);
        } catch (Throwable $e) { /* 静默:计数失败不影响下载 */ }
    }
    http_response_code(204);
    exit;
}
add_action('init', 'cloud_drive_count_beacon', 1);

// =========================================================================
// 4. [download] 短代码 (支持密码标识)
// =========================================================================
function cloud_drive_download_shortcode($atts, $content = null) {
    // mode: auto(按类型自动内嵌) | embed(强制内嵌) | link(强制下载卡片)
    $defaults = ['id' => 0, 'mode' => 'auto'];
    if (is_array($atts)) {
        $atts = array_merge($defaults, $atts);
    } else {
        $atts = $defaults;
    }
    $file_id = (int)$atts['id'];
    if ($file_id <= 0) return '<span class="cloud-dl-error">[无效文件ID]</span>';

    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM cloud_files WHERE id = ?');
    $stmt->execute([$file_id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$file) return '<span class="cloud-dl-error">[文件不存在]</span>';

    $token = cloud_token($file_id, $file['stored_name']);
    // 直链省资源模式:无密码文件直接给静态直链(Apache 直出,不占 PHP 进程),
    // 配微型 204 beacon 计数;密码文件/保护模式一律走 token 路由
    $protected = !empty($file['password']) || !cloud_drive_direct_mode();
    $download_url = $protected
        ? SITE_URL . '?cloud_download=' . $file_id . '&token=' . $token
        : CLOUD_DRIVE_URL . $file['filepath'];
    $beacon = $protected ? '' :
        ' onclick="try{fetch(' . json_encode(SITE_URL . '?cd_count=' . $file_id) . ',{cache:\'no-store\'})}catch(e){}"';

    $size_str = cloud_format_filesize($file['filesize']);
    $ext = strtolower(pathinfo($file['filename'], PATHINFO_EXTENSION));
    $icon = cloud_get_file_icon($ext);
    $label = $content ?: $file['filename'];
    $has_pw = !empty($file['password']);

    // 内嵌展示的判定（三个条件缺一不可）：
    //   1. 文件确实是图片/音频/视频——mode=embed 写在 zip/pdf 上也只能回落下载卡片；
    //   2. 没有密码——<img>/<video> 的请求带不上密码，只会拿到密码表单；
    //   3. mode 不是 link（link = 强制下载卡片）。
    $type     = cloud_drive_media_type($file['filename'], $file['mime_type']);
    $is_media = in_array($type, ['image', 'audio', 'video'], true);
    $mode     = strtolower((string)($atts['mode'] ?? 'auto'));
    if (!in_array($mode, ['auto', 'embed', 'link'], true)) { $mode = 'auto'; }
    if ($is_media && !$has_pw && $mode !== 'link') {
        return cloud_drive_render_media($file, $type, $label);
    }

    // 密码标识
    $pw_badge = $has_pw ? ' <span class="cloud-dl-pw-badge">🔒 需要密码</span>' : '';

    return '<div class="cloud-download-box">'
        . '<a href="' . e($download_url) . '"' . $beacon . ' class="cloud-download-link" target="_blank">'
        . '<span class="cloud-dl-icon">' . $icon . '</span>'
        . '<span class="cloud-dl-info">'
        . '<span class="cloud-dl-name">' . e($label) . $pw_badge . '</span>'
        . '<span class="cloud-dl-meta">' . $size_str . ' · 已下载 ' . (int)$file['download_count'] . ' 次</span>'
        . '</span>'
        . '<span class="cloud-dl-btn">' . ($has_pw ? '🔒 验证密码下载' : '⬇ 下载') . '</span>'
        . '</a>'
        . '</div>';
}

// =========================================================================
// 5. 前端下载路由 (密码验证)
// =========================================================================
function cloud_drive_download_router() {
    if (!isset($_GET['cloud_download'])) return;

    $file_id = (int)$_GET['cloud_download'];
    $token = $_GET['token'] ?? '';
    if ($file_id <= 0) { http_response_code(400); exit('无效请求'); }

    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM cloud_files WHERE id = ?');
    $stmt->execute([$file_id]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$file) { http_response_code(404); exit('文件不存在'); }

    // M-2:统一走 cloud_token()(HMAC-SHA256 + AUTH_KEY)。生成端(上传/列表/短代码/API)同源,
    // 不再出现「生成端 md5、校验端 hmac」导致链接 403 的半截修复。
    $expected_token = cloud_token($file_id, $file['stored_name']);
    if (!hash_equals($expected_token, $token)) { http_response_code(403); exit('链接无效或已过期'); }

    $full_path = ABSPATH . 'content/uploads/cloud/' . $file['filepath'];
    if (!file_exists($full_path)) { http_response_code(404); exit('文件已丢失'); }

    // inline=1 → 内嵌展示（图片/音视频，Content-Disposition: inline）；否则按下载处理（attachment + 计数）
    $inline = isset($_GET['inline']) && $_GET['inline'] !== '0';

    // 直链省资源模式:无密码文件 302 到静态直链(Apache 直出,不占 PHP 进程/Entry Process)
    if (empty($file['password']) && cloud_drive_direct_mode()) {
        header('Location: ' . CLOUD_DRIVE_URL . $file['filepath'], true, 302);
        exit;
    }

    // ── 密码保护逻辑 ──
    if (!empty($file['password'])) {
        $session_key = 'cloud_pw_verified_' . $file_id;

        // 检查是否已通过密码验证（session 记录，有效期 1 小时）
        if (isset($_SESSION[$session_key]) && $_SESSION[$session_key] > time() - 3600) {
            // 已验证，直接下载
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cloud_pw_submit'])) {
            // 提交密码验证
            $provided_pw = $_POST['cloud_pw'] ?? '';
            // 爆破锁定改存统一缓存层(按 file_id 全局计数,600s 自动过期):
            // 旧实现存 $_SESSION,攻击者每轮清 cookie 即重置,锁定形同虚设
            $brute_key = 'cloud_pw_lock_' . $file_id;
            $attempts = function_exists('cache_get') ? cache_get($brute_key, 600, true) : null;
            if (!is_array($attempts) || !isset($attempts['count'])) {
                $attempts = ['count' => 0, 'lockout' => 0];
            }

            // 暴力破解保护：5 次失败后锁定 10 分钟
            if ($attempts['count'] >= 5 && $attempts['lockout'] > time()) {
                $remain = ceil(($attempts['lockout'] - time()) / 60);
                cloud_show_pw_form($file, $token, "⚠️ 密码错误次数过多，请 {$remain} 分钟后再试。", true);
                exit;
            }

            if (password_verify($provided_pw, $file['password'])) {
                // 验证通过
                $_SESSION[$session_key] = time();
                if (function_exists('cache_delete')) { cache_delete($brute_key); }
                // 继续下载（不 exit，往下走）
            } else {
                // 密码错误
                $attempts['count']++;
                if ($attempts['count'] >= 5) {
                    $attempts['lockout'] = time() + 600; // 锁定 10 分钟
                }
                if (function_exists('cache_set')) { cache_set($brute_key, $attempts, 600); }
                $remaining = 5 - $attempts['count'];
                $msg = "❌ 密码错误" . ($remaining > 0 ? "，还剩 {$remaining} 次机会" : "，已锁定 10 分钟");
                cloud_show_pw_form($file, $token, $msg, $attempts['count'] >= 5);
                exit;
            }
        } else {
            // 首次访问：显示密码输入表单
            cloud_show_pw_form($file, $token, '');
            exit;
        }
    }

    // 内嵌请求（文章里直显图片/音视频）不算「下载」，不计入 download_count；只有点下载才计数
    if (!$inline) {
        $db->prepare('UPDATE cloud_files SET download_count = download_count + 1 WHERE id = ?')->execute([$file_id]);
    }
    // 下载与内嵌共用同一条流式输出（支持 Range，视频可拖动进度）
    cloud_drive_stream_file($full_path, cloud_drive_effective_mime($file), $file['filename'], $inline);
}
add_action('init', 'cloud_drive_download_router', 0);

/**
 * 显示密码输入表单
 */
function cloud_show_pw_form($file, $token, $error_msg = '', $locked = false) {
    $ext = strtolower(pathinfo($file['filename'], PATHINFO_EXTENSION));
    $icon = cloud_get_file_icon($ext);
    $size_str = cloud_format_filesize($file['filesize']);
    // 使用当前请求的 URL 构建表单 action，避免 SITE_URL 与实际访问地址不一致
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
        . '://' . ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost')
        . $_SERVER['REQUEST_URI'];
    $download_url = $current_url;
    // 如果当前 URL 没有 token 参数（理论上不会，因为进入此函数前已验证过 token），补上
    if (strpos($download_url, 'token=') === false) {
        $download_url .= (strpos($download_url, '?') !== false ? '&' : '?') . 'token=' . $token;
    }
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>下载验证 - <?php echo e($file['filename']); ?></title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f0f2f5; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
            .pw-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,0,0,0.1); padding: 40px; max-width: 420px; width: 90%; }
            .pw-header { text-align: center; margin-bottom: 24px; }
            .pw-icon { font-size: 3rem; margin-bottom: 8px; }
            .pw-filename { font-size: 1.1rem; font-weight: 600; color: #2c3e50; margin-bottom: 4px; word-break: break-all; }
            .pw-meta { font-size: 0.85rem; color: #999; }
            .pw-lock { font-size: 2.5rem; text-align: center; margin-bottom: 16px; }
            .pw-input { width: 100%; padding: 12px 16px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 1rem; outline: none; transition: border-color 0.2s; }
            .pw-input:focus { border-color: #4a9f6b; }
            .pw-btn { width: 100%; padding: 12px; background: #4a9f6b; color: #fff; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 12px; transition: background 0.2s; }
            .pw-btn:hover { background: #367952; }
            .pw-btn:disabled { background: #ccc; cursor: not-allowed; }
            .pw-error { color: #e53e3e; font-size: 0.85rem; text-align: center; margin-top: 12px; padding: 8px; background: #fff5f5; border-radius: 6px; }
            .pw-hint { text-align: center; margin-top: 16px; font-size: 0.8rem; color: #999; }
        </style>
    </head>
    <body>
        <div class="pw-card">
            <div class="pw-header">
                <div class="pw-icon"><?php echo $icon; ?></div>
                <div class="pw-filename"><?php echo e($file['filename']); ?></div>
                <div class="pw-meta"><?php echo $size_str; ?> · 已下载 <?php echo (int)$file['download_count']; ?> 次</div>
            </div>
            <div class="pw-lock">🔒</div>
            <form method="post" action="<?php echo e($download_url); ?>">
                <input type="password" name="cloud_pw" class="pw-input" placeholder="请输入下载密码"
                    autocomplete="off" <?php echo $locked ? 'disabled' : ''; ?> required autofocus>
                <button type="submit" name="cloud_pw_submit" value="1" class="pw-btn" <?php echo $locked ? 'disabled' : ''; ?>>
                    <?php echo $locked ? '⏳ 已锁定' : '🔓 验证并下载'; ?>
                </button>
            </form>
            <?php if (!empty($error_msg)): ?>
                <div class="pw-error"><?php echo e($error_msg); ?></div>
            <?php endif; ?>
            <div class="pw-hint">此文件受密码保护，请向文件分享者获取密码</div>
        </div>
    </body>
    </html>
    <?php
}

// =========================================================================
// 6. 后台管理界面 (支持密码设置)
// =========================================================================
function cloud_drive_admin_menu() {
    add_menu_page(
        '网盘文件管理',
        '☁️ 网盘',
        'manage_options',
        'cloud_drive',
        'cloud_drive_admin_page',
        'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#4a9f6b" stroke-width="2"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>')
    );
}
add_action('admin_menu', 'cloud_drive_admin_menu');

function cloud_drive_admin_page() {
    $db = get_db();
    $message = '';

    // 网盘模式开关(0=直链省资源,1=完整保护)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cloud_mode_nonce'])) {
        if (verifyCsrfToken($_POST['cloud_mode_nonce'], 'cloud_mode')) {
            $mode = ($_POST['cloud_mode'] ?? '0') === '1' ? '1' : '0';
            update_option('cloud_drive_mode', $mode);
            cloud_drive_write_storage_htaccess();
            $message = '<div class="alert alert-success">✅ 网盘模式已切换：'
                . ($mode === '1' ? '完整保护（token 校验 + 密码表单，全部走 PHP）'
                                 : '直链省资源（无密码文件走 Apache 静态直出，密码文件仍走保护路由）')
                . '</div>';
        } else {
            $message = '<div class="alert alert-danger">CSRF 验证失败</div>';
        }
    }

    // 处理上传（支持密码）
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cloud_upload_nonce'])) {
        if (!verifyCsrfToken($_POST['cloud_upload_nonce'], 'cloud_upload')) {
            $message = '<div class="alert alert-danger">CSRF 验证失败</div>';
        } elseif (!empty($_FILES['cloud_files'])) {
            $uploaded = 0;
            $errors = [];
            $files = $_FILES['cloud_files'];
            $file_count = is_array($files['name']) ? count($files['name']) : 1;
            $pw = $_POST['cloud_password'] ?? '';

            for ($i = 0; $i < $file_count; $i++) {
                $name = is_array($files['name']) ? $files['name'][$i] : $files['name'];
                $tmp = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
                $error = is_array($files['error']) ? $files['error'][$i] : $files['error'];
                $size = is_array($files['size']) ? $files['size'][$i] : $files['size'];
                $type = is_array($files['type']) ? $files['type'][$i] : $files['type'];

                if ($error !== UPLOAD_ERR_OK) { $errors[] = "$name: 上传错误"; continue; }

                $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                $dangerous = ['php','php3','php4','php5','phtml','pht','phps','cgi','pl','asp','aspx','jsp','sh','bash','htaccess'];
                if (in_array($ext, $dangerous)) { $errors[] = "$name: 不允许的文件类型"; continue; }

                $stored_name = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . ($ext ?: 'bin');
                $relative_path = date('Y/m/');
                $full_dir = CLOUD_DRIVE_STORAGE . $relative_path;
                if (!is_dir($full_dir)) @mkdir($full_dir, 0755, true);

                $dest = $full_dir . $stored_name;
                if (move_uploaded_file($tmp, $dest)) {
                    $filepath = $relative_path . $stored_name;
                    $pw_hash = !empty($pw) ? password_hash($pw, PASSWORD_DEFAULT) : '';
                    $stmt = $db->prepare('INSERT INTO cloud_files (filename, stored_name, filepath, filesize, mime_type, password, uploader_id) VALUES (?, ?, ?, ?, ?, ?, ?)');
                    $stmt->execute([$name, $stored_name, $filepath, filesize($dest), $type, $pw_hash, $_SESSION['user_id'] ?? 0]);
                    $uploaded++;
                } else {
                    $errors[] = "$name: 保存失败";
                }
            }
            $msg = '成功上传 ' . $uploaded . ' 个文件';
            if (!empty($pw)) $msg .= '（已设密码保护）';
            $message = '<div class="alert alert-success">' . $msg . '</div>';
            if (!empty($errors)) $message .= '<div class="alert alert-danger">' . implode('<br>', $errors) . '</div>';
        }
    }

    // 处理设置/清除密码
    if (isset($_POST['pw_action']) && isset($_POST['pw_file_id'])) {
        $pw_nonce = $_POST['pw_nonce'] ?? '';
        if (verifyCsrfToken($pw_nonce, 'cloud_pw_' . $_POST['pw_file_id'])) {
            $fid = (int)$_POST['pw_file_id'];
            $action = $_POST['pw_action'];
            if ($action === 'set') {
                $new_pw = $_POST['new_password'] ?? '';
                if (!empty($new_pw)) {
                    $hash = password_hash($new_pw, PASSWORD_DEFAULT);
                    $db->prepare('UPDATE cloud_files SET password = ? WHERE id = ?')->execute([$hash, $fid]);
                    $message = '<div class="alert alert-success">✅ 密码已设置</div>';
                }
            } elseif ($action === 'clear') {
                $db->prepare('UPDATE cloud_files SET password = "" WHERE id = ?')->execute([$fid]);
                $message = '<div class="alert alert-success">🔓 密码已清除</div>';
            }
        }
    }

    // 处理删除
    if (isset($_GET['delete_id']) && isset($_GET['_nonce'])) {
        if (verifyCsrfToken($_GET['_nonce'], 'cloud_delete_' . $_GET['delete_id'])) {
            $del_id = (int)$_GET['delete_id'];
            $stmt = $db->prepare('SELECT * FROM cloud_files WHERE id = ?');
            $stmt->execute([$del_id]);
            $file = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($file) {
                $full_path = ABSPATH . 'content/uploads/cloud/' . $file['filepath'];
                if (file_exists($full_path)) @unlink($full_path);
                $db->prepare('DELETE FROM cloud_files WHERE id = ?')->execute([$del_id]);
                $message = '<div class="alert alert-success">已删除：' . e($file['filename']) . '</div>';
            }
        }
    }

    // 分页与搜索
    $page = max(1, (int)($_GET['paged'] ?? 1));
    $per_page = 20;
    $offset = ($page - 1) * $per_page;
    $search = $_GET['s'] ?? '';
    $where = '';
    $params = [];
    if (!empty($search)) {
        $where = "WHERE filename LIKE ?";
        $params[] = '%' . $search . '%';
    }

    $count_stmt = $db->prepare("SELECT COUNT(*) FROM cloud_files $where");
    $count_stmt->execute($params);
    $total = (int)$count_stmt->fetchColumn();

    $stmt = $db->prepare("SELECT * FROM cloud_files $where ORDER BY created DESC LIMIT ? OFFSET ?");
    $params[] = $per_page;
    $params[] = $offset;
    $stmt->execute($params);
    $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $total_size = $db->query("SELECT COALESCE(SUM(filesize), 0) FROM cloud_files")->fetchColumn();
    ?>
    <div class="card">
        <h2 style="margin-bottom: 20px; color: var(--primary-green);">☁️ 网盘文件管理</h2>
        <?php echo $message; ?>

        <div style="display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap;">
            <div style="background: #e8f4f8; padding: 12px 20px; border-radius: 8px;">
                <strong>📁 文件总数：</strong> <?php echo $total; ?>
            </div>
            <div style="background: #e8f4f8; padding: 12px 20px; border-radius: 8px;">
                <strong>💾 占用空间：</strong> <?php echo cloud_format_filesize($total_size); ?>
            </div>
        </div>

        <!-- 网盘模式开关 -->
        <div style="background: #f8f9fa; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid var(--border-color);">
            <form method="post" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <?php csrf_token_field('cloud_mode'); ?>
                <input type="hidden" name="cloud_mode_nonce" value="<?php echo e(generateCsrfToken('cloud_mode')); ?>">
                <label style="font-weight: bold;">⚡ 网盘模式：</label>
                <select name="cloud_mode" style="padding: 6px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="0" <?php echo cloud_drive_direct_mode() ? 'selected' : ''; ?>>0 = 直链省资源（默认：无密码文件静态直出，微请求计数）</option>
                    <option value="1" <?php echo cloud_drive_direct_mode() ? '' : 'selected'; ?>>1 = 完整保护（全部走 token 校验 + PHP 下载）</option>
                </select>
                <button type="submit" class="btn btn-outline">保存模式</button>
                <small style="display: block; width: 100%; color: #999; margin-top: 4px;">
                    带密码的文件在任何模式下都强制走保护路由；切换模式会同步改写存储目录 .htaccess（直链模式放开静态访问但禁列目录、禁 PHP 脚本）。
                </small>
            </form>
        </div>

        <!-- 上传区域（含密码） -->
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border: 2px dashed var(--border-color); margin-bottom: 30px;">
            <form method="post" enctype="multipart/form-data">
                <?php csrf_token_field('cloud_upload'); ?>
                <input type="hidden" name="cloud_upload_nonce" value="<?php echo e(generateCsrfToken('cloud_upload')); ?>">
                <label style="font-weight: bold; display: block; margin-bottom: 10px;">📤 上传文件（支持多选）</label>
                <input type="file" name="cloud_files[]" multiple id="cloudFileInput"
                    style="margin-bottom: 10px; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px; width: 100%;">
                <div style="margin-bottom: 10px;">
                    <label style="font-weight: bold; display: block; margin-bottom: 4px;">🔒 下载密码（可选，留空则无需密码）</label>
                    <input type="text" name="cloud_password" placeholder="设置下载密码"
                        style="padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 4px; width: 300px;">
                </div>
                <div id="cloudFileInfo" style="font-size: 0.85rem; color: #666; margin-bottom: 10px;"></div>
                <button type="submit" class="btn btn-primary">📤 开始上传</button>
            </form>
        </div>

        <!-- 搜索 -->
        <form method="get" style="margin-bottom: 20px; display: flex; gap: 10px;">
            <input type="hidden" name="page" value="cloud_drive">
            <input type="text" name="s" value="<?php echo e($search); ?>" placeholder="🔍 搜索文件名..."
                style="flex: 1; padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 4px;">
            <button type="submit" class="btn btn-outline">搜索</button>
        </form>

        <?php if (empty($files)): ?>
            <p style="color: #999; text-align: center; padding: 40px;">暂无文件，请上传。</p>
        <?php else: ?>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid var(--border-color);">
                        <th style="text-align: left; padding: 10px;">文件名</th>
                        <th style="text-align: center; padding: 10px; width: 60px;">大小</th>
                        <th style="text-align: center; padding: 10px; width: 50px;">下载</th>
                        <th style="text-align: center; padding: 10px; width: 80px;">密码</th>
                        <th style="text-align: left; padding: 10px; width: 170px;">短代码</th>
                        <th style="text-align: center; padding: 10px; width: 120px;">时间</th>
                        <th style="text-align: center; padding: 10px; width: 200px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($files as $f):
                    $token = cloud_token($f['id'], $f['stored_name']);
                    $dl_url = SITE_URL . '?cloud_download=' . $f['id'] . '&token=' . $token;
                    $del_nonce = generateCsrfToken('cloud_delete_' . $f['id']);
                    $pw_nonce = generateCsrfToken('cloud_pw_' . $f['id']);
                    $ext = strtolower(pathinfo($f['filename'], PATHINFO_EXTENSION));
                    $has_pw = !empty($f['password']);
                ?>
                    <tr style="border-bottom: 1px solid #eee;">
                        <td style="padding: 10px;">
                            <span style="margin-right: 6px;"><?php echo cloud_get_file_icon($ext); ?></span>
                            <strong><?php echo e($f['filename']); ?></strong>
                            <?php if (!empty($f['description'])): ?>
                                <br><small style="color: #999;"><?php echo e($f['description']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center; padding: 10px; color: #666; font-size: 0.85rem;">
                            <?php echo cloud_format_filesize($f['filesize']); ?>
                        </td>
                        <td style="text-align: center; padding: 10px;">
                            <?php echo (int)$f['download_count']; ?>
                        </td>
                        <td style="text-align: center; padding: 10px;">
                            <?php if ($has_pw): ?>
                                <span style="color: #e53e3e;" title="已设密码">🔒</span>
                            <?php else: ?>
                                <span style="color: #999;" title="无密码">🔓</span>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 10px;">
                            <code style="background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 0.8rem; cursor: pointer;"
                                onclick="navigator.clipboard.writeText(this.textContent).then(()=>{this.textContent='✅ 已复制';setTimeout(()=>{this.textContent='[download id=<?php echo $f['id']; ?>]'},1500)})"
                                title="点击复制">[download id=<?php echo $f['id']; ?>]</code>
                        </td>
                        <td style="text-align: center; padding: 10px; color: #999; font-size: 0.8rem;">
                            <?php echo e($f['created']); ?>
                        </td>
                        <td style="text-align: center; padding: 10px;">
                            <!-- 密码设置/清除 -->
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="pw_file_id" value="<?php echo $f['id']; ?>">
                                <input type="hidden" name="pw_nonce" value="<?php echo e($pw_nonce); ?>">
                                <?php if ($has_pw): ?>
                                    <input type="hidden" name="pw_action" value="clear">
                                    <button type="submit" class="btn btn-sm" style="background:#ffa500;color:#fff;" title="清除密码"
                                        onclick="return confirm('确定清除密码保护？')">🔓</button>
                                <?php else: ?>
                                    <input type="hidden" name="pw_action" value="set">
                                    <input type="text" name="new_password" placeholder="密码" required
                                        style="width:70px;padding:2px 4px;font-size:0.75rem;border:1px solid #ccc;border-radius:3px;">
                                    <button type="submit" class="btn btn-sm" style="background:#e53e3e;color:#fff;" title="设置密码">🔒</button>
                                <?php endif; ?>
                            </form>
                            <a href="<?php echo e($dl_url); ?>" class="btn btn-sm btn-primary" style="margin: 0 3px;" title="下载">⬇️</a>
                            <a href="?page=cloud_drive&delete_id=<?php echo $f['id']; ?>&_nonce=<?php echo $del_nonce; ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('确定删除此文件？')"
                                title="删除">🗑️</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <?php if ($total > $per_page): ?>
            <div style="margin-top: 20px; text-align: center;">
                <?php
                $total_pages = ceil($total / $per_page);
                for ($p = 1; $p <= $total_pages; $p++):
                    $active = ($p === $page) ? 'style="background: var(--primary-green); color: #fff;"' : '';
                ?>
                    <a href="?page=cloud_drive&paged=<?php echo $p; ?>&s=<?php echo e($search); ?>"
                        class="btn btn-sm" <?php echo $active; ?>><?php echo $p; ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- API 说明 -->
    <div class="card" style="margin-top: 20px;">
        <h3 style="color: var(--primary-green); margin-bottom: 15px;">🤖 AI Agent API 说明（含密码功能）</h3>
        <textarea style="width: 100%; height: 420px; font-family: monospace; font-size: 0.85rem; background: #282c34; color: #abb2bf; padding: 15px; border-radius: 8px; border: none;" readonly>
博客域名：<?php echo SITE_URL; ?>

【认证方式】(2026-09 更新：多传输通道回退)
优先：Authorization: Bearer {API_KEY}
若主机丢弃 Authorization 头(401 但 key 无误时，如 mod_fcgid/LiteSpeed/CGI)，改用等效凭据：
  头：X-API-Key: {API_KEY}
  或：URL 追加 &apikey={API_KEY}
凭据说明：仅 Admin Key 可调用本文件 API；Comment Key 无文件权限。

【下载模式】(后台"网盘模式"开关)
模式 0 直链省资源(默认)：无密码文件的 download_url 为静态直链(Apache 直出，不占 PHP 进程)，
  每次下载由前端 beacon 自动计数；带密码的文件仍走 token + 密码表单保护路由。
  mode=url 响应中：direct_url 仅在直链模式下返回真实可用地址，保护模式下为 null。
模式 1 完整保护：全部下载经 token 校验 + PHP readfile，direct_url 恒为 null。

====================
1. 上传文件 (Admin Key, 支持密码)
====================
方式A - multipart/form-data：
POST /?agent_api=files&action=upload
Body: form-data
  file=@test.pdf
  description=描述
  password=下载密码    ← 新增！

方式B - JSON Base64：
POST /?agent_api=files&action=upload
Body: {"filename":"test.pdf", "data":"BASE64...", "password":"下载密码"}

响应新增字段：{"has_password": true}

====================
2. 下载文件 (需密码验证)
====================
无密码文件：
GET /?agent_api=files&action=download&id=1

有密码文件 - 方式1 (URL参数)：
GET /?agent_api=files&action=download&id=1&password=xxx

有密码文件 - 方式2 (POST body)：
GET /?agent_api=files&action=download&id=1
Body: {"password": "xxx"}

密码错误响应：
{"code": 403, "message": "此文件需要密码才能下载", "data": {"require_password": true}}

====================
3. 文件列表 (显示密码状态)
====================
GET /?agent_api=files&action=list
响应每个文件新增：{"has_password": true/false}

====================
4. 前端下载密码验证
====================
有密码文件的下载链接会自动显示密码输入表单
验证通过后 session 记录 1 小时内免重复输入
暴力破解保护：5 次错误锁定 10 分钟
        </textarea>
    </div>

    <script>
    document.getElementById('cloudFileInput')?.addEventListener('change', function() {
        const info = document.getElementById('cloudFileInfo');
        if (this.files.length > 0) {
            let total = 0;
            for (let f of this.files) total += f.size;
            info.innerHTML = '已选 <strong>' + this.files.length + '</strong> 个文件，共 <strong>' + (total/1024).toFixed(1) + ' KB</strong>';
        } else { info.innerHTML = ''; }
    });
    </script>
    <?php
}

// =========================================================================
// 7. 前台样式
// =========================================================================
function cloud_drive_inject_styles() {
    ?>
    <style>
    .cloud-download-box { margin: 16px 0; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; transition: box-shadow 0.2s; }
    .cloud-download-box:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
    .cloud-download-link { display: flex; align-items: center; padding: 14px 18px; text-decoration: none; color: #333; gap: 14px; }
    .cloud-dl-icon { font-size: 2rem; flex-shrink: 0; }
    .cloud-dl-info { flex: 1; min-width: 0; }
    .cloud-dl-name { display: block; font-weight: 600; color: #2c3e50; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .cloud-dl-meta { display: block; font-size: 0.8rem; color: #999; margin-top: 2px; }
    .cloud-dl-btn { background: #4a9f6b; color: #fff; padding: 8px 18px; border-radius: 6px; font-size: 0.9rem; font-weight: 500; white-space: nowrap; transition: background 0.2s; }
    .cloud-download-link:hover .cloud-dl-btn { background: #367952; }
    .cloud-dl-error { color: #dc3545; font-size: 0.85rem; background: #fff5f5; padding: 2px 8px; border-radius: 3px; }
    .cloud-dl-pw-badge { display: inline-block; background: #fff3e0; color: #e65100; font-size: 0.7rem; padding: 1px 6px; border-radius: 3px; margin-left: 6px; font-weight: 500; vertical-align: middle; }
    /* 内嵌媒体（图片/音频/视频）：结构只用净化器白名单内的 div/span/a/img/audio/video */
    .cloud-media { margin: 20px 0; }
    .cloud-media-el { display: block; width: 100%; height: auto; max-width: 100%; border-radius: 10px; }
    .cloud-media-video .cloud-media-el { background: #000; }
    .cloud-media-bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; font-size: 0.8rem; color: #999; margin-top: 6px; }
    .cloud-media-name { font-weight: 600; color: #2c3e50; }
    .cloud-media-dl { margin-left: auto; color: #4a9f6b; text-decoration: none; }
    </style>
    <?php
}
add_action('wp_head', 'cloud_drive_inject_styles');

// =========================================================================
// 8. 编辑器集成：AJAX 上传/列表 + Quill 工具栏按钮（admin/editor-button.php）
// =========================================================================
add_action('wp_ajax_cloud_drive_upload', 'cloud_drive_ajax_upload');
add_action('wp_ajax_cloud_drive_files', 'cloud_drive_ajax_files');

/** AJAX 统一准入：必须已登录且有发帖权限（CSRF 由框架 ajax.php 统一校验） */
function cloud_drive_ajax_guard() {
    if (!is_logged_in() || !current_user_can('publish_posts')) {
        wp_send_json_error(['message' => '未授权：请先登录后台。'], 403);
    }
}

/** 编辑器内上传：与后台管理页、Agent API 共用同一张表与同一套存储规则 */
function cloud_drive_ajax_upload() {
    cloud_drive_ajax_guard();
    if (empty($_FILES['file'])) { wp_send_json_error(['message' => '没有收到文件。'], 400); }
    try {
        $row = cloud_drive_store_upload(
            $_FILES['file'],
            (string)($_POST['password'] ?? ''),
            (string)($_POST['description'] ?? '')
        );
    } catch (Exception $e) {
        wp_send_json_error(['message' => $e->getMessage()], 400);
    }
    wp_send_json_success($row);
}

/** 编辑器弹层用：列出现有文件（可选关键词搜索） */
function cloud_drive_ajax_files() {
    cloud_drive_ajax_guard();
    $db  = get_db();
    $s   = trim((string)($_REQUEST['s'] ?? ''));
    $sql = 'SELECT * FROM cloud_files';
    $params = [];
    if ($s !== '') { $sql .= ' WHERE filename LIKE ?'; $params[] = '%' . $s . '%'; }
    $sql .= ' ORDER BY id DESC LIMIT 30';

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $files = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $f) {
        $files[] = [
            'id'           => (int)$f['id'],
            'filename'     => $f['filename'],
            'filesize'     => cloud_format_filesize((int)$f['filesize']),
            'media_type'   => cloud_drive_media_type($f['filename'], $f['mime_type']),
            'has_password' => !empty($f['password']),
            'shortcode'    => '[download id=' . (int)$f['id'] . ']',
        ];
    }
    wp_send_json_success(['files' => $files]);
}

/** 单文件入库：危险扩展名拦截 + 存储命名 + 建表写入（编辑器上传入口） */
function cloud_drive_store_upload($file, $password = '', $description = '') {
    $original_name = basename((string)($file['name'] ?? ''));
    if ($original_name === '') { throw new Exception('文件名为空。'); }

    $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $dangerous = ['php','php3','php4','php5','phtml','pht','phps','cgi','pl','asp','aspx','jsp','sh','bash','htaccess'];
    if (in_array($ext, $dangerous, true)) { throw new Exception('出于安全考虑，禁止上传此类型文件：.' . $ext); }

    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || (!is_uploaded_file($tmp) && !is_file($tmp))) { throw new Exception('临时文件不可用。'); }

    $mime        = cloud_safe_mime($file['type'] ?? 'application/octet-stream');
    $stored_name = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . ($ext ?: 'bin');
    $relative    = date('Y/m/');
    $full_dir    = CLOUD_DRIVE_STORAGE . $relative;
    if (!is_dir($full_dir) && !@mkdir($full_dir, 0755, true)) { throw new Exception('无法创建存储目录。'); }

    $dest_path = $full_dir . $stored_name;
    if (!move_uploaded_file($tmp, $dest_path) && !@rename($tmp, $dest_path)) { throw new Exception('文件保存失败。'); }

    $filesize = (int)@filesize($dest_path);
    $pw_hash  = $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : '';
    $db       = get_db();
    $stmt = $db->prepare('INSERT INTO cloud_files (filename, stored_name, filepath, filesize, mime_type, description, password, uploader_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    if (!$stmt->execute([$original_name, $stored_name, $relative . $stored_name, $filesize, $mime, $description, $pw_hash, $_SESSION['user_id'] ?? 0])) {
        @unlink($dest_path);
        throw new Exception('数据库写入失败。');
    }
    $id = (int)$db->lastInsertId();
    return [
        'id'           => $id,
        'filename'     => $original_name,
        'filesize'     => cloud_format_filesize($filesize),
        'media_type'   => cloud_drive_media_type($original_name, $mime),
        'has_password' => $pw_hash !== '',
        'shortcode'    => '[download id=' . $id . ']',
    ];
}

// 只在文章编辑页（admin/content.php）加载编辑器按钮文件。
// 刻意不用 is_admin()：它内部会走 current_user_can → is_logged_in → 查库，
// 挂在每次请求上等于给全站（含前台）加一次会话/DB 开销；basename 判断是纯字符串操作，0 成本。
if (basename($_SERVER['PHP_SELF'] ?? '') === 'content.php') {
    require_once CLOUD_DRIVE_DIR . 'admin/editor-button.php';
}

// =========================================================================
// 工具函数
// =========================================================================
function cloud_format_filesize($bytes) {
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}

function cloud_get_file_icon($ext) {
    $icons = [
        'pdf'=>'📕','doc'=>'📘','docx'=>'📘','xls'=>'📊','xlsx'=>'📊','ppt'=>'📙','pptx'=>'📙',
        'zip'=>'📦','rar'=>'📦','7z'=>'📦','tar'=>'📦','gz'=>'📦',
        'jpg'=>'🖼️','jpeg'=>'🖼️','png'=>'🖼️','gif'=>'🖼️','webp'=>'🖼️','svg'=>'🖼️',
        'mp3'=>'🎵','wav'=>'🎵','flac'=>'🎵','aac'=>'🎵',
        'mp4'=>'🎬','avi'=>'🎬','mkv'=>'🎬','mov'=>'🎬',
        'txt'=>'📄','md'=>'📄','csv'=>'📄','json'=>'📋','xml'=>'📋',
        'html'=>'🌐','css'=>'🎨','js'=>'⚡',
    ];
    return $icons[$ext] ?? '📎';
}
