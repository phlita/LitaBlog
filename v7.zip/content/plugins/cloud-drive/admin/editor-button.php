<?php
if (!defined('ABSPATH')) exit;

/**
 * 后台编辑器集成：Quill 工具栏「☁️ 网盘」按钮。
 * =============================================================================
 * 流程：点按钮 → 弹层（上传新文件 / 从已有文件选取）→ 在光标处插入 [download id=N]。
 * 前端由主插件渲染：图片/音频/视频自动内嵌展示（<img>/<audio>/<video>），
 * 其他类型仍是下载卡片；带密码的文件一律下载卡片（内嵌请求带不上密码）。
 *
 * 上传走框架 AJAX：POST {SITE_URL}/ajax.php，字段 action=cloud_drive_upload + _ajax_csrf_token，
 * 由 ajax.php 统一完成 CSRF 与登录态校验后触发 wp_ajax_cloud_drive_upload。
 * 接入方式：admin_footer 钩子，仅 content.php 编辑页生效（与 lita-music 相同模式）。
 */
add_action('admin_footer', 'cloud_drive_admin_editor_button');

function cloud_drive_admin_editor_button() {
    if (basename($_SERVER['PHP_SELF'] ?? '') !== 'content.php') return;   // 只在文章编辑页

    $ajax_url   = rtrim(SITE_URL, '/') . '/ajax.php';
    $token_up   = generateCsrfToken('cloud_drive_upload');
    $token_list = generateCsrfToken('cloud_drive_files');
    ?>
<style>
.cd-ebtn{display:inline-flex;align-items:center;gap:4px;padding:0 8px;height:24px;cursor:pointer;
    border-radius:4px;color:#4a6741;font-weight:600;background:none;border:none;font-size:14px;}
.cd-ebtn:hover{background:#e3ead9;}
.cd-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:99999;
    justify-content:center;align-items:center;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;}
.cd-modal.open{display:flex;}
.cd-dialog{background:#fff;border-radius:12px;width:92%;max-width:560px;max-height:86vh;overflow:auto;
    box-shadow:0 16px 48px rgba(0,0,0,.28);}
.cd-head{padding:14px 18px;font-weight:600;color:#2c3e2d;border-bottom:1px solid #ece8d9;
    display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:#fff;}
.cd-head .cd-close{cursor:pointer;border:none;background:none;font-size:18px;color:#765c43;}
.cd-body{padding:16px 18px 20px;}
.cd-block{border:1px solid #ece8d9;border-radius:10px;padding:14px;margin-bottom:14px;background:#fbfbf8;}
.cd-label{font-weight:600;color:#2c3e2d;font-size:13px;margin-bottom:10px;}
.cd-row{display:flex;gap:8px;align-items:center;margin-top:8px;}
.cd-row input[type=text]{flex:1;padding:8px 10px;border:1px solid #ddd;border-radius:6px;font-size:13px;}
.cd-btn{padding:8px 14px;border:none;border-radius:6px;background:#4a9f6b;color:#fff;cursor:pointer;font-size:13px;white-space:nowrap;}
.cd-btn:hover{background:#367952;}
.cd-btn:disabled{background:#bbb;cursor:not-allowed;}
.cd-btn.ghost{background:#fff;color:#4a6741;border:1px solid #cfd9c5;}
.cd-tip{font-size:12px;color:#8a8a8a;margin-top:8px;line-height:1.6;}
.cd-list{margin-top:10px;max-height:240px;overflow:auto;border-top:1px solid #ece8d9;}
.cd-item{display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px solid #f1f1ec;cursor:pointer;}
.cd-item:hover{background:#f4f7f0;}
.cd-item .ico{flex-shrink:0;}
.cd-item .nm{flex:1;min-width:0;font-size:13px;color:#2c3e2d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.cd-item .mt{font-size:11px;color:#9a9a9a;flex-shrink:0;}
.cd-item .ins{font-size:12px;color:#4a6741;flex-shrink:0;}
.cd-empty{padding:18px 4px;color:#9a9a9a;font-size:13px;text-align:center;}
</style>

<div class="cd-modal" id="cd-modal">
    <div class="cd-dialog">
        <div class="cd-head"><span>☁️ 插入网盘资源</span><button class="cd-close" id="cd-close" title="关闭">✕</button></div>
        <div class="cd-body">
            <div class="cd-block">
                <div class="cd-label">上传新文件（图片 / 音频 / 视频会直接内嵌到文章）</div>
                <input type="file" id="cd-file" multiple style="font-size:13px;">
                <div class="cd-row">
                    <input type="text" id="cd-pw" placeholder="下载密码（可选，填了就只能下载）" autocomplete="off">
                    <button class="cd-btn" id="cd-upload" type="button">上传并插入</button>
                </div>
                <div class="cd-tip" id="cd-tip">图片、mp3/wav、mp4/webm 等会内嵌播放，其他类型生成下载卡片；带密码的文件只显示下载卡片。</div>
            </div>
            <div class="cd-block">
                <div class="cd-label">从已有文件选取</div>
                <div class="cd-row">
                    <input type="text" id="cd-search" placeholder="搜索文件名…">
                    <button class="cd-btn ghost" id="cd-refresh" type="button">刷新</button>
                </div>
                <div class="cd-list" id="cd-list"><div class="cd-empty">加载中…</div></div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var AJAX     = <?php echo json_encode($ajax_url); ?>;
    var T_UPLOAD = <?php echo json_encode($token_up); ?>;
    var T_LIST   = <?php echo json_encode($token_list); ?>;
    var ICON     = { image: '🖼️', audio: '🎵', video: '🎬', file: '📎' };

    function $(id) { return document.getElementById(id); }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
        return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }

    // 在光标处插入短代码（与 lita-music 同一插入模式，独占一行更稳）
    function insert(sc) {
        var q = window.quillInstance;
        if (!q) { alert('编辑器还没准备好，请稍后再试。'); return; }
        var range = q.getSelection(true) || { index: q.getLength() };
        q.insertText(range.index, '\n' + sc + '\n', 'user');
        q.setSelection(range.index + sc.length + 2);
    }

    function post(fd) {
        return fetch(AJAX, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
    }

    function openModal() { $('cd-modal').classList.add('open'); loadList(); }
    function closeModal() { $('cd-modal').classList.remove('open'); }

    function loadList() {
        var fd = new FormData();
        fd.append('action', 'cloud_drive_files');
        fd.append('_ajax_csrf_token', T_LIST);
        fd.append('s', $('cd-search').value || '');
        post(fd).then(function (j) {
            var box = $('cd-list');
            var files = (j && j.success && j.data && j.data.files) ? j.data.files : [];
            if (!files.length) { box.innerHTML = '<div class="cd-empty">还没有文件，先上传一个吧。</div>'; return; }
            box.innerHTML = files.map(function (f) {
                return '<div class="cd-item" data-sc="' + esc(f.shortcode) + '">'
                     + '<span class="ico">' + (ICON[f.media_type] || '📎') + '</span>'
                     + '<span class="nm">' + esc(f.filename) + (f.has_password ? ' 🔒' : '') + '</span>'
                     + '<span class="mt">' + esc(f.filesize) + '</span>'
                     + '<span class="ins">插入 →</span></div>';
            }).join('');
            Array.prototype.forEach.call(box.querySelectorAll('.cd-item'), function (el) {
                el.addEventListener('click', function () { insert(el.getAttribute('data-sc')); closeModal(); });
            });
        }).catch(function () { $('cd-list').innerHTML = '<div class="cd-empty">列表加载失败，请刷新重试。</div>'; });
    }

    function upload() {
        var input = $('cd-file'), tip = $('cd-tip'), btn = $('cd-upload');
        var files = input.files;
        if (!files || !files.length) { tip.textContent = '请先选择文件。'; return; }
        var pw = $('cd-pw').value || '';
        var i = 0;
        btn.disabled = true;

        (function next() {
            if (i >= files.length) {
                btn.disabled = false;
                tip.textContent = '已全部插入 ✓';
                input.value = '';
                loadList();
                return;
            }
            var fd = new FormData();
            fd.append('action', 'cloud_drive_upload');
            fd.append('_ajax_csrf_token', T_UPLOAD);
            fd.append('password', pw);
            fd.append('file', files[i]);
            tip.textContent = '上传中 (' + (i + 1) + '/' + files.length + ')：' + files[i].name;
            post(fd).then(function (j) {
                if (j && j.success && j.data && j.data.shortcode) {
                    insert(j.data.shortcode);
                    i++; next();
                } else {
                    tip.textContent = '失败：' + ((j && j.data && j.data.message) || '未知错误');
                    btn.disabled = false;
                }
            }).catch(function () {
                tip.textContent = '上传请求失败（网络中断或主机限制上传体积）。';
                btn.disabled = false;
            });
        })();
    }

    // 工具栏按钮：等 Quill 就绪后挂到「清除格式」右侧
    var timer = setInterval(function () {
        if (!window.quillInstance) return;
        var tb = document.querySelector('.ql-toolbar');
        if (!tb) return;
        clearInterval(timer);
        if (tb.querySelector('#cd-btn')) return;
        var b = document.createElement('button');
        b.type = 'button'; b.id = 'cd-btn'; b.className = 'cd-ebtn'; b.textContent = '☁️ 网盘';
        b.addEventListener('click', openModal);
        var clean = tb.querySelector('.ql-clean');
        if (clean) { clean.parentNode.insertBefore(b, clean.nextSibling); } else { tb.appendChild(b); }
    }, 300);

    $('cd-close').addEventListener('click', closeModal);
    $('cd-modal').addEventListener('click', function (e) { if (e.target === this) closeModal(); });
    $('cd-upload').addEventListener('click', upload);
    $('cd-refresh').addEventListener('click', loadList);
    $('cd-search').addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); loadList(); }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && $('cd-modal').classList.contains('open')) closeModal();
    });
})();
</script>
    <?php
}
