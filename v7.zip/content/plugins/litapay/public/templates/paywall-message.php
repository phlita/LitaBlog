<?php
if (!defined('ABSPATH')) exit;
// $paywall_data is passed to this template, includes:
// 'price', 'post_id', 'currency_symbol', 'is_afdian_enabled',
// 'user_is_logged_in', 'login_url', 'ajax_url', 'purchase_nonce', 'current_user_balance'

// B-7 修复辅助：把支付所需数据编码为 URL-safe base64，放进 <a> 的 href。
// 原因：核心净化器 litablog_purify_html 会
//   1) 销毁 button/form/input 标签（付费墙按钮被剥光，只剩文本）
//   2) 剥离 a 标签上的 data-* 属性（只保留 href/title/target/class/style）
// 导致前端 JS 读 dataset.* 全为空 → "支付信息不完整"，完全无法购买。
// 解法：按钮用 <a>，数据编码进 href（净化器保留 href），前端 JS 解析。
if (!function_exists('litapay_encode_pay_data')) {
    function litapay_encode_pay_data($data) {
        return rtrim(strtr(base64_encode(json_encode($data)), '+/', '-_'), '=');
    }
}
?>
<div class="litapay-paywall">
<?php if ($paywall_data['price'] > 0): ?>
<p>付费可见：<strong><?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['price'], 2)); ?></strong></p>
<?php endif; ?>

<?php if ($paywall_data['user_is_logged_in']): ?>
<?php if (get_option('litapay_enable_balance', '1') === '1'): // Check if balance payment is enabled ?>
<?php // B-7：<button> → <a>，支付数据编码进 href（原 data-* 会被净化器剥掉） ?>
<a href="#lp-b-<?php echo litapay_encode_pay_data([
    'pid'   => (int)$paywall_data['post_id'],
    'price' => number_format($paywall_data['price'], 2, '.', ''),
    'nonce' => $paywall_data['purchase_nonce'],
    'ajax'  => $paywall_data['ajax_url'],
]); ?>" class="litapay-purchase-btn litapay-btn-visible">用余额</a>
<?php endif; ?>

<?php if ($paywall_data['is_afdian_enabled']): // This checks LitaPay's specific Afdian enable option AND API keys
// Generate Afdian payment URL for this specific post/price
// This function now resides in litapay/includes/functions-afdian.php
$current_post_for_afdian = get_post($paywall_data['post_id']); // LitaBlog's function
$afdian_payment_url = LitaPayAfdianAPI::generate_payment_url(
'POSTID-' . $paywall_data['post_id'] . '-' . time(), // Unique order ID for Afdian
$paywall_data['price'],
$current_post_for_afdian['title'] ?? ('文章ID ' . $paywall_data['post_id'])
);
?>
<?php if ($afdian_payment_url): ?>
<?php // B-7：原 5 个 data-* 属性会被净化器剥掉，改为编码进 href ?>
<a href="#lp-a-<?php echo litapay_encode_pay_data([
    'pid'        => (int)$paywall_data['post_id'],
    'price'      => number_format($paywall_data['price'], 2, '.', ''),
    'nonce'      => $paywall_data['create_afdian_order_nonce'],
    'checkNonce' => $paywall_data['check_order_status_nonce'],
    'ajax'       => $paywall_data['ajax_url'],
]); ?>" target="_blank" class="litapay-purchase-afdian-btn litapay-btn-visible">爱发电</a>
<?php else: ?>
<!-- Optional: Message if Afdian URL generation failed for this specific item -->
<?php endif; ?>
<?php endif; ?>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<p class="litapay-balance-info">
当前余额：<?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['current_user_balance'], 2)); ?>
<?php if ($paywall_data['current_user_balance'] < $paywall_data['price']): ?>
（余额不足）<a href="<?php echo rtrim(SITE_URL, '/'); ?>/?litapay_page=recharge">去充值</a>
<?php endif; ?>
</p>
<?php endif; ?>
<?php else: ?>
<p><a href="<?php echo e($paywall_data['login_url']); ?>">登录</a>后购买。</p>
<?php endif; ?>
<div class="litapay-message-area"></div>


<?php
// --- START: Add Global Purchase Button ---
if (
$paywall_data['user_is_logged_in'] &&
!$paywall_data['user_has_global_access'] && // User doesn't already have it
$paywall_data['global_access_price'] > 0     // Global purchase is enabled and has a price
) :
?>
<span class="payment-method-separator">或者，您可以选择购买全局阅读权限：</span>
<p>全局权限：<strong><?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['global_access_price'], 2)); ?></strong></p>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<?php // B-7：同单篇，<button> → <a> + href 编码 ?>
<a href="#lp-g-<?php echo litapay_encode_pay_data([
    'nonce' => $paywall_data['purchase_global_nonce'],
    'ajax'  => $paywall_data['ajax_url'],
]); ?>" class="litapay-purchase-global-btn litapay-btn-visible">用余额</a>
<?php endif; ?>

<?php
if ($paywall_data['is_afdian_enabled']) :
// Generate Afdian payment URL for global access
$afdian_global_order_id = 'GLOBAL-' . $_SESSION['user_id'] . '-' . time();
$afdian_global_payment_url = LitaPayAfdianAPI::generate_payment_url(
$afdian_global_order_id,
$paywall_data['global_access_price'],
get_option('site_title', '本站') . '全局阅读权限' // Product title for Afdian
);
?>
<?php if ($afdian_global_payment_url): ?>
<?php // B-7：全局爱发电，postid 用 0 作为特殊标识，数据编码进 href ?>
 <a href="#lp-a-<?php echo litapay_encode_pay_data([
       'pid'        => 0, // 使用 0 作为全局标识
       'price'      => number_format($paywall_data['global_access_price'], 2, '.', ''),
       'nonce'      => $paywall_data['create_afdian_order_nonce'],
       'checkNonce' => $paywall_data['check_order_status_nonce'],
       'ajax'       => $paywall_data['ajax_url'],
 ]); ?>" target="_blank" class="litapay-purchase-afdian-btn litapay-btn-visible">爱发电</a>
<?php endif; ?>
<?php endif; ?>

<?php if (get_option('litapay_enable_balance', '1') === '1'): ?>
<p class="litapay-balance-info">
当前余额：<?php echo e($paywall_data['currency_symbol'] . number_format($paywall_data['current_user_balance'], 2)); ?>
<?php if ($paywall_data['current_user_balance'] < $paywall_data['global_access_price']): ?>
（余额不足）<a href="<?php echo litapay_get_recharge_page_url(); /* Use helper for recharge URL */ ?>">去充值</a>
<?php endif; ?>
</p>
<?php endif; ?>
<?php endif; ?>
<?php // --- END: Add Global Purchase Button --- ?>
</div>
