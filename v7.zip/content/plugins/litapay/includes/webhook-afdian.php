<?php
/**
* LitaPay - Afdian Webhook Handler
* This file is accessed directly by Afdian.
*/

// Define a constant to indicate webhook execution if needed by other files
define('LITAPAY_DOING_WEBHOOK', true);

if (!defined('LITAPAY_LOG_FILE')) {
    // B-5 修复：日志移出插件目录（Web 可达）到 content/cache/。
    // 注意：本文件是独立入口，ABSPATH / LITAPAY_PLUGIN_DIR 在下方才定义，
    // 因此此处用 dirname 向上推算博客根目录（等价于下方 $litablog_root 的算法）。
    define('LITAPAY_LOG_FILE', dirname(dirname(dirname(dirname(__DIR__)))) . '/content/cache/litapay_debug.log');
}
function litapay_logs($message, $level = 'INFO') {
  $message_string = is_string($message) ? $message : print_r($message, true);
    $log_entry = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), $level, $message_string);
    
     // 如果想写入到特定文件，可以使用 file_put_contents(LOG_FILE_PATH, $log_entry, FILE_APPEND);
@file_put_contents(LITAPAY_LOG_FILE, $log_entry, FILE_APPEND | LOCK_EX);
}
// Function to get the real IP address, considering reverse proxies
function get_real_ip_address() {
    if (isset($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // X-Forwarded-For can contain a comma-separated list of IPs. The first one is the original client.
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        return $_SERVER['REMOTE_ADDR'];
    }
    return 'N/A';
}

// start 捕获并记录完整的请求信息
// B-5 附带修复：原代码在 $request_log 初始化（下一行）之前就对其执行 `.=`，
// 触发 "Undefined variable: request_log" Notice（直接访问本文件时可见）。
// 已删除那两行错位的 `.=`（其内容与下方 "Source IP" 行重复）。
$request_log = "--- New Webhook Request Received ---\n";
$request_log .= "Request Time: " . date('Y-m-d H:i:s') . "\n";
$request_log .= "Request Method: " . ($_SERVER['REQUEST_METHOD'] ?? 'N/A') . "\n";
$request_log .= "Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "\n";
$request_log .= "Source IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";
$request_log .= "Source IP (Real): " . get_real_ip_address() . "\n";
$request_log .= "Source IP (Direct Connector): " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";

// 获取所有请求头
// B-5 修复：过滤 Cookie / Authorization / Token 敏感头，避免会话 ID 落盘
$headers = [];
foreach ($_SERVER as $key => $value) {
    if (substr($key, 0, 5) == 'HTTP_') {
        $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
        if (stripos($header, 'Cookie') !== false || stripos($header, 'Authorization') !== false || stripos($header, 'Token') !== false) {
            continue;
        }
        $headers[$header] = $value;
    }
}
$request_log .= "Request Headers: \n" . print_r($headers, true) . "\n";

// 获取原始请求体
$raw_body = file_get_contents('php://input');
$request_log .= "Raw Request Body: \n" . $raw_body . "\n";
$request_log .= "--------------------------------------\n\n";
file_put_contents(LITAPAY_LOG_FILE, $request_log, FILE_APPEND | LOCK_EX);
//end
$litablog_root = dirname(dirname(dirname(dirname(__DIR__)))); // 正确！这会指向博客根目录
if (file_exists($litablog_root . '/config.php')) {
require_once $litablog_root . '/config.php';
} else {
http_response_code(500);
error_log("LitaPay Webhook Error: LitaBlog config.php not found.".$litablog_root);
echo json_encode(['ec' => 500, 'em' => 'Core configuration missing.']);
exit;
}

if (defined('ABSPATH') && file_exists(ABSPATH . 'includes/functions.php')) {
require_once ABSPATH . 'includes/functions.php';
} else {
http_response_code(500);
error_log("LitaPay Webhook Error: LitaBlog functions.php not found.");
echo json_encode(['ec' => 500, 'em' => 'Core functions missing.']);
exit;
}

// Include LitaPay core functions
require_once dirname(__FILE__) . '/functions-core.php';
require_once dirname(__FILE__) . '/functions-afdian.php'; // For LitaPayAfdianAPI class

// --- Webhook Processing Logic ---
$raw_input = file_get_contents('php://input');
// Log all incoming requests for debugging
error_log("LitaPay Afdian Webhook Raw Input: " . $raw_input);

$webhook_data = json_decode($raw_input, true);

if (!$webhook_data || json_last_error() !== JSON_ERROR_NONE) {
http_response_code(400); // Bad Request
error_log("LitaPay Afdian Webhook Error: Invalid JSON received.");
echo json_encode(['ec' => 400, 'em' => 'Invalid JSON payload.']);
exit;
}

// Call the handler method from LitaPayAfdianAPI class
$processed = LitaPayAfdianAPI::handle_webhook($webhook_data);

if ($processed) {
http_response_code(200);
echo json_encode(['ec' => 200, 'em' => 'success']); // Afdian expects this format
} else {
// handle_webhook should log specific errors. Here we send a generic server error if it returned false.
http_response_code(500);
echo json_encode(['ec' => 500, 'em' => 'Webhook processing failed internally.']);
}
exit;
?>