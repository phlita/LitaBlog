
<?php
/**
* Plugin Name: Litapay
* Plugin URI: https://blog.lita.eu.org
* Description: Enables paid content sections, recharge codes, and Afdian payments for LitaBlog.
* Version: 1.0
* Author: 芙里塔
* Author URI: https://lita.eu.org
*/
error_log('LitaPay DEBUG: litapay.php loaded1.'); // 添加日志
if (!defined('ABSPATH')) exit; // Exit if accessed directly

define('LITAPAY_VERSION', '1.0.0');
define('LITAPAY_PLUGIN_DIR', __DIR__ . '/'); // Use __DIR__ for path
define('LITAPAY_PLUGIN_URL', rtrim(SITE_URL, '/') . '/content/plugins/litapay/'); // Construct URL based on SITE_URL
error_log('LitaPay: litapay.php loaded. LITAPAY_PLUGIN_DIR: ' . LITAPAY_PLUGIN_DIR);
// Include dependencies
require_once LITAPAY_PLUGIN_DIR . 'includes/db-schema.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-core.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-recharge.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/functions-afdian.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/shortcodes.php';
require_once LITAPAY_PLUGIN_DIR . 'includes/ajax-handlers.php';
// 调试：记录 db-schema.php 加载
error_log('LitaPay: db-schema.php included.');
if (is_admin()) { // Admin-only includes and hooks
require_once LITAPAY_PLUGIN_DIR . 'admin/admin-menu.php';
require_once LITAPAY_PLUGIN_DIR . 'admin/meta-boxes.php';
// Note: settings-page.php etc. are loaded via add_menu_page callback
}
error_log('LitaPay: Registering activation hook for: ' . __FILE__);
// Activation, Deactivation, Uninstall Hooks
register_activation_hook(__FILE__, 'litapay_activate');
register_deactivation_hook(__FILE__, 'litapay_deactivate');
// uninstall.php will be used for uninstallation.

/**
* Plugin Activation.
*/error_log('LitaPay: About to define litapay_activate function.'); 
function litapay_activate() {
error_log('LitaPay: litapay_activate function called.');
litapay_create_db_tables(); // From db-schema.php

// Add default options if any
update_option('litapay_version', LITAPAY_VERSION);
update_option('litapay_currency_symbol', '¥');
update_option('litapay_global_access_price', '99.00');
update_option('litapay_afdian_user_id', '');
update_option('litapay_afdian_api_token', '');
update_option('litapay_enable_afdian', '0'); // 0 for disabled, 1 for enabled
update_option('litapay_enable_balance', '1'); // Enable balance by default
update_option('litapay_enable_recharge_codes', '1'); // Enable recharge codes by default
// --- 新增：为新页面设置添加默认值 ---
update_option('litapay_login_page_id', 0); // 登录/注册页 ID
update_option('litapay_user_center_page_id', 0); // 用户中心页 ID
// --- 结束新增 ---
error_log('LitaPay: Default options updated.');
}

/**
* Plugin Deactivation.
*/
function litapay_deactivate() {
// Optional: actions on deactivation
}


/**
* Initialize plugin: hooks, shortcodes.
*/
function litapay_init() {
    // B-2 修复：移除原首行的 error_log('LitaPay DEBUG: litapay_init() CALLED.')（调试刷屏）

    // --- START: 新增代码 ---
    add_shortcode('litapay_user_center', 'litapay_user_center_shortcode_handler');
    add_shortcode('litapay_login_form', 'litapay_login_form_shortcode_handler');
    
    // 注册给未登录用户使用的 AJAX actions
    add_action('wp_ajax_nopriv_litapay_user_login', 'litapay_handle_ajax_login');
    add_action('wp_ajax_nopriv_litapay_user_register', 'litapay_handle_ajax_register');
    // --- END: 新增代码 ---

litapay_register_shortcodes(); // From shortcodes.php

// Register AJAX handlers
litapay_register_ajax_handlers(); // From ajax-handlers.php

// Frontend Assets
add_action('header', 'litapay_enqueue_frontend_styles');
// B-2 修复：兼容不同主题——部分主题触发 wp_footer，部分触发 footer。
// 两个都注册，函数内已用 static 防重，避免资源重复输出。
add_action('wp_footer', 'litapay_enqueue_frontend_scripts'); // LitaBlog uses 'wp_footer'
add_action('footer', 'litapay_enqueue_frontend_scripts');

// Admin Assets
add_action('admin_enqueue_scripts', 'litapay_enqueue_admin_scripts', 10, 1); // Priority, accepted_args
add_filter('the_content', 'litapay_filter_post_content', 20, 2);
}
add_action('init', 'litapay_init'); // LitaBlog's 'init' hook from includes/load.php


/**
 * B-2 修复：前端样式加载。
 * 原实现调用 wp_register_style/wp_enqueue_style —— LitaBlog（v7/v10）**没有 WordPress 资源队列**，
 * 这些函数未定义 → PHP Fatal Error → 付费墙 CSS 完全不加载；且函数内有 error_log 调试刷屏。
 * 改为 LitaBlog 原生方式：直接输出 <link>。
 */
function litapay_enqueue_frontend_styles() {
    static $done = false;
    if ($done) return;
    $done = true;
    echo '<link rel="stylesheet" href="' . e(LITAPAY_PLUGIN_URL . 'public/assets/css/litapay-frontend.css') . '?v=' . e(LITAPAY_VERSION) . '">' . "\n";
}

/**
 * B-2 修复：前端脚本加载（同上，wp_register_script/wp_enqueue_script 未定义）。
 * 另外删除了原实现中的 `echo "ok";`（调试残留，会污染页面输出）与 error_log 刷屏。
 */
function litapay_enqueue_frontend_scripts() {
    static $done = false;
    if ($done) return;
    $done = true;
    echo '<script src="' . e(LITAPAY_PLUGIN_URL . 'public/assets/js/litapay-frontend.js') . '?v=' . e(LITAPAY_VERSION) . '"></script>' . "\n";
}


/**
* Enqueue admin scripts and styles.
* $hook_suffix is provided by LitaBlog's admin_enqueue_scripts action.
*//*
function litapay_enqueue_admin_scripts($hook_suffix) {
$litapay_admin_pages = [
'admin_page_litapay-settings',
'admin_page_litapay-recharge-codes',
'admin_page_litapay-transactions',
// Add other LitaPay admin page hook suffixes here
];

// Check if current page is content editor or one of LitaPay's admin pages
$load_assets = false;
if (strpos($hook_suffix, 'content.php') === 0) { // For admin/content.php (post editor)
$load_assets = true;
} elseif (in_array($hook_suffix, $litapay_admin_pages)) {
$load_assets = true;
}

if ($load_assets) {
wp_register_style('litapay-admin-css', LITAPAY_PLUGIN_URL . 'admin/assets/css/litapay-admin.css', [], LITAPAY_VERSION);
wp_enqueue_style('litapay-admin-css');

wp_register_script('litapay-admin-js', LITAPAY_PLUGIN_URL . 'admin/assets/js/litapay-admin.js', [], LITAPAY_VERSION, true);
wp_enqueue_script('litapay-admin-js');
// Data for admin JS will be passed similarly to frontend if needed, or via data attributes.
}
}*/
/**
 * B-2 修复：后台资源加载。
 * 原实现同样调用未定义的 wp_register_style/wp_enqueue_style（LitaBlog 无 WP 资源队列）
 * → PHP Fatal Error；且函数内有 5 处 error_log 调试刷屏（含 print_r 输出数组）。
 * 改为 LitaBlog 原生方式：直接输出 <link>/<script>，并移除全部调试日志。
 */
function litapay_enqueue_admin_scripts($hook_suffix) {
$litapay_admin_page_slugs = [
'litapay-main', // The slug for the main menu page
'litapay-settings',
'litapay-recharge-codes',
'litapay-transactions',
];

// Construct the expected hook suffixes for LitaPay pages
$litapay_hook_suffixes = [];
foreach ($litapay_admin_page_slugs as $slug) {
$litapay_hook_suffixes[] = 'admin.php_page_' . $slug;
}

// Also include the content edit page for the meta box CSS/JS if needed
$load_assets = false;
if (strpos($hook_suffix, 'content.php') === 0) { // For admin/content.php (post editor)
$load_assets = true;
} elseif (in_array($hook_suffix, $litapay_hook_suffixes)) { // Check against LitaPay's admin pages
$load_assets = true;
}

if ($load_assets) {
echo '<link rel="stylesheet" href="' . e(LITAPAY_PLUGIN_URL . 'admin/css/litapay-admin.css') . '?v=' . e(LITAPAY_VERSION) . '">' . "\n";
echo '<script src="' . e(LITAPAY_PLUGIN_URL . 'admin/js/litapay-admin.js') . '?v=' . e(LITAPAY_VERSION) . '"></script>' . "\n";
}
}


// Webhook endpoint check (must be before any output or session start if not already started)
if (isset($_GET['litapay_webhook']) && $_GET['litapay_webhook'] === 'afdian') {
// This file will handle its own bootstrapping of config/functions
require_once LITAPAY_PLUGIN_DIR . 'includes/webhook-afdian.php';
exit;
}

// --- Modified Recharge Page Handling ---
if (isset($_GET['litapay_page']) && $_GET['litapay_page'] === 'recharge') {
$official_recharge_page_id = (int)get_option('litapay_official_recharge_page_id', 0);
$enable_standalone_recharge_page = get_option('litapay_enable_standalone_recharge_page', '1') === '1'; // Default enabled
$redirect_standalone_to_official = get_option('litapay_redirect_standalone_to_official', '0') === '1';

if ($official_recharge_page_id > 0 && $redirect_standalone_to_official) {
// 如果设置了官方页面并且启用了重定向，则重定向到官方页面
$official_page_url = Permalink::get_post_link($official_recharge_page_id); // LitaBlog's permalink function
if ($official_page_url) {
header('Location: ' . $official_page_url, true, 301); // Permanent redirect
exit;
} else {
// Official page ID is set but somehow couldn't get URL, fallback to standalone or error
// This case should be rare. For now, we can log and proceed to standalone if enabled.
error_log("LitaPay: Could not get permalink for official recharge page ID: " . $official_recharge_page_id);
if ($enable_standalone_recharge_page) {
require_once LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form.php';
exit;
} else {
// Neither official page URL found nor standalone enabled.
// Show a 404 or simple error message if LitaBlog's router doesn't handle it.
// For now, let's assume the router would catch it if we don't output anything.
// Or, you can explicitly send a 404 header:
if (!headers_sent()) { header("HTTP/1.0 404 Not Found"); }
echo "Recharge page not configured."; // Simple message
exit;
}
}
} elseif ($enable_standalone_recharge_page) {
// 如果启用了独立页面 (且不重定向或未设置官方页面)，则加载独立页面
require_once LITAPAY_PLUGIN_DIR . 'public/templates/recharge-form.php';
exit;
} else {
// 如果独立页面被禁用，并且没有官方页面可以重定向，则视为未找到
// LitaBlog's router should ideally handle this by not matching this condition.
// If reached here, it means ?litapay_page=recharge was accessed but standalone is disabled.
// You could send a 404 or redirect to homepage.
if (!headers_sent()) { header("HTTP/1.0 404 Not Found"); }
// For a cleaner 404, let LitaBlog's main router handle it by not outputting here
// and ensuring the Router class has a 404 fallback.
// If you want a custom message:
echo "Recharge functionality via this link is currently disabled by the administrator.";
exit;
}
}
// --- End Modified Recharge Page Handling ---
/**
 * LitaPay 插件的权限过滤器 — B-1 修复：已禁用（2026-08-30）。
 *
 * 原实现：插件激活时通过 user_has_cap 过滤器（priority 99）强制禁止非管理员发帖
 * （publish_posts = false），这**覆盖了核心 get_roles_and_caps() 中 'user' 角色
 * 本应拥有的 publish_posts = true**，导致：
 *   admin/content.php 的 current_user_can('publish_posts') 判定失败
 *   → 302 跳转 adminonly → 普通用户完全无法发帖（论坛核心功能被插件剥夺）。
 *
 * 正确原则：插件不得覆盖核心权限体系。是否允许普通用户发帖属于站点角色策略，
 * 应由核心角色配置（get_roles_and_caps）决定，而非插件硬编码。
 *
 * 保留函数定义以防外部引用，但不再注册过滤器。
 */
function litapay_disable_user_posting($has_cap, $capability, $user_role) {
    // 不做任何干预，原样返回核心的权限判定结果
    return $has_cap;
}
// 已禁用（B-1）：add_filter('user_has_cap', 'litapay_disable_user_posting', 99, 3);



?>
