<?php
/**
 * 卸载清理：仅删除插件写入的 options。
 * 歌单元数据删除；已上传的音频文件（content/uploads/music/）保留，避免"删了重建"浪费写。
 */
if (!defined('SBP_UNINSTALL_PLUGIN') && !defined('ABSPATH')) {
    // 直接访问保护：仅在经由核心卸载流程时执行
    exit;
}

if (defined('ABSPATH')) {
    // 经由核心 do_uninstall_plugin() 入口
    if (function_exists('update_option')) {
        // 用覆盖写空数组，而非 delete_option（惰性，避免删+建两次写）
        update_option('lita_music_playlist', json_encode([]));
        update_option('lita_music_settings', json_encode([]));
    }
}
