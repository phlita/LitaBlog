<?php
/**
 * Plugin Name: Lita Music
 * Description: 极简全局音乐播放器。服务器只存歌单元数据，播放状态全下沉用户本机（localStorage）。支持后台上传音频与填写外部 URL 两种方式添加歌曲。
 * Version: 1.0.0
 * Author: Lita
 */

if (!defined('ABSPATH')) exit;

// ── 常量定义 ───────────────────────────────────────────────
define('LITA_MUSIC_DIR', __DIR__ . '/');
define('LITA_MUSIC_URL', rtrim(SITE_URL, '/') . '/content/plugins/lita-music/');
define('LITA_MUSIC_UPLOAD_DIR', ABSPATH . 'content/uploads/music/');
define('LITA_MUSIC_UPLOAD_URL', rtrim(SITE_URL, '/') . '/content/uploads/music/');
define('LITA_MUSIC_OPT_PLAYLIST', 'lita_music_playlist');
define('LITA_MUSIC_OPT_SETTINGS', 'lita_music_settings');

// ── 模块加载（手工拼装，无自动加载）───────────────────────
require_once LITA_MUSIC_DIR . 'includes/functions-core.php';
require_once LITA_MUSIC_DIR . 'public/player.php';
if (is_admin()) {
    require_once LITA_MUSIC_DIR . 'admin/settings.php';
    require_once LITA_MUSIC_DIR . 'admin/editor-button.php';
}

// ── 生命周期钩子 ──────────────────────────────────────────
register_activation_hook(__FILE__, 'lita_music_activate');
register_deactivation_hook(__FILE__, 'lita_music_deactivate');

/**
 * 激活：写入默认歌单与设置（低频一次性写，免费主机无压力）。
 * 同时建立上传目录（仅在不存在时创建，避免重复写）。
 */
function lita_music_activate() {
    if (false === get_option(LITA_MUSIC_OPT_PLAYLIST)) {
        update_option(LITA_MUSIC_OPT_PLAYLIST, json_encode([]));
    }
    if (false === get_option(LITA_MUSIC_OPT_SETTINGS)) {
        update_option(LITA_MUSIC_OPT_SETTINGS, json_encode([
            'autoplay'     => 0,
            'default_mode' => 'list', // list | shuffle | repeat-one
        ]));
    }
    if (!is_dir(LITA_MUSIC_UPLOAD_DIR)) {
        @mkdir(LITA_MUSIC_UPLOAD_DIR, 0755, true);
    }
}

function lita_music_deactivate() {
    // 不删任何数据（歌单、音频文件均保留），符合"能保留就不删了重建"。
}
