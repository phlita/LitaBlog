<?php
if (!defined('ABSPATH')) exit;

/**
 * 前端播放器：在 footer 钩子一次性输出播放器 HTML + 内联样式/脚本。
 *
 * 关键设计（呼应"免费主机 + 用户本机承接"）：
 *   - 服务器只交付一次数据（window.LITA_MUSIC_DATA），之后播放过程零请求、零写。
 *   - 播放器为页面内 <audio>；页面切换时用 pagehide 把断点写入 localStorage，
 *     新页面加载后立即从断点续播（音频已被浏览器 HTTP 缓存，恢复近乎瞬时）。
 *   - 所有播放状态（进度/模式/音量/当前曲目）存用户本机 localStorage。
 *   - JS/CSS 内联，避免额外请求（免费主机带宽宝贵）。
 */

// 双钩子兼容不同主题（部分主题用 footer，部分用 wp_footer）
add_action('footer', 'lita_music_render_player', 99);
add_action('wp_footer', 'lita_music_render_player', 99);

// 短代码卡片样式：仅在短代码被使用时输出一次
add_action('footer', 'lita_music_card_style', 98);
add_action('wp_footer', 'lita_music_card_style', 98);

// 短代码：文中嵌入歌单/单曲（点击控制全局播放器）
add_shortcode('lita_music', 'lita_music_shortcode');

/**
 * 短代码卡片样式 CSS（森林绿主题风格，与全局播放器一致）。
 * 返回字符串，供短代码内联输出与 footer 钩子共用，保证样式一定生效。
 */
function lita_music_card_style_css() {
    return '.lita-music-card{max-width:420px;margin:16px 0;border:1px solid var(--forest-light,#9cb380);'
        . 'border-radius:12px;background:var(--forest-white,#f8f7f2);color:var(--forest-dark,#2c3e2d);'
        . 'font-family:var(--body-font,system-ui,-apple-system,"Segoe UI",sans-serif);overflow:hidden;'
        . 'box-shadow:0 4px 14px rgba(44,62,45,.12);}'
        . '.lita-music-card *{box-sizing:border-box;}'
        . '.lmc-audio-wrap{padding:12px 16px;}'
        . '.lmc-audio{width:100%;height:36px;accent-color:var(--forest-mid,#4a6741);}'
        . '.lmc-tracks{list-style:none;margin:0;padding:0;border-top:1px solid var(--forest-light,#9cb380);max-height:220px;overflow:auto;}'
        . '.lmc-tracks li{font-size:13px;border-bottom:1px solid var(--forest-beige,#ece8d9);}'
        . '.lmc-tracks a{display:flex;align-items:center;gap:8px;padding:9px 16px;color:var(--forest-dark,#2c3e2d);text-decoration:none;'
        . 'white-space:nowrap;overflow:hidden;cursor:pointer;}'
        . '.lmc-tracks a:hover{background:var(--forest-beige,#ece8d9);}'
        . '.lmc-tracks .lmc-active a{color:var(--forest-mid,#4a6741);}'
        . '.lmc-tracks .lmc-active a::before{content:"♫";margin-right:2px;color:var(--forest-mid,#4a6741);}'
        . '.lmc-tname{flex:1;overflow:hidden;text-overflow:ellipsis;}'
        . '.lmc-tartist{color:var(--forest-brown,#765c43);font-size:11px;flex-shrink:0;}'
        . '.lmc-ext{color:var(--forest-accent,#d9bf77);font-size:11px;flex-shrink:0;}'
        // 视频卡片（音频视频同库，视频标签共用卡片容器样式）
        . '.lita-music-card-video .lmc-audio-wrap{padding:0;}'
        . '.lmc-video{display:block;width:100%;max-height:420px;background:#000;accent-color:var(--forest-mid,#4a6741);}'
        . '.lmc-ttype{color:var(--forest-mid,#4a6741);font-size:11px;flex-shrink:0;}';
}

/**
 * 短代码卡片样式 footer 钩子：全局播放器页也输出一次（兜底）。
 */
function lita_music_card_style() {
    static $done = false;
    if ($done) return;
    $done = true;
    echo '<style>' . lita_music_card_style_css() . '</style>';
}

function lita_music_render_player() {
    static $rendered = false;
    if ($rendered) return; // 防止主题同时触发 footer 与 wp_footer 导致重复渲染
    $rendered = true;

    // 全局播放器只加载音频（视频条目由文章短代码处理，不进入全局播放器）
    $playlist = lita_music_get_audio_playlist();
    $settings = lita_music_get_settings();
    $data = [
        'playlist' => $playlist,
        'settings' => [
            'autoplay'     => !empty($settings['autoplay']),
            'default_mode' => $settings['default_mode'] ?? 'list',
        ],
    ];
    // 转义 </script 防注入
    $json = str_replace('</', '<\/', json_encode($data, JSON_UNESCAPED_UNICODE));
    ?>
    <div id="lita-music-root" aria-live="polite"></div>
    <script>
    window.LITA_MUSIC_DATA = <?php echo $json; ?>;
    (function () {
        'use strict';
        var DATA = window.LITA_MUSIC_DATA || { playlist: [], settings: {} };
        var LS_KEY = 'lita_music_state';
        var list = DATA.playlist;
        var root = document.getElementById('lita-music-root');
        if (!root) return;

        function loadState() {
            try {
                var s = JSON.parse(localStorage.getItem(LS_KEY));
                if (s && typeof s === 'object') return s;
            } catch (e) {}
            return { index: -1, time: 0, mode: DATA.settings.default_mode || 'list', volume: 0.8, open: false, playing: false };
        }
        function saveState() {
            state.time = audio.currentTime || 0;
            state.playing = !audio.paused;
            try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) {}
        }

        if (!list.length) {
            // 无歌曲时不渲染播放器，避免无效 IO/UI
            return;
        }

        var state = loadState();
        var audio = new Audio();
        audio.volume = state.volume;
        audio.preload = 'auto'; // 页面加载即预取音频（已缓存时近乎瞬时），配合续播

        // ── 渲染播放器 UI（方形播放钮 + 侧边展开钮 + 163 风格面板）──
        root.innerHTML = ''
            + '<div id="lm-bar" class="' + (state.open ? 'lm-open' : '') + (state.playing ? ' lm-playing' : '') + '">'
            +   '<div class="lm-panel" id="lm-panel">'
            +     '<div class="lm-controls">'
            +       '<span class="lm-time" id="lm-time-cur">0:00</span>'
            +       '<input type="range" class="lm-progress" id="lm-progress" min="0" max="100" value="0">'
            +       '<span class="lm-time" id="lm-time-dur">0:00</span>'
            +       '<button class="lm-btn" id="lm-mode" title="播放模式">' + modeLabel(state.mode) + '</button>'
            +       '<button class="lm-btn" id="lm-prev" title="上一首">⏮</button>'
            +       '<button class="lm-play" id="lm-toggle" title="播放/暂停">' + (state.playing ? '⏸' : '▶') + '</button>'
            +       '<button class="lm-btn" id="lm-next" title="下一首">⏭</button>'
            +       '<input type="range" class="lm-vol" id="lm-vol" min="0" max="1" step="0.05" value="' + state.volume + '" title="音量">'
            +     '</div>'
            +     '<div class="lm-tracks" id="lm-tracks"></div>'
            +   '</div>'
            +   '<div class="lm-body">'
            +     '<button class="lm-expand" id="lm-list" title="展开/收起播放器">' + (state.open ? '✕' : '☰') + '</button>'
            +     '<button class="lm-square" id="lm-toggle2" title="播放/暂停">' + (state.playing ? '⏸' : '▶') + '</button>'
            +   '</div>'
            + '</div>';

        var elToggle  = document.getElementById('lm-toggle');
        var elToggle2 = document.getElementById('lm-toggle2');
        var elProg    = document.getElementById('lm-progress');
        var elTimeCur = document.getElementById('lm-time-cur');
        var elTimeDur = document.getElementById('lm-time-dur');
        var elMode    = document.getElementById('lm-mode');
        var elVol     = document.getElementById('lm-vol');
        var elList    = document.getElementById('lm-list');
        var elTracks  = document.getElementById('lm-tracks');
        var bar       = document.getElementById('lm-bar');

        function modeLabel(m) { return m === 'shuffle' ? '🔀' : (m === 'repeat-one' ? '🔂' : '📜'); }
        function fmt(s) { s = Math.floor(s || 0); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }

        function renderPanel() {
            var html = '<ul class="lm-tracks">';
            list.forEach(function (t, i) {
                html += '<li data-i="' + i + '" class="' + (i === state.index ? 'lm-active' : '') + '">'
                    +   '<span class="lm-tname">' + escapeHtml(t.title || '未命名') + '</span>'
                    +   (t.artist ? ' <span class="lm-tartist">' + escapeHtml(t.artist) + '</span>' : '')
                    +   (t.local ? '' : ' <span class="lm-ext" title="外部链接，需 CSP media-src 放行">↗</span>')
                    + '</li>';
            });
            html += '</ul>';
            elTracks.innerHTML = html;
            Array.prototype.forEach.call(elTracks.querySelectorAll('li'), function (li) {
                li.addEventListener('click', function () { playIndex(parseInt(li.getAttribute('data-i'), 10)); });
            });
        }
        function escapeHtml(s) {
            return String(s).replace(/[&<>"']/g, function (c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
        }

        function setMeta(i) {
            Array.prototype.forEach.call(elTracks.querySelectorAll('li'), function (li, idx) {
                li.className = idx === i ? 'lm-active' : '';
            });
        }

        function pauseArticleAudios() {
            // 暂停文章中所有媒体卡片（音频+视频），避免多路同时出声
            document.querySelectorAll('.lita-music-card audio.lmc-audio, .lita-music-card video.lmc-video').forEach(function (a) {
                a.pause();
            });
        }

        function playIndex(i) {
            if (i < 0 || i >= list.length) return;
            pauseArticleAudios();
            state.index = i;
            state.time = 0;
            setMeta(i);
            audio.src = list[i].src;
            audio.play().then(function () {
                state.playing = true;
                elToggle.textContent = '⏸';
                if (elToggle2) elToggle2.textContent = '⏸';
                bar.className = (state.open ? 'lm-open ' : '') + 'lm-playing';
                saveState();
            }).catch(function () {
                // 自动播放被拦截或外部 URL 被 CSP 拦截：仅更新状态，不报错刷屏
                state.playing = false;
                elToggle.textContent = '▶';
                if (elToggle2) elToggle2.textContent = '▶';
                bar.className = state.open ? 'lm-open' : '';
                saveState();
            });
            saveState();
        }

        function nextIndex() {
            if (!list.length) return -1;
            if (state.mode === 'shuffle') return Math.floor(Math.random() * list.length);
            return (state.index + 1) % list.length;
        }
        function prevIndex() {
            if (!list.length) return -1;
            if (state.mode === 'shuffle') return Math.floor(Math.random() * list.length);
            return (state.index - 1 + list.length) % list.length;
        }

        // ── 事件（直接操作页面内 <audio>）──
        function toggle() {
            if (state.index < 0) { playIndex(0); return; }
            if (audio.paused) {
                pauseArticleAudios();
                audio.play().then(function () {
                    state.playing = true;
                    elToggle.textContent = '⏸';
                    if (elToggle2) elToggle2.textContent = '⏸';
                    bar.className = (state.open ? 'lm-open ' : '') + 'lm-playing';
                    saveState();
                }).catch(function () {});
            } else {
                audio.pause();
                state.playing = false;
                elToggle.textContent = '▶';
                if (elToggle2) elToggle2.textContent = '▶';
                bar.className = state.open ? 'lm-open' : '';
                saveState();
            }
        }
        elToggle.addEventListener('click', toggle);
        if (elToggle2) elToggle2.addEventListener('click', toggle);
        document.getElementById('lm-next').addEventListener('click', function () { playIndex(nextIndex()); });
        document.getElementById('lm-prev').addEventListener('click', function () { playIndex(prevIndex()); });
        elMode.addEventListener('click', function () {
            state.mode = state.mode === 'list' ? 'shuffle' : (state.mode === 'shuffle' ? 'repeat-one' : 'list');
            elMode.textContent = modeLabel(state.mode);
            saveState();
        });
        elVol.addEventListener('input', function () {
            state.volume = parseFloat(elVol.value);
            audio.volume = state.volume;
            saveState();
        });
        elList.addEventListener('click', function () {
            state.open = !state.open;
            bar.className = (state.open ? 'lm-open ' : '') + (state.playing ? 'lm-playing' : '');
            elList.textContent = state.open ? '✕' : '☰';
            saveState();
        });
        elProg.addEventListener('input', function () {
            if (audio.duration) { audio.currentTime = (elProg.value / 100) * audio.duration; }
        });

        // ── <audio> 事件 ──
        audio.addEventListener('timeupdate', function () {
            if (audio.duration) {
                elProg.value = (audio.currentTime / audio.duration) * 100;
                elTimeCur.textContent = fmt(audio.currentTime);
                elTimeDur.textContent = fmt(audio.duration);
                state.time = audio.currentTime;
                // 节流写：每 ~5s 落一次 localStorage，避免高频写用户本机
                if (Math.floor(audio.currentTime) % 5 === 0) saveState();
            }
        });
        audio.addEventListener('ended', function () {
            if (state.mode === 'repeat-one' && state.index >= 0) {
                audio.currentTime = 0; audio.play();
            } else {
                playIndex(nextIndex());
            }
        });
        audio.addEventListener('pause', function () { state.playing = false; saveState(); });
        audio.addEventListener('play', function () {
            state.playing = true;
            elToggle.textContent = '⏸';
            if (elToggle2) elToggle2.textContent = '⏸';
            bar.className = (state.open ? 'lm-open ' : '') + 'lm-playing';
            saveState();
        });

        // ── 无缝续播：页面卸载前保存断点，新页面加载后立即续播 ──
        window.addEventListener('pagehide', function () {
            saveState();
        });
        window.addEventListener('pageshow', function (e) {
            // 浏览器往返缓存（bfcache）恢复时继续播放
            if (e.persisted && state.playing && audio.src && audio.paused) {
                audio.play().catch(function () {});
            }
        });

        // ── 初始恢复 ──
        renderPanel();
        if (state.index >= 0 && state.index < list.length) {
            setMeta(state.index);
            audio.src = list[state.index].src;
            if (state.time > 0) audio.currentTime = state.time;
            elTimeCur.textContent = fmt(state.time);
            elTimeDur.textContent = '0:00';
            // 若上次在播放（用户点链接跳转前），新页面加载后自动从断点续播
            if (state.playing) {
                var resume = function () { audio.play().catch(function () {}); };
                if (document.readyState === 'complete') { resume(); }
                else { window.addEventListener('load', resume); }
            }
        }

        // 暴露给短代码：play 播放指定曲目；pause 供文章卡片暂停全局播放器
        window.LitaMusic = {
            play: playIndex,
            pause: function () {
                audio.pause();
                state.playing = false;
                elToggle.textContent = '▶';
                if (elToggle2) elToggle2.textContent = '▶';
                bar.className = state.open ? 'lm-open' : '';
                saveState();
            }
        };

        // 注入样式（一次性内联）
        if (!document.getElementById('lm-style')) {
            var st = document.createElement('style');
            st.id = 'lm-style';
            st.textContent = ''
                // ── 方形播放钮 + 侧边展开钮 + 融入论坛森林绿主题的面板 ──
                // 位置：桌面端与右侧按钮同列(right:40px)，置于快捷发文(bottom:92px)上方(bottom:150px)；移动端对齐(right:20px)置于上方(bottom:130px)
                // 按钮尺寸 42px = 主题悬浮钮(返回顶部/快捷发文)直径，同一垂直列
                // 配色引用主题 CSS 变量 var(--forest-*)：--forest-dark:#2c3e2d / --forest-mid:#4a6741 / --forest-light:#9cb380 / --forest-white:#f8f7f2 / --forest-beige:#ece8d9 / --forest-brown:#765c43
                + '#lm-bar{position:fixed;right:40px;bottom:150px;z-index:9999;'
                + 'font-family:var(--body-font,system-ui,-apple-system,"Segoe UI",sans-serif);'
                + 'display:flex;flex-direction:column;align-items:flex-end;gap:10px;}'
                + '#lm-bar *{box-sizing:border-box;margin:0;padding:0;}'
                // 底部按钮组：方形播放钮(42px=主题钮直径) + 侧边展开钮(42px 同尺寸)，垂直对齐主题按钮列
                + '.lm-body{display:flex;align-items:center;gap:10px;}'
                + '.lm-square{width:42px;height:42px;border-radius:12px;border:none;cursor:pointer;color:#fff;font-size:17px;'
                + 'background:linear-gradient(135deg,var(--forest-mid,#4a6741),var(--forest-dark,#2c3e2d));'
                + 'display:flex;align-items:center;justify-content:center;'
                + 'box-shadow:0 4px 14px rgba(44,62,45,.4);transition:transform .15s,box-shadow .2s;}'
                + '.lm-square:hover{transform:scale(1.06);box-shadow:0 6px 20px rgba(44,62,45,.55);}'
                + '.lm-square:active{transform:scale(.94);}'
                + '.lm-expand{width:42px;height:42px;border-radius:12px;border:none;cursor:pointer;font-size:16px;'
                + 'background:var(--forest-mid,#4a6741);color:var(--forest-white,#f8f7f2);'
                + 'box-shadow:0 4px 14px rgba(44,62,45,.35);transition:background .15s,transform .1s;}'
                + '.lm-expand:hover{background:var(--forest-dark,#2c3e2d);}'
                + '.lm-expand:active{transform:scale(.92);}'
                // 面板（论坛浅色卡片风，从按钮左侧横向滑出；absolute 定位不占位）
                + '.lm-panel{position:absolute;right:calc(100% + 14px);bottom:0;width:340px;max-width:calc(100vw - 170px);'
                + 'background:rgba(248,247,242,.98);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);'
                + 'border:1px solid var(--forest-light,#9cb380);border-radius:12px;'
                + 'box-shadow:0 12px 36px rgba(44,62,45,.22);overflow:hidden;display:flex;flex-direction:column;'
                + 'opacity:0;transform:translateX(12px);pointer-events:none;transform-origin:right center;'
                + 'transition:opacity .22s,transform .22s;}'
                + '#lm-bar.lm-open .lm-panel{opacity:1;transform:none;pointer-events:auto;}'
                // 控制行：时间+进度条+控制按钮合并一横排，进度条被压缩变短
                + '.lm-controls{display:flex;align-items:center;gap:8px;padding:10px 12px;'
                + 'border-bottom:1px solid var(--forest-light,#9cb380);}'
                + '.lm-progress{flex:1;min-width:40px;height:4px;accent-color:var(--forest-mid,#4a6741);cursor:pointer;background:transparent;}'
                + '.lm-time{font-size:10px;color:var(--forest-brown,#765c43);white-space:nowrap;min-width:26px;text-align:center;}'
                + '.lm-btn{background:none;border:none;color:var(--forest-mid,#4a6741);font-size:15px;cursor:pointer;padding:3px;line-height:1;transition:color .15s,transform .1s;}'
                + '.lm-btn:hover{color:var(--forest-dark,#2c3e2d);transform:scale(1.1);}'
                + '.lm-play{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--forest-mid,#4a6741),var(--forest-dark,#2c3e2d));'
                + 'border:none;color:#fff;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;'
                + 'box-shadow:0 3px 10px rgba(44,62,45,.4);transition:transform .12s,box-shadow .2s;}'
                + '.lm-play:hover{transform:scale(1.08);box-shadow:0 5px 16px rgba(44,62,45,.55);}'
                + '.lm-play:active{transform:scale(.94);}'
                + '.lm-vol{width:48px;accent-color:var(--forest-mid,#4a6741);cursor:pointer;}'
                // 歌单列表直接显示（无头部标题）
                + '.lm-tracks{list-style:none;margin:0;padding:0;overflow:auto;max-height:240px;}'
                + '.lm-tracks li{padding:9px 16px;cursor:pointer;font-size:13px;color:var(--forest-dark,#2c3e2d);display:flex;align-items:center;gap:8px;'
                + 'border-bottom:1px solid var(--forest-beige,#ece8d9);white-space:nowrap;overflow:hidden;}'
                + '.lm-tracks li:hover{background:var(--forest-beige,#ece8d9);}'
                + '.lm-tracks .lm-active{color:var(--forest-mid,#4a6741);}'
                + '.lm-tracks .lm-active::before{content:"♫";margin-right:2px;color:var(--forest-mid,#4a6741);}'
                + '.lm-tname{flex:1;overflow:hidden;text-overflow:ellipsis;}'
                + '.lm-tartist{color:var(--forest-brown,#765c43);font-size:11px;flex-shrink:0;}'
                + '.lm-ext{color:var(--forest-accent,#d9bf77);font-size:11px;flex-shrink:0;}'
                // 移动端适配：与主题按钮组同列（right:20px），置于快捷发文(bottom:70px)上方
                + '@media(max-width:900px){'
                + '#lm-bar{right:20px;bottom:130px;}'
                + '.lm-panel{width:calc(100vw - 150px);}'
                + '.lm-vol{display:none;}'
                + '}';
            document.head.appendChild(st);
        }
    })();
    </script>
    <?php
}

/**
 * 短代码 [lita_music]：在文章中嵌入音频/视频媒体播放（单一媒体库，按 type 渲染 audio/video）。
 * 支持参数：
 *   [lita_music]                  → 完整媒体列表卡片，默认选中首项（音频/视频混排）
 *   [lita_music start="2"]        → 媒体列表卡片，默认选中第 3 项（index 从 0 计）
 *   [lita_music track="3"]        → 单项媒体卡片（只播这一项，按 type 渲染 audio/video）
 *   [lita_music list="0"]         → 仅显示可点击列表，点击调全局播放器（仅音频项有效）
 * 卡片自带原生 <audio>/<video controls>，不依赖全局悬浮播放器。
 */
function lita_music_shortcode($atts) {
    $defaults = ['start' => 0, 'track' => -1, 'list' => 1];
    $atts = array_merge($defaults, is_array($atts) ? $atts : []);

    $list = lita_music_get_playlist();
    if (empty($list)) return '<p style="color:#999">（暂无媒体）</p>';

    $track = (int)$atts['track'];

    // 单曲模式：只渲染这一首
    if ($track >= 0 && $track < count($list)) {
        $t = $list[$track];
        return lita_music_wrap_card(lita_music_render_track_card($t, $track, $list));
    }

    // 仅列表模式（点击调全局播放器）—— href 携带索引，规避净化器剥 data-* 与 script
    if ((int)$atts['list'] === 0) {
        $html = '<ol class="lita-music-shortcode">';
        foreach ($list as $i => $t) {
            $html .= '<li><a href="#lm-global-' . $i . '" class="lm-sc-track" title="' . e($t['title'] ?: '') . '">'
                . e($t['title'] ?: '未命名')
                . (empty($t['artist']) ? '' : ' — ' . e($t['artist']))
                . '</a></li>';
        }
        $html .= '</ol>';
        return lita_music_wrap_card($html);
    }

    // 完整歌单卡片（默认），start 指定默认选中
    return lita_music_wrap_card(lita_music_render_playlist_card($list, (int)$atts['start']));
}

/**
 * 段落保护包装：解决"多个短代码被净化器包进一个 div"的缺陷。
 *
 * 根因：Quill 编辑器把 [sc] 包进 <p>，do_shortcode 替换后变成 <p><div class="card">...</div></p>。
 * HTML5 规范 <p> 不能包含 <div>，litablog_purify_html 的 DOMDocument 解析时自动隐式闭合 <p>，
 * 把多个 <div> 卡片踢到同一层级，又因 loadHTML('<div>'+html+'</div>') 强制包裹，最终所有卡片
 * 收进一个根 div → 表现为"3 张卡片包在一个 div 块"。
 *
 * 解法（WordPress block shortcode 标准做法）：卡片前后补 </p> 和 <p>，让
 * <p>[sc]</p> → <p></p><div class="card">…</div><p></p>，解析合法、每张卡片独立。
 * 空段落通过卡片自身的 margin 抵消视觉影响。
 */
function lita_music_wrap_card($html) {
    return '</p>' . $html . '<p>';
}

/**
 * 渲染单曲卡片：原生 <audio>/<video controls> 播放（按 type 判断标签，
 * 核心净化器允许 audio/video 与 controls 属性，不依赖内联 JS，绝对可靠）。
 */
function lita_music_render_track_card($t, $index, $list) {
    $src = e($t['src']);
    $aid = 'lma_' . substr(md5($src), 0, 8);
    $tag = ($t['type'] ?? '') === 'video' ? 'video' : 'audio';
    $cls = $tag === 'video' ? 'lmc-video' : 'lmc-audio';
    $cardcls = $tag === 'video' ? 'lita-music-card lita-music-card-video' : 'lita-music-card lita-music-card-single';
    // 精简卡片：直接点原生控件播放；视频卡带类型标记类名
    return '<div class="' . $cardcls . '" id="' . $aid . '-card">'
        . '<div class="lmc-audio-wrap">'
        .   '<' . $tag . ' controls preload="none" class="' . $cls . '" id="' . $aid . '" src="' . $src . '"></' . $tag . '>'
        . '</div>'
        . '</div>';
}

/**
 * 渲染完整媒体卡片：原生 <audio>/<video controls> + 可点击列表（音频视频混排）。
 * 播放器标签按列表首项 type 决定；列表项切换时委托脚本按目标 type 换标签。
 * 注意：核心 litablog_purify_html 会剥除 data-* 属性与 script/style/button/input，
 * 因此列表项用 <a href="{URL}"> 携带 URL，委托脚本读 href 切换。
 */
function lita_music_render_playlist_card($list, $start = 0) {
    if ($start < 0 || $start >= count($list)) $start = 0;
    $aid = 'lma_' . substr(md5(json_encode(array_column($list, 'src'))), 0, 8);
    $first = $list[$start];
    $tag = ($first['type'] ?? '') === 'video' ? 'video' : 'audio';
    $cls = $tag === 'video' ? 'lmc-video' : 'lmc-audio';
    $html = '<div class="lita-music-card lita-music-playlist" id="' . $aid . '-card">';
    $html .= '<div class="lmc-audio-wrap">'
        . '<' . $tag . ' controls preload="none" class="' . $cls . '" id="' . $aid . '" src="' . e($first['src']) . '"></' . $tag . '>'
        . '</div>';
    $html .= '<ol class="lmc-tracks">';
    foreach ($list as $i => $t) {
        $active = ($i === $start) ? ' lmc-active' : '';
        $ttype = ($t['type'] ?? '') === 'video' ? 'video' : 'audio';
        $html .= '<li class="lmc-track' . $active . '">'
            . '<a href="' . e($t['src']) . '" class="lmc-track-link" title="' . e($t['title'] ?: '') . '">'
            . '<span class="lmc-tname">' . e($t['title'] ?: '未命名') . '</span>'
            . (empty($t['artist']) ? '' : ' <span class="lmc-tartist">' . e($t['artist']) . '</span>')
            . '<span class="lmc-ttype">' . ($ttype === 'video' ? '🎬' : '♪') . '</span>'
            . (empty($t['local']) ? ' <span class="lmc-ext">↗</span>' : '')
            . '</a></li>';
    }
    $html .= '</ol></div>';
    return $html;
}

/**
 * 短代码卡片委托脚本（footer 输出，避开 the_content 净化器剥 script）。
 * 功能：
 *   1. 歌单卡片点击列表项 → 切换 audio src 并播放（互斥暂停其他）。
 *   2. 任何卡片 audio 开始播放 → 暂停全局悬浮播放器与其他卡片（双音频冲突处理）。
 *   3. 全局悬浮播放器开始播放 → 暂停所有卡片 audio。
 *   4. "在全局播放器播放"链接 → 调 window.LitaMusic.play()。
 */
function lita_music_card_delegate_script() {
    static $done = false;
    if ($done) return;
    $done = true;
    ?>
<script>
(function () {
    'use strict';
    function pauseAllCardAudios(except) {
        document.querySelectorAll('.lita-music-card audio.lmc-audio, .lita-music-card video.lmc-video').forEach(function (a) {
            if (a !== except) a.pause();
        });
    }
    function pauseGlobal() {
        if (window.LitaMusic && window.LitaMusic.pause) window.LitaMusic.pause();
    }
    function playCard(audio, except) {
        if (window.LitaMusic && window.LitaMusic.pause) window.LitaMusic.pause(); // 停全局
        pauseAllCardAudios(except); // 停其他卡片
        audio.play().catch(function () {});
    }

    // 按 URL 扩展名判断媒体类型（净化器会剥 data-*，故用 href 推断）
    function mediaTypeOf(url) {
        var m = /\.(mp4|webm|mov|m4v)(?:$|[?#])/i.exec(url || '');
        return m ? 'video' : 'audio';
    }

    // 事件委托：媒体列表点击 → 按目标类型切换 audio/video 标签
    document.addEventListener('click', function (e) {
        var link = e.target && e.target.closest ? e.target.closest('a.lmc-track-link') : null;
        if (link) {
            var card = link.closest('.lita-music-card');
            var wrap = card ? card.querySelector('.lmc-audio-wrap') : null;
            var href = link.getAttribute('href');
            var wantType = mediaTypeOf(href);
            var cur = wrap ? wrap.querySelector('audio.lmc-audio, video.lmc-video') : null;
            var curType = cur ? (cur.tagName === 'VIDEO' ? 'video' : 'audio') : 'audio';
            if (wrap && href) {
                // 类型变化则重建标签；否则直接换 src
                if (curType !== wantType) {
                    var nid = 'lma_' + Math.random().toString(16).slice(2, 10);
                    var ntag = document.createElement(wantType === 'video' ? 'video' : 'audio');
                    ntag.controls = true;
                    ntag.preload = 'none';
                    ntag.className = wantType === 'video' ? 'lmc-video' : 'lmc-audio';
                    ntag.id = nid;
                    ntag.src = href;
                    if (cur) cur.remove();
                    wrap.appendChild(ntag);
                    cur = ntag;
                } else {
                    cur.src = href;
                }
                // 高亮当前项
                Array.prototype.forEach.call(card.querySelectorAll('.lmc-tracks li'), function (x) {
                    x.classList.remove('lmc-active');
                });
                var li = link.closest('li');
                if (li) li.classList.add('lmc-active');
                playCard(cur, cur);
            }
            e.preventDefault();
            return;
        }
        // 仅列表模式的 .lm-sc-track（href="#lm-global-N" 携带索引，调全局播放器）
        var link = e.target && e.target.closest
            ? e.target.closest('.lm-sc-track')
            : null;
        if (link) {
            e.preventDefault();
            var m = /#lm-global-(\d+)/.exec(link.getAttribute('href') || '');
            if (m && window.LitaMusic && window.LitaMusic.play) {
                window.LitaMusic.play(parseInt(m[1], 10));
            }
        }
    });

    // 捕获阶段监听：任何卡片 audio/video 开始播放 → 停全局 + 其他卡片
    document.addEventListener('play', function (e) {
        var a = e.target;
        if (a && a.classList && (a.classList.contains('lmc-audio') || a.classList.contains('lmc-video'))) {
            pauseGlobal();
            pauseAllCardAudios(a);
        }
    }, true);

    // 全局播放器暴露互斥钩子：playIndex 内部已暂停卡片，此处兜底
    if (window.LitaMusic && window.LitaMusic._bindMutex) window.LitaMusic._bindMutex(pauseAllCardAudios);
})();
</script>
    <?php
}
add_action('footer', 'lita_music_card_delegate_script', 99);
add_action('wp_footer', 'lita_music_card_delegate_script', 99);


