<?php
if (!defined('ABSPATH')) exit;

/**
 * 后台管理：双通道添加歌曲（上传 / 外部 URL），并列出歌单可删除。
 *
 * 设计边界（已确认）：插件只负责"存和播"，不管 CSP 放行。
 * 外部 URL 能否播放取决于核心 CSP 的 media-src，本页在醒目位置提示站长前提条件。
 */

add_action('admin_menu', 'lita_music_register_menu');

function lita_music_register_menu() {
    add_menu_page(
        'Lita 音乐',
        '音乐',
        'manage_options',
        'lita-music',
        'lita_music_render_settings_page',
        '',
        76
    );
}

function lita_music_render_settings_page() {
    if (!is_admin()) {
        echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
        return;
    }

    $msg = '';

    // ── 处理表单提交（POST 到当前 admin.php?page=lita-music）──
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = isset($_POST['lm_action']) ? sanitize_text_field($_POST['lm_action']) : '';

        if ($action === 'add_upload') {
            if (!verifyCsrfToken($_POST['lm_nonce'] ?? '', 'lita_music_add')) {
                $msg = '<div class="alert alert-danger">安全校验失败，请重试。</div>';
            } else {
                $r = lita_music_handle_upload(
                    $_FILES['lm_file'] ?? null,
                    trim($_POST['lm_title'] ?? ''),
                    trim($_POST['lm_artist'] ?? '')
                );
                $msg = is_string($r)
                    ? '<div class="alert alert-danger">添加失败：' . e($r) . '</div>'
                    : '<div class="alert alert-success">已添加（上传）：' . e($r['title']) . '</div>';
            }
        } elseif ($action === 'add_url') {
            if (!verifyCsrfToken($_POST['lm_nonce'] ?? '', 'lita_music_add')) {
                $msg = '<div class="alert alert-danger">安全校验失败，请重试。</div>';
            } else {
                $url = trim($_POST['lm_url'] ?? '');
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    $msg = '<div class="alert alert-danger">请输入合法的 URL。</div>';
                } else {
                    $r = lita_music_add_track([
                        'title'  => trim($_POST['lm_title'] ?? ''),
                        'artist' => trim($_POST['lm_artist'] ?? ''),
                        'src'    => $url,
                        'local'  => 0,
                    ]);
                    $msg = $r
                        ? '<div class="alert alert-success">已添加（外部链接）：' . e($r['title']) . '</div>'
                        : '<div class="alert alert-danger">写入歌单失败。</div>';
                }
            }
        } elseif ($action === 'delete') {
            if (!verifyCsrfToken($_POST['lm_nonce'] ?? '', 'lita_music_delete')) {
                $msg = '<div class="alert alert-danger">安全校验失败，请重试。</div>';
            } else {
                $id = isset($_POST['lm_id']) ? sanitize_text_field($_POST['lm_id']) : '';
                if (lita_music_delete_track($id)) {
                    $msg = '<div class="alert alert-success">已删除该曲目（音频文件保留）。</div>';
                } else {
                    $msg = '<div class="alert alert-warning">未找到该曲目。</div>';
                }
            }
        } elseif ($action === 'settings') {
            if (verifyCsrfToken($_POST['lm_nonce'] ?? '', 'lita_music_settings')) {
                $settings = lita_music_get_settings();
                $settings['autoplay'] = isset($_POST['lm_autoplay']) ? 1 : 0;
                $settings['default_mode'] = in_array($_POST['lm_mode'] ?? '', ['list', 'shuffle', 'repeat-one'])
                    ? $_POST['lm_mode'] : 'list';
                lita_music_save_settings($settings);
                $msg = '<div class="alert alert-success">设置已保存。</div>';
            }
        }
    }

    $playlist = lita_music_get_playlist();
    $settings = lita_music_get_settings();
    $add_nonce = generateCsrfToken('lita_music_add');
    $del_nonce = generateCsrfToken('lita_music_delete');
    $set_nonce = generateCsrfToken('lita_music_settings');
    ?>
    <div class="card" style="max-width:960px;margin:0 auto;">
        <?php echo $msg; ?>

        <div class="alert alert-info" style="font-size:13px;line-height:1.7;">
            <strong>前提说明（务必阅读）：</strong>
            <ul style="margin:6px 0 0 18px;">
                <li><strong>上传方式</strong>：音频/视频统一存到本站 <code>content/uploads/music/</code>，同源，CSP 默认放行，最省心。</li>
                <li><strong>外部 URL 方式</strong>：媒体托管在第三方。当前核心 CSP 的 <code>default-src 'self'</code> 会拦截非同源媒体。
                    若外部链接无法播放，需站长在 <code>includes/load.php</code> 或服务器的 CSP 中把对应域名加入 <code>media-src</code> 白名单。
                    <em>插件本身不负责放行。</em></li>
                <li>前端全局播放器只加载音频；视频条目仅通过 <code>[lita_music track="n"]</code> 插入文章。</li>
                <li>播放进度、音量、模式等状态全部保存在<strong>访客浏览器 localStorage</strong>，服务器零写入、零带宽，最适合免费主机。</li>
            </ul>
        </div>

        <h3 style="margin-top:24px;">① 上传媒体文件（音频/视频）</h3>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="lm_action" value="add_upload">
            <input type="hidden" name="lm_nonce" value="<?php echo e($add_nonce); ?>">
            <p><label>文件：</label> <input type="file" name="lm_file" accept="audio/*,video/*" required></p>
            <p><label>标题：</label> <input type="text" name="lm_title" placeholder="留空则用文件名"></p>
            <p><label>艺术家（音频可选）：</label> <input type="text" name="lm_artist"></p>
            <p><button type="submit" class="button button-primary">上传并添加</button></p>
        </form>

        <h3 style="margin-top:24px;">② 填写外部媒体 URL（音频/视频）</h3>
        <form method="post">
            <input type="hidden" name="lm_action" value="add_url">
            <input type="hidden" name="lm_nonce" value="<?php echo e($add_nonce); ?>">
            <p><label>URL：</label> <input type="url" name="lm_url" placeholder="https://example.com/song.mp3 或 video.mp4" style="width:60%" required></p>
            <p><label>标题：</label> <input type="text" name="lm_title"></p>
            <p><label>艺术家（音频可选）：</label> <input type="text" name="lm_artist"></p>
            <p><button type="submit" class="button button-primary">添加链接</button></p>
        </form>

        <h3 style="margin-top:24px;">播放设置</h3>
        <form method="post">
            <input type="hidden" name="lm_action" value="settings">
            <input type="hidden" name="lm_nonce" value="<?php echo e($set_nonce); ?>">
            <p>
                <label>默认模式：</label>
                <select name="lm_mode">
                    <option value="list"<?php echo ($settings['default_mode'] ?? 'list') === 'list' ? ' selected' : ''; ?>>顺序列表</option>
                    <option value="shuffle"<?php echo ($settings['default_mode'] ?? '') === 'shuffle' ? ' selected' : ''; ?>>随机</option>
                    <option value="repeat-one"<?php echo ($settings['default_mode'] ?? '') === 'repeat-one' ? ' selected' : ''; ?>>单曲循环</option>
                </select>
                &nbsp;&nbsp;
                <label><input type="checkbox" name="lm_autoplay" value="1"<?php echo !empty($settings['autoplay']) ? ' checked' : ''; ?>> 加载时自动恢复播放</label>
            </p>
            <p><button type="submit" class="button">保存设置</button></p>
        </form>

        <h3 style="margin-top:24px;">媒体库（共 <?php echo count($playlist); ?> 项，音频 + 视频）</h3>
        <?php if (empty($playlist)): ?>
            <p style="color:#999;">暂无媒体，请使用上方方式添加。</p>
        <?php else: ?>
            <table class="widefat" style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr><th>类型</th><th>标题</th><th>艺术家</th><th>来源</th><th>添加时间</th><th>操作</th></tr>
                </thead>
                <tbody>
                <?php foreach ($playlist as $t): ?>
                    <tr>
                        <td><?php echo ($t['type'] ?? 'audio') === 'video' ? '🎬 视频' : '♪ 音频'; ?></td>
                        <td><?php echo e($t['title'] ?? ''); ?></td>
                        <td><?php echo e($t['artist'] ?? ''); ?></td>
                        <td><?php echo !empty($t['local']) ? '本站上传' : '外部链接 ↗'; ?></td>
                        <td><?php echo date('Y-m-d H:i', $t['added'] ?? time()); ?></td>
                        <td>
                            <form method="post" style="display:inline;" onsubmit="return confirm('确认删除该媒体？文件将保留。');">
                                <input type="hidden" name="lm_action" value="delete">
                                <input type="hidden" name="lm_nonce" value="<?php echo e($del_nonce); ?>">
                                <input type="hidden" name="lm_id" value="<?php echo e($t['id'] ?? ''); ?>">
                                <button type="submit" class="button">删除</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}
