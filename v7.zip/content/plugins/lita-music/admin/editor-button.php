<?php
if (!defined('ABSPATH')) exit;

/**
 * 后台编辑器集成：在 Quill 工具栏添加"♫ 音乐"按钮。
 * 点击弹出媒体列表（音频+视频混排，带类型标记），选中后插入 [lita_music track="n"] / [lita_music] 短代码。
 *
 * 接入方式：admin_footer 钩子，仅 content.php 编辑页生效（与 litamarkdown 相同模式）。
 */

add_action('admin_footer', 'lita_music_admin_editor_button');

function lita_music_admin_editor_button() {
    $current_page = basename($_SERVER['PHP_SELF'] ?? '');
    if ($current_page !== 'content.php') return;

    $list = lita_music_get_playlist();
    if (empty($list)) $list = [];
    ?>
<style>
.lm-ebtn{display:inline-flex;align-items:center;gap:4px;padding:0 8px;height:24px;cursor:pointer;
    border-radius:4px;color:#4a6741;font-weight:600;background:none;border:none;font-size:14px;}
.lm-ebtn:hover{background:#e3ead9;}
.lm-music-modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:99999;
    justify-content:center;align-items:center;font-family:var(--body-font,system-ui,sans-serif);}
.lm-music-modal.open{display:flex;}
.lm-music-dialog{background:#f8f7f2;border:1px solid #9cb380;border-radius:12px;width:90%;max-width:480px;
    max-height:80vh;overflow:auto;box-shadow:0 12px 40px rgba(0,0,0,.25);}
.lm-music-dialog-head{padding:14px 16px;font-weight:600;color:#2c3e2d;border-bottom:1px solid #9cb380;
    display:flex;align-items:center;justify-content:space-between;}
.lm-music-dialog-head .lm-close{cursor:pointer;border:none;background:none;font-size:18px;color:#765c43;}
.lm-music-empty{padding:24px;color:#765c43;text-align:center;}
.lm-music-item{display:flex;align-items:center;gap:10px;padding:10px 16px;cursor:pointer;border-bottom:1px solid #ece8d9;}
.lm-music-item:hover{background:#ece8d9;}
.lm-music-item .t{flex:1;min-width:0;}
.lm-music-item .t .n{font-size:14px;color:#2c3e2d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.lm-music-item .t .a{font-size:11px;color:#765c43;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.lm-music-item .tag{font-size:10px;color:#9cb380;flex-shrink:0;}
.lm-music-item .insert{font-size:12px;color:#4a6741;flex-shrink:0;}
.lm-music-dialog .all-btn{display:block;width:100%;padding:12px 16px;border:none;background:none;cursor:pointer;
    font-size:13px;color:#4a6741;font-weight:600;text-align:center;border-bottom:1px solid #ece8d9;}
.lm-music-dialog .all-btn:hover{background:#ece8d9;}
</style>
<!-- 媒体插入弹层（音频+视频混排） -->
<div class="lm-music-modal" id="lm-music-modal">
    <div class="lm-music-dialog">
        <div class="lm-music-dialog-head">
            <span>插入媒体</span>
            <button class="lm-close" id="lm-music-close" title="关闭">✕</button>
        </div>
        <?php if (empty($list)): ?>
            <div class="lm-music-empty">媒体库为空，请先到「音乐」后台添加。</div>
        <?php else: ?>
            <button class="all-btn" data-sc="[lita_music]">🎵 插入完整媒体列表卡片</button>
            <?php foreach ($list as $i => $t): ?>
            <div class="lm-music-item" data-sc="<?php echo e('[lita_music track="' . $i . '"]'); ?>">
                <span class="tag"><?php echo ($t['type'] ?? 'audio') === 'video' ? '🎬' : '♪'; ?></span>
                <div class="t">
                    <div class="n"><?php echo e($t['title'] ?: '未命名'); ?></div>
                    <?php if (!empty($t['artist'])): ?><div class="a"><?php echo e($t['artist']); ?></div><?php endif; ?>
                </div>
                <span class="tag"><?php echo !empty($t['local']) ? '本站' : '外链'; ?></span>
                <span class="insert">插入 →</span>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var timer = setInterval(function () {
        if (!window.quillInstance) return;
        clearInterval(timer);
        var toolbars = document.querySelectorAll('.ql-toolbar');
        if (!toolbars.length) return;
        var tb = toolbars[0];
        if (tb.querySelector('#lm-music-btn')) return;
        var b = document.createElement('button');
        b.type = 'button'; b.id = 'lm-music-btn'; b.className = 'lm-ebtn'; b.textContent = '♫ 音乐';
        b.addEventListener('click', function () { openModal(); });
        var clean = tb.querySelector('.ql-clean');
        if (clean) clean.parentNode.insertBefore(b, clean.nextSibling);
        else tb.appendChild(b);
    }, 300);

    function openModal() {
        var m = document.getElementById('lm-music-modal');
        if (m) m.classList.add('open');
    }
    function closeModal() {
        var m = document.getElementById('lm-music-modal');
        if (m) m.classList.remove('open');
    }
    document.getElementById('lm-music-close').addEventListener('click', closeModal);
    document.getElementById('lm-music-modal').addEventListener('click', function (e) {
        if (e.target === this) closeModal();
    });

    function insertShortcode(sc) {
        if (window.quillInstance) {
            var range = window.quillInstance.getSelection(true) || { index: 0 };
            window.quillInstance.insertText(range.index, '\n' + sc + '\n', 'user');
            window.quillInstance.setSelection(range.index + sc.length + 2);
        }
        closeModal();
    }
    document.querySelectorAll('.lm-music-item[data-sc], .all-btn[data-sc]').forEach(function (el) {
        el.addEventListener('click', function () {
            insertShortcode(el.getAttribute('data-sc'));
        });
    });
});
</script>
    <?php
}
