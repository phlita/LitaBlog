<?php
if (!defined('ABSPATH')) exit;

/**
 * 核心数据函数：歌单元数据存于 options 表，读取走 PHP static 内存缓存。
 * 设计原则（呼应 io.md / 免费主机约束）：
 *   - 能读就不写：播放过程完全不调用本文件（状态在用户本机 localStorage）。
 *   - 能内存就不磁盘：一次请求内多次读取只查一次库（static 缓存）。
 *   - 能批量就不零散：增删改均整体覆写一次 option，绝不做逐条事务。
 *   - 能保留就不删了重建：删除歌曲只从数组移除并覆盖写，不 delete_option 后重建。
 */

/**
 * 取歌单（带内存缓存）。
 * @return array [{id,title,artist,src,local,added}]
 */
function lita_music_get_playlist() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $raw = get_option(LITA_MUSIC_OPT_PLAYLIST);
    $decoded = $raw ? json_decode($raw, true) : [];
    $cache = is_array($decoded) ? $decoded : [];
    return $cache;
}

/**
 * 整体保存歌单（惰性覆盖写，非删建）。
 */
function lita_music_save_playlist($list) {
    return update_option(LITA_MUSIC_OPT_PLAYLIST, json_encode(array_values($list)));
}

/**
 * 取设置（带内存缓存）。
 */
function lita_music_get_settings() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $raw = get_option(LITA_MUSIC_OPT_SETTINGS);
    $decoded = $raw ? json_decode($raw, true) : [];
    $cache = is_array($decoded) ? $decoded : [];
    return $cache;
}

function lita_music_save_settings($settings) {
    return update_option(LITA_MUSIC_OPT_SETTINGS, json_encode($settings));
}

/**
 * 根据 URL 扩展名推断媒体类型：video / audio（默认 audio）。
 */
function lita_music_type_from_src($src) {
    $ext = strtolower(pathinfo(parse_url($src, PHP_URL_PATH) ?: $src, PATHINFO_EXTENSION));
    if (in_array($ext, lita_music_allowed_video_exts(), true)) return 'video';
    return 'audio';
}

/**
 * 净化单条曲目输入（音频与视频同库，type 按扩展名推断）。
 */
function lita_music_sanitize_track($track) {
    $src = trim((string)($track['src'] ?? ''));
    return [
        'id'     => isset($track['id']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $track['id']) : uniqid('t_', true),
        'title'  => trim(strip_tags((string)($track['title'] ?? ''))),
        'artist' => trim(strip_tags((string)($track['artist'] ?? ''))),
        'src'    => $src,
        'type'   => ($track['type'] ?? '') === 'video' ? 'video' : lita_music_type_from_src($src),
        'local'  => !empty($track['local']) ? 1 : 0,
        'added'  => isset($track['added']) ? (int)$track['added'] : time(),
    ];
}

/**
 * 全局播放器使用的音频歌单（只含 type=audio，视频不加载）。
 * 带内存缓存。
 */
function lita_music_get_audio_playlist() {
    static $acache = null;
    if ($acache !== null) return $acache;
    $all = lita_music_get_playlist();
    $audio = [];
    foreach ($all as $t) {
        if (($t['type'] ?? 'audio') === 'audio') $audio[] = $t;
    }
    // 重排索引（前端按数组下标播放）
    $acache = array_values($audio);
    return $acache;
}

/**
 * 新增一首歌曲到歌单（内存读→追加→整体覆盖写，单次写）。
 */
function lita_music_add_track($track) {
    $list = lita_music_get_playlist();
    $track = lita_music_sanitize_track($track);
    if ($track['title'] === '') $track['title'] = '未命名曲目';
    $list[] = $track;
    return lita_music_save_playlist($list) ? $track : false;
}

/**
 * 删除一首歌曲（仅从数组移除并覆盖写，不触碰音频文件本身）。
 */
function lita_music_delete_track($id) {
    $list = lita_music_get_playlist();
    $new = [];
    foreach ($list as $t) {
        if (($t['id'] ?? '') !== $id) $new[] = $t;
    }
    if (count($new) === count($list)) return false; // 未找到
    return lita_music_save_playlist($new);
}

/**
 * 允许的扩展名（音频 + 视频，单一媒体库）。
 * type 由扩展名推断：音频→audio，视频→video。
 */
function lita_music_allowed_exts() {
    return array_merge(lita_music_allowed_audio_exts(), lita_music_allowed_video_exts());
}

function lita_music_allowed_audio_exts() {
    return ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'];
}

function lita_music_allowed_video_exts() {
    return ['mp4', 'webm', 'mov', 'm4v'];
}

/**
 * 处理后台"上传文件"方式添加：移动文件到 content/uploads/music/，返回曲目数组或错误串。
 * 音频/视频统一入口，type 由扩展名推断。
 */
function lita_music_handle_upload($file_input, $title, $artist) {
    if (empty($file_input) || !isset($file_input['error']) || $file_input['error'] !== UPLOAD_ERR_OK) {
        return '上传失败（错误码 ' . ($file_input['error'] ?? '?') . '）';
    }
    $name = $file_input['name'];
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, lita_music_allowed_exts(), true)) {
        return '不支持的媒体格式，仅允许：' . implode(', ', lita_music_allowed_exts());
    }
    if (!is_dir(LITA_MUSIC_UPLOAD_DIR)) {
        @mkdir(LITA_MUSIC_UPLOAD_DIR, 0755, true);
    }
    // 安全文件名：随机前缀 + 原扩展名，避免覆盖与路径注入
    $stored = uniqid('m_', true) . '.' . $ext;
    $dest = LITA_MUSIC_UPLOAD_DIR . $stored;
    if (!move_uploaded_file($file_input['tmp_name'], $dest)) {
        return '文件保存失败，请检查 uploads 目录权限';
    }
    $src = LITA_MUSIC_UPLOAD_URL . $stored;
    $track = lita_music_sanitize_track([
        'title'  => $title ?: pathinfo($name, PATHINFO_FILENAME),
        'artist' => $artist,
        'src'    => $src,
        'type'   => lita_music_type_from_src($src),
        'local'  => 1,
    ]);
    return lita_music_add_track($track) ?: '写入媒体库失败';
}
