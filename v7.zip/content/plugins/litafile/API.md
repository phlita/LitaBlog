# litafile Agent API 调用说明

> 版本：litafile v1.0.0 ／ 文档更新：2026-09-16
> 适用：给 AI／脚本调用本站的「媒体与文件」能力（上传、列表、下载链接、密码、歌单、删除）

---

## 0. 依赖：密钥由 `lita-agent-api` 插件签发 ★（先看这段）

**litafile 不自己管理密钥** ✓ —— 它直接复用 `lita-agent-api` 插件写入的 option：

| 密钥类型 | option 名 | litafile 里的权限 |
|---|---|---|
| **Admin**（全能） | `lita_agent_api_key_admin` | 读 + 写（上传 / 修改 / 删除 / 歌单增删） |
| **Comment**（只读） | `lita_agent_api_key_comment` | 只读（list / get / 歌单 list、items） |

**去哪里拿密钥**：后台菜单「**Agent API**」（地址 `/admin/admin.php?page=agent_api_settings`）→
点「生成 / 更新 Admin Key」或「生成 Comment Key」✓（该插件还能给指定用户签发 `usermeta.agent_api_key`，
但 **litafile 目前只认 admin / comment 两把钥匙** ✗）。

---

## 1. 认证（三选一，推荐第一种）

```
Authorization: Bearer <key>
X-API-Key: <key>
?apikey=<key>          # 需在 litafile 设置里勾选「允许用 ?apikey= 传密钥」；默认关闭（密钥会进访问日志 ✗）
```

鉴权失败：`401 {"code":401,"message":"认证失败：无效的 API Key。","data":null}`

## 2. 统一响应

```json
{ "code": 200, "message": "ok", "data": { } }
```

`code` **同时**就是 HTTP 状态码 ✓；`data` 随 `action` 变化 ✓。

## 3. 端点（推荐：`?agent_api=litafile`）

基础地址：`http://<你的站点>/`（本站框架站点在根目录；生产在子目录时用 `.../v10/` ✓）

### 3.1 条目 `resource=items`

| 方法 | URL | 权限 | 说明 |
|---|---|---|---|
| GET | `?agent_api=litafile&resource=items&action=list&page=1&per_page=20&kind=audio&search=xx&source=` | 任意 Key | 分页列表。`kind`：`all/image/audio/video/file`；`source`：`local/remote` 或留空 |
| GET | `?agent_api=litafile&resource=items&action=get&id=1` | 任意 Key | 单条详情（含 `token` 与访问 `url`；**不含密码哈希** ✓） |
| POST | `?agent_api=litafile&resource=items&action=update&id=1` | Admin | 改 `title` / `artist` / `description` / `filename`；`password=` 传空串=**清除密码** ✓ |
| DELETE | `?agent_api=litafile&resource=items&action=delete&id=1` | Admin | 删除条目（本地文件一并删除；旧目录文件只删记录 ✓） |
| POST | `?agent_api=litafile&resource=items&action=upload` | Admin | 上传（见 3.3） |

### 3.2 歌单 `resource=playlists`

| 方法 | URL | 权限 | 说明 |
|---|---|---|---|
| GET | `?agent_api=litafile&resource=playlists&action=list` | 任意 Key | 全部歌单（含条目数 `count`） |
| GET | `?agent_api=litafile&resource=playlists&action=items&playlist_id=1&audio_only=1` | 任意 Key | 歌单内容 |
| POST | `?agent_api=litafile&resource=playlists&action=create`（`name`、可选 `is_default=1`） | Admin | 新建歌单 |
| POST | `?agent_api=litafile&resource=playlists&action=add` / `remove`（`playlist_id`、`item_id`） | Admin | 加入 / 移出 |

> ⚠️ **歌单只收音频** ✓：`kind != audio` 的条目加入会被拒（`400`）——这是产品规则，不是 bug ✓。

### 3.3 上传的两种入参

**① multipart（推荐）**

```bash
curl -X POST "http://localhost/?agent_api=litafile&resource=items&action=upload" \
  -H "Authorization: Bearer $KEY" \
  -F "file=@songs/abc.mp3" \
  -F "title=歌曲名" -F "artist=歌手" -F "password="
```

**② JSON + Base64**（适合不方便传文件的客户端）

```bash
curl -X POST "http://localhost/?agent_api=litafile&resource=items&action=upload" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"filename":"abc.mp3","data":"<base64>","mime_type":"audio/mpeg","title":"歌曲名"}'
```

**成功响应（`201`）**

```json
{
  "code": 201, "message": "上传成功",
  "data": {
    "id": 7, "filename": "abc.mp3", "filesize": 2512345, "mime_type": "audio/mpeg",
    "has_password": false, "kind": "audio",
    "download_url": "http://localhost/?litafile_dl=7&token=...",
    "shortcode": "[litafile id=7]"
  }
}
```

> 插入文章时用返回的 `shortcode` ✓（**只此一种**：`[litafile id=N]`；旧的 `[download id=N]` 已不再渲染 ✗）。

## 4. 常见动作速查（curl）

```bash
KEY=sk-admin-xxxxxxxx

# 列表（只看音频）
curl -s -H "Authorization: Bearer $KEY" \
  "http://localhost/?agent_api=litafile&resource=items&action=list&kind=audio" | jq .

# 单条详情
curl -s -H "Authorization: Bearer $KEY" \
  "http://localhost/?agent_api=litafile&resource=items&action=get&id=7" | jq .

# 拿下载直链（不真的下载；mode=url）
curl -s -H "Authorization: Bearer $KEY" \
  "http://localhost/?agent_api=files&action=download&mode=url&id=7" | jq .

# 新建歌单 + 加入两首歌
curl -s -X POST -H "Authorization: Bearer $KEY" \
  -d "name=我的歌单" "http://localhost/?agent_api=litafile&resource=playlists&action=create" | jq .
curl -s -X POST -H "Authorization: Bearer $KEY" \
  -d "playlist_id=2&item_id=7" "http://localhost/?agent_api=litafile&resource=playlists&action=add" | jq .

# 删除条目
curl -s -X DELETE -H "Authorization: Bearer $KEY" \
  "http://localhost/?agent_api=litafile&resource=items&action=delete&id=7" | jq .
```

## 5. 旧形态 `?agent_api=files`（保留，但**新脚本不要用**）

`?agent_api=files&action=upload|download|list|delete` 与老 cloud-drive 的参数/响应保持一致 ✓，
仅为兼容既有脚本而保留 ✓。**新脚本请统一用第 3 节的 `?agent_api=litafile`** ✓。

## 6. 排障对照表

| 现象 | 原因 / 处理 |
|---|---|
| `401 认证失败` | Key 错或还没生成 → 去「Agent API」页面生成 ✓ |
| `403 权限不足` | 用了只读 Key 做写操作；或歌单增删没带 Admin Key ✓ |
| `400 歌单只收音频` | `item_id` 指向的不是 `audio` 条目 ✓ |
| `400 缺少 filename 或 data` | JSON 上传时字段漏了 ✓ |
| `302`（不是 JSON） | `action=download` 指向 **remote 外链**条目时会 302 到外链 ✓（这是设计行为 ✓） |
| `403 此文件需要密码才能下载` | 条目带密码：`action=download` 时附加 `&password=xxx` ✓ |
| `404 条目不存在` | `id` 不对（先 `action=list` 取 id ✓） |
| `OPTIONS` 预检 | 直接返回 `200 {}` ✓（CORS 允许来源可在设置里收紧 ✓） |
