<?php
/**
 * litafile/public/shortcodes.php — 短代码渲染
 *
 * 只认**新标签**（2026-09-16 用户明确：litafile 是新插件，旧标签兼容没必要留着 ✗）：
 *   `[litafile id=N mode=auto|embed|link]`、`[litafile_playlist id=N]`
 * 渲染出的 HTML 仍**同时带旧类名**（`.cloud-media` 等）——那只是 CSS 类名复用，与"旧标签兼容"无关 ✓
 */

if (!defined('ABSPATH')) exit;

/** 文件大小可读化 */
function litafile_format_size($bytes) {
    $bytes = (int)$bytes;
    if ($bytes <= 0) return '—';
    $u = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < 4) { $bytes /= 1024; $i++; }
    return round($bytes, $i === 0 ? 0 : 1) . $u[$i];
}

/** 图标 */
function litafile_kind_icon($kind) {
    switch ($kind) {
        case 'image': return '🖼️';
        case 'audio': return '🎵';
        case 'video': return '🎬';
        default:      return '📄';
    }
}

/**
 * 渲染"媒体本体"（不含信息条 / 下载链接 ✓）。
 * 抽出来是为了让 `mode=file`（只显示内容 ✓）与 `mode=auto`（内容 + 信息条 ✓）共用同一段 HTML ✓
 */
function litafile_bare_media($item, $kind) {
    $src   = e(litafile_stream_url($item, true));
    $label = e($item['title'] !== '' ? $item['title'] : $item['filename']);
    if ($kind === 'image') {
        return '<img class="litafile-el cloud-media-el" src="' . $src . '" alt="' . $label . '" loading="lazy" decoding="async">';
    }
    if ($kind === 'audio') {
        return '<audio class="litafile-el cloud-media-el" controls preload="metadata" src="' . $src . '"></audio>';
    }
    return '<video class="litafile-el cloud-media-el" controls preload="metadata" playsinline src="' . $src . '"></video>';
}

/**
 * 编辑器/Agent 插入时用的短代码文本（2026-09-16 用户定义 ✓）。
 *
 * 规则（用户原话："媒体资源就 =file，文件类型可以下载的 =link" ✓）：
 *   · 媒体（图片/音频/视频）且**无密码** → `mode=file`：只显示内容，不显示下载链接与信息 ✓
 *   · 其它（文档/压缩包/…）或**受密码保护**的条目 → `mode=link`：只给下载链接 ✓
 *     （受密码保护的媒体也不能内嵌 ✗ —— 内嵌会绕过密码 ✓）
 *   · **不写 mode 的 `[litafile id=N]`** 仍然表示"两者都显示" ✓（手动写标签时可用 ✓）
 */
function litafile_shortcode_for_item($item) {
    if (!$item) return '';
    $kind = (string)($item['kind'] ?? 'file');
    $pw   = !empty($item['password']);
    $mode = (!$pw && in_array($kind, ['image', 'audio', 'video'], true)) ? 'file' : 'link';
    return '[litafile id=' . (int)$item['id'] . ' mode=' . $mode . ']';
}

/**
 * 渲染单个条目。
 *
 * mode 语义（2026-09-16 用户定义 ✓）：
 *   省略 / auto → 媒体：内容 + 信息条（两者都显示 ✓）；非媒体：下载卡片
 *   file        → **只显示内容**（媒体本体，无信息条/无下载链接 ✓）；非媒体无法内嵌 → 退化为卡片（即只有链接 ✓）
 *   link        → **只显示链接**（下载卡片；媒体也不再内嵌 ✓）
 *   embed       → 旧写法，等同 auto 对媒体的处理（内容 + 信息条 ✓），保留兼容 ✓
 *
 * @param array  $item
 * @param string $mode auto|file|link|embed
 */
function litafile_render_item($item, $mode = 'auto') {
    if (!$item) return '';
    $kind = $item['kind'] ?? 'file';
    $need_pw = litafile_needs_password($item);
    $mode = strtolower(trim((string)$mode));
    if (!in_array($mode, ['auto', 'file', 'link', 'embed'], true)) $mode = 'auto';

    // 受密码保护：一律只给"下载卡片"（内嵌会绕过密码 ✗）
    $embed = ($mode !== 'link') && !$need_pw && in_array($kind, ['image', 'audio', 'video'], true);

    if ($embed) {
        $media = litafile_bare_media($item, $kind);
        if ($mode === 'file') {
            // 只显示内容 ✓：不加信息条、不给下载链接 ✓
            // （要下载仍可用浏览器原生右键/控件菜单 ✓，那是浏览器行为、不是页面上的链接 ✓）
            return '<div class="litafile-media litafile-media-bare cloud-media">' . $media . '</div>';
        }
        $label = e($item['title'] !== '' ? $item['title'] : $item['filename']);
        $dl    = e(litafile_stream_url($item, false));
        $ext   = e(strtoupper(litafile_ext($item['filename'])));
        $size  = litafile_format_size($item['filesize']);
        return '<div class="litafile-media cloud-media">' . $media
             . '<div class="litafile-media-bar cloud-media-bar">'
             . '<span>' . $label . ($ext !== '' ? ' · ' . $ext : '') . ' · ' . $size . '</span>'
             . '<a href="' . $dl . '" target="_blank" rel="noopener">下载</a>'
             . '</div></div>';
    }

    // 下载卡片
    $url   = e(litafile_stream_url($item, false));
    $label = e($item['title'] !== '' ? $item['title'] : $item['filename']);
    $sub   = trim(($item['artist'] !== '' ? e($item['artist']) . ' · ' : '')
                . strtoupper(e(litafile_ext($item['filename']))) . ' · ' . litafile_format_size($item['filesize'])
                . ($item['download_count'] ? ' · ' . (int)$item['download_count'] . ' 次下载' : ''));
    $desc  = $item['description'] !== '' ? '<div class="sub">' . e($item['description']) . '</div>' : '';
    $lock  = $need_pw ? ' <span class="litafile-lock">🔒 需密码</span>' : '';
    return '<div class="litafile-card cloud-download-box"><div class="ic cloud-dl-ic">' . litafile_kind_icon($kind) . '</div>'
         . '<div class="meta cloud-dl-meta"><span class="nm cloud-dl-name">' . $label . $lock . '</span>'
         . '<span class="sub cloud-dl-sub">' . $sub . '</span>' . $desc . '</div>'
         . '<a class="btn cloud-dl-btn" href="' . $url . '" target="_blank" rel="noopener">' . ($need_pw ? '输入密码' : '下载') . '</a></div>';
}

/** 渲染歌单（卡片 + 条目列表；音频可直接播放） */
function litafile_render_playlist($playlist_id = 0, $args = []) {
    $auto_play_index = (int)($args['start'] ?? -1);
    if ($playlist_id <= 0) $playlist_id = litafile_default_playlist_id();
    if ($playlist_id <= 0) return '';
    $items = litafile_playlist_items($playlist_id, false);
    if (!$items) return '';
    $pl = litafile_get_playlist($playlist_id);

    $html = '<div class="litafile-pl lita-music-card">';
    $html .= '<div class="litafile-pl-hd lmc-hd">🎧 ' . e($pl['name'] ?? '歌单') . ' <span class="a">(' . count($items) . ')</span></div><ul>';
    $i = 0;
    foreach ($items as $it) {
        $is_audio = ($it['kind'] === 'audio');
        $src = e(litafile_stream_url($it, true));
        $label = e($it['title'] !== '' ? $it['title'] : $it['filename']);
        $artist = $it['artist'] !== '' ? '<span class="a">' . e($it['artist']) . '</span>' : '';
        $cur = ($i === $auto_play_index) ? ' class="cur"' : '';
        $html .= '<li' . $cur . ' data-src="' . $src . '" data-kind="' . e($it['kind']) . '">'
               . '<span class="idx">' . ($i + 1) . '</span>'
               . '<a class="t" href="' . $src . '">' . $label . '</a>' . $artist
               . '<audio class="litafile-pl-a" preload="none" src="' . $src . '"></audio>'
               . '</li>';
        $i++;
    }
    $html .= '</ul>';
    // 若指定了 start，自动播放对应曲目（浏览器策略可能拦截，前端会兜底提示）
    if ($auto_play_index >= 0) {
        $html .= '<script>(function(){var l=document.querySelectorAll(".litafile-pl li")[' . $auto_play_index . '];'
               . 'if(l){var a=l.querySelector("audio");if(a){a.preload="metadata";a.play().catch(function(){});}}})();</script>';
    }
    return $html . '</div>';
}

/* ───────────────────────── 短代码注册 ─────────────────────────────────── */

function litafile_shortcode_item($atts) {
    $a = shortcode_atts(['id' => 0, 'mode' => 'auto'], (array)$atts);
    $item = litafile_get_item((int)$a['id']);
    return $item ? litafile_render_item($item, (string)$a['mode']) : '';
}

function litafile_shortcode_playlist_new($atts) {
    $a = shortcode_atts(['id' => 0, 'start' => -1], (array)$atts);
    return litafile_render_playlist((int)$a['id'], ['start' => (int)$a['start']]);
}

/**
 * 旧短代码处理函数（`litafile_shortcode_download` = [download]、
 * `litafile_shortcode_playlist` = [lita_music]）已按用户要求**删除** ✗（2026-09-16）。
 * 本插件只认新标签：`[litafile id=N]` 与 `[litafile_playlist id=N]` ✓
 */

/** 从字符串解析 id= / mode= 属性 */
function litafile_parse_atts($raw) {
    $out = [];
    if (preg_match('/\bid\s*=\s*["\']?(\d+)/i', $raw, $m)) $out['id'] = (int)$m[1];
    if (preg_match('/\bmode\s*=\s*["\']?(auto|file|embed|link)/i', $raw, $m)) $out['mode'] = strtolower($m[1]);
    return $out;
}

/**
 * 内容过滤（早期展开，priority 5）：避免内容里出现 markdown/净化器把短代码拆坏的情况
 * ——旧 cloud-drive 也有这一步（pre_markdown_process），这里做等价处理。
 */
function litafile_expand_shortcodes_early($content) {
    if (!is_string($content) || $content === '') return $content;
    // 2026-09-16：旧标签 [download] / [lita_music] 的展开已按用户要求删除 ✗（litafile 是新插件）
    if (strpos($content, '[litafile') === false) {
        return $content;
    }
    $content = preg_replace_callback(
        '/\[litafile\s+([^\]]*)\]/i',
        function ($m) { return litafile_shortcode_item(litafile_parse_atts($m[1])); },
        $content
    );
    $content = preg_replace_callback(
        '/\[litafile_playlist\s*([^\]]*)\]/i',
        function ($m) { return litafile_shortcode_playlist_new(litafile_parse_atts($m[1])); },
        $content
    );
    return $content;
}
