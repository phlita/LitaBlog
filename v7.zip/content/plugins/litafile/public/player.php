<?php
/**
 * litafile/public/player.php — 全局悬浮播放器
 *
 * ★2026-09-16 简化版 UI（用户要求"位置/界面简化，参考 lita-music 的设计，能否再简化" ✓）
 *
 * 沿用了用户认可的旧 lita-music `#lm-bar` 设计语言 ✓：
 *   · 与主题右下角悬浮钮（返回顶部 / 快捷发文）**同列同尺寸**：right:40px + 42px 方块 ✓
 *   · 面板从圆钮**左侧横向滑出**（absolute 定位，不占位 ✓），浅色卡片 + 森林绿描边 ✓
 *   · 配色引用主题 CSS 变量 `--forest-*` ✓（原来是蓝色 ✗，与森林绿主题不搭 ✓）
 *
 * 在这基础上**再简化**：
 *   ① 默认状态只剩**一枚 42px 圆钮**（点它展开面板；播放状态用 ♫ / ⏸ 表达 ✓）
 *   ② 彻底去掉标题栏 ✗ ③ 时间不再独占一行 ✗（缩成进度条两端 10px 小字 ✓）
 *   ④ 去掉音量滑杆 ✗ ⑤ 曲目列表默认收起（点 ≡ 展开 ✓）⑥ 点面板外自动收起 ✓
 *
 * ★续播（2026-09-16，用户报"页面刷新或切换回就从头播放" ✓ 根因已实测定位）：
 *   本站是 **MPA**（多页文档）✗ —— 实测证据：
 *     · 同一页面**切标签再切回**：文档不重建、播放不中断 ✓（`__probeMark` 还在、0:04→0:10 ✓）
 *     · **链接导航 / 刷新**：浏览器新建文档 ✓（probeMark 消失 ✓）→ 页面里的 `new Audio()` 随页面销毁 ✓
 *   而 `localStorage['litafile_state']` **只存了 `{i, mode}`** ✗ —— 没有播放位置、没有"是否在播" ✓
 *   ⇒ 新页面只能知道"上次听第几首" ✓，无从知道"听到几分几秒" ✗ → 必然从 0 开始 ✓（实测新页面点播放 = 0:01 ✓）
 *   （浏览器自动播放策略还会再放大症状：新文档没有用户手势 → 带声音的 play() 被拦 ✓，
 *     表现为"点了才响、而且从头响" ✓）
 *
 *   ⇒ 修法（本文件）：把状态扩成 `{i, mode, t: 秒, id: 条目id, p: 是否在播, ts: 时间戳}` ✓，
 *      新页面等 `loadedmetadata` 后 `currentTime = t`（夹在末尾前 1 秒 ✓）再按需续播 ✓。
 *      只在 ① 未过期（30 分钟 ✓）② **同一条目**（避免换页后套用到另一首歌里乱跳 ✗）时才套用 ✓。
 *      `preload` 从 none 改成 metadata ✓（要恢复进度必须先有时长 ✓，代价每首几十 KB ✓）。
 *      ⚠️ 真正的"零中断"只有把前台做成 SPA/iframe 壳才行 ✗（页面不重建 ✓）；这里做的是
 *         "听感近似连续"（有 0.3~1s 重新缓冲 ✓）—— 这是 MPA 下的现实最优解 ✓。
 */
if (!defined('ABSPATH')) exit;

function litafile_render_player() {
    static $rendered = false;
    if ($rendered) return;
    $s = litafile_get_settings();
    if (empty($s['player_enabled'])) return;

    // ⚠️ 歌单为空也照常输出播放器（2026-09-16 用户报障：勾了"前台显示悬浮播放器"却看不到播放器 ✗）
    //    原来这里 `if (!$items) return;` 会把**空歌单**整个吞掉 ✗ → 用户以为功能缺失 ✓
    //    现在 0 首也渲染外壳、面板里提示"歌单里还没有音频"，加了音频后自动生效 ✓
    $items = litafile_default_playlist_items(true);   // 只取 audio
    $rendered = true;

    $data = [];
    foreach ($items as $it) {
        $data[] = [
            'id'     => (int)$it['id'],
            'title'  => $it['title'] !== '' ? $it['title'] : $it['filename'],
            'artist' => $it['artist'],
            'src'    => litafile_stream_url($it, true),
        ];
    }
    $cfg = [
        'autoplay' => (int)!empty($s['player_autoplay']),
        'mode'     => (string)$s['player_mode'],
    ];

    // ── 背景音乐（2026-09-16）───────────────────────────────────────────────
    // 勾选「背景音乐自动播放」后，按**页面特征**（正文字数/主题词）自动挑一首相关氛围的曲子
    // 循环低音量播放 ✓；且**必须「自动播放」也勾了才生效** ✓（litafile_bgm_enabled ✓）
    // 选曲是确定性的（同一篇文章永远同一首 ✓）→ 与整页缓存友好共存 ✓，也让"续播"更自然 ✓
    $bgm = null;
    if (litafile_bgm_enabled($s)) {
        $bgm = litafile_bgm_pick($items, $s);   // $items 顺序 == $data 顺序 ✓（同一个数组建出来的 ✓）
        if ($bgm) $cfg['bgm'] = $bgm;
    }
    $tracks = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $cfgjs  = json_encode($cfg, JSON_UNESCAPED_UNICODE);

    echo <<<HTML
<div id="litafile-player">
  <div class="lp-panel">
    <div class="lp-row">
      <button type="button" id="lp-listbtn" title="曲目列表">≡</button>
      <span class="ttl">未在播放</span>
      <button type="button" id="lp-prev" title="上一首">⏮</button>
      <button type="button" class="main" id="lp-toggle" title="播放/暂停">▶</button>
      <button type="button" id="lp-next" title="下一首">⏭</button>
      <button type="button" id="lp-mode" title="播放模式">↻</button>
    </div>
    <div class="lp-bar" id="lp-bar"><i></i></div>
    <div class="lp-tm"><span id="lp-cur">0:00</span><span id="lp-dur">0:00</span></div>
    <ul class="lp-list" id="lp-list"></ul>
  </div>
  <button type="button" class="lp-bubble" id="lp-open" title="音乐">♫</button>
</div>
<script>
(function(){
  var TRACKS = {$tracks}, CFG = {$cfgjs};
  var box = document.getElementById('litafile-player');
  if (!box) return;
  var ttl = box.querySelector('.ttl');
  var bubble = document.getElementById('lp-open');
  var listBox = document.getElementById('lp-list');
  var bar = document.getElementById('lp-bar');

  function open(on){ box.classList.toggle('lp-open', !!on); }
  function fmt(t){ t = Math.max(0, t|0); return (t/60|0) + ':' + ('0' + (t%60)).slice(-2); }

  // 空歌单：仍然渲染 + 可展开（否则用户找不到入口 ✗），只是没有可播的曲目 ✓
  if (!TRACKS.length) {
    ttl.textContent = '歌单里还没有音频';
    if (listBox) listBox.innerHTML = '<li><span class="t">去后台「📁 媒体 → 歌单」里加音频</span></li>';
    bubble.addEventListener('click', function(e){ e.stopPropagation(); open(!box.classList.contains('lp-open')); });
    document.addEventListener('click', function(e){ if (!box.contains(e.target)) open(false); });
    window.LitaFilePlayer = { pause: function(){}, play: function(){}, isPlaying: function(){ return false; } };
    window.LITAFILE_DATA = { tracks: [], cfg: CFG };
    return;
  }

  var audio = new Audio();
  // ★metadata（而不是 none）：恢复播放进度需要先拿到时长 ✓（代价只是每首几十 KB ✓）
  audio.preload = 'metadata';
  var i = 0, mode = CFG.mode || 'list';

  // ★续播窗口：30 分钟内的旧记录才算"接着听" ✓；更早的当作一次新的收听（从头 ✓）
  var RESUME_WINDOW_MS = 30 * 60 * 1000;

  // 背景音乐（服务端已按文章特征选好曲目 ✓）：从该曲起步、循环、低音量 ✓
  var BGM = (CFG.bgm && typeof CFG.bgm.index === 'number') ? CFG.bgm : null;
  if (BGM) {
    if (BGM.index >= 0 && BGM.index < TRACKS.length) i = BGM.index;
    audio.loop = true;
    audio.volume = Math.max(0, Math.min(1, (BGM.volume || 35) / 100));
    box.setAttribute('data-bgm', BGM.reason || '1');
  }

  var resumeT = 0, resumeId = 0, resumePlay = false;

  // 状态：新键优先；无新键时从旧键迁移（一次性）
  function load(){
    try {
      var s = localStorage.getItem('litafile_state');
      if (!s) {
        var old = localStorage.getItem('lita_music_state');
        if (old) { localStorage.setItem('litafile_state', old); s = old; }
      }
      if (!s) return;
      var o = JSON.parse(s);
      if (!o) return;
      if (typeof o.i === 'number') i = Math.min(o.i, TRACKS.length - 1);
      if (o.mode) mode = o.mode;
      // 续播信息三件套：位置 / 条目 id / 是否在播 —— 只在**未过期**时才认 ✓
      var fresh = o.ts && (Date.now() - o.ts) < RESUME_WINDOW_MS;
      if (fresh && typeof o.t === 'number' && o.t > 1) resumeT = o.t;
      if (fresh && typeof o.id === 'number' && o.id > 0) resumeId = o.id;
      if (fresh && o.p) resumePlay = true;
    } catch(e){}
  }
  var lastSave = 0;
  function save(force){
    var now = Date.now();
    if (!force && now - lastSave < 2000) return;   // 节流：timeupdate 约每秒触发，别每秒写 localStorage ✓
    lastSave = now;
    try {
      localStorage.setItem('litafile_state', JSON.stringify({
        i: i, mode: mode,
        t: Math.max(0, audio.currentTime | 0),
        id: (TRACKS[i] || {}).id || 0,
        p: audio.paused ? 0 : 1,
        ts: now
      }));
    } catch(e){}
  }

  function paintMode(){
    var b = document.getElementById('lp-mode');
    if (b) b.textContent = mode === 'list' ? '↻' : (mode === 'shuffle' ? '⇄' : '↻1');
  }
  // 曲目列表：只在需要时重建 ✓
  function renderList(){
    if (!listBox) return;
    listBox.innerHTML = '';
    for (var n = 0; n < TRACKS.length; n++) {
      var t = TRACKS[n];
      var li = document.createElement('li');
      if (n === i) li.className = 'cur';
      var s1 = document.createElement('span'); s1.className = 't'; s1.textContent = t.title;
      li.appendChild(s1);
      if (t.artist) { var s2 = document.createElement('span'); s2.className = 'a'; s2.textContent = t.artist; li.appendChild(s2); }
      (function(idx){ li.addEventListener('click', function(){ i = idx; save(true); load_track(true); renderList(); }); })(n);
      listBox.appendChild(li);
    }
  }
  function load_track(auto){
    var t = TRACKS[i];
    audio.src = t.src;
    ttl.textContent = (BGM ? '🎵 ' : '') + (t.artist ? t.artist + ' - ' : '') + t.title;
    if (bar) bar.querySelector('i').style.width = '0%';
    renderList();

    // ★续播：同一条目才套用上次的位置 ✓（换页后若 BGM 选中了别的曲子，套用会"乱跳" ✗）
    var wantT = (resumeT > 1 && (!resumeId || resumeId === (t.id || 0))) ? resumeT : 0;
    var wantPlay = (auto && CFG.autoplay) || resumePlay;
    resumeT = 0; resumeId = 0; resumePlay = false;
    if (wantT > 0 || wantPlay) {
      var once = function(){
        audio.removeEventListener('loadedmetadata', once);
        if (wantT > 0) {
          var d = audio.duration || 0;
          // 夹在末尾前 1 秒：不留这点余量的话，一进去就立刻 ended → 直接跳下一首 ✗
          audio.currentTime = d > 0 ? Math.min(wantT, Math.max(0, d - 1)) : wantT;
        }
        if (wantPlay) audio.play().catch(function(){});
        save(true);
      };
      audio.addEventListener('loadedmetadata', once);
    }
  }
  function play(){ audio.play().catch(function(){}); }
  function next(step){
    if (mode === 'shuffle') i = Math.floor(Math.random() * TRACKS.length);
    else i = (i + (step || 1) + TRACKS.length) % TRACKS.length;
    save(true); load_track(true);
  }

  audio.addEventListener('play', function(){
    document.getElementById('lp-toggle').textContent = '⏸';
    if (bubble) bubble.textContent = '⏸';   // 收起状态下也能看出"正在响" ✓
    save(true);
    // ★反向互斥：本播放器由 new Audio() 构造、**不在 DOM 里** ✗ → media-controller 的 play 委托抓不到它 ✗
    //   （原来只有"文章内媒体起播 → 暂停全局播放器"这一半 ✓，反向是缺口 ✗，2026-09-16 补上 ✓）
    if (window.LitaFileMedia && window.LitaFileMedia.pauseDom) window.LitaFileMedia.pauseDom(audio);
  });
  audio.addEventListener('pause', function(){
    document.getElementById('lp-toggle').textContent = '▶';
    if (bubble) bubble.textContent = '♫';
    save(true);
  });
  audio.addEventListener('ended', function(){
    if (mode === 'repeat-one') { audio.currentTime = 0; play(); } else next(1);
  });
  audio.addEventListener('timeupdate', function(){
    var d = audio.duration || 0;
    if (d > 0 && bar) bar.querySelector('i').style.width = (audio.currentTime / d * 100) + '%';
    document.getElementById('lp-cur').textContent = fmt(audio.currentTime);
    document.getElementById('lp-dur').textContent = fmt(d);
    save();   // 节流保存（2 秒一次 ✓）→ 刷新/换页才能接着上次的位置 ✓
  });

  document.getElementById('lp-toggle').addEventListener('click', function(){ if (audio.paused) play(); else audio.pause(); });
  document.getElementById('lp-next').addEventListener('click', function(){ next(1); });
  document.getElementById('lp-prev').addEventListener('click', function(){ next(-1); });
  document.getElementById('lp-mode').addEventListener('click', function(){
    mode = (mode === 'list') ? 'shuffle' : (mode === 'shuffle' ? 'repeat-one' : 'list');
    paintMode(); save(true);
  });
  document.getElementById('lp-listbtn').addEventListener('click', function(){ box.classList.toggle('lp-liston'); });
  if (bar) bar.addEventListener('click', function(e){
    var d = audio.duration || 0; if (!d) return;
    var r = this.getBoundingClientRect();
    audio.currentTime = (e.clientX - r.left) / r.width * d;
    save(true);
  });
  // 圆钮：展开/收起面板（播放状态由图标表达 ✓）；点面板外自动收起 ✓
  bubble.addEventListener('click', function(e){ e.stopPropagation(); open(!box.classList.contains('lp-open')); });
  document.addEventListener('click', function(e){ if (!box.contains(e.target)) open(false); });
  // 页面即将离开（换页/刷新/关闭）→ 立刻把位置落盘 ✓（pagehide 比 beforeunload 可靠 ✓）
  window.addEventListener('pagehide', function(){ save(true); });

  // 供媒体互斥脚本调用（全局播放器暂停）
  window.LitaFilePlayer = { pause: function(){ audio.pause(); }, play: play, isPlaying: function(){ return !audio.paused; } };
  window.LITAFILE_DATA = { tracks: TRACKS, cfg: CFG };

  load();
  paintMode();
  // BGM 模式：按文章特征选好的曲子自动起播 ✓；否则：若上次正在播则续播 ✓（被策略拦则位置已就位 ✓）
  load_track(!!BGM);
})();
</script>
HTML;
    echo "\n";
}
