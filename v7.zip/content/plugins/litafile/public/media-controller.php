<?php
/**
 * litafile/public/media-controller.php — ★统一媒体互斥 + 歌单卡片点击播放
 *
 * 解决的问题（合并前的真实缺陷）：
 *   · 旧 lita-music 有"卡片/全局播放器互斥"，但只识别 `.lita-music-card` ✗
 *   · 旧 cloud-drive 内嵌的 `.cloud-media-el` 完全不在它的管辖内 ✗
 *   → 同一个页面上，文章内的音频还在响，另一个媒体又开始了。
 *
 * 现在的做法：**一处事件委托**监听页面上所有 audio/video 的 play 事件，
 * 谁开始播就暂停其它（含全局悬浮播放器），对主题/插件后续新增的媒体同样生效 ✓。
 *
 * 2026-09-16 补两处（用户提问"文章内播放器与浮动播放器能否互相牵制" ✓）：
 *   ① **反向缺口**：全局播放器用 `new Audio()` 构造，**不在 DOM 里** ✗
 *      → 本文件的事件委托**抓不到它**（play 事件不冒泡、元素也不在文档树里 ✓）
 *      → 表现为"文章里的音频还在响，浮动播放器又开始播" ✗。修法：把 `pauseDom()` 挂到
 *        `window.LitaFileMedia` 上，由播放器在自己的 play 事件里调用 ✓（见 player.php ✓）
 *   ② **歌单卡片根本点不动** ✗：条目里只有 `<a href="音频地址">`（点了会跳去裸音频文件 ✗）
 *      和一个没人调用的 `<audio class="litafile-pl-a">` ✗ → 这里补"点击条目即播放"的事件委托 ✓
 *      （播放走 DOM 元素 ⇒ 自动纳入上面的互斥 ✓）
 */

if (!defined('ABSPATH')) exit;

function litafile_media_controller() {
    static $done = false;
    if ($done) return;
    $done = true;
    echo <<<HTML
<script id="litafile-media-controller">
(function(){
  if (window.__litafileMediaController) return;
  window.__litafileMediaController = true;

  // 暂停页面上其它 audio/video（不含 cur）
  function pauseDom(cur){
    var all = document.querySelectorAll('audio, video');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el !== cur && !el.paused) { try { el.pause(); } catch(e){} }
    }
  }
  function stopOthers(cur){
    pauseDom(cur);
    // 全局悬浮播放器（new Audio() 构造，不在 DOM 里 → 必须显式暂停 ✓）
    if (window.LitaFilePlayer && window.LitaFilePlayer.isPlaying && window.LitaFilePlayer.isPlaying()) {
      window.LitaFilePlayer.pause();
    }
  }

  // 捕获阶段监听 play（媒体元素的 play 事件不冒泡，必须用 capture ✓）
  document.addEventListener('play', function(e){
    var t = e.target;
    if (t && (t.tagName === 'AUDIO' || t.tagName === 'VIDEO')) stopOthers(t);
  }, true);

  // 供全局播放器反向调用 ✓（它自己起播时暂停文章内的媒体 ✓）
  window.LitaFileMedia = { pauseDom: pauseDom, pauseOthers: stopOthers };

  // ── 歌单卡片：点击条目 → 播放它自己的 <audio>（再点一次 = 暂停 ✓）────────────
  document.addEventListener('click', function(e){
    var t = e.target;
    if (!t || !t.closest) return;
    var li = t.closest('.litafile-pl li, .lita-music-card li');
    if (!li) return;
    var a = li.querySelector('audio');
    if (!a) return;
    // 允许"新标签页打开"（Ctrl/⌘/Shift + 点击）照旧走链接 ✓
    if (t.tagName === 'A' && (e.metaKey || e.ctrlKey || e.shiftKey)) return;
    e.preventDefault();
    if (!a.paused) { a.pause(); return; }
    a.preload = 'metadata';
    a.play().catch(function(){});
  }, false);

  // 高亮正在播放的那一条 ✓
  document.addEventListener('play', function(e){
    var t = e.target;
    if (!t || t.tagName !== 'AUDIO' || !t.closest) return;
    var wrap = t.closest('.litafile-pl, .lita-music-card');
    if (!wrap) return;
    var lis = wrap.querySelectorAll('li');
    for (var i = 0; i < lis.length; i++) {
      if (lis[i].classList) lis[i].classList.toggle('cur', lis[i] === t.closest('li'));
    }
  }, true);
})();
</script>
HTML;
    echo "\n";
}
