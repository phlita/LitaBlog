<?php
/**
 * litafile/public/styles.php — 前台样式（一次注入，挂 wp_head）
 *
 * 注意：类名**同时保留旧插件的类**（`.cloud-media`/`.cloud-download-box`/`.lita-music-card`），
 * 这样已被浏览器/CDN 缓存的老页面、以及主题里的自定义样式仍然匹配 ✓。
 */

if (!defined('ABSPATH')) exit;

function litafile_inject_styles() {
    static $done = false;
    if ($done) return;
    $done = true;
    echo '<style id="litafile-css">' . litafile_styles_css() . '</style>' . "\n";
}

function litafile_styles_css() {
    return '
/* ── 下载卡片 ── */
.litafile-card,.cloud-download-box{display:flex;align-items:center;gap:12px;padding:12px 14px;margin:14px 0;border:1px solid #e6e8ec;border-radius:12px;background:#fafbfc}
.litafile-card .ic,.cloud-download-box .cloud-dl-ic{flex:0 0 auto;width:38px;height:38px;display:flex;align-items:center;justify-content:center;border-radius:10px;background:#eef2ff;font-size:18px}
.litafile-card .meta,.cloud-download-box .cloud-dl-meta{flex:1 1 auto;min-width:0}
.litafile-card .nm,.cloud-download-box .cloud-dl-name{display:block;font-weight:600;color:#222;word-break:break-all;text-decoration:none}
.litafile-card .sub,.cloud-download-box .cloud-dl-sub{font-size:12px;color:#8892a0}
.litafile-card .btn,.cloud-download-box .cloud-dl-btn{flex:0 0 auto;display:inline-block;padding:8px 14px;border-radius:9px;background:#3b82f6;color:#fff!important;text-decoration:none;font-size:13px}
.litafile-lock{font-size:12px;color:#c0392b}
/* ── 内嵌媒体 ── */
.litafile-media,.cloud-media{margin:16px 0}
.litafile-media img,.litafile-media video,.cloud-media img,.cloud-media video{max-width:100%;height:auto;border-radius:12px;display:block}
.litafile-media audio,.cloud-media audio{width:100%}
.litafile-media-bar,.cloud-media-bar{display:flex;align-items:center;gap:10px;font-size:12px;color:#8892a0;margin-top:6px}
.litafile-media-bar a,.cloud-media-bar a{color:#3b82f6;text-decoration:none}
/* ── 歌单卡片 ── */
.litafile-pl,.lita-music-card{border:1px solid #e6e8ec;border-radius:12px;background:#fff;padding:10px 12px;margin:14px 0}
.litafile-pl-hd,.lita-music-card .lmc-hd{font-weight:600;margin-bottom:6px;color:#222}
.litafile-pl li,.lita-music-card li{list-style:none;display:flex;align-items:center;gap:8px;padding:6px 4px;border-radius:8px}
.litafile-pl li:hover,.lita-music-card li:hover{background:#f5f7fa}
.litafile-pl li.cur,.lita-music-card li.cur{background:#eef2ff}
.litafile-pl .idx{width:22px;color:#98a2b3;font-size:12px;text-align:right}
.litafile-pl .t{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.litafile-pl .a{color:#98a2b3;font-size:12px}
/* ── 全局悬浮播放器（★2026-09-16 简化版：默认只有一枚 42px 圆钮 ✓）──
   位置与主题右下角悬浮钮（返回顶部 bottom:40px / 快捷发文 bottom:92px，均为 42px）**同列** ✓
   配色改用主题变量 --forest-* ✓（原来是蓝色 ✗，与森林绿主题不搭 ✓） */
#litafile-player{position:fixed;right:40px;bottom:150px;z-index:9990;font-size:13px;font-family:var(--body-font,system-ui,-apple-system,"Segoe UI",sans-serif)}
#litafile-player *{box-sizing:border-box}
/* 圆钮：与主题悬浮钮同尺寸（42px / 圆角 12）✓；图标 ♫ 表示待播、⏸ 表示正在播 ✓ */
#litafile-player .lp-bubble{width:42px;height:42px;border:0;border-radius:12px;cursor:pointer;color:#fff;font-size:17px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--forest-mid,#4a6741),var(--forest-dark,#2c3e2d));box-shadow:0 4px 14px rgba(44,62,45,.4);transition:transform .15s,box-shadow .2s}
#litafile-player .lp-bubble:hover{transform:scale(1.06);box-shadow:0 6px 20px rgba(44,62,45,.55)}
#litafile-player .lp-bubble:active{transform:scale(.94)}
/* 面板：从圆钮**左侧滑出**（absolute 不占位 ✓）；默认隐藏，lp-open 时出现 ✓ */
#litafile-player .lp-panel{position:absolute;right:calc(100% + 12px);bottom:0;width:264px;max-width:calc(100vw - 140px);background:rgba(248,247,242,.98);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);border:1px solid var(--forest-light,#9cb380);border-radius:12px;box-shadow:0 12px 36px rgba(44,62,45,.22);overflow:hidden;opacity:0;transform:translateX(10px);pointer-events:none;transition:opacity .2s,transform .2s}
#litafile-player.lp-open .lp-panel{opacity:1;transform:none;pointer-events:auto}
/* 控制行：曲名 + 控制钮**同一行**（无标题栏 ✓ 时间也挪走 ✓） */
#litafile-player .lp-row{display:flex;align-items:center;gap:5px;padding:9px 10px 7px}
#litafile-player .ttl{flex:1 1 auto;min-width:0;font-weight:600;font-size:12px;color:var(--forest-dark,#2c3e2d);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#litafile-player button{background:none;border:0;color:var(--forest-mid,#4a6741);font-size:14px;line-height:1;cursor:pointer;padding:2px}
#litafile-player button:hover{color:var(--forest-dark,#2c3e2d)}
#litafile-player button.main{width:32px;height:32px;border-radius:50%;color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--forest-mid,#4a6741),var(--forest-dark,#2c3e2d));box-shadow:0 3px 10px rgba(44,62,45,.4);transition:transform .12s}
#litafile-player button.main:hover{transform:scale(1.08)}
/* 进度：细线（可点跳转 ✓）+ 两端 10px 小字时间 ✓（原来时间独占一行 ✗） */
#litafile-player .lp-bar{height:4px;margin:0 10px;background:rgba(44,62,45,.15);cursor:pointer}
#litafile-player .lp-bar i{display:block;height:100%;width:0;background:var(--forest-mid,#4a6741);transition:width .15s linear}
#litafile-player .lp-tm{display:flex;justify-content:space-between;padding:4px 10px 8px;font-size:10px;color:var(--forest-brown,#765c43)}
/* 曲目列表：**默认收起** ✓，点 ≡ 才展开（旧版一直占 240px ✗） */
#litafile-player .lp-list{display:none;list-style:none;margin:0;padding:0;max-height:190px;overflow:auto;border-top:1px solid var(--forest-beige,#ece8d9)}
#litafile-player.lp-liston .lp-list{display:block}
#litafile-player .lp-list li{display:flex;gap:6px;padding:7px 12px;font-size:12px;color:var(--forest-dark,#2c3e2d);cursor:pointer;border-bottom:1px solid var(--forest-beige,#ece8d9);white-space:nowrap;overflow:hidden}
#litafile-player .lp-list li:hover{background:var(--forest-beige,#ece8d9)}
#litafile-player .lp-list li.cur{color:var(--forest-mid,#4a6741)}
#litafile-player .lp-list li.cur .t::before{content:"♫ "}
#litafile-player .lp-list .t{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
#litafile-player .lp-list .a{flex:0 0 auto;font-size:11px;color:var(--forest-brown,#765c43)}
/* 移动端：与主题按钮同列（right:20px），置于快捷发文上方 ✓ */
@media (max-width:900px){#litafile-player{right:20px;bottom:130px}#litafile-player .lp-panel{width:236px}}
';
}
