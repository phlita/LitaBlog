<?php
/**
 * litafile/public/pjax.php — ★前台"不重载文档"的导航（PJAX）→ 换页时音乐**一个采样都不断**
 *
 * ── 为什么需要它（2026-09-16 用户实测吐槽："网易云切页 0 停顿，litafile 明显卡顿" ✓）──
 * 本站是 **MPA**：点链接 = 浏览器丢掉当前文档 ✗ → 页面里的 `new Audio()` 随之销毁 ✗ →
 * 新文档必须**重新建播放器、重新取流、重新 seek** ✓。真浏览器实测（命中整页缓存时 ✓）：
 *     页面 HTML 就绪 56ms + 音频 metadata 38ms + 起播 2ms ≈ **约 100ms 的可听间隙** ✓
 * 再叠加两个"体感放大器"：
 *     ① 整页重建 → 白屏/重绘 ≈ 100ms ✓（"刷新卡顿感" ✓）
 *     ② **新文档没有用户手势 → 带声音的 play() 被浏览器拦** ✗（实测 NotAllowedError ✓）
 *        ⇒ 音乐直接停住、必须点一下 ✓ —— 这一条的体感远大于那 100ms ✓
 *     （另外：页面**未命中**整页缓存时 TTFB 会到 **1.4~3.3s** ✗✗，那才是真正的"明显卡顿" ✓）
 *
 * 网易云网页版为什么 0 停顿 ✓：它是 **SPA** —— 文档从不重建 ✓、`<audio>` 挂在持久层 ✓、
 * 路由在**前端**（History API + 局部渲染）✓ ⇒ 换页对音频**完全无感** ✓。
 *
 * 所以这里做同样的事 ✓：点站内链接 → `fetch` 新页面 → **只把主内容区换掉** + `pushState` ✓
 * ⇒ 播放器（以及它的 `Audio` 实例、BGM、进度）**原地不动** ✓ → 换页时**音频零中断** ✓✓
 *
 * ── 安全与降级（很重要 ✓）──────────────────────────────────────────────
 *   · **默认关闭** ✓（后台设置里手动打开；出任何问题一键关掉即回到原生导航 ✓）
 *   · 只接管**同源、非后台、非下载/接口**的 `<a>` 左键点击 ✓；Ctrl/⌘/中键、`target=_blank`、
 *     `download`、`#锚点`、`mailto:` 一律不管 ✓
 *   · **认不出主容器就正常跳转** ✓；fetch 失败 / 非 200 / 解析异常 → `location.href = url` ✓✓
 *   · 主容器里**不能包含播放器**（含则放弃接管 ✓ 防止把播放器换掉 ✗）
 *   · `innerHTML` 不执行 `<script>` ✗ → 换完后**手动重放**内容区里的 script ✓
 *     （例如 `[litafile_playlist start=N]` 的自动播放、文章内的行内脚本 ✓）
 *   · `popstate` 接管后退/前进 ✓；每次换页 `scrollTo(0,0)` + 同步 `document.title` ✓
 *   · 后台（`/admin/`）完全不接管 ✓（编辑器重、且有 Quill 实例 ✓）
 */
if (!defined('ABSPATH')) exit;

/** 是否启用 PJAX 导航 */
function litafile_pjax_enabled($s = null) {
    $s = $s ?: litafile_get_settings();
    return !empty($s['pjax']);
}

/** 注入 PJAX 脚本（挂在 footer，priority 100 —— 在播放器之后 ✓） */
function litafile_pjax_nav() {
    static $done = false;
    if ($done) return;
    $s = litafile_get_settings();
    if (!litafile_pjax_enabled($s)) return;
    $done = true;
    echo <<<HTML
<style id="litafile-pjax-css">html.lf-pjax-busy .litafile-main-swap{opacity:.55;transition:opacity .12s}</style>
<script id="litafile-pjax">
(function(){
  if (window.__litafilePjax) return;
  if (!window.fetch || !window.DOMParser || !window.history || !history.pushState) return;
  window.__litafilePjax = true;

  // 主内容区候选（按主题不同逐个试 ✓）；要求"新旧文档里都唯一命中"且"不含播放器" ✓
  var SELECTORS = ['.content-area', '.site-main', '.main-wrapper', 'main', '#main', '.main-content'];
  var busy = false;

  // ⚠️ 必须**同一个选择器在新旧文档里都唯一命中** ✗ —— 否则会出现
  //    "用旧页的 .content-area 去装后台页的 <main>" 这种**错配** ✓
  //    （2026-09-16 真浏览器"兜底用例"抓到的真实缺陷：`main` 太泛，后台页也有 ✓）
  function pick(doc){
    for (var i = 0; i < SELECTORS.length; i++) {
      var a = document.querySelectorAll(SELECTORS[i]);
      var b = doc.querySelectorAll(SELECTORS[i]);
      if (a.length === 1 && b.length === 1
          && !a[0].querySelector('#litafile-player') && !b[0].querySelector('#litafile-player')
          && b[0].innerHTML.length >= 200) {
        return { old: a[0], fresh: b[0] };
      }
    }
    return null;
  }
  // 只接管"前台页面"✓（后台/接口/下载一律交给浏览器 ✓）
  function allowed(url){
    var u;
    try { u = new URL(url, location.href); } catch (e) { return false; }
    if (u.origin !== location.origin) return false;
    if (u.pathname.indexOf('/admin') === 0) return false;
    if (u.search.indexOf('agent_api=') >= 0 || u.search.indexOf('litafile_dl=') >= 0) return false;
    return true;
  }
  function skip(a){
    if (!a) return true;
    var href = a.getAttribute('href') || '';
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) return true;
    if (a.target === '_blank' || a.hasAttribute('download')) return true;
    var u;
    try { u = new URL(a.href, location.href); } catch (e) { return true; }
    if (u.origin !== location.origin) return true;
    if (u.pathname.indexOf('/admin') === 0) return true;      // 后台不接管 ✓
    if (u.search.indexOf('agent_api=') >= 0 || u.search.indexOf('litafile_dl=') >= 0
        || u.search.indexOf('litafile_count=') >= 0) return true;
    if (u.href === location.href) return true;
    return false;
  }
  function replayScripts(root){
    // innerHTML 换进来的 <script> 不会执行 ✗ → 逐个重建 ✓（行内与外部都支持 ✓）
    var ss = root.querySelectorAll('script');
    for (var i = 0; i < ss.length; i++) {
      var o = ss[i], s = document.createElement('script');
      for (var k = 0; k < o.attributes.length; k++) {
        var at = o.attributes[k];
        if (at.name !== 'src' || at.value) s.setAttribute(at.name, at.value);
      }
      if (o.src) s.src = o.src; else s.textContent = o.textContent;
      o.parentNode.replaceChild(s, o);
    }
  }
  function swap(html, url, push){
    var doc;
    try { doc = new DOMParser().parseFromString(html, 'text/html'); } catch (e) { return false; }
    var pair = pick(doc);                                 // 同一个选择器、新旧都唯一 ✓
    if (!pair) return false;
    pair.old.innerHTML = pair.fresh.innerHTML;
    replayScripts(pair.old);
    if (doc.title) document.title = doc.title;
    if (push) history.pushState({ lfPjax: 1, url: url }, '', url);
    scrollTo(0, 0);
    try { document.dispatchEvent(new CustomEvent('litafile:pjax', { detail: { url: url } })); } catch (e) {}
    return true;
  }
  function go(url, push){
    if (!allowed(url)) { location.href = url; return; }   // 后台/接口/跨源 → 原生跳转 ✓（兜底 ✓）
    if (busy) return;
    busy = true;
    document.documentElement.classList.add('lf-pjax-busy');
    fetch(url, { credentials: 'same-origin', headers: { 'X-Litafile-Pjax': '1' } })
      .then(function(r){ return r.ok ? r.text() : null; })
      .then(function(html){
        busy = false;
        document.documentElement.classList.remove('lf-pjax-busy');
        var ok = false;
        if (html) { ok = swap(html, url, push); }
        if (!ok) location.href = url;                 // 任何异常 → 退回原生导航 ✓
      })
      .catch(function(){
        busy = false;
        document.documentElement.classList.remove('lf-pjax-busy');
        location.href = url;
      });
  }
  document.addEventListener('click', function(e){
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (skip(a)) return;
    e.preventDefault();
    go(a.href, true);
  }, false);
  window.addEventListener('popstate', function(){ go(location.href, false); });
  // 供调试/测试用 ✓
  window.LitaFilePjax = { go: go, swap: swap, selectors: SELECTORS };
})();
</script>
HTML;
    echo "\n";
}
