<?php
/**
 * litafile/includes/schema.php — 建表与自愈（幂等，可重复调用）
 *
 * 设计：见 DESIGN.md §2。三张表：
 *   litafile_items           核心媒体/文件表（替代 cloud_files）
 *   litafile_playlists       歌单
 *   litafile_playlist_items  歌单条目（复合主键，天然去重）
 *
 * 为什么"每次加载都自检"：免费主机常见"库被重置但插件仍 active"，
 * 沿用 cloud-drive 的成熟做法 —— 缺表就补建，失败静默跳过，绝不阻塞站点。
 */

if (!defined('ABSPATH')) exit;

/**
 * 建表 + 建索引（幂等）。
 */
function litafile_create_schema() {
    if (!defined('ABSPATH')) return;
    try {
        $db = get_db();

        // ① 核心表
        $db->exec("CREATE TABLE IF NOT EXISTS litafile_items (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            kind           TEXT NOT NULL DEFAULT 'file',
            filename       TEXT NOT NULL,
            stored_name    TEXT NOT NULL,
            filepath       TEXT NOT NULL,
            storage        TEXT NOT NULL DEFAULT 'litafile',
            source         TEXT NOT NULL DEFAULT 'local',
            external_url   TEXT DEFAULT '',
            filesize       INTEGER DEFAULT 0,
            mime_type      TEXT DEFAULT 'application/octet-stream',
            title          TEXT DEFAULT '',
            artist         TEXT DEFAULT '',
            description    TEXT DEFAULT '',
            password       TEXT DEFAULT '',
            download_count INTEGER DEFAULT 0,
            play_count     INTEGER DEFAULT 0,
            uploader_id    INTEGER DEFAULT 0,
            legacy_id      INTEGER DEFAULT 0,
            legacy_src     TEXT DEFAULT '',
            created        DATETIME DEFAULT CURRENT_TIMESTAMP,
            modified       DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // ② 歌单
        $db->exec("CREATE TABLE IF NOT EXISTS litafile_playlists (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT NOT NULL DEFAULT '默认歌单',
            is_default INTEGER DEFAULT 0,
            created    DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // ③ 歌单条目（复合主键 = 同一首歌不会重复加入同一歌单）
        $db->exec("CREATE TABLE IF NOT EXISTS litafile_playlist_items (
            playlist_id INTEGER NOT NULL,
            item_id     INTEGER NOT NULL,
            sort_order  INTEGER DEFAULT 0,
            PRIMARY KEY (playlist_id, item_id)
        )");

        // ④ 索引（旧 cloud_files 一个索引都没建，深翻页会退化成全表扫描）
        $db->exec("CREATE INDEX IF NOT EXISTS idx_litafile_kind    ON litafile_items(kind)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_litafile_created ON litafile_items(created)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_litafile_legacy  ON litafile_items(legacy_src, legacy_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_litafile_pl_sort ON litafile_playlist_items(playlist_id, sort_order)");
    } catch (Throwable $e) {
        return; // DB 未就绪/锁定等场景：静默跳过，下个请求再试
    }
}

/**
 * 默认歌单（懒创建，幂等）：返回 playlist_id。
 * 迁移旧 lita_music_playlist 时也用它作为目标歌单。
 */
function litafile_default_playlist_id() {
    try {
        $db = get_db();
        $row = $db->query("SELECT id FROM litafile_playlists WHERE is_default = 1 ORDER BY id LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        if ($row) return (int)$row['id'];
        $db->exec("INSERT INTO litafile_playlists (name, is_default) VALUES ('默认歌单', 1)");
        return (int)$db->lastInsertId();
    } catch (Throwable $e) {
        return 0;
    }
}
