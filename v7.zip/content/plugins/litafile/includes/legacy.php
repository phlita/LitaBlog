<?php
/**
 * litafile/includes/legacy.php — 老插件检测（**仅**用于后台提示"建议停用"）
 *
 * 2026-09-16 用户两次要求后，旧世界的兼容已**全部删除** ✗：
 *   · 迁移：`litafile_import_legacy()` / `litafile_legacy_exists()` 删除 ✓
 *   · 旧短代码接管：`litafile_register_legacy_shortcodes()` 删除 ✓（只注册 `[litafile]` / `[litafile_playlist]`）
 *   · 旧参数：`?cloud_download=` / `?cd_count=` 删除 ✓；旧短代码处理函数删除 ✓
 * 保留下来的唯一用途：`litafile_legacy_plugin_active()` / `litafile_legacy_status()` →
 * 后台在"老插件仍处于激活"时给一条提示 ✓（避免两个插件同时注册短代码/编辑器按钮造成重复 ✓）
 */

if (!defined('ABSPATH')) exit;

/** 旧插件是否处于激活状态（用于"让位"判断） */
function litafile_legacy_plugin_active($slug) {
    if (!function_exists('get_active_plugins')) return false;
    foreach ((array)get_active_plugins() as $p) {
        if (($p['slug'] ?? '') === $slug) return true;
    }
    return false;
}

/**
 * 旧数据导入相关函数（`litafile_import_legacy` / `litafile_legacy_exists`）
 * 已按用户要求**整块删除** ✗（2026-09-16：后台入口已移除、本地无旧数据、生产不需要迁移 ✓）。
 * 注：DB 里可能残留一条旧的 option `litafile_import_report`（最后一次导入的报告），无人读取、无副作用 ✓。
 */

/**
 * 旧短代码的"接管/让位"逻辑（`litafile_register_legacy_shortcodes`）已按用户要求**删除** ✗
 * （2026-09-16 用户明确："[download id=N]、[lita_music …]、?cloud_download= 这些运行期兼容也没必要留着，
 *   因为 litafile 是新插件" ✓）→ 本插件现在只注册 `[litafile]` / `[litafile_playlist]` ✓
 */

/** 老插件是否仍激活（后台用于提示"建议停用"，以及短代码让位判断） */
function litafile_legacy_status() {
    return [
        'cloud-drive' => litafile_legacy_plugin_active('cloud-drive'),
        'lita-music'  => litafile_legacy_plugin_active('lita-music'),
    ];
}
