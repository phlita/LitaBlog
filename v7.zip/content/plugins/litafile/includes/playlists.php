<?php
/**
 * litafile/includes/playlists.php — 歌单（合并 lita-music 的单歌单能力并升级为多歌单）
 *
 * 与旧实现的差异：
 *   · 旧 lita-music 把整个歌单塞在 option `lita_music_playlist`（JSON）里，且"服务器只存元数据"
 *   · litafile 用表存储（可多歌单、可排序、可复用媒体库条目），旧 option **只读兼容**（见 legacy.php）
 */

if (!defined('ABSPATH')) exit;

/** 全部歌单（默认歌单排最前） */
function litafile_get_playlists() {
    try {
        $db = get_db();
        return $db->query('SELECT * FROM litafile_playlists ORDER BY is_default DESC, id ASC')->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

/** 单个歌单 */
function litafile_get_playlist($id) {
    try {
        $db = get_db();
        $st = $db->prepare('SELECT * FROM litafile_playlists WHERE id = ? LIMIT 1');
        $st->execute([(int)$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/** 新建歌单；$is_default=true 时把其它歌单的默认位清掉 */
function litafile_playlist_create($name, $is_default = false) {
    $name = trim((string)$name);
    if ($name === '') $name = '新歌单';
    try {
        $db = get_db();
        if ($is_default) $db->exec('UPDATE litafile_playlists SET is_default = 0');
        $st = $db->prepare('INSERT INTO litafile_playlists (name, is_default) VALUES (?, ?)');
        $st->execute([$name, $is_default ? 1 : 0]);
        return (int)$db->lastInsertId();
    } catch (Throwable $e) {
        return 0;
    }
}

/** 重命名 / 设为默认 */
function litafile_playlist_update($id, $name = null, $is_default = null) {
    try {
        $db = get_db();
        if ($name !== null) {
            $db->prepare('UPDATE litafile_playlists SET name = ? WHERE id = ?')->execute([trim((string)$name), (int)$id]);
        }
        if ($is_default === true) {
            $db->exec('UPDATE litafile_playlists SET is_default = 0');
            $db->prepare('UPDATE litafile_playlists SET is_default = 1 WHERE id = ?')->execute([(int)$id]);
        }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** 删除歌单（只删关联，不动媒体条目） */
function litafile_playlist_delete($id) {
    try {
        $db = get_db();
        $db->prepare('DELETE FROM litafile_playlist_items WHERE playlist_id = ?')->execute([(int)$id]);
        return $db->prepare('DELETE FROM litafile_playlists WHERE id = ?')->execute([(int)$id]);
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 加入歌单（幂等：复合主键 + INSERT OR IGNORE）
 *
 * ⚠️ **只收音频**（2026-09-16 用户明确："加入歌单功能只有音乐格式才是" ✓）：
 *    之前只按 id 加入 → 图片/视频/文档也会混进歌单 ✗（用户实测图片出现在歌单列表里 ✓）。
 *    界面层已只列音频（page-playlists.php ✓），这里再做一次服务端兜底 ✓（防手工 POST 与旧调用）。
 */
function litafile_playlist_add($playlist_id, $item_id, $sort_order = null) {
    $playlist_id = (int)$playlist_id;
    $item_id = (int)$item_id;
    if ($playlist_id <= 0 || $item_id <= 0) return false;
    $item = litafile_get_item($item_id);
    if (!$item || (string)($item['kind'] ?? '') !== 'audio') return false;
    try {
        $db = get_db();
        if ($sort_order === null) {
            $max = (int)$db->query('SELECT COALESCE(MAX(sort_order),0) FROM litafile_playlist_items WHERE playlist_id = ' . $playlist_id)->fetchColumn();
            $sort_order = $max + 1;
        }
        $st = $db->prepare('INSERT OR IGNORE INTO litafile_playlist_items (playlist_id, item_id, sort_order) VALUES (?,?,?)');
        return $st->execute([$playlist_id, $item_id, (int)$sort_order]);
    } catch (Throwable $e) {
        return false;
    }
}

/** 移出歌单 */
function litafile_playlist_remove($playlist_id, $item_id) {
    try {
        $db = get_db();
        return $db->prepare('DELETE FROM litafile_playlist_items WHERE playlist_id = ? AND item_id = ?')
                 ->execute([(int)$playlist_id, (int)$item_id]);
    } catch (Throwable $e) {
        return false;
    }
}

/** 歌单里的条目（按 sort_order） */
function litafile_playlist_items($playlist_id, $only_audio = false) {
    try {
        $db = get_db();
        $sql = 'SELECT i.* FROM litafile_playlist_items pi
                INNER JOIN litafile_items i ON i.id = pi.item_id
                WHERE pi.playlist_id = ?' . ($only_audio ? " AND i.kind = 'audio'" : '') . '
                ORDER BY pi.sort_order ASC, pi.item_id ASC';
        $st = $db->prepare($sql);
        $st->execute([(int)$playlist_id]);
        return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

/** 重排（传入按新顺序排列的 item_id 数组） */
function litafile_playlist_reorder($playlist_id, array $item_ids) {
    try {
        $db = get_db();
        $st = $db->prepare('UPDATE litafile_playlist_items SET sort_order = ? WHERE playlist_id = ? AND item_id = ?');
        $i = 1;
        foreach ($item_ids as $iid) {
            $iid = (int)$iid;
            if ($iid > 0) $st->execute([$i++, (int)$playlist_id, $iid]);
        }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** 默认歌单的条目（全局播放器用） */
function litafile_default_playlist_items($only_audio = true) {
    $pid = litafile_default_playlist_id();
    if ($pid <= 0) return [];
    return litafile_playlist_items($pid, $only_audio);
}
