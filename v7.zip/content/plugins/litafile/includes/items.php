<?php
/**
 * litafile/includes/items.php — 数据访问层（统一媒体/文件条目）
 *
 * 设计：见 DESIGN.md §2。这里是**唯一**直接读写 litafile_items 的地方，
 * 其它模块（上传/下载/短代码/Agent API/后台）一律走本文件，避免 SQL 散落各处。
 *
 * 统一"类型判定"：合并 cloud-drive 的 image/audio/video/file 四级分类
 * 与 lita-music 的 audio/video 两级分类 → 用 litafile_kind() 一处判定。
 */

if (!defined('ABSPATH')) exit;

/** 取扩展名（小写，不带点） */
function litafile_ext($filename) {
    $ext = strtolower((string)pathinfo((string)$filename, PATHINFO_EXTENSION));
    return preg_replace('/[^a-z0-9]/', '', $ext);
}

/** 允许上传/外链的扩展名（白名单；比旧插件只有黑名单更安全） */
function litafile_allowed_exts() {
    return [
        // 图片
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'avif', 'ico',
        // 音频
        'mp3', 'wav', 'flac', 'aac', 'ogg', 'oga', 'm4a', 'opus', 'wma',
        // 视频
        'mp4', 'webm', 'ogv', 'mov', 'm4v', 'mkv', 'avi',
        // 文档/压缩包（网盘常见分享内容）
        'pdf', 'txt', 'md', 'csv', 'json', 'zip', 'rar', '7z', 'gz', 'tar',
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    ];
}

/** 是否白名单内（白名单 + 危险扩展名兜底，双保险） */
function litafile_is_allowed_ext($ext) {
    $ext = strtolower((string)$ext);
    if ($ext === '' ) return false;
    if (in_array($ext, litafile_dangerous_exts(), true)) return false;
    return in_array($ext, litafile_allowed_exts(), true);
}

/** 扩展名/MIME → kind（image|audio|video|file） */
function litafile_kind($filename, $mime = '') {
    $ext  = litafile_ext($filename);
    $mime = strtolower((string)$mime);
    if (strpos($mime, 'image/') === 0 || in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'avif', 'ico'], true)) return 'image';
    if (strpos($mime, 'audio/') === 0 || in_array($ext, ['mp3', 'wav', 'flac', 'aac', 'ogg', 'oga', 'm4a', 'opus', 'wma'], true)) return 'audio';
    if (strpos($mime, 'video/') === 0 || in_array($ext, ['mp4', 'webm', 'ogv', 'mov', 'm4v', 'mkv', 'avi'], true)) return 'video';
    return 'file';
}

/**
 * 净化 MIME（防头注入）。
 *
 * ⚠️ 2026-09-16 安全修复（P1）：改为**以扩展名为准**，不再直接采用客户端传来的 MIME ✗
 *   原因：调用方可在上传里指定 `type` / `mime_type`（Agent API 的 JSON 上传完全可控 ✗）→
 *   把白名单内的 `.txt/.md/.csv` 标成 `text/html` → 流式下载以 text/html 返回 ⇒ **同源存储型 XSS** ✓
 *   （活体 PoC 实测确认 ✓）。现在：扩展名先查映射表（= 白名单内的安全类型才原样返回 ✓）。
 *   ⚠️ `svg` 仍映射成 `image/svg+xml`（`<img>` 内嵌需要它 ✓），但流式接口会为它加 CSP 沙箱 ✓（见 stream.php）。
 */
function litafile_safe_mime($mime, $filename = '') {
    $ext = litafile_ext($filename);
    $map = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'svg' => 'image/svg+xml', 'bmp' => 'image/bmp', 'avif' => 'image/avif',
        'ico' => 'image/x-icon',
        'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'flac' => 'audio/flac', 'aac' => 'audio/aac',
        'ogg' => 'audio/ogg', 'oga' => 'audio/ogg', 'm4a' => 'audio/mp4', 'opus' => 'audio/ogg',
        'wma' => 'audio/x-ms-wma',
        'mp4' => 'video/mp4', 'webm' => 'video/webm', 'ogv' => 'video/ogg', 'mov' => 'video/quicktime',
        'm4v' => 'video/mp4', 'mkv' => 'video/x-matroska', 'avi' => 'video/x-msvideo',
        'pdf' => 'application/pdf', 'txt' => 'text/plain; charset=utf-8', 'zip' => 'application/zip',
        'md' => 'text/markdown; charset=utf-8', 'csv' => 'text/csv; charset=utf-8', 'json' => 'application/json',
    ];
    if ($ext !== '' && isset($map[$ext])) return $map[$ext];

    // 扩展名不在映射表里（正常进不来）→ 退一步接受客户端 MIME，但**剔除能当文档渲染的类型** ✗
    $mime = trim((string)$mime);
    if ($mime !== '' && preg_match('~^[\w.\-+/]{1,100}$~', $mime)) {
        $risky = ['text/html', 'application/xhtml+xml', 'image/svg+xml', 'text/xml', 'application/xml',
                  'text/javascript', 'application/javascript', 'application/ecmascript'];
        if (!in_array(strtolower($mime), $risky, true)) return $mime;
    }
    return 'application/octet-stream';
}

/**
 * 净化原始文件名（展示用）：去路径、去控制字符、限长。
 *
 * ⚠️ 不要用 PHP 的 basename()：它是**locale 相关**的，在非 UTF-8 locale 的 Windows 上
 * 会把中文文件名截断（实测 `测试 歌曲.mp3` → basename 后扩展名丢失 → 落盘成 .bin ✗）。
 * 这里手工按 / 切分，纯字节操作，对中文/Emoji 都安全 ✓（单元测试捕获）。
 */
function litafile_clean_filename($name) {
    $name = (string)$name;
    $name = str_replace('\\', '/', $name);
    $pos = strrpos($name, '/');
    if ($pos !== false) $name = substr($name, $pos + 1);
    $name = preg_replace('/[\x00-\x1F\x7F]/', '', $name);   // 控制字符（不加 /u：容忍非法 UTF-8）
    $name = trim($name);
    if ($name === '') $name = 'file';
    if (function_exists('mb_substr')) return mb_substr($name, 0, 180);
    return substr($name, 0, 180);
}

/** 取单条 */
function litafile_get_item($id) {
    $id = (int)$id;
    if ($id <= 0) return null;
    try {
        $db = get_db();
        $st = $db->prepare('SELECT * FROM litafile_items WHERE id = ? LIMIT 1');
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * 列表（后台/编辑器弹层/播放器共用）。
 * @param array $args kind|search|page|per_page|order|ids|only_audio|source
 * @return array{items:array,total:int,page:int,per_page:int,pages:int}
 */
function litafile_list_items($args = []) {
    $kind   = $args['kind']   ?? '';
    $search = trim((string)($args['search'] ?? ''));
    $page   = max(1, (int)($args['page'] ?? 1));
    $per    = min(200, max(1, (int)($args['per_page'] ?? 20)));
    $order  = (($args['order'] ?? 'new') === 'old') ? 'ASC' : 'DESC';
    $only_audio = !empty($args['only_audio']);
    $source = (string)($args['source'] ?? '');

    $where = [];
    $bind  = [];
    if ($kind !== '' && $kind !== 'all') { $where[] = 'kind = ?';      $bind[] = $kind; }
    if ($only_audio)                     { $where[] = "kind = 'audio'"; }
    if ($source !== '')                  { $where[] = 'source = ?';    $bind[] = $source; }
    if ($search !== '') {
        $where[] = '(filename LIKE ? OR title LIKE ? OR artist LIKE ? OR description LIKE ?)';
        $like = '%' . $search . '%';
        array_push($bind, $like, $like, $like, $like);
    }
    $sql_where = $where ? (' WHERE ' . implode(' AND ', $where)) : '';

    try {
        $db = get_db();
        $st = $db->prepare('SELECT COUNT(*) FROM litafile_items' . $sql_where);
        $st->execute($bind);
        $total = (int)$st->fetchColumn();

        $offset = ($page - 1) * $per;
        $st = $db->prepare('SELECT * FROM litafile_items' . $sql_where . " ORDER BY id $order LIMIT $per OFFSET $offset");
        $st->execute($bind);
        $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        return ['items' => [], 'total' => 0, 'page' => $page, 'per_page' => $per, 'pages' => 0];
    }
    return [
        'items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $per,
        'pages' => (int)ceil($total / $per),
    ];
}

/** 按 id 列表取（保持传入顺序；歌单渲染用） */
function litafile_get_items_by_ids($ids) {
    $ids = array_values(array_filter(array_map('intval', (array)$ids), function ($v) { return $v > 0; }));
    if (!$ids) return [];
    $out = [];
    foreach ($ids as $id) {
        $it = litafile_get_item($id);
        if ($it) $out[] = $it;
    }
    return $out;
}

/** 插入一条；返回新 id（失败 0） */
function litafile_insert_item(array $d) {
    $d = array_merge([
        'kind' => 'file', 'filename' => '', 'stored_name' => '', 'filepath' => '',
        'storage' => 'litafile', 'source' => 'local', 'external_url' => '',
        'filesize' => 0, 'mime_type' => 'application/octet-stream',
        'title' => '', 'artist' => '', 'description' => '', 'password' => '',
        'uploader_id' => 0, 'legacy_id' => 0, 'legacy_src' => '',
    ], $d);
    $d['kind'] = in_array($d['kind'], ['image', 'audio', 'video', 'file'], true) ? $d['kind'] : 'file';
    try {
        $db = get_db();
        $st = $db->prepare('INSERT INTO litafile_items
            (kind, filename, stored_name, filepath, storage, source, external_url, filesize,
             mime_type, title, artist, description, password, uploader_id, legacy_id, legacy_src)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $ok = $st->execute([
            $d['kind'], $d['filename'], $d['stored_name'], $d['filepath'], $d['storage'], $d['source'],
            $d['external_url'], (int)$d['filesize'], $d['mime_type'], $d['title'], $d['artist'],
            $d['description'], $d['password'], (int)$d['uploader_id'], (int)$d['legacy_id'], $d['legacy_src'],
        ]);
        return $ok ? (int)$db->lastInsertId() : 0;
    } catch (Throwable $e) {
        return 0;
    }
}

/** 更新允许的字段（白名单，防止 mass assignment） */
function litafile_update_item($id, array $fields) {
    $allow = ['filename', 'title', 'artist', 'description', 'password', 'kind', 'mime_type',
              'external_url', 'source', 'storage', 'filepath', 'stored_name', 'filesize'];
    $set = [];
    $bind = [];
    foreach ($fields as $k => $v) {
        if (!in_array($k, $allow, true)) continue;
        $set[] = "$k = ?";
        $bind[] = $v;
    }
    if (!$set) return false;
    $bind[] = (int)$id;
    try {
        $db = get_db();
        $st = $db->prepare('UPDATE litafile_items SET ' . implode(', ', $set) . ', modified = CURRENT_TIMESTAMP WHERE id = ?');
        return $st->execute($bind);
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 删除条目（并尽力删除物理文件）。
 * ⚠️ 只删**本插件目录内**的文件：旧目录（cloud/music）里的文件一律保留
 *    （避免误删老插件仍在引用的资源 ✗）。
 */
function litafile_delete_item($id, $delete_file = true) {
    $item = litafile_get_item($id);
    if (!$item) return false;
    if ($delete_file && ($item['storage'] ?? 'litafile') === 'litafile') {
        $p = litafile_item_path($item);
        if ($p !== '' && is_file($p)) @unlink($p);
    }
    try {
        $db = get_db();
        $db->prepare('DELETE FROM litafile_playlist_items WHERE item_id = ?')->execute([(int)$id]);
        return $db->prepare('DELETE FROM litafile_items WHERE id = ?')->execute([(int)$id]);
    } catch (Throwable $e) {
        return false;
    }
}

/** 计数 +1（列名白名单，防注入） */
function litafile_bump_counter($id, $col = 'download_count') {
    if (!in_array($col, ['download_count', 'play_count'], true)) return false;
    try {
        $db = get_db();
        return $db->prepare("UPDATE litafile_items SET $col = $col + 1 WHERE id = ?")->execute([(int)$id]);
    } catch (Throwable $e) {
        return false;
    }
}

/** 统计（后台概览用） */
function litafile_stats() {
    $out = ['total' => 0, 'image' => 0, 'audio' => 0, 'video' => 0, 'file' => 0, 'bytes' => 0];
    try {
        $db = get_db();
        foreach ($db->query('SELECT kind, COUNT(*) c, COALESCE(SUM(filesize),0) b FROM litafile_items GROUP BY kind') as $r) {
            $k = $r['kind'];
            if (isset($out[$k])) $out[$k] = (int)$r['c'];
            $out['total'] += (int)$r['c'];
            $out['bytes'] += (int)$r['b'];
        }
    } catch (Throwable $e) {
    }
    return $out;
}
