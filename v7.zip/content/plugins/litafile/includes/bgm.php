<?php
/**
 * litafile/includes/bgm.php — 背景音乐（按文章特征自动选曲）
 *
 * 需求（2026-09-16 用户）：
 *   勾选「背景音乐自动播放」（且「自动播放」已勾 ✓ 才生效 ✓）后，
 *   根据**页面的某种特征**（文章长度/字数、主题关键词）自动挑一首时长/风格匹配的曲子，
 *   循环低声播放，营造氛围背景音乐 ✓
 *
 * ★**不需要 AI** ✓ —— 纯确定性规则（词频 + 时长估算 + 稳定 tie-break ✓）：
 *   ① 主题匹配：文章（标题 + 正文 + 分类 + 标签）的高频词 与 曲目（标题/艺术家/描述/文件名）
 *      做**词面重合**打分 ✓ —— 这就是"关联特征"的可解释版本 ✓（同主题的词会自然对上 ✓）
 *   ② 时长匹配：预估阅读时长（中文 ≈300 字/分钟）→ 挑"估算时长"最接近的曲子 ✓
 *      （曲目时长**不入库** ✗ 且本机无 ffprobe ✗ → 用 filesize 按 192kbps 估算：
 *        秒数 ≈ 字节数 / 24000 ✓，对 MP3 足够可用 ✓，纯音乐尤其稳 ✓）
 *   ③ 稳定性：**同一篇文章永远选同一首** ✓（同分时按 md5(页面标识 + 条目 id) 做确定性 tie-break ✓）
 *      → 与整页缓存友好共存 ✓，访客也不会"每次刷新都换歌" ✓
 *
 * 为什么不加"氛围标签"字段 ✗：那要改表结构（本插件刻意零 schema 改动就能用 ✓）。
 * 想更准的话，在曲目的**描述**里写风格词（如「钢琴 安静 夜」）即可 —— 本算法会自然纳入匹配 ✓。
 */

if (!defined('ABSPATH')) exit;

/**
 * BGM 是否启用。
 * ⚠️ 用户明确：**必须「自动播放」已勾选才生效** ✗ → 这里把 player_autoplay 作为前置条件 ✓
 */
function litafile_bgm_enabled($s = null) {
    $s = $s ?: litafile_get_settings();
    return !empty($s['player_enabled'])
        && !empty($s['player_autoplay'])
        && !empty($s['bgm_autoplay']);
}

/**
 * 抓取当前文章的"氛围特征"（挂在 `the_content` 上执行 ✓ 因为只有那时才知道正文 ✓）。
 *
 * ⚠️ **不能用框架的 `is_single()` / `get_post_title()`** ✗ —— 它们读 `$GLOBALS['current_post']`，
 *    而**全项目没有任何地方给这个变量赋值** ✗（2026-09-16 核实：只有函数自己读它 ✓）
 *    → 这两个函数恒为 false / '' ✗。这里改用本框架单篇页的 URL 形态 `?p=<id>` 判定 ✓。
 *
 * 只接受**单篇页** ✓：分类页/首页/搜索页不设特征 → 那些页面在选曲时走 URL 兜底（见 litafile_bgm_pick ✓）。
 */
function litafile_bgm_capture_features($content) {
    $post_id = (int)($_GET['p'] ?? 0);
    if ($post_id <= 0 || !is_string($content) || $content === '') return $content;
    // 正文长度上限：只取前 8000 字做词频（防超长文章把正则累着 ✓，对主题判断无影响 ✓）
    $body = mb_substr($content, 0, 8000, 'UTF-8');

    // 去掉短代码本身：`[litafile id=2 mode=file]` 不该参与主题词统计 ✗
    // （用 [[] 表示字面量「[」，避免多余转义 ✓）
    $body = preg_replace('/[[]litafile[^]]*]/i', ' ', $body);
    $body = preg_replace('/[[]litafile_playlist[^]]*]/i', ' ', (string)$body);

    $plain = strip_tags((string)$body);
    $chars = (int)mb_strlen(preg_replace('/\s+/u', '', $plain), 'UTF-8');

    // 主题词来源：标题（权重高）+ 正文 + 分类/标签名（权重高）
    $text_for_terms = $plain;
    $weight_extra   = [];
    if (function_exists('get_post')) {
        $post = get_post($post_id);
        if (is_array($post)) {
            $title = (string)($post['title'] ?? '');
            $text_for_terms .= ' ' . $title . ' ' . $title;      // 标题重复一次 = 加权 ✓
        }
    }
    foreach (['get_post_categories', 'get_post_tags'] as $fn) {
        if (!function_exists($fn)) continue;
        foreach ((array)$fn($post_id) as $row) {
            $nm = is_array($row) ? (string)($row['name'] ?? '') : (string)$row;
            if ($nm !== '') { $text_for_terms .= ' ' . $nm . ' ' . $nm; $weight_extra[$nm] = 3; }
        }
    }

    $terms = litafile_bgm_terms($text_for_terms);

    // 预计阅读时长 → 目标曲长（夹在 45 秒 ~ 10 分钟）
    $read_sec = (int)round($chars / 300 * 60);
    $target   = max(45, min(600, $read_sec));

    $GLOBALS['litafile_bgm_feat'] = [
        'seed'       => 'post:' . $post_id,
        'terms'      => $terms,
        'weight'     => $weight_extra,
        'chars'      => $chars,
        'target_sec' => $target,
        'source'     => 'post#' . $post_id,
    ];
    return $content;
}

/** 停用词（中英）——只做粗过滤，宁少勿多（漏掉的交给词频自然排序 ✓） */
function litafile_bgm_stopwords() {
    static $stop = null;
    if ($stop !== null) return $stop;
    $stop = array_flip(['的','了','和','是','在','我','有','就','不','人','都','一','一个','上','也','很','到','说','要','去','你','会','着','没有','看','好','自己','这','那','他','她','它','们','这个','那个','什么','怎么','可以','因为','所以','但是','如果','还是','已经','一直','这样','那样','时候','现在','知道','觉得','可能','需要','这里','那里','我们','你们','他们','一个','一些','只是','就是','不是','不能','还有','以及','对于','关于','通过','进行','没有','什么','为了','然后','不过','而且','the','and','for','with','that','this','you','are','was','were','have','has','had','not','but','from','they','will','would','can','could','should','about','into','than','then','them','there','their','what','when','where','which','who','how','all','any','been','more','most','some','such','only','also','just','like','over','other','out','up','down','its','it','is','of','to','in','on','at','be','as','by','or','an','a','http','https','www','com']);
    return $stop;
}

/**
 * 从文本里提取"主题词"（无 AI ✓ 纯词频）：
 *   · 中文：连续汉字片段的 2~3 字滑窗（2 字最常见，3 字能抓到"人工智能"这类）
 *   · 英文/数字：长度 ≥3 的单词
 * 返回按词频降序的候选词数组（最多 $limit 个 ✓）
 */
function litafile_bgm_terms($text, $limit = 60) {
    $text = mb_strtolower((string)$text, 'UTF-8');
    if ($text === '') return [];
    $stop  = litafile_bgm_stopwords();
    $terms = [];

    if (preg_match_all('/[\x{4e00}-\x{9fa5}]+/u', $text, $m)) {
        foreach ($m[0] as $seg) {
            $len = (int)mb_strlen($seg, 'UTF-8');
            if ($len < 2) continue;
            for ($w = 2; $w <= 3; $w++) {
                if ($len < $w) break;
                for ($i = 0; $i + $w <= $len; $i++) {
                    $t = (string)mb_substr($seg, $i, $w, 'UTF-8');
                    if (isset($stop[$t])) continue;
                    $terms[$t] = ($terms[$t] ?? 0) + 1;
                }
            }
        }
    }
    if (preg_match_all('/[a-z0-9]{3,}/', $text, $m2)) {
        foreach ($m2[0] as $w) {
            if (isset($stop[$w])) continue;
            $terms[$w] = ($terms[$w] ?? 0) + 1;
        }
    }
    if (!$terms) return [];
    arsort($terms);
    return array_slice(array_keys($terms), 0, $limit);
}

/** 单曲打分（越大越合适 ✓） */
function litafile_bgm_score($item, array $feat) {
    $score = 0.0;

    // ① 主题词重合：曲目的"元数据字符串"里出现文章高频词 → 加分 ✓
    $hay = mb_strtolower(
        (string)($item['title'] ?? '') . ' ' .
        (string)($item['artist'] ?? '') . ' ' .
        (string)($item['description'] ?? '') . ' ' .
        (string)($item['filename'] ?? ''), 'UTF-8');
    $hit = 0;
    $topn = 0;
    foreach ((array)$feat['terms'] as $t) {
        $topn++;
        if ($topn > 60) break;
        if ($t === '') continue;
        if (mb_strpos($hay, $t) !== false) {
            // 越靠前（词频越高）的主题词，命中越值钱 ✓；分类/标签命中有额外权重 ✓
            $hit += 1 + max(0, (int)($feat['weight'][$t] ?? 0));
        }
    }
    $score += min($hit, 24) * 3.0;

    // ② 时长匹配（filesize 按 192kbps 估算 ✓）
    $bytes  = (int)($item['filesize'] ?? 0);
    $est    = $bytes > 0 ? (int)round($bytes / 24000) : 0;
    $target = (int)($feat['target_sec'] ?? 180);
    if ($est > 0) {
        $score -= abs($est - $target) / 60.0;     // 每差 1 分钟扣 1 分 ✓
    }

    // ③ 轻度人气项：常被播放的更像"正经音乐"而不是误传的文件 ✓（权重很小，不影响主判据 ✓）
    $score += min((int)($item['play_count'] ?? 0), 20) * 0.05;

    return $score;
}

/**
 * 选曲（返回 `['index'=>…, 'volume'=>…, 'reason'=>…]`；$items 顺序 = 播放器曲目顺序 ✓）。
 * 无文章特征时用 URL 兜底 → 每个页面仍稳定地各有一首 ✓。
 */
function litafile_bgm_pick(array $items, $s = null) {
    if (!$items) return null;
    $s = $s ?: litafile_get_settings();

    $feat = $GLOBALS['litafile_bgm_feat'] ?? null;
    if (!is_array($feat) || empty($feat['seed'])) {
        $feat = [
            'seed'       => 'url:' . (string)($_SERVER['REQUEST_URI'] ?? '/'),
            'terms'      => [],
            'weight'     => [],
            'chars'      => 0,
            'target_sec' => 180,
            'source'     => 'url',
        ];
    }

    $best = null;
    $hit_best = 0;
    foreach ($items as $i => $it) {
        $sc  = litafile_bgm_score($it, $feat);
        $tie = md5($feat['seed'] . '#' . (int)($it['id'] ?? 0));   // 稳定 tie-break ✓
        if ($best === null
            || $sc > $best['score'] + 0.0001
            || (abs($sc - $best['score']) <= 0.0001 && strcmp($tie, $best['tie']) < 0)) {
            $best = [
                'score' => $sc, 'tie' => $tie, 'index' => (int)$i,
                'title' => trim((string)($it['title'] ?? '')) !== '' ? (string)$it['title'] : (string)($it['filename'] ?? ''),
            ];
        }
    }
    if ($best === null) return null;

    // 给后台/调试一个可解释的原因 ✓（会以 data 属性输出，不影响访客 ✓）
    $reason = ($feat['source'] === 'url' ? '无文章特征，按页面稳定选取' : '按文章特征选取')
        . '（正文 ' . (int)$feat['chars'] . ' 字 · 目标约 ' . (int)round(((int)$feat['target_sec']) / 60) . ' 分钟）';

    return [
        'index'  => (int)$best['index'],
        'volume' => max(0, min(100, (int)($s['bgm_volume'] ?? 35))),
        'reason' => $reason,
        'title'  => $best['title'],
    ];
}
