<?php
/**
 * litafile/includes/compat.php — 框架兼容层（补齐"WP 同名但本框架没有"的 API）
 *
 * 事故背景（2026-09-16，本地与远程一致）：
 *   文章正文里写 `[litafile id=1]` 后，帖子页整页 500（响应体 0 字节）。
 *   真因是 public/shortcodes.php 调用了 `shortcode_atts()` —— 这是 **WordPress 的函数**，
 *   本框架（LitaBlog）并没有实现 ✗：
 *     PHP Fatal error: Uncaught Error: Call to undefined function shortcode_atts()
 *       in content/plugins/litafile/public/shortcodes.php:118
 *       #0 functions.php(1859): litafile_shortcode_item(Array, NULL, 'litafile')
 *       #2 functions.php(1833): preg_replace_callback → do_shortcode_tag
 *       #3 functions.php(2223): do_shortcode  ← 渲染帖子正文
 *       #4 index.php(79): prepare_template_data('single', Array)
 *
 * ⚠️ 为什么"零日志、更难查"：非 DEBUG 分支里 load.php 执行 error_reporting(0)，
 *    而 error_reporting 同时决定"是否记录"——于是这个致命错误既不回显、也不进
 *    php_errors.log ✗（表现为"500 + 0 字节 + 无任何日志"）。
 *    排查手法：临时把 load.php 的 error_reporting(0) 换成 error_reporting(E_ALL)
 *    （display_errors 仍保持 '0'，即"只记录不回显"）→ 错误就会落到
 *    D:/laragon/tmp/php_errors.log（本地）✓。
 *
 * 处理原则：
 *   1) 一律用 if (!function_exists()) 兜底 —— **绝不覆盖框架已有实现**；
 *   2) 放在模块加载列表最前，保证所有调用点之前已定义。
 *   3) 只补"本插件确实用到"的函数，不无脑塞一堆未经验证的 WP API ✗。
 */
if (!defined('ABSPATH')) exit;

if (!function_exists('shortcode_atts')) {
    /**
     * WordPress 兼容：把 $atts 里命中的键覆盖到 $pairs 的默认值上（未提供的键保留默认值）。
     *
     * 与 WP 行为一致；第三个参数（$shortcode）在 WP 里只用于 `shortcode_atts_{$shortcode}`
     * 过滤钩子，本框架没有该机制，故忽略。
     *
     * 注意：属性既可能是"框架已解析好的数组"（本框架 do_shortcode_tag 会解析，
     * 调用时形如 litafile_shortcode_item(Array, NULL, 'litafile')），也可能是原样字符串，
     * 因此这里对两者都做 (array) 归一化 ✓
     */
    function shortcode_atts($pairs, $atts, $shortcode = '') {
        $pairs = (array)$pairs;
        $atts  = (array)$atts;
        $out   = [];
        foreach ($pairs as $name => $default) {
            $out[$name] = array_key_exists($name, $atts) ? $atts[$name] : $default;
        }
        return $out;
    }
}
