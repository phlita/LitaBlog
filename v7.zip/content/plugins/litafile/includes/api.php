<?php
/**
 * litafile/includes/api.php — Agent API（供 AI/脚本调用）
 *
 * 两种形态：
 *   ① 兼容旧调用方：`?agent_api=files&action=upload|download|list|delete`
 *      —— 响应体结构、参数名、状态码与旧 cloud-drive **保持一致**（老脚本零改动 ✓）
 *   ② 新形态：`?agent_api=litafile&resource=items|playlists&action=...`
 *
 * 鉴权（沿用旧机制）：`Authorization: Bearer <key>` → 回退 `X-API-Key` → （可选）`?apikey=`
 *   key 取自 `lita_agent_api_key_admin`（可上传/删除）与 `lita_agent_api_key_comment`（只读）。
 *   比较统一用 hash_equals（旧实现是 `===`，非常量时间 ✗）。
 */

if (!defined('ABSPATH')) exit;

/** 统一响应（与旧 cloud_api_response 同结构） */
function litafile_api_response($code, $message, $data = null) {
    if (!headers_sent()) {
        http_response_code((int)$code);
        header('Content-Type: application/json; charset=utf-8');
        $s = litafile_get_settings();
        header('Access-Control-Allow-Origin: ' . ($s['api_cors_origin'] ?? '*'));
        header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, X-API-Key, Content-Type');
    }
    while (ob_get_level() > 0) { @ob_end_clean(); }
    echo json_encode(['code' => (int)$code, 'message' => (string)$message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

/** 取出请求里的凭据 */
function litafile_api_provided_token() {
    $h = '';
    if (function_exists('apache_request_headers')) {
        $hs = apache_request_headers();
        $h = $hs['Authorization'] ?? ($hs['authorization'] ?? '');
    }
    if ($h === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) $h = $_SERVER['HTTP_AUTHORIZATION'];
    if ($h !== '' && preg_match('/Bearer\s+(\S+)/', $h, $m)) return $m[1];
    if (!empty($_SERVER['HTTP_X_API_KEY'])) return (string)$_SERVER['HTTP_X_API_KEY'];
    $s = litafile_get_settings();
    if (!empty($s['api_allow_query_key']) && isset($_GET['apikey'])) return (string)$_GET['apikey'];
    return '';
}

/** 鉴权 → 返回 'admin' | 'bot' | '' */
function litafile_api_role() {
    $tok = litafile_api_provided_token();
    if ($tok === '') return '';
    $admin = (string)get_option('lita_agent_api_key_admin', '');
    $bot   = (string)get_option('lita_agent_api_key_comment', '');
    if ($admin !== '' && hash_equals($admin, $tok)) return 'admin';
    if ($bot !== '' && hash_equals($bot, $tok)) return 'bot';
    return '';
}

/** 拦截器（init priority 2，与旧 cloud-drive 相同位置） */
function litafile_agent_api_interceptor() {
    $api = (string)($_GET['agent_api'] ?? '');
    if ($api !== 'files' && $api !== 'litafile') return;

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') litafile_api_response(200, 'ok');

    $role = litafile_api_role();
    if ($role === '') litafile_api_response(401, '认证失败：无效的 API Key。');

    if ($api === 'files') return litafile_api_files($role);
    return litafile_api_litafile($role);
}

/* ───────────────────────── ① 旧形态：?agent_api=files ───────────────────── */

/**
 * 上传实现（两种形态共用 ✓ 2026-09-16 抽出，让 `?agent_api=litafile&action=upload` 也是完整功能）
 * 支持 multipart（$_FILES['file']）与 JSON base64（{"filename","data","mime_type"}）两种入参 ✓
 */
function litafile_api_do_upload($role) {
    if ($role !== 'admin') litafile_api_response(403, '权限不足：仅 Admin Key 可上传文件');
    $opts = [
        'description' => (string)($_POST['description'] ?? ''),
        'password'    => (string)($_POST['password'] ?? ''),
        'title'       => (string)($_POST['title'] ?? ''),
        'artist'      => (string)($_POST['artist'] ?? ''),
        'uploader_id' => 0,
    ];
    if (!empty($_FILES['file']['tmp_name'])) {
        $r = litafile_handle_upload($_FILES['file'], $opts);
    } else {
        // JSON base64：{"filename":..,"data":..,"mime_type":..,"password":..}
        $in = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($in) || empty($in['filename']) || empty($in['data'])) {
            litafile_api_response(400, '缺少 filename 或 data 字段（data 为 Base64 编码内容）');
        }
        $bin = base64_decode((string)$in['data'], true);
        if ($bin === false) litafile_api_response(400, 'Base64 解码失败');
        $tmp = tempnam(sys_get_temp_dir(), 'litafile_');
        if ($tmp === false || file_put_contents($tmp, $bin) === false) litafile_api_response(500, '临时文件写入失败');
        $opts['description'] = (string)($in['description'] ?? '');
        $opts['password']    = (string)($in['password'] ?? '');
        $opts['title']       = (string)($in['title'] ?? '');
        $opts['artist']      = (string)($in['artist'] ?? '');
        $r = litafile_handle_upload([
            'name' => (string)$in['filename'], 'tmp_name' => $tmp,
            'type' => (string)($in['mime_type'] ?? ''), 'error' => UPLOAD_ERR_OK, 'size' => strlen($bin),
        ], $opts + ['trusted' => true]);
        @unlink($tmp);
    }
    if (!$r['ok']) litafile_api_response(400, $r['error']);
    $it = $r['item'];
    // ⚠️ 返回的 shortcode 只给**新标签** `[litafile id=N]` ✓
    //    （2026-09-16：旧 `[download id=N]` 已不再渲染 ✗，再返回它等于给 AI 一个坏标签 ✗）
    litafile_api_response(201, '上传成功', [
        'id'           => (int)$it['id'],
        'filename'     => $it['filename'],
        'filesize'     => (int)$it['filesize'],
        'mime_type'    => $it['mime_type'],
        'has_password' => !empty($it['password']),
        'kind'         => $it['kind'],
        'download_url' => rtrim(SITE_URL, '/') . '/?litafile_dl=' . (int)$it['id'] . '&token=' . litafile_token($it['id'], $it['stored_name']),
        'shortcode'    => '[litafile id=' . (int)$it['id'] . ']',
    ]);
}

/** ① 旧形态：?agent_api=files（保留给既有脚本；新脚本请用 ?agent_api=litafile ✓） */
function litafile_api_files($role) {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $action = (string)($_GET['action'] ?? '');

    if ($method === 'POST' && $action === 'upload') {
        litafile_api_do_upload($role);
    }

    if ($method === 'GET' && $action === 'download') {
        $id = (int)($_GET['id'] ?? 0);
        $item = litafile_get_item($id);
        if (!$item) litafile_api_response(404, '文件不存在');
        if (litafile_needs_password($item)) {
            $pw = (string)($_GET['password'] ?? '');
            if ($pw === '') {
                $in = json_decode((string)file_get_contents('php://input'), true);
                $pw = is_array($in) ? (string)($in['password'] ?? '') : '';
            }
            if ($pw === '') litafile_api_response(403, '此文件需要密码才能下载', ['require_password' => true, 'file_id' => $id]);
            $chk = litafile_check_password($item, $pw);
            if (!$chk['ok']) litafile_api_response(403, $chk['error'], ['require_password' => true, 'file_id' => $id]);
        }
        if (($item['source'] ?? 'local') === 'remote') {
            if ($role === 'admin' || empty($item['password'])) {
                litafile_bump_counter($id, 'download_count');
                if (!headers_sent()) header('Location: ' . $item['external_url'], true, 302);
                exit;
            }
        }
        if (isset($_GET['mode']) && $_GET['mode'] === 'url') {
            $protected = !empty($item['password']) || !litafile_direct_mode();
            litafile_api_response(200, '下载链接', [
                'id'           => $id,
                'filename'     => $item['filename'],
                'has_password' => !empty($item['password']),
                'download_url' => rtrim(SITE_URL, '/') . '/?litafile_dl=' . $id . '&token=' . litafile_token($id, $item['stored_name']),
                'direct_url'   => $protected ? null : litafile_item_public_url($item),
            ]);
        }
        litafile_bump_counter($id, 'download_count');
        litafile_stream_file($item, false);
    }

    if ($method === 'GET' && $action === 'list') {
        $res = litafile_list_items([
            'page'     => (int)($_GET['page'] ?? 1),
            'per_page' => (int)($_GET['per_page'] ?? 20),
            'search'   => (string)($_GET['search'] ?? ''),
            'kind'     => (string)($_GET['kind'] ?? 'all'),
        ]);
        $files = array_map(function ($f) {
            return [
                'id'           => (int)$f['id'],
                'filename'     => $f['filename'],
                'filesize'     => (int)$f['filesize'],
                'mime_type'    => $f['mime_type'],
                'kind'         => $f['kind'],
                'has_password' => !empty($f['password']),
                'description'  => $f['description'],
                'created'      => $f['created'],
            ];
        }, $res['items']);
        litafile_api_response(200, 'ok', ['total' => $res['total'], 'page' => $res['page'], 'per_page' => $res['per_page'], 'files' => $files]);
    }

    if ($method === 'DELETE') {
        if ($role !== 'admin') litafile_api_response(403, '权限不足：仅 Admin Key 可删除文件');
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) litafile_api_response(400, '缺少 id');
        if (!litafile_get_item($id)) litafile_api_response(404, '文件不存在');
        litafile_delete_item($id, true);
        litafile_api_response(200, '删除成功', ['id' => $id]);
    }

    litafile_api_response(400, '不支持的操作');
}

/* ───────────────────────── ② 新形态：?agent_api=litafile ────────────────── */

function litafile_api_litafile($role) {
    $method   = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $resource = (string)($_GET['resource'] ?? 'items');
    $action   = (string)($_GET['action'] ?? 'list');

    if ($resource === 'playlists') {
        if ($action === 'list') {
            $pls = litafile_get_playlists();
            foreach ($pls as &$p) { $p['count'] = count(litafile_playlist_items($p['id'])); }
            unset($p);
            return litafile_api_response(200, 'ok', ['playlists' => $pls]);
        }
        if ($role !== 'admin') litafile_api_response(403, '权限不足：仅 Admin Key 可修改歌单');
        if ($action === 'create') {
            $id = litafile_playlist_create((string)($_POST['name'] ?? '新歌单'), !empty($_POST['is_default']));
            return litafile_api_response(200, '已创建', ['id' => $id]);
        }
        if ($action === 'add' || $action === 'remove') {
            $pid = (int)($_POST['playlist_id'] ?? $_GET['playlist_id'] ?? 0);
            $iid = (int)($_POST['item_id'] ?? $_GET['item_id'] ?? 0);
            $ok = ($action === 'add') ? litafile_playlist_add($pid, $iid) : litafile_playlist_remove($pid, $iid);
            return litafile_api_response($ok ? 200 : 400, $ok ? 'ok' : '操作失败', ['playlist_id' => $pid, 'item_id' => $iid]);
        }
        if ($action === 'items') {
            $pid = (int)($_GET['playlist_id'] ?? 0);
            return litafile_api_response(200, 'ok', ['items' => litafile_playlist_items($pid, !empty($_GET['audio_only']))]);
        }
        litafile_api_response(400, '不支持的操作');
    }

    // resource=items
    if ($action === 'upload') {
        // 与旧形态共用同一实现 ✓（这样"新脚本"只需看一套文档 ✓）
        litafile_api_do_upload($role);
    }
    if ($action === 'list') {
        $res = litafile_list_items([
            'page' => (int)($_GET['page'] ?? 1), 'per_page' => (int)($_GET['per_page'] ?? 20),
            'search' => (string)($_GET['search'] ?? ''), 'kind' => (string)($_GET['kind'] ?? 'all'),
            'source' => (string)($_GET['source'] ?? ''),
        ]);
        return litafile_api_response(200, 'ok', $res);
    }
    if ($action === 'get') {
        $it = litafile_get_item((int)($_GET['id'] ?? 0));
        if (!$it) litafile_api_response(404, '条目不存在');
        $it['token'] = litafile_token($it['id'], $it['stored_name']);
        $it['url']   = litafile_stream_url($it, false);
        // 不外泄密码哈希
        unset($it['password']);
        return litafile_api_response(200, 'ok', $it);
    }
    if ($role !== 'admin') litafile_api_response(403, '权限不足：仅 Admin Key 可修改');

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
        if (!litafile_get_item($id)) litafile_api_response(404, '条目不存在');
        $f = [];
        foreach (['title', 'artist', 'description', 'filename'] as $k) {
            if (isset($_POST[$k])) $f[$k] = sanitize_text_field((string)$_POST[$k]);
        }
        if (isset($_POST['password'])) {
            $f['password'] = $_POST['password'] === '' ? '' : password_hash((string)$_POST['password'], PASSWORD_DEFAULT);
        }
        return litafile_api_response(litafile_update_item($id, $f) ? 200 : 400, 'ok', ['id' => $id]);
    }
    if ($action === 'delete') {
        $id = (int)($_GET['id'] ?? 0);
        if (!litafile_get_item($id)) litafile_api_response(404, '条目不存在');
        litafile_delete_item($id, true);
        return litafile_api_response(200, '删除成功', ['id' => $id]);
    }
    litafile_api_response(400, '不支持的操作');
}
