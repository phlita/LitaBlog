<?php
/**
 * litafile/includes/ajax.php — 后台 AJAX（编辑器弹层用）
 *
 * 准入：is_logged_in() + current_user_can('publish_posts') + CSRF
 * CSRF 说明：这里刻意使用 **非一次性** 令牌（verifyCsrfToken(..., false)）——
 *   编辑器弹层要支持"连续上传多首/多次插入"，一次性令牌会让第二次起必然失败 ✗
 *   （旧 lita-music 编辑器就有这个坑：每次提交都得刷新页面取新 token）。
 *   非一次性仍是会话绑定 + hash_equals 校验，安全性足够 ✓。
 */

if (!defined('ABSPATH')) exit;

function litafile_ajax_guard() {
    if (!function_exists('is_logged_in') || !is_logged_in()) {
        if (function_exists('wp_send_json_error')) wp_send_json_error('请先登录。', 403);
        exit;
    }
    if (!function_exists('current_user_can') || !current_user_can('publish_posts')) {
        if (function_exists('wp_send_json_error')) wp_send_json_error('权限不足。', 403);
        exit;
    }
    // ⚠️ 令牌必须绑定**当前 action 名** ✗ —— 框架 ajax.php:70 就是这么校验的：
    //      verifyCsrfToken($token, $action, false)
    //    这里原来写死 'litafile_ajax' ✗ → 前端拿同一枚令牌打 litafile_items / litafile_upload
    //    时框架层直接 403 "Security check failed (CSRF)"（2026-09-16 真浏览器实测 ✓，
    //    现象＝编辑器弹层"从媒体库选"永远显示"加载失败"）。
    $tok = (string)($_POST['_ajax_csrf_token'] ?? '');
    $act = (string)($_POST['action'] ?? '');
    if ($act === '' || !verifyCsrfToken($tok, $act, false)) {
        if (function_exists('wp_send_json_error')) wp_send_json_error('安全令牌校验失败，请刷新页面。', 403);
        exit;
    }
}

/** 上传（编辑器弹层） */
function litafile_ajax_upload() {
    litafile_ajax_gate_ok();
    litafile_ajax_guard();
    $uid = (int)($_SESSION['user_id'] ?? 0);
    $r = litafile_handle_upload($_FILES['file'] ?? null, [
        'password'    => (string)($_POST['password'] ?? ''),
        'title'       => (string)($_POST['title'] ?? ''),
        'artist'      => (string)($_POST['artist'] ?? ''),
        'uploader_id' => $uid,
        'playlist_id' => (int)($_POST['playlist_id'] ?? 0),
    ]);
    if (!$r['ok']) wp_send_json_error($r['error']);
    $it = $r['item'];
    wp_send_json_success([
        'id' => (int)$it['id'], 'filename' => $it['filename'], 'kind' => $it['kind'],
        // 只给新标签 ✓（2026-09-16 旧 [download]/[lita_music] 兼容已删 → 不再返回 legacy_shortcode ✗）
        // 2026-09-16：改由 litafile_shortcode_for_item() 生成 —— 它会按类型自动带 mode=
        //   （媒体 → mode=file「只显示内容」✓；其它可下载文件 → mode=link「只显示链接」✓）
        'shortcode' => litafile_shortcode_for_item($it),
        'url' => litafile_stream_url($it, true),
    ]);
}

/** 列表（编辑器弹层"从媒体库选"） */
function litafile_ajax_items() {
    litafile_ajax_guard();
    $res = litafile_list_items([
        'kind' => (string)($_POST['kind'] ?? 'all'),
        'search' => (string)($_POST['search'] ?? ''),
        'page' => (int)($_POST['page'] ?? 1), 'per_page' => 30,
    ]);
    $out = array_map(function ($f) {
        return ['id' => (int)$f['id'], 'filename' => $f['filename'], 'kind' => $f['kind'],
                'title' => $f['title'], 'has_password' => !empty($f['password']),
                // 同上：按类型自动带 mode= ✓（媒体→file 只显示内容；文件→link 只有链接 ✓）
                'shortcode' => litafile_shortcode_for_item($f)];
    }, $res['items']);
    wp_send_json_success(['items' => $out, 'total' => $res['total'], 'pages' => $res['pages']]);
}

/** 歌单列表（编辑器弹层"插入歌单"） */
function litafile_ajax_playlists() {
    litafile_ajax_guard();
    $out = [];
    foreach (litafile_get_playlists() as $p) {
        $out[] = ['id' => (int)$p['id'], 'name' => $p['name'], 'is_default' => (int)$p['is_default'],
                  'count' => count(litafile_playlist_items($p['id'])),
                  'shortcode' => '[litafile_playlist id=' . (int)$p['id'] . ']'];
    }
    wp_send_json_success(['playlists' => $out]);
}

/** 兼容：不同版本的 wp_send_json_* 可能有额外参数，这里做一次存在性保护 */
function litafile_ajax_gate_ok() {
    if (!function_exists('wp_send_json_success')) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'data' => '框架缺少 wp_send_json_success']);
        exit;
    }
}
