<?php
/**
 * litafile/includes/upload.php — 统一上传与添加（本地文件 / 外部 URL）
 *
 * 合并要点：
 *   · 扩展名策略统一为**白名单**（旧 cloud-drive 只有黑名单 ✗、旧 lita-music 是白名单 ✓）
 *   · 命名统一为 `Ymd_His_<8hex>.<ext>` + `Y/m/` 分目录（旧 cloud-drive 的日期分目录更好维护）
 *   · 文件名不沿用原名（防 `x.php` / 双扩展名绕过）→ 原名只存 DB 作展示
 *   · 外部 URL 项（旧 lita-music 支持）保留，但**禁内网/非 http(s)**（SSRF 面）
 */

if (!defined('ABSPATH')) exit;

/** 新文件相对目录（按年月分桶，避免单目录堆几万个文件） */
function litafile_rel_dir() {
    return date('Y/m') . '/';
}

/**
 * 生成落盘名：原名信息不进入文件名。
 *
 * ⚠️ 入参是**裸扩展名**（如 'mp3'，不带点）→ 这里**不能**再调 litafile_ext()：
 * litafile_ext('mp3') 走 pathinfo 找的是"最后一个点之后"，对 'mp3' 会返回空 ✗
 * → 落盘成 .bin（实测：中文名上传后变 .bin，直链模式下服务器会因此给错 Content-Type ✗）。
 * 直接净化这一个片段即可。
 */
function litafile_gen_stored_name($ext) {
    $ext = preg_replace('/[^a-z0-9]/', '', strtolower((string)$ext));
    if (!litafile_is_allowed_ext($ext)) $ext = 'bin';   // 兜底：不该发生（上游已校验）
    return date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
}

/**
 * 处理一次本地文件上传。
 * @param array $file $_FILES['xxx'] 单个条目
 * @param array $opts title|artist|description|password|uploader_id|check_ext_white
 * @return array{ok:bool,id:int,error:string,item:?array}
 */
function litafile_handle_upload($file, $opts = []) {
    $fail = function ($msg) { return ['ok' => false, 'id' => 0, 'error' => $msg, 'item' => null]; };

    if (!is_array($file) || !isset($file['tmp_name'])) return $fail('没有收到文件。');
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $map = [
            UPLOAD_ERR_INI_SIZE   => '文件超过服务器 upload_max_filesize 限制。',
            UPLOAD_ERR_FORM_SIZE  => '文件超过表单大小限制。',
            UPLOAD_ERR_PARTIAL    => '文件只上传了一部分，请重试。',
            UPLOAD_ERR_NO_FILE    => '没有选择文件。',
            UPLOAD_ERR_NO_TMP_DIR => '服务器缺少临时目录。',
            UPLOAD_ERR_CANT_WRITE => '服务器写入失败（磁盘/权限）。',
            UPLOAD_ERR_EXTENSION  => '上传被某个 PHP 扩展中止。',
        ];
        return $fail($map[$file['error']] ?? '上传失败（错误码 ' . $file['error'] . '）。');
    }
    // $opts['trusted']=true 用于"程序自己生成的临时文件"（如 Agent API 的 JSON base64 解码结果），
    // 这类文件不是 PHP 上传来的，is_uploaded_file() 必然为 false ✗ —— 用显式信任开关放行。
    if (empty($opts['trusted']) && !is_uploaded_file($file['tmp_name'])) return $fail('非法的上传来源。');

    $orig = litafile_clean_filename($file['name'] ?? 'file');
    $ext  = litafile_ext($orig);

    // 白名单（可在 $opts 里放宽为"仅黑名单"，但默认必须白名单）
    if (!empty($opts['check_ext_white']) || !isset($opts['check_ext_white'])) {
        if (!litafile_is_allowed_ext($ext)) {
            return $fail('不允许的文件类型：' . ($ext !== '' ? '.' . $ext : '(无扩展名)'));
        }
    }

    $storage_dir = litafile_storage_root('litafile');
    $rel_dir     = litafile_rel_dir();
    $dest_dir    = $storage_dir . $rel_dir;
    if (!is_dir($dest_dir) && !@mkdir($dest_dir, 0755, true)) return $fail('无法创建存储目录（权限/磁盘）。');
    litafile_ensure_storage_dir($storage_dir);

    $stored = litafile_gen_stored_name($ext);
    $dest   = $dest_dir . $stored;

    $moved = @move_uploaded_file($file['tmp_name'], $dest);
    if (!$moved) { $moved = @rename($file['tmp_name'], $dest); }
    if (!$moved || !is_file($dest)) { @unlink($dest); return $fail('文件保存失败（目标目录不可写？）。'); }

    $pw_hash = '';
    if (!empty($opts['password'])) $pw_hash = password_hash((string)$opts['password'], PASSWORD_DEFAULT);

    $item = [
        'kind'        => litafile_kind($orig, $file['type'] ?? ''),
        'filename'    => $orig,
        'stored_name' => $stored,
        'filepath'    => $rel_dir . $stored,
        'storage'     => 'litafile',
        'source'      => 'local',
        'filesize'    => (int)@filesize($dest),
        'mime_type'   => litafile_safe_mime($file['type'] ?? '', $orig),
        'title'       => sanitize_text_field($opts['title'] ?? ''),
        'artist'      => sanitize_text_field($opts['artist'] ?? ''),
        'description' => sanitize_text_field($opts['description'] ?? ''),
        'password'    => $pw_hash,
        'uploader_id' => (int)($opts['uploader_id'] ?? 0),
    ];
    $id = litafile_insert_item($item);
    if ($id <= 0) { @unlink($dest); return $fail('数据库写入失败。'); }
    $item['id'] = $id;

    // 若指定加入歌单（M4 用）
    if (!empty($opts['playlist_id']) && function_exists('litafile_playlist_add')) {
        litafile_playlist_add((int)$opts['playlist_id'], $id);
    }
    return ['ok' => true, 'id' => $id, 'error' => '', 'item' => $item];
}

/**
 * 添加"外部 URL"条目（旧 lita-music 的外链能力）。
 * 安全：仅 http(s)，且拒绝内网/回环地址（SSRF）。
 */
function litafile_handle_external($url, $opts = []) {
    $fail = function ($m) { return ['ok' => false, 'id' => 0, 'error' => $m, 'item' => null]; };
    $url = trim((string)$url);
    if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) return $fail('URL 格式不正确。');

    $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
    if (!in_array($scheme, ['http', 'https'], true)) return $fail('只允许 http/https 链接。');

    $host = strtolower((string)parse_url($url, PHP_URL_HOST));
    if ($host === '') return $fail('URL 缺少主机名。');
    if (litafile_host_is_private($host)) return $fail('不允许指向内网/本机地址。');

    $name = basename((string)parse_url($url, PHP_URL_PATH));
    if ($name === '') $name = 'remote-media';
    $ext = litafile_ext($name);
    if ($ext === '') {
        // 无扩展名时按 MIME 猜（不抓取，仅按 URL 结尾兜底给 audio）
        $ext = 'mp3';
    }
    if (!litafile_is_allowed_ext($ext)) return $fail('不允许的类型：.' . $ext);

    $item = [
        'kind'         => litafile_kind($name, ''),
        'filename'     => litafile_clean_filename($name),
        'stored_name'  => '',
        'filepath'     => '',
        'storage'      => 'litafile',
        'source'       => 'remote',
        'external_url' => $url,
        'filesize'     => 0,
        'mime_type'    => litafile_safe_mime('', $name),
        'title'        => sanitize_text_field($opts['title'] ?? ''),
        'artist'       => sanitize_text_field($opts['artist'] ?? ''),
        'description'  => sanitize_text_field($opts['description'] ?? ''),
        'password'     => '',
        'uploader_id'  => (int)($opts['uploader_id'] ?? 0),
    ];
    $id = litafile_insert_item($item);
    if ($id <= 0) return $fail('数据库写入失败。');
    $item['id'] = $id;
    if (!empty($opts['playlist_id']) && function_exists('litafile_playlist_add')) {
        litafile_playlist_add((int)$opts['playlist_id'], $id);
    }
    return ['ok' => true, 'id' => $id, 'error' => '', 'item' => $item];
}

/** 内网/回环判定（IPv4/IPv6 字面量 + localhost 名称） */
function litafile_host_is_private($host) {
    $host = trim($host, '[]');
    if ($host === 'localhost' || substr($host, -6) === '.local') return true;
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        // 私有/保留网段
        if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return true;
    }
    return false;
}
