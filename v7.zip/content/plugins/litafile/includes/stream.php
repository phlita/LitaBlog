<?php
/**
 * litafile/includes/stream.php — 下载/内嵌路由 + 流式输出（Range）+ 计数
 *
 * 合并来源：cloud-drive 的 `cloud_drive_download_router` / `cloud_drive_stream_file` / `cloud_drive_count_beacon`。
 * 保留旧参数名（`?cloud_download=` / `?cd_count=`）→ 存量文章里的老链接继续可用 ✓。
 *
 * 两种模式（设置项 litafile_settings.mode）：
 *   '0' 直链省资源：无密码的本地文件 → 302 到静态直链（Web 服务器直出，0 PHP 进程）
 *   '1' 完整保护  ：全部经 token 校验 + PHP readfile（计费主机上更稳，也便于统计）
 */

if (!defined('ABSPATH')) exit;

/** 是否直链省资源模式 */
function litafile_direct_mode() {
    $s = litafile_get_settings();
    return ($s['mode'] ?? '0') !== '1';
}

/**
 * 直链模式下的"静态直出"是否可用（2026-09-16 P2 优化）。
 *
 * ⚠️ **IIS 上返回 false** ✗ —— 原因是硬约束，不是偷懒：
 *   IIS 默认把 `system.webServer/httpProtocol` 与 `staticContent` 锁为 **Deny** 节（overrideModeDefault=Deny ✗），
 *   插件**无法**通过上传目录的 web.config 给静态响应挂 `nosniff` / CSP ✗；
 *   硬写这两个节会让**整个上传目录 500.19** ✗✗（比没有 nosniff 糟得多 ✓）。
 * ⇒ 于是让 IIS 上的下载**一律走 PHP 流式**（`litafile_stream_file()` 自带
 *   `X-Content-Type-Options: nosniff` ✓ 与 svg 的 CSP 沙箱 ✓），换来同等防护 ✓。
 *   代价：IIS 上"直链省资源"不再省 PHP 进程 ✓（安全优先 ✓，可在设置里切"完整保护"得到一致行为 ✓）。
 * 无法判定服务器类型时保守放行（Apache / Nginx 等按原样直出，并由 .htaccess 挂 nosniff + svg 沙箱 ✓）。
 */
function litafile_direct_static_ok() {
    $sw = strtolower((string)($_SERVER['SERVER_SOFTWARE'] ?? ''));
    return strpos($sw, 'iis') === false;
}

/** 对外可用的访问 URL（内嵌/下载共用；$inline 仅影响 Content-Disposition） */
function litafile_stream_url($item, $inline = false) {
    if (($item['source'] ?? 'local') === 'remote') return (string)$item['external_url'];

    $no_pw = empty($item['password']);
    if ($no_pw && litafile_direct_mode() && litafile_direct_static_ok()) {
        // 静态直出（浏览器原生支持 Range ✓；计数由前端 beacon 补 ✓）
        return litafile_item_public_url($item);
    }
    $url = rtrim(SITE_URL, '/') . '/?litafile_dl=' . (int)$item['id'] . '&token=' . litafile_token($item['id'], $item['stored_name']);
    return $inline ? $url . '&inline=1' : $url;
}

/** 下载/内嵌入口（init 早期挂钩，命中即 exit） */
function litafile_download_router() {
    $id = 0;
    // 2026-09-16 用户要求：删掉旧参数兼容（litafile 是新插件，无需承接 cloud-drive 的老链接 ✗）
    if (isset($_GET['litafile_dl'])) $id = (int)$_GET['litafile_dl'];
    if ($id <= 0) return;

    // 清掉可能已被 PHP 设置的缓存头（避免中间层缓存下载内容）
    if (!headers_sent()) {
        header_remove('Cache-Control');
        header('Cache-Control: private, max-age=0, no-store');
    }

    $item = litafile_get_item($id);
    if (!$item) { http_response_code(404); exit('文件不存在'); }

    $inline = isset($_GET['inline']) && $_GET['inline'] !== '0';
    $token  = (string)($_GET['token'] ?? '');
    if (!litafile_token_ok($item['id'], $item['stored_name'], $token)) {
        http_response_code(403);
        exit('链接无效或已过期');
    }

    // 密码保护
    if (litafile_require_password($item)) {
        $pw = (string)($_POST['litafile_pw'] ?? $_GET['password'] ?? '');
        if ($pw === '') { litafile_render_password_prompt($item); exit; }
        $r = litafile_check_password($item, $pw);
        if (!$r['ok']) { litafile_render_password_prompt($item, $r['error']); exit; }
    }

    // 直链模式：无密码本地文件 → 302 到静态地址（省 PHP 进程）
    if (($item['source'] ?? 'local') === 'local' && empty($item['password']) && litafile_direct_mode()) {
        if (!$inline) litafile_bump_counter($item['id'], 'download_count');
        header('Location: ' . litafile_item_public_url($item), true, 302);
        exit;
    }
    if (($item['source'] ?? 'local') === 'remote') {
        if (!$inline) litafile_bump_counter($item['id'], 'download_count');
        header('Location: ' . $item['external_url'], true, 302);
        exit;
    }

    if (!$inline) litafile_bump_counter($item['id'], 'download_count');
    litafile_stream_file($item, $inline);
}

/**
 * 计数 beacon（204 立即返回）。旧参数 ?cd_count= 的兼容已按用户要求删除 ✗
 *
 * ⚠️ 2026-09-16（P3 优化）：**加节流** —— 同一 IP 对同一条目 **1 小时内只计 1 次** ✓
 *   原因：这个接口无鉴权（任何人都能 GET `?litafile_count=N`）✗ → 原来可以无限刷下载数 ✓。
 *   **为什么不改成"带令牌"**：直链省资源模式下"无密码文件的下载根本不经过 PHP" ✗（302/静态直出 ✓），
 *   计数只能靠这个前端 beacon 补 ✓；再要求令牌会和"直链"的设计冲突，
 *   而且已缓存的匿名页面里的旧 beacon 会带着旧 URL 失效一个 TTL ✗ → **节流才是对症的解法** ✓
 *   （判定用框架的 cache_*，与密码锁定同一套路 ✓；拿不到 IP 或缓存不可用时退化为原行为 ✓）
 */
function litafile_count_beacon() {
    $id = 0;
    if (isset($_GET['litafile_count'])) $id = (int)$_GET['litafile_count'];
    if ($id <= 0) return;
    if (!litafile_get_item($id)) { http_response_code(204); exit; }   // 不存在的 id 不再计数 ✓

    $ip  = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $key = 'litafile_cnt_' . $id . '_' . md5($ip);
    if ($ip !== '' && function_exists('cache_get') && function_exists('cache_set')) {
        if (cache_get($key, 0) !== null) { http_response_code(204); exit; }   // 1 小时内已计过 → 不再 +1 ✓
        cache_set($key, 1, 3600);
    }

    litafile_bump_counter($id, 'download_count');
    http_response_code(204);
    exit;
}

/**
 * 流式输出（支持 Range，视频可拖动进度）。
 * @param array $item   条目
 * @param bool  $inline true=内嵌展示（img/audio/video），false=附件下载
 */
function litafile_stream_file($item, $inline = false) {
    $path = litafile_item_path($item);
    if ($path === '' || !is_file($path)) { http_response_code(404); exit('文件已丢失'); }

    // ★浏览器缓存（2026-09-16 渲染优化轮实测结论 ✓）：
    //   原来这里一律 `no-store` ✗ → 播放器 `preload='metadata'` 每次页面加载都要付一次
    //   **条件请求**（实测 ~38ms ✓，而且文件刚上传时浏览器启发式新鲜度=0 ✗）。
    //   上传文件名自带「时间戳+随机串」✓ ⇒ 换文件必然换 URL ⇒ 长缓存**不会**取到旧内容 ✓。
    //   受密码保护的条目保持 `no-store` ✗（缓存副本会绕过密码/令牌 ✓）。
    if (!headers_sent()) {
        header_remove('Cache-Control');
        header(!empty($item['password'])
            ? 'Cache-Control: private, max-age=0, no-store'
            : 'Cache-Control: private, max-age=86400');
    }

    $size = (int)filesize($path);
    $mime = litafile_safe_mime($item['mime_type'] ?? '', $item['filename'] ?? '');
    $name = (string)($item['filename'] ?? 'file');

    // 双段 Content-Disposition（剥离引号/CRLF，防头注入）
    $safe = str_replace(['"', "\r", "\n"], '', $name);
    $disp = $inline
        ? 'inline; filename="' . $safe . '"; filename*=UTF-8\'\'' . rawurlencode($name)
        : 'attachment; filename="' . $safe . '"; filename*=UTF-8\'\'' . rawurlencode($name);

    while (ob_get_level() > 0) { @ob_end_clean(); }   // 防框架缓冲影响大文件

    if (!headers_sent()) {
        header('Content-Type: ' . $mime);
        header('Content-Disposition: ' . $disp);
        header('Accept-Ranges: bytes');
        header('X-Content-Type-Options: nosniff');
        // ⚠️ 2026-09-16 安全修复（P1，活体 PoC 确认过 ✗）：SVG/HTML 这类内容在 **inline** 返回时
        //    会被浏览器当"文档"渲染，其内嵌脚本在**本站同源**执行 ⇒ 存储型 XSS
        //    （实测：直接打开 ?litafile_dl=N&token=…&inline=1 → 脚本执行 ✓）。
        //    修法：给这类响应加 **CSP 沙箱**（脚本一律不执行 ✓）；`<img>` 内嵌渲染**不受影响** ✓✓
        //    ⚠️ 绝不能改用 `Content-Disposition: attachment` 来修 ✗ —— 那会破坏 <img> 内嵌显示 ✗
        if (in_array(strtolower((string)$mime),
                     ['image/svg+xml', 'text/html', 'application/xhtml+xml', 'text/xml', 'application/xml'], true)) {
            header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox");
        }
    }

    // Range 解析（单区间：bytes=a-b）
    $start = 0; $end = $size - 1; $partial = false;
    $range = $_SERVER['HTTP_RANGE'] ?? '';
    if ($range !== '' && preg_match('/bytes=(\d*)-(\d*)/i', $range, $m)) {
        $has_s = ($m[1] !== ''); $has_e = ($m[2] !== '');
        if ($has_s) {
            $start = (int)$m[1];
            if ($has_e) $end = min((int)$m[2], $size - 1);
        } elseif ($has_e) {
            $start = max(0, $size - (int)$m[2]);   // 尾段请求
        }
        if ($start > $end || $start >= $size) {
            http_response_code(416);
            header('Content-Range: bytes */' . $size);
            exit;
        }
        $partial = true;
    }

    $len = $end - $start + 1;
    http_response_code($partial ? 206 : 200);
    if (!headers_sent()) {
        header('Content-Length: ' . $len);
        if ($partial) header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }

    $fp = @fopen($path, 'rb');
    if (!$fp) { http_response_code(500); exit; }
    if ($start > 0) @fseek($fp, $start);

    $chunk = 262144; // 256KB
    $sent  = 0;
    while ($sent < $len && !feof($fp)) {
        $read = (int)min($chunk, $len - $sent);
        $buf  = fread($fp, $read);
        if ($buf === false || $buf === '') break;
        echo $buf;
        $sent += strlen($buf);
        if (function_exists('flush')) @flush();
    }
    fclose($fp);
    exit;
}

/** 密码提示页（自包含，不依赖主题；POST 回本 URL） */
function litafile_render_password_prompt($item, $error = '') {
    $action = e($_SERVER['REQUEST_URI'] ?? '/');
    $title  = e($item['filename'] ?? '受保护文件');
    if (!headers_sent()) header('Content-Type: text/html; charset=UTF-8');
    http_response_code(401);
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'
       . '<meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<title>需要密码</title><style>'
       . 'body{font:15px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif;background:#f6f7f9;margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center}'
       . '.box{background:#fff;padding:28px 26px;border-radius:14px;box-shadow:0 8px 28px rgba(0,0,0,.08);width:min(92vw,380px)}'
       . 'h1{font-size:17px;margin:0 0 6px}.fn{color:#666;font-size:13px;word-break:break-all;margin-bottom:14px}'
       . 'input{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #d5d9e0;border-radius:9px;font-size:15px}'
       . 'button{margin-top:12px;width:100%;padding:11px;border:0;border-radius:9px;background:#3b82f6;color:#fff;font-size:15px;cursor:pointer}'
       . '.err{background:#fff1f0;color:#c0392b;padding:8px 10px;border-radius:8px;font-size:13px;margin-bottom:12px}'
       . '</style></head><body><div class="box"><h1>🔒 该文件受密码保护</h1><div class="fn">' . $title . '</div>'
       . ($error !== '' ? '<div class="err">' . e($error) . '</div>' : '')
       . '<form method="post" action="' . $action . '"><input type="password" name="litafile_pw" placeholder="请输入密码" required autofocus>'
       . '<button type="submit">下载</button></form></div></body></html>';
}
