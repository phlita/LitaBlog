<?php
/**
 * litafile/includes/settings.php — 设置读写（option: litafile_settings）
 *
 * 与整页缓存的配合：设置里含"模式/播放器"等会影响前台输出的项，
 * 改完必须清整页缓存（否则匿名访客最长 TTL 内仍看到旧页面 ✗）→ 见 litafile_update_settings()。
 */

if (!defined('ABSPATH')) exit;

/** 默认设置 */
function litafile_default_settings() {
    return [
        'mode'                => '0',      // 0=直链省资源，1=完整保护
        'player_autoplay'     => 0,
        'player_mode'         => 'list',   // list | shuffle | repeat-one
        'player_enabled'      => 1,        // 是否输出全局播放器
        // 背景音乐（2026-09-16）：按文章特征自动选一首循环低音量播放 ✓
        // ⚠️ 只在 player_autoplay=1 时才生效 ✓（用户明确要求 ✓，见 admin/menu.php 保存时的强制归零 ✓）
        'bgm_autoplay'        => 0,
        'bgm_volume'          => 35,       // 背景音乐音量 0-100 ✓
        // PJAX 导航（2026-09-16）：点站内链接只换主内容区、不重载文档 ✓ →
        //   播放器原地不动 ⇒ 换页时音乐**零中断**（对标网易云网页版的做法 ✓）
        //   ⚠️ 默认**关** ✓（出问题一键关掉即回到原生导航 ✓）
        'pjax'                => 0,
        'api_allow_query_key' => 0,        // 是否允许 ?apikey= 传参（默认关，防密钥进日志）
        'api_cors_origin'     => '*',      // Agent API 的 CORS 允许来源
    ];
}

/**
 * 读设置（请求内缓存）。
 *
 * ⚠️ 缓存放 $GLOBALS 而不是函数 static —— static 无法从外部重置，一旦写入新设置，
 * 同一个请求内继续读到旧值 ✗（单元测试捕获：改 mode 后 stream_url 仍按旧模式给直链）。
 * 框架自己的 option 缓存也是这个套路（unset($GLOBALS['litablog_option_cache'])）✓
 */
function litafile_get_settings() {
    if (isset($GLOBALS['litafile_settings_cache']) && is_array($GLOBALS['litafile_settings_cache'])) {
        return $GLOBALS['litafile_settings_cache'];
    }
    $raw = get_option('litafile_settings', '');
    $arr = is_string($raw) ? json_decode($raw, true) : (is_array($raw) ? $raw : []);
    $GLOBALS['litafile_settings_cache'] = array_merge(litafile_default_settings(), is_array($arr) ? $arr : []);
    return $GLOBALS['litafile_settings_cache'];
}

/**
 * 净化 CORS 允许来源（2026-09-16 P2 优化）。
 *
 * 只接受 `*` 或**一个** http(s) 来源 ✓；其余（含 CRLF、空格、怪字符）一律退回 `*` ✓。
 * 理由：这个值会**直接拼进响应头** `Access-Control-Allow-Origin:` ✗ ——
 * 带换行的值会被 PHP 拒绝（留下警告且 CORS 失效 ✗），顺手在入口净化更稳 ✓。
 */
function litafile_sanitize_cors_origin($v) {
    $v = trim((string)$v);
    if ($v === '' || $v === '*') return '*';
    // ⚠️ 含空白/控制字符 → **整条退回 `*`** ✓，**不要**"删掉再拼" ✗ ——
    //    删掉再拼会把 `https://a.com\n.evil.com` 拼成 `https://a.com.evil.com`（一个**合法域名** ✗）
    //    → 静默放行了一个你根本没打算允许的来源 ✓（2026-09-16 复测抓到这个弱点 ✓）
    if (preg_match('/[\x00-\x20\x7F]/', $v)) return '*';
    if (preg_match('~^https?://[A-Za-z0-9._\-]+(?::\d{1,5})?$~', $v)) return $v;
    return '*';
}

/**
 * 合并写入设置；成功则失效请求内缓存 + 清整页缓存。
 * @param array $patch 只写传入的键
 */
function litafile_update_settings(array $patch) {
    $cur = litafile_get_settings();
    $new = array_merge($cur, $patch);
    $ok  = update_option('litafile_settings', json_encode($new));
    if ($ok) {
        unset($GLOBALS['litafile_settings_cache']);   // 同请求内立即读到新值 ✓
        // update_option() 已让 options 快照失效；整页缓存需显式清（渲染相关）
        if (function_exists('litablog_purge_page_cache')) {
            litablog_purge_page_cache();
        } elseif (function_exists('pc_purge')) {
            pc_purge();
        }
    }
    return $ok;
}
