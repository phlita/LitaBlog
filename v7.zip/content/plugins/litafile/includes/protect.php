<?php
/**
 * litafile/includes/protect.php — 下载令牌 + 密码保护 + 爆破锁定
 *
 * 合并来源：cloud-drive（token/HMAC + 密码 + 会话免密 + 5 次锁定 600s）✓
 * 改动点（对照 2026-09-16 安全审计）：
 *   · token 校验统一走 hash_equals（常量时间）
 *   · 锁定计数走框架 cache_*（与旧实现一致，避免自建文件）
 *   · 免密凭证放 $_SESSION，且绑定条目 id
 */

if (!defined('ABSPATH')) exit;

/** 下载/内嵌令牌：HMAC(sha256, id|stored_name) —— 与旧 cloud-drive 算法相同（老链接不破） */
function litafile_token($id, $stored_name) {
    $key = defined('AUTH_KEY') ? AUTH_KEY : 'litafile-fallback-key';
    return hash_hmac('sha256', (int)$id . '|' . (string)$stored_name, $key);
}

/** 常量时间校验 */
function litafile_token_ok($id, $stored_name, $token) {
    $expect = litafile_token($id, $stored_name);
    return is_string($token) && $token !== '' && hash_equals($expect, $token);
}

/** 该条目是否需要密码（有 hash 即需要；外链条目不设密码） */
function litafile_needs_password($item) {
    return !empty($item['password']);
}

/* ───────────────────────── 爆破锁定（5 次 / 600s）───────────────────────── */

function litafile_pw_lock_key($id) {
    return 'litafile_pw_lock_' . (int)$id;
}

function litafile_pw_locked($id) {
    if (!function_exists('cache_get')) return false;
    $n = (int)cache_get(litafile_pw_lock_key($id), 0);
    return $n >= 5;
}

function litafile_pw_register_fail($id) {
    if (!function_exists('cache_get') || !function_exists('cache_set')) return;
    $k = litafile_pw_lock_key($id);
    $n = (int)cache_get($k, 0) + 1;
    cache_set($k, $n, 600);
}

function litafile_pw_clear_fail($id) {
    if (function_exists('cache_delete')) cache_delete(litafile_pw_lock_key($id));
}

/* ───────────────────────── 会话免密（1 小时）────────────────────────────── */

function litafile_session_grant($id) {
    if (session_status() === PHP_SESSION_NONE && function_exists('session_start')) {
        // 框架在需要会话时会自行启动；这里仅在已有时标记，避免擅自建会话
        if (isset($_SESSION)) return;
    }
    if (!isset($_SESSION) || !is_array($_SESSION)) return;
    $_SESSION['litafile_pw_ok'][(int)$id] = time() + 3600;
}

function litafile_session_has($id) {
    if (!isset($_SESSION['litafile_pw_ok'][(int)$id])) return false;
    return (int)$_SESSION['litafile_pw_ok'][(int)$id] > time();
}

/* ───────────────────────── 访问判定 ─────────────────────────────────────── */

/**
 * 是否需要"拦截并索要密码"。
 * @return bool true=必须走密码流程
 */
function litafile_require_password($item) {
    if (!litafile_needs_password($item)) return false;
    if (litafile_session_has($item['id'])) return false;
    // 有管理/发布权限的人不看密码（后台预览方便）
    if (function_exists('current_user_can') && (current_user_can('manage_options') || current_user_can('publish_posts'))) return false;
    return true;
}

/**
 * 校验提交的密码。
 * @return array{ok:bool,error:string,locked:bool}
 */
function litafile_check_password($item, $password) {
    if (litafile_pw_locked($item['id'])) {
        return ['ok' => false, 'error' => '尝试次数过多，请 10 分钟后再试。', 'locked' => true];
    }
    if (!litafile_needs_password($item)) return ['ok' => true, 'error' => '', 'locked' => false];
    if (is_string($password) && $password !== '' && password_verify($password, $item['password'])) {
        litafile_pw_clear_fail($item['id']);
        litafile_session_grant($item['id']);
        return ['ok' => true, 'error' => '', 'locked' => false];
    }
    litafile_pw_register_fail($item['id']);
    return ['ok' => false, 'error' => '密码不正确。', 'locked' => false];
}

/** 设置/清除密码（后台用；清除传空串） */
function litafile_set_password($id, $password) {
    $hash = ($password === '' || $password === null) ? '' : password_hash((string)$password, PASSWORD_DEFAULT);
    return litafile_update_item($id, ['password' => $hash]);
}
