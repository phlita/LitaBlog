<?php
/**
 * litafile/includes/storage.php — 存储解析 + 目录保护（.htaccess 与 web.config **双写**）
 *
 * 背景（2026-09-16 安全审计结论）：旧 cloud-drive 只写 Apache 的 `.htaccess`，
 * 而生产是 IIS → 该保护在生产**等于不存在** ✗（上传目录里的 .php 会被当脚本执行）。
 * litafile 从第一天起就同时写两份：
 *   · `.htaccess`  → Apache（本地 Laragon）
 *   · `web.config` → IIS（生产；用 Request Filtering 拒绝脚本扩展名，不依赖默认未安装的 URL Authorization）
 * 另外写一个 `index.php` 兜底（防目录列举被绕过时的源码窥探）。
 */

if (!defined('ABSPATH')) exit;

/** 会被当脚本执行的扩展名（两个服务器都要挡） */
function litafile_dangerous_exts() {
    return ['php', 'php3', 'php4', 'php5', 'php7', 'php8', 'phtml', 'pht', 'phps', 'phar',
            'cgi', 'pl', 'asp', 'asa', 'asax', 'ascx', 'ashx', 'asmx', 'axd',
            'jsp', 'jspx', 'htaccess', 'htpasswd'];
}

/** 存储代号 → 绝对目录（含末尾斜杠） */
function litafile_storage_root($storage = 'litafile') {
    switch ($storage) {
        case 'cloud': return LITAFILE_LEGACY_CLOUD_DIR;   // 旧网盘文件：原地引用，不搬
        case 'music': return LITAFILE_LEGACY_MUSIC_DIR;   // 旧音乐文件：原地引用，不搬
        default:      return LITAFILE_STORAGE_DIR;
    }
}

/** 存储代号 → 基础 URL（含末尾斜杠） */
function litafile_storage_base_url($storage = 'litafile') {
    $site = rtrim(SITE_URL, '/');
    switch ($storage) {
        case 'cloud': return $site . '/content/uploads/cloud/';
        case 'music': return $site . '/content/uploads/music/';
        default:      return LITAFILE_STORAGE_URL;
    }
}

/**
 * 新建存储目录（幂等）并写入保护文件。
 *
 * ⚠️ 2026-09-16 安全修复（PoC 连带发现，比 P1 更严重 ✗）：
 *   原来固定调用 `litafile_write_dir_protection($dir)`（默认 `$deny_all = false` ✗）→
 *   **每上传一次，就把"完整保护"站点的目录保护降级成"允许静态直出"** ✗：
 *   实测：上传一个文件后，原本 403 的静态直链变成 **200** ✓、`.htaccess` 从 `Require all denied`
 *   变成宽松规则 ✓ ⇒ 密码保护形同虚设（拿到 static URL 即可绕过 token 与密码 ✗）。
 *   修法：按**当前设置的模式**写保护 ✓（mode='1' = 完整保护 → deny_all=true ✓）。
 */
function litafile_ensure_storage_dir($dir = null) {
    $dir = $dir ?: LITAFILE_STORAGE_DIR;
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $deny_all = ((string)(litafile_get_settings()['mode'] ?? '0')) === '1';
    litafile_write_dir_protection($dir, $deny_all);
    return is_dir($dir);
}

/**
 * 写目录保护文件（幂等；内容不变则不重写，避免每次请求都写盘）。
 * @param string $dir       目标目录（默认新存储目录）
 * @param bool   $deny_all  true=整个目录禁止 HTTP 访问（完整保护模式）；
 *                          false=允许静态直出，但拒绝脚本扩展名（直链省资源模式）
 */
function litafile_write_dir_protection($dir = null, $deny_all = false) {
    $dir = rtrim($dir ?: LITAFILE_STORAGE_DIR, '/\\') . DIRECTORY_SEPARATOR;
    if (!is_dir($dir)) return false;

    // ① Apache
    if ($deny_all) {
        $ht = "Options -Indexes\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n";
    } else {
        $ht = "Options -Indexes\n<FilesMatch \"\\.(php|php3|php4|php5|php7|php8|phtml|pht|phps|phar|cgi|pl|asp|aspx|jsp|sh|bash|htaccess)$\">\n"
            . "    <IfModule mod_authz_core.c>\n        Require all denied\n    </IfModule>\n</FilesMatch>\n";
        // ⚠️ 2026-09-16（P1 直链模式的兜底）：只写"允许静态直出"是不够的 ✗ ——
        //    直链模式下 svg 会由 Web 服务器**当文档渲染**，其内嵌脚本同源执行 ⇒ 存储型 XSS ✗。
        //    Apache 可按扩展名挂响应头 → 给 svg 加 CSP 沙箱 ✓（`<img>` 内嵌渲染不受影响 ✓✓）
        // 2026-09-16（P2 优化）：整目录补 `X-Content-Type-Options: nosniff` ✓
        //    （直链模式下文件由 Web 服务器直出，PHP 那条 nosniff 管不到 → 浏览器可能 MIME 嗅探 ✓）
        //    ⚠️ 仅 Apache（mod_headers ✓，缺模块时 `IfModule` 自动降级 ✓）；
        //    **IIS 不能这么写** ✗ —— `httpProtocol`/`staticContent` 在 IIS 默认是锁定节（overrideModeDefault=Deny ✗），
        //    写进 web.config 会让**整个上传目录 500.19** ✗✗（比没有 nosniff 糟得多 ✓）。
        //    IIS 的处理办法在 PHP 侧：IIS 上直链模式**不再直出静态地址**，一律走 PHP 流式（自带 nosniff ✓ + svg 沙箱 ✓），
        //    见 stream.php 的 litafile_direct_static_ok() ✓
        $ht .= "<IfModule mod_headers.c>\n"
            . "    Header set X-Content-Type-Options \"nosniff\"\n"
            // ★媒体长缓存（2026-09-16 渲染优化轮实测 ✓）：没有 Cache-Control 时浏览器启发式新鲜度为 0 ✗
            //   → 播放器每次页面加载都要付一次条件请求（实测 ~38ms ✓）。
            //   文件名含「上传时间戳+随机串」✓ ⇒ 换文件必换 URL ⇒ 长缓存安全 ✓；private 防中间层缓存 ✓
            . "    <FilesMatch \"\\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|mp4|m4v|webm|mov|jpg|jpeg|png|gif|webp|avif)$\">\n"
            . "        Header set Cache-Control \"private, max-age=86400\"\n"
            . "    </FilesMatch>\n"
            . "    <FilesMatch \"\\.(svg|svgz)$\">\n"
            . "        Header set Content-Security-Policy \"default-src 'none'; style-src 'unsafe-inline'; img-src data:; sandbox\"\n"
            . "    </FilesMatch>\n"
            . "</IfModule>\n";
    }
    litafile_maybe_write($dir . '.htaccess', $ht);

    // ② IIS：Request Filtering 拒脚本扩展名（$deny_all 时把所有扩展名都拒掉）
    $rules = '';
    if ($deny_all) {
        $rules .= "          <add fileExtension=\".*\" allowed=\"false\" />\n";
    } else {
        foreach (litafile_dangerous_exts() as $e) {
            if ($e === 'htaccess' || $e === 'htpasswd') continue; // 这两个不是扩展名，见下方 hiddenSegments
            $rules .= "          <add fileExtension=\"." . $e . "\" allowed=\"false\" />\n";
        }
    }
    // ⚠️ 直链模式（$deny_all=false）下 svg 会被 Web 服务器当文档渲染 ⇒ 存储型 XSS ✗（2026-09-16 P1）
    //    IIS 侧**不用** web.config 挂响应头 ✗ —— `httpProtocol` / `staticContent` 在 IIS 默认是**锁定节**
    //    （overrideModeDefault=Deny ✗），写进去会让整个上传目录 **500.19** ✗✗（比不做防护糟得多 ✓）。
    //    IIS 的防护改在 PHP 侧：IIS 上直链模式不直出静态地址，一律走 PHP 流式
    //    （自带 nosniff ✓ + svg CSP 沙箱 ✓）→ 见 stream.php 的 litafile_direct_static_ok() ✓
    $wc = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        . "<!-- litafile 自动生成：禁止上传目录里的脚本被执行（IIS）。勿手改，后台可重写。 -->\n"
        . "<configuration>\n  <system.webServer>\n"
        . "    <security>\n      <requestFiltering>\n"
        . "        <fileExtensions>\n" . $rules . "        </fileExtensions>\n"
        . "        <hiddenSegments>\n          <add segment=\".htaccess\" />\n          <add segment=\"web.config\" />\n        </hiddenSegments>\n"
        . "      </requestFiltering>\n    </security>\n  </system.webServer>\n</configuration>\n";
    litafile_maybe_write($dir . 'web.config', $wc);

    // ③ 兜底
    litafile_maybe_write($dir . 'index.php', "<?php // Silence is golden.\n");
    return true;
}

/** 内容相同则不写（幂等 + 省 I/O） */
function litafile_maybe_write($path, $content) {
    if (is_file($path)) {
        $old = @file_get_contents($path);
        if ($old === $content) return true;
    }
    return @file_put_contents($path, $content) !== false;
}

/** 条目 → 绝对路径（按 storage 解析实际目录） */
function litafile_item_path($item) {
    if (!empty($item['external_url'])) return '';
    return litafile_storage_root($item['storage'] ?? 'litafile') . ltrim($item['filepath'] ?? '', '/');
}

/** 条目 → 公开 URL（外链项直接返回其 URL） */
function litafile_item_public_url($item) {
    if (!empty($item['external_url'])) return $item['external_url'];
    return litafile_storage_base_url($item['storage'] ?? 'litafile') . ltrim($item['filepath'] ?? '', '/');
}
