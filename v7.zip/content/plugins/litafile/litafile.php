<?php
/**
 * Plugin Name: LitaFile (媒体与文件)
 * Plugin URI:  https://lita.eu.org/
 * Description: 网盘 + 音乐播放器合并版：统一管理文件与媒体（图片/音频/视频/文档），支持后台上传、文章内嵌（图片/音视频自动展示，其余下载卡片）、文件密码保护、直链省资源 / 完整保护双模式、全局悬浮播放器与歌单，并提供 Agent API 供 AI 上传/下载。由 cloud-drive 与 lita-music 合并而来（旧短代码 [download] / [lita_music]、旧下载链接与旧 Agent API 全部保持兼容）。
 * Version:     1.0.0
 * Author:      Lita
 * Author URI:  https://lita.eu.org/
 *
 * 目录结构与设计见同目录 DESIGN.md / README.md。
 */

if (!defined('ABSPATH')) exit;

// ── 常量 ──────────────────────────────────────────────────────────────────
// 用 if(!defined()) 包一层：一是防重复包含时告警，二是让 CLI 单元测试能把存储目录
// 指到临时目录（零副作用测试），不必真的往 content/uploads/ 写文件 ✗
if (!defined('LITAFILE_VERSION'))      define('LITAFILE_VERSION', '1.0.0');
if (!defined('LITAFILE_SLUG'))         define('LITAFILE_SLUG', 'litafile');
if (!defined('LITAFILE_DIR'))          define('LITAFILE_DIR', __DIR__ . '/');
if (!defined('LITAFILE_URL'))          define('LITAFILE_URL', rtrim(SITE_URL, '/') . '/content/plugins/litafile/');
if (!defined('LITAFILE_STORAGE_DIR'))  define('LITAFILE_STORAGE_DIR', ABSPATH . 'content/uploads/litafile/');
if (!defined('LITAFILE_STORAGE_URL'))  define('LITAFILE_STORAGE_URL', rtrim(SITE_URL, '/') . '/content/uploads/litafile/');
// 旧目录（只读兼容：迁移时按 storage 字段解析，文件不搬）
if (!defined('LITAFILE_LEGACY_CLOUD_DIR')) define('LITAFILE_LEGACY_CLOUD_DIR', ABSPATH . 'content/uploads/cloud/');
if (!defined('LITAFILE_LEGACY_MUSIC_DIR')) define('LITAFILE_LEGACY_MUSIC_DIR', ABSPATH . 'content/uploads/music/');

// ── 模块加载 ──────────────────────────────────────────────────────────────
foreach ([
    // 兼容层必须放最前：补齐本框架缺失的 WP 同名函数（如 shortcode_atts），
    // 否则 public/shortcodes.php 渲染 [litafile id=N] 时会 "Call to undefined function" ✗（整页 500，见 compat.php 注释）
    'includes/compat.php',
    'includes/schema.php', 'includes/storage.php', 'includes/settings.php', 'includes/items.php',
    'includes/upload.php', 'includes/protect.php', 'includes/stream.php', 'includes/playlists.php',
    'includes/bgm.php',   // 背景音乐选曲（按文章特征 ✓ 无 AI ✓）
    'includes/legacy.php', 'includes/api.php', 'includes/ajax.php',
    'public/styles.php', 'public/shortcodes.php', 'public/player.php', 'public/media-controller.php',
    'public/pjax.php',   // ★换页不重载文档 → 音乐零中断（默认关，后台开关 ✓）
] as $__lf_file) {
    require_once LITAFILE_DIR . $__lf_file;
}
unset($__lf_file);

// 后台模块：只对管理员加载（本框架的 is_admin() = "当前用户是管理员"）
if (function_exists('is_admin') && is_admin()) {
    require_once LITAFILE_DIR . 'admin/ui.php';      // 统一外观（CSS + 小助手）必须在页面文件之前 ✓
    require_once LITAFILE_DIR . 'admin/menu.php';
    require_once LITAFILE_DIR . 'admin/page-library.php';
    require_once LITAFILE_DIR . 'admin/page-playlists.php';
    require_once LITAFILE_DIR . 'admin/page-settings.php';
    require_once LITAFILE_DIR . 'admin/editor-button.php';
}

// ── 生命周期 ──────────────────────────────────────────────────────────────
register_activation_hook(__FILE__, 'litafile_activate');
register_deactivation_hook(__FILE__, 'litafile_deactivate');

function litafile_activate() {
    litafile_create_schema();
    litafile_ensure_storage_dir(LITAFILE_STORAGE_DIR);

    // ⚠️ 判空不能写 `false === get_option($k)`：本框架 get_option 的**隐式默认值不是 false** ✗
    //    （实测：不传默认值时返回空串 → `false === ''` 为假 → 默认值永远写不进去，
    //      表现为"插件激活了但设置项缺失、播放器/模式取不到值"✗）。统一用显式哨兵 + empty()。
    if (empty(get_option('litafile_settings', null))) {
        update_option('litafile_settings', json_encode(litafile_default_settings()));
    }
    if (empty(get_option('litafile_install_version', null))) {
        update_option('litafile_install_version', LITAFILE_VERSION);
    }
    litafile_default_playlist_id();   // 建默认歌单（全局播放器依赖它）
}

function litafile_deactivate() {
    // 不删任何数据（本项目约定：能保留就保留）
}

/** 每次加载自检（幂等、静默失败）：库被重置后自动补表 */
function litafile_boot() {
    litafile_create_schema();
}
add_action('init', 'litafile_boot', 1);

// ── 前台路由（顺序与旧 cloud-drive 一致：下载 → 计数 → Agent API）──────────
add_action('init', 'litafile_download_router', 0);
add_action('init', 'litafile_count_beacon', 1);
add_action('init', 'litafile_agent_api_interceptor', 2);

/**
 * 短代码注册。
 * 2026-09-16 用户明确：litafile 是**新插件**，不需要承接 cloud-drive / lita-music 的旧标签 ✗
 *   → 只注册新标签；`[download]` / `[lita_music]` 的接管（原 litafile_register_legacy_shortcodes）已删除 ✓
 */
function litafile_register_shortcodes() {
    add_shortcode('litafile', 'litafile_shortcode_item');
    add_shortcode('litafile_playlist', 'litafile_shortcode_playlist_new');
}
add_action('init', 'litafile_register_shortcodes', 10);

// ── 前台输出 ──────────────────────────────────────────────────────────────
// ⚠️ 样式必须**同时**挂 `header`！本框架前台主题的 header.php（content/themes/*/header.php）触发的是
//    `do_action('header')`，**不触发 wp_head** ✗ → 只挂 wp_head 的后果是"前台一条样式都没有"：
//    播放器不悬浮、被排在页面最底下、卡片没有圆角（2026-09-16 用户报障"播放器没悬浮" ✓ 真因就在这一行 ✓）
//    litafile_inject_styles() 内部有 static 守卫 → 两处都挂也不会重复输出 ✓
add_action('wp_head', 'litafile_inject_styles');                    // 兼容会触发 wp_head 的主题
add_action('header', 'litafile_inject_styles');                     // 本框架主题（default / dan）触发这个 ✓
// ⚠️⚠️ 本框架的 add_action 与 add_filter 是**两套独立注册表** ✗（2026-09-16 实测确认 ✓）：
//     add_action → `$wp_actions`（只被 do_action 读 ✓）
//     add_filter → `$wp_filters`（只被 apply_filters 读 ✓）
//     两者**不是** WordPress 那种别名 ✗ ⇒ 挂 `the_content` 这类**过滤器**必须用 add_filter！
//     （原来写成 add_action ✗ → 回调**永不触发** ✗：实测 the_content 注册表里只有别的插件的 2 条 ✓，
//      表现为"背景音乐说『无文章特征』"、"早期展开短代码"从未真正生效 —— 用 error_log + 探针定位 ✓）
add_filter('the_content', 'litafile_expand_shortcodes_early', 5);    // 内容里早期展开短代码
// 背景音乐：抓取文章特征（标题/正文/分类/标签的高频词 + 字数 ✓）
// ⚠️ priority 6 = 短代码**展开之后** ✓（统计真正的正文文字 ✓，短代码文本已被剔除 ✓）
// ⚠️ 只传 1 个参数：apply_filters 按登记的 accepted_args 传参 ✓
//    → 文章 id 由函数内部读单篇页 URL 形态 `?p=<id>` 得到 ✓（详见 bgm.php ✓）
add_filter('the_content', 'litafile_bgm_capture_features', 6);
add_action('footer', 'litafile_media_controller', 98);               // ★统一媒体互斥
add_action('wp_footer', 'litafile_media_controller', 98);
add_action('footer', 'litafile_render_player', 99);                  // 全局悬浮播放器
add_action('wp_footer', 'litafile_render_player', 99);
// ★PJAX 导航（priority 100 = 在播放器**之后** ✓）：默认关，开了之后换页不重载文档
//   → 播放器原地不动 ⇒ 换页时音乐零中断 ✓（对标网易云网页版 ✓，见 pjax.php 的说明 ✓）
add_action('footer', 'litafile_pjax_nav', 100);
add_action('wp_footer', 'litafile_pjax_nav', 100);

// ── 后台 AJAX（编辑器弹层）────────────────────────────────────────────────
add_action('wp_ajax_litafile_upload', 'litafile_ajax_upload');
add_action('wp_ajax_litafile_items', 'litafile_ajax_items');
add_action('wp_ajax_litafile_playlists', 'litafile_ajax_playlists');
add_action('admin_footer', 'litafile_admin_editor_button');
