<?php
/**
 * litafile/uninstall.php — 卸载清理
 *
 * 由核心 `do_uninstall_plugin('litafile')` 调用（它会先 define('SBP_UNINSTALL_PLUGIN')）。
 * 契约（见 DESIGN.md §9）：
 *   ✅ 删除：本插件自己的三张表 + litafile_* 设置项
 *   ❌ 永不删除：content/uploads/** 里的任何文件（含 litafile/ 目录本身）
 *   ❌ 永不动：旧插件的表 cloud_files、旧设置项 lita_music_playlist / lita_music_settings
 *             （用户可能只想换插件、不想丢数据；要彻底清理由站长手动处理）
 */

if (!defined('ABSPATH')) exit;
if (!defined('SBP_UNINSTALL_PLUGIN')) exit;   // 只允许经核心卸载流程执行（防直接访问）

// ① 删表
try {
    $db = get_db();
    foreach (['litafile_playlist_items', 'litafile_playlists', 'litafile_items'] as $t) {
        $db->exec('DROP TABLE IF EXISTS ' . $t);
    }
} catch (Throwable $e) {
    // 忽略：数据库不可用时也不应阻塞卸载
}

// ② 删设置项（框架可能没有 delete_option → 退化为覆盖写空）
foreach (['litafile_settings', 'litafile_install_version', 'litafile_import_report'] as $opt) {
    try {
        if (function_exists('delete_option')) {
            delete_option($opt);
        } else {
            update_option($opt, '');
        }
    } catch (Throwable $e) {
    }
}

// ③ 不删文件：content/uploads/litafile/** 保持原样（这是用户数据，不是插件数据）
