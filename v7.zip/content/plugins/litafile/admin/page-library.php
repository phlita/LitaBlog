<?php
/**
 * litafile/admin/page-library.php — 媒体库（上传 + 列表 + 编辑 + 密码 + 删除）
 *
 * 2026-09-16 UI 改版（用户要求）：
 *   · 顶部一条**工具条**（统计 pills + 筛选/搜索），去掉原来"统计一行、筛选另一行"的堆叠 ✓
 *   · 宽屏两栏：左侧「上传 / 外链」固定操作区，右侧文件列表 ✓（窄屏自动堆叠 ✓）
 *   · 每行操作降噪：预览 · 下载 · 复制短代码 为主；「编辑信息 / 设置密码」折叠；删除为危险色 ✓
 *   · **表单字段 / action / CSRF 令牌全部原样保留** ✓（只动结构与样式，不动功能 ✓）
 */

if (!defined('ABSPATH')) exit;

function litafile_admin_page_library() {
    $kind   = (string)($_GET['kind'] ?? 'all');
    $search = (string)($_GET['s'] ?? '');
    $page   = max(1, (int)($_GET['paged'] ?? 1));
    $res    = litafile_list_items(['kind' => $kind, 'search' => $search, 'page' => $page, 'per_page' => 20]);
    $stats  = litafile_stats();
    $pls    = litafile_get_playlists();
    $act    = e(litafile_admin_url('library'));

    // ── 工具条：统计 + 筛选 ──────────────────────────────────────────────────
    echo '<div class="lf-bar">';
    echo '<div class="lf-stats">'
       . litafile_ui_pill('📦', '条目', (int)$stats['total'], true)
       . litafile_ui_pill('🖼️', '图片', (int)$stats['image'])
       . litafile_ui_pill('🎵', '音频', (int)$stats['audio'])
       . litafile_ui_pill('🎬', '视频', (int)$stats['video'])
       . litafile_ui_pill('📄', '文件', (int)$stats['file'])
       . litafile_ui_pill('💾', '占用', litafile_format_size($stats['bytes']))
       . '</div>';
    echo '<form class="lf-filter" method="get" action="' . e(rtrim(SITE_URL, '/') . '/admin/admin.php') . '">'
       . '<input type="hidden" name="page" value="litafile"><input type="hidden" name="tab" value="library">'
       . '<select name="kind">';
    foreach (['all' => '全部类型', 'image' => '🖼️ 图片', 'audio' => '🎵 音频', 'video' => '🎬 视频', 'file' => '📄 文件'] as $k => $lbl) {
        echo '<option value="' . $k . '"' . ($kind === $k ? ' selected' : '') . '>' . $lbl . '</option>';
    }
    echo '</select>'
       . '<input type="search" name="s" value="' . e($search) . '" placeholder="搜索文件名 / 标题 / 艺术家">'
       . '<button type="submit" class="button">筛选</button>';
    if ($search !== '' || $kind !== 'all') {
        echo '<a class="button" href="' . e(litafile_admin_url('library')) . '">重置</a>';
    }
    echo '</form></div>';

    echo '<div class="lf-cardsrow">';

    // ── 上排左：上传 ─────────────────────────────────────────────────────────

    echo '<div class="lf-card"><h2>⬆️ 上传文件 <span class="lf-hint">可多选 · 图片/音视频自动内嵌</span></h2>';
    echo '<form method="post" enctype="multipart/form-data" action="' . $act . '">';
    csrf_token_field('litafile_upload');
    echo '<input type="hidden" name="litafile_action" value="upload">';
    echo '<div class="lf-fields">';
    echo '<input type="file" name="litafile_files[]" multiple required>';
    echo '<input type="text" name="litafile_title" placeholder="标题（单文件时生效，可选）">';
    echo '<div class="lf-line">'
       . '<input type="text" name="litafile_artist" placeholder="作者/艺术家（可选）">'
       . '<input type="text" name="litafile_pw" placeholder="下载密码（可选）">'
       . '</div>';
    echo '<select name="litafile_playlist"><option value="0">不加入歌单</option>';
    foreach ($pls as $p) echo '<option value="' . (int)$p['id'] . '">🎧 ' . e($p['name']) . '</option>';
    echo '</select>';
    echo '<div class="lf-line"><button type="submit" class="button button-primary lf-btn">开始上传</button></div>';
    echo '</div>';
    echo '<p class="lf-note">允许：图片 / 音频 / 视频 / 常见文档与压缩包；脚本类扩展名一律拒绝 ✓</p>';
    echo '</form></div>';

    // ── 上排右：外链 ─────────────────────────────────────────────────────────
    echo '<div class="lf-card"><h2>🔗 添加外部链接 <span class="lf-hint">不占本站空间</span></h2>';
    echo '<form method="post" action="' . $act . '">';
    csrf_token_field('litafile_add_url');
    echo '<input type="hidden" name="litafile_action" value="add_url">';
    echo '<div class="lf-fields">';
    echo '<input type="url" name="litafile_url" placeholder="https://example.com/song.mp3" required>';
    echo '<div class="lf-line">'
       . '<input type="text" name="litafile_title" placeholder="标题（可选）">'
       . '<input type="text" name="litafile_artist" placeholder="艺术家（可选）">'
       . '</div>';
    echo '<div><button type="submit" class="button">添加外链</button></div>';
    echo '</div></form></div>';

    // ── 下方：全宽列表（880px 都用在这里，文件名不再被挤断 ✓）────────────────
    echo '</div>';
    echo '<div class="lf-card" style="margin-top:14px"><h2>📚 文件列表 <span class="lf-hint">'
       . ($search !== '' ? '搜索「' . e($search) . '」' : '最新在前') . ' · 共 ' . (int)$res['total'] . ' 条</span></h2>';

    if (!$res['items']) {
        echo '<div class="lf-empty">没有条目。' . ($search !== '' ? '试试清空搜索 ✓' : '先从上面上传一个吧 ✓') . '</div>';
        echo '</div>';
        return;
    }

    echo '<table class="lf-table"><thead><tr>'
       . '<th class="lf-ic">类型</th><th>文件 / 信息</th><th style="width:74px">大小</th>'
       . '<th style="width:56px">下载</th><th style="width:174px">操作</th></tr></thead><tbody>';

    foreach ($res['items'] as $it) {
        $id     = (int)$it['id'];
        $url    = litafile_stream_url($it, false);
        $view   = litafile_stream_url($it, true);
        $short  = '[litafile id=' . $id . ']';
        $has_pw = !empty($it['password']);
        $tags   = '';
        if (($it['storage'] ?? 'litafile') !== 'litafile') $tags .= '<span class="lf-tag warn" title="文件在旧目录中原位引用，未搬动">旧目录</span>';
        if (($it['source'] ?? 'local') === 'remote')        $tags .= '<span class="lf-tag ok">外链</span>';
        if ($has_pw)                                        $tags .= '<span class="lf-tag dgr">🔒 有密码</span>';
        $can_preview = in_array($it['kind'], ['image', 'audio', 'video'], true) && !$has_pw;

        echo '<tr>';
        echo '<td class="lf-ic">' . litafile_kind_icon($it['kind']) . '</td>';
        echo '<td>'
           . '<div class="lf-title">' . e($it['title'] !== '' ? $it['title'] : $it['filename']) . $tags . '</div>'
           . '<div class="lf-sub">' . e($it['filename']) . ($it['artist'] !== '' ? ' ｜ ' . e($it['artist']) : '') . '</div>'
           . ($it['description'] !== '' ? '<div class="lf-sub">' . e($it['description']) . '</div>' : '')
           . '<div style="margin-top:6px" class="lf-actions">'
           .   '<code class="lf-code">' . e($short) . '</code>'
           .   '<button type="button" class="button button-small lf-btn" data-lf-copybtn="' . e($short) . '">📋 复制短代码</button>'
           . '</div>'
           . '<details class="lf-details"><summary>编辑信息</summary>'
           .   '<form method="post" action="' . $act . '" class="lf-fields">'
           .     csrf_token_field('litafile_save_item')
           .     '<input type="hidden" name="litafile_action" value="save_item"><input type="hidden" name="id" value="' . $id . '">'
           .     '<div class="lf-line"><input type="text" name="title" value="' . e($it['title']) . '" placeholder="标题">'
           .       '<input type="text" name="artist" value="' . e($it['artist']) . '" placeholder="艺术家"></div>'
           .     '<input type="text" name="description" value="' . e($it['description']) . '" placeholder="描述（可选）">'
           .     '<div><button type="submit" class="button button-small">保存</button></div>'
           .   '</form></details>'
           . '<details class="lf-details"><summary>设置密码</summary>'
           .   '<form method="post" action="' . $act . '" class="lf-fields">'
           .     csrf_token_field('litafile_set_pw')
           .     '<input type="hidden" name="litafile_action" value="set_pw"><input type="hidden" name="id" value="' . $id . '">'
           .     '<input type="text" name="new_password" placeholder="' . ($has_pw ? '输入新密码（留空 = 取消密码）' : '新密码（留空 = 保持公开）') . '">'
           .     '<div><button type="submit" class="button button-small">应用</button></div>'
           .   '</form></details>'
           . '</td>';
        echo '<td>' . litafile_format_size($it['filesize']) . '</td>';
        echo '<td>' . (int)$it['download_count'] . '</td>';
        echo '<td><div class="lf-actions">'
           . '<a class="button button-small" href="' . e($view) . '" target="_blank" rel="noopener">' . ($can_preview ? '预览' : '打开') . '</a>'
           . '<a class="button button-small" href="' . e($url) . '" target="_blank" rel="noopener">下载</a>'
           . '<form method="post" action="' . $act . '" style="display:inline" onsubmit="return confirm(\'确定删除该条目？\')">'
           .   csrf_token_field('litafile_delete_item')
           .   '<input type="hidden" name="litafile_action" value="delete_item"><input type="hidden" name="id" value="' . $id . '">'
           .   '<button type="submit" class="button button-small lf-danger">删除</button>'
           . '</form></div></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';

    // 分页（页码多时折叠中间段 ✓）
    if ($res['pages'] > 1) {
        echo '<div class="lf-pager"><span class="lf-sub">第 ' . (int)$res['page'] . ' / ' . (int)$res['pages'] . ' 页</span>';
        for ($i = 1; $i <= $res['pages']; $i++) {
            if ($res['pages'] > 20 && $i > 3 && $i < $res['pages'] - 2 && abs($i - $res['page']) > 1) {
                if ($i === 4) echo '<span class="lf-sub">…</span>';
                continue;
            }
            $on = ($i === (int)$res['page']);
            echo '<a class="button' . ($on ? ' button-primary' : '') . ' button-small" href="'
               . e(litafile_admin_url('library', ['kind' => $kind, 's' => $search, 'paged' => $i])) . '">' . $i . '</a>';
        }
        echo '</div>';
    }
    echo '</div>';

    // 复制短代码（后台用，无依赖）
    echo '<script>(function(){document.querySelectorAll("[data-lf-copybtn]").forEach(function(b){'
       . 'b.addEventListener("click",function(){var t=b.getAttribute("data-lf-copybtn");'
       . 'if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){b.textContent="已复制 ✓";'
       . 'setTimeout(function(){b.textContent="📋 复制短代码";},1200);});}});});})();</script>';
}
