<?php
/**
 * litafile/admin/page-settings.php — 设置 / 目录保护 / Agent API 调用说明
 *
 * 2026-09-16 用户要求：删掉"从 cloud-drive / lita-music 导入"与"旧内容兼容"两块设置 ✗ → 已移除 ✓
 * 同日续：旧标签/旧链接的**运行期**兼容也删除 ✓（只注册 [litafile] / [litafile_playlist] ✓）
 * 同日 UI 改版：宽屏两栏 —— 右「基本设置（吸底保存）+ 目录保护」，左「Agent API 调用说明」✓
 * **表单字段 / action / CSRF 令牌全部原样保留** ✓
 */

if (!defined('ABSPATH')) exit;

function litafile_admin_page_settings($status) {
    $s   = litafile_get_settings();
    $act = e(litafile_admin_url('settings'));

    echo '<div class="lf-grid">';

    // ── 右（主）：基本设置 + 目录保护 ────────────────────────────────────────
    echo '<section class="lf-col-main">';

    echo '<div class="lf-card"><h2>⚙️ 基本设置</h2>';
    echo '<form method="post" action="' . $act . '" class="lf-fields">';
    csrf_token_field('litafile_settings');
    echo '<input type="hidden" name="litafile_action" value="save_settings">';

    echo '<div class="lf-note" style="margin:0">① 存储与下载模式</div>';
    echo '<label><input type="radio" name="mode" value="0"' . ($s['mode'] !== '1' ? ' checked' : '') . '> <b>直链省资源</b> — 无密码文件由 Web 服务器静态直出（不占 PHP 进程，免费主机友好 ✓）</label>';
    echo '<label><input type="radio" name="mode" value="1"' . ($s['mode'] === '1' ? ' checked' : '') . '> <b>完整保护</b> — 全部经令牌校验 + PHP 流式输出（可精确计数、支持 Range ✓）</label>';

    echo '<div class="lf-note" style="margin:8px 0 0">② 全局播放器</div>';
    echo '<label><input type="checkbox" name="player_enabled" value="1"' . (!empty($s['player_enabled']) ? ' checked' : '') . '> 在前台显示悬浮播放器（只收录默认歌单里的音频 ✓）</label>';
    echo '<label><input type="checkbox" name="player_autoplay" value="1"' . (!empty($s['player_autoplay']) ? ' checked' : '') . '> 自动播放（多数浏览器会拦截，建议关闭 ✓）</label>';
    echo '<label class="lf-line" style="align-items:center;gap:8px">默认播放模式：<select name="player_mode" style="flex:0 0 180px">';
    foreach (['list' => '顺序 🔁', 'shuffle' => '随机 🔀', 'repeat-one' => '单曲循环 🔂'] as $k => $lbl) {
        echo '<option value="' . $k . '"' . ($s['player_mode'] === $k ? ' selected' : '') . '>' . $lbl . '</option>';
    }
    echo '</select></label>';
    echo '<p class="lf-note">播放器需要「默认歌单」里有音频才会出声；歌单为空时前台只显示一个"暂无歌曲"的小条 ✓</p>';

    // ── 背景音乐（2026-09-16 用户需求）──────────────────────────────────────
    // 前置依赖：必须「自动播放」已勾选才生效 ✓（用户明确要求 ✓）→ 未勾选时把本项置灰并说明 ✓
    $auto_on = !empty($s['player_autoplay']);
    echo '<div class="lf-note" style="margin:8px 0 0">③ 背景音乐（按文章特征自动选曲，无需 AI ✓）</div>';
    echo '<label><input type="checkbox" name="bgm_autoplay" value="1"'
       . ((!empty($s['bgm_autoplay']) && $auto_on) ? ' checked' : '') . ($auto_on ? '' : ' disabled')
       . '> 背景音乐自动播放 — 打开文章时，按「正文字数 + 主题关键词」自动挑一首相关的曲子，循环、低音量播放 ✓</label>';
    echo '<label class="lf-line" style="align-items:center;gap:8px">背景音乐音量：'
       . '<input type="number" name="bgm_volume" min="0" max="100" value="' . (int)$s['bgm_volume'] . '" style="flex:0 0 90px"> '
       . '<span class="lf-note" style="margin:0">0-100（默认 35 ✓；背景音乐建议压低 ✓）</span></label>';
    echo '<p class="lf-note" style="margin:4px 0 0">'
       . ($auto_on
            ? '✓ 前置条件已满足（上面的「自动播放」已勾选）'
            : '⚠️ <b>需先勾选上面的「自动播放」才会生效</b> ✗（保存时会自动把本项取消，避免出现"勾了 BGM 但前置没勾"的不一致态 ✓）')
       . '<br>选曲规则（<b>不需要 AI</b> ✓）：① 时长 ≈ 预计阅读时长（正文字数 ÷ 300 字/分钟）✓ '
       . '② 与标题/分类/标签的**主题词重合度**打分 ✓ ③ 同一篇文章**永远同一首** ✓（与整页缓存兼容 ✓）<br>'
       . '想让某首更"对味"：在它的 <b>描述</b> 里写风格词（如 <code class="lf-code">钢琴 安静 夜</code>）就会被优先匹配 ✓</p>';

    // ── PJAX 导航（2026-09-16：对标网易云网页版"换页不断音" ✓）────────────────
    echo '<div class="lf-note" style="margin:8px 0 0">④ 换页方式（音乐连续性）</div>';
    echo '<label><input type="checkbox" name="pjax" value="1"' . (!empty($s['pjax']) ? ' checked' : '') . '> 站内链接**不重载页面**（PJAX）— 换页只替换主内容区，'
       . '播放器原地不动 ⇒ <b>换页时音乐零中断</b> ✓（网易云网页版就是这个原理 ✓）</label>';
    echo '<p class="lf-note" style="margin:4px 0 0">'
       . '开：切页/前进后退像"同一页换内容"，音乐不会停、也不会有重新起播的顿感 ✓；'
       . '关（默认）：每次点链接都整页刷新 ✓。<br>'
       . '本框架是 MPA：整页刷新时实测"HTML 56ms + 音频起流 38ms + 起播 2ms ≈ 100ms 的可听间隙" ✓，'
       . '而且**新页面没有用户手势 → 播放会被浏览器拦**（实测 NotAllowedError ✗）→ 表现为"音乐停住、要点一下" ✓ —— 这才是卡顿感的来源 ✓。<br>'
       . '开了 PJAX 这两条都消失 ✓；若某项页面不适合接管，会自动退回正常跳转 ✓；'
       . '怀疑有副作用时把它取消勾选保存即可恢复原样 ✓。</p>';

    echo '<div class="lf-note" style="margin:8px 0 0">⑤ Agent API（密钥由 lita-agent-api 插件签发 ✓）</div>';
    echo '<label><input type="checkbox" name="api_allow_query_key" value="1"' . (!empty($s['api_allow_query_key']) ? ' checked' : '') . '> 允许用 <code class="lf-code">?apikey=</code> 传密钥（免费主机丢 Authorization 头时的兜底；但密钥会进访问日志/Referer，默认关闭 ✓）</label>';
    // ⚠️ 2026-09-16（P2）：值为 `*` 时给一条醒目提示（凭据走 Header 不走 Cookie，所以不是漏洞 ✓，但收敛更干净 ✓）
    $cors_star = ((string)$s['api_cors_origin'] === '*');
    echo '<label class="lf-line" style="align-items:center;gap:8px">CORS 允许来源：<input type="text" name="api_cors_origin" value="' . e($s['api_cors_origin']) . '" style="flex:0 0 220px"> '
       . '<span class="lf-note" style="margin:0">填 <code class="lf-code">*</code> 表示任何站点都能读取；'
       . ($cors_star
            ? '<b style="color:#996800">当前为 * ✗ —— 如果只给自己或自己的脚本用，改成站点域名更收敛 ✓</b>'
            : '当前已收敛为指定来源 ✓')
       . '（保存时自动净化：只接受 <code class="lf-code">*</code> 或一个 http(s) 来源 ✓）</span></label>';

    echo '<div class="lf-savebar"><button type="submit" class="button button-primary">保存设置</button>'
       . '<span class="lf-note" style="margin:0">保存会同时按当前模式重写上传目录的保护文件 ✓</span></div>';
    echo '</form></div>';

    echo '<div class="lf-card"><h2>🛡️ 上传目录保护</h2>';
    echo '<p class="lf-note" style="margin:0 0 10px">会**同时**写入 <code class="lf-code">.htaccess</code>（Apache）与 <code class="lf-code">web.config</code>（IIS）✓'
       . '（旧网盘只写 .htaccess，生产是 IIS 时等于没保护 ✗）；目录列举也已关闭 ✓</p>';
    echo '<form method="post" action="' . $act . '">';
    csrf_token_field('litafile_rewrite');
    echo '<input type="hidden" name="litafile_action" value="rewrite_protection">'
       . '<button type="submit" class="button">按当前模式重写保护文件</button></form></div>';

    echo '</section>';

    // ── 左（侧）：Agent API 调用说明 ─────────────────────────────────────────
    $doc_file = LITAFILE_DIR . 'API.md';
    $api_doc  = is_file($doc_file) ? (string)@file_get_contents($doc_file) : '';
    if ($api_doc === '') {
        $api_doc = "§1 认证: Authorization: Bearer <key>（或 X-API-Key / ?apikey=）\n"
                 . "§2 端点: ?agent_api=litafile&resource=items|playlists&action=list|get|update|delete|upload\n"
                 . "§3 列表: GET  ?agent_api=litafile&resource=items&action=list&kind=audio\n"
                 . "§4 上传: POST ?agent_api=litafile&resource=items&action=upload  (multipart file=@x.mp3 或 JSON base64)\n"
                 . "§5 歌单: POST ?agent_api=litafile&resource=playlists&action=create|add|remove\n"
                 . "（完整文档见插件目录下 API.md ✓）";
    }
    echo '<aside class="lf-col-side">';
    echo '<div class="lf-card"><h2>🤖 Agent API 调用说明</h2>';
    echo '<p class="lf-note" style="margin:0 0 8px">'
       . '① <b>密钥不在这里签发</b> ✗：由 <b>lita-agent-api</b> 插件统一管理 → 后台菜单「<b>Agent API</b>」里生成 ✓<br>'
       . '本插件只读它写的两个 option：<code class="lf-code">lita_agent_api_key_admin</code>（可读写）、'
       . '<code class="lf-code">lita_agent_api_key_comment</code>（只读）✓</p>';
    echo '<p class="lf-note" style="margin:0 0 8px">'
       . '② 请求：<code class="lf-code">?agent_api=litafile&amp;resource=items|playlists&amp;action=…</code><br>'
       . '③ 认证：<code class="lf-code">Authorization: Bearer &lt;key&gt;</code><br>'
       . '④ 响应：<code class="lf-code">{"code":&lt;HTTP 状态码&gt;,"message":"…","data":{…}}</code></p>';
    echo '<details class="lf-details"><summary>展开完整规则 / 示例（API.md）</summary>';
    echo '<pre class="lf-pre">' . e($api_doc) . '</pre></details>';
    echo '</div></aside>';

    echo '</div>';
}
