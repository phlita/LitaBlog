<?php
/**
 * litafile/admin/editor-button.php — 编辑器统一按钮（合并旧插件的两个按钮）
 *
 * 合并前：cloud-drive 与 lita-music 各插一个按钮，都往 Quill 工具栏 `.ql-clean` 右侧挤 ✗
 *         → 位置竞争，还会出现两个功能相似的弹层。
 * 现在：**一个按钮 + 一个弹层**，弹层里三个页签：上传新文件 / 从媒体库选 / 插入歌单 ✓
 *
 * 插入实现：优先用 Quill 官方 API（`Quill.find(.ql-editor)` → `insertText`），
 *          取不到实例时回退 `document.execCommand('insertText')`（纯 contenteditable 场景）。
 */

if (!defined('ABSPATH')) exit;

function litafile_admin_editor_button() {
    $self = basename((string)($_SERVER['PHP_SELF'] ?? ''));
    if ($self !== 'content.php') return;   // 只在文章编辑器页注入（与旧插件一致）

    $ajax  = rtrim(SITE_URL, '/') . '/ajax.php';
    // 令牌按 **action 名** 一一签发（框架 ajax.php 用 action 名校验 ✗；共用一个令牌必 403）
    $tok_upload = generateCsrfToken('litafile_upload');
    $tok_items  = generateCsrfToken('litafile_items');
    $pls   = [];
    foreach (litafile_get_playlists() as $p) {
        $pls[] = ['id' => (int)$p['id'], 'name' => $p['name'], 'count' => count(litafile_playlist_items($p['id']))];
    }
    // ⚠️ 必须 json_encode 后再插进 JS！
    //    踩过的坑（2026-09-16，用户反馈"工具栏没有按钮"）：写成裸 `{$ajax}` 会生成
    //    `var AJAX = http://localhost/ajax.php;` —— 这是**非法 JS** ✗ → 整个 IIFE 不执行
    //    → 后面的"轮询 .ql-toolbar 插按钮"根本不是运行 ✗（按钮当然不出现）。
    //    旧的 cloud-drive 插件正是用 json_encode 才一直好用 ✓（见同目录旁证的写法）。
    $ajaxjs  = json_encode($ajax);
    $tupjs   = json_encode($tok_upload);
    $tlistjs = json_encode($tok_items);
    $plsjs   = json_encode($pls, JSON_UNESCAPED_UNICODE);
    if ($ajaxjs === false)  $ajaxjs = '"/ajax.php"';   // json_encode 对非法 UTF-8 会返回 false
    if ($tupjs === false)   $tupjs = '""';
    if ($tlistjs === false) $tlistjs = '""';
    if ($plsjs === false)   $plsjs = '[]';
    $css = <<<CSS
<style>
/* 工具栏按钮：**不要**复用 Quill 自带的 .ql-clean/.ql-* 类 —— 那些是 24px 宽的图标按钮，
   塞文字会被裁掉（按钮"看起来不存在"✗）。这里用自定义类 + 自带尺寸，与旧插件 .cd-ebtn 一致。
   ⚠️ 但只写 .lf-ebtn 会被 Quill 的 `.ql-snow .ql-toolbar button{width:28px}` 压过 ✗
   （2026-09-16 真浏览器实测：clientWidth 28 / scrollWidth 52 → 文字溢出、点击区只有 28px ✗）→
   选择器写到 `button.lf-ebtn` 提高优先级，关键属性加 !important ✓ */
.ql-toolbar button.lf-ebtn,.ql-toolbar .lf-ebtn{width:auto !important;display:inline-flex !important;align-items:center;gap:4px;padding:0 8px !important;height:24px;line-height:24px;cursor:pointer;border:none;background:none;border-radius:4px;color:#2c3e2d;font-size:13px;font-weight:600;vertical-align:middle;font-family:inherit;white-space:nowrap}
.ql-toolbar button.lf-ebtn:hover,.ql-toolbar .lf-ebtn:hover{background:#e8eff7}
#lf-modal{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:100000;display:none;align-items:center;justify-content:center}
#lf-modal.on{display:flex}
.lf-box{background:#fff;border-radius:14px;width:min(94vw,720px);max-height:86vh;overflow:auto;box-shadow:0 20px 50px rgba(0,0,0,.25)}
.lf-hd{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #eee;position:sticky;top:0;background:#fff}
.lf-hd b{flex:1 1 auto;font-size:15px}
.lf-tabs{display:flex;gap:6px;padding:10px 18px 0}
.lf-tabs button{border:0;background:#f0f2f5;border-radius:8px 8px 0 0;padding:8px 14px;cursor:pointer;font-size:13px}
.lf-tabs button.on{background:#2271b1;color:#fff}
.lf-body{padding:14px 18px 20px}
.lf-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:10px}
.lf-list{max-height:320px;overflow:auto;border:1px solid #eee;border-radius:10px}
.lf-item{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #f4f4f4;font-size:13px}
.lf-item:last-child{border-bottom:0}
.lf-item .nm{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lf-msg{font-size:13px;margin-top:8px}
.lf-msg.err{color:#c0392b}.lf-msg.ok{color:#0a7}
</style>
CSS;

    echo $css;
    // ⚠️ 下面的 <<<HTML 是**会解释转义**的 heredoc ✗：任何 JS 字符串里的 \n 都会被 PHP 变成真换行，
    //    把 JS 字符串/注释劈成两行 = 语法错误（node --check 抓过两次 ✗）。所以：
    //      ① 要输出 JS 的 \n 必须写 \\n；② **注释一律写在 heredoc 外面**，别写在里面 ✗
    echo <<<HTML
<div id="lf-modal"><div class="lf-box">
  <div class="lf-hd"><span>📁</span><b>插入媒体 / 文件</b><button type="button" class="button" id="lf-close">关闭</button></div>
  <div class="lf-tabs">
    <button type="button" data-tab="up" class="on">上传新文件</button>
    <button type="button" data-tab="pick">从媒体库选</button>
    <button type="button" data-tab="pl">插入歌单</button>
  </div>
  <div class="lf-body">
    <div data-panel="up">
      <div class="lf-row"><input type="file" id="lf-file" multiple></div>
      <div class="lf-row">
        <input type="text" id="lf-title" placeholder="标题（可选）" class="regular-text">
        <input type="text" id="lf-artist" placeholder="艺术家（可选）" class="regular-text">
        <input type="text" id="lf-pw" placeholder="下载密码（可选）" class="regular-text">
        <select id="lf-pl"><option value="0">不加入歌单</option></select>
      </div>
      <div class="lf-row"><button type="button" class="button button-primary" id="lf-do-upload">上传</button>
        <span style="font-size:12px;color:#888">上传后自动插入短代码（图片/音视频会内嵌展示）</span></div>
      <div class="lf-msg" id="lf-msg-up"></div>
    </div>
    <div data-panel="pick" style="display:none">
      <div class="lf-row">
        <input type="search" id="lf-search" placeholder="搜索文件名/标题" class="regular-text">
        <select id="lf-kind"><option value="all">全部类型</option><option value="image">图片</option><option value="audio">音频</option><option value="video">视频</option><option value="file">文件</option></select>
        <button type="button" class="button" id="lf-reload">刷新</button>
      </div>
      <div class="lf-list" id="lf-list"></div>
      <div class="lf-msg" id="lf-msg-pick"></div>
    </div>
    <div data-panel="pl" style="display:none">
      <div class="lf-list" id="lf-pl-list"></div>
      <div class="lf-msg" id="lf-msg-pl"></div>
    </div>
  </div>
</div></div>
<script>
(function(){
  var AJAX = {$ajaxjs}, T_UP = {$tupjs}, T_LIST = {$tlistjs}, PLAYLISTS = {$plsjs};
  var modal = document.getElementById('lf-modal');
  var cur = { tab:'up', lastFocus:null };

  function insert(text){
    // 优先用编辑器暴露的实例（本框架 admin/views/content.php:146 有 window.quillInstance = quill ✓），
    // 再退到 Quill.find()，最后 execCommand ✓ —— 三层兜底，与旧插件同一套路 ✓
    var ed = document.querySelector('.ql-editor');
    var payload = '\\n' + text + '\\n';   // 短代码独占一行更稳（避免与相邻文字粘连 ✗）
    var done = false;
    try {
      var q = window.quillInstance;
      if (!q && window.Quill && typeof window.Quill.find === 'function' && ed) q = window.Quill.find(ed);
      if (q && typeof q.insertText === 'function') {
        var idx = (typeof q.getSelection === 'function') ? ((q.getSelection(true) || {index: q.getLength()}).index) : q.getLength();
        q.insertText(idx, payload, 'user');
        if (typeof q.setSelection === 'function') q.setSelection(idx + payload.length, 0);
        done = true;
      }
    } catch(e){}
    if (!done && ed) {
      ed.focus();
      try { document.execCommand('insertText', false, payload); done = true; } catch(e){}
    }
    if (!done) alert('插入失败，请手动复制：' + text);
  }

  function fillPlaylists(sel, withEmpty){
    if (!sel) return;
    sel.innerHTML = withEmpty ? '<option value="0">不加入歌单</option>' : '';
    PLAYLISTS.forEach(function(p){
      var o = document.createElement('option');
      o.value = p.id; o.textContent = p.name + ' (' + p.count + ')';
      sel.appendChild(o);
    });
  }
  fillPlaylists(document.getElementById('lf-pl'), true);

  function show(tab){
    cur.tab = tab;
    document.querySelectorAll('.lf-tabs button').forEach(function(b){ b.classList.toggle('on', b.getAttribute('data-tab') === tab); });
    document.querySelectorAll('[data-panel]').forEach(function(p){ p.style.display = (p.getAttribute('data-panel') === tab) ? '' : 'none'; });
    if (tab === 'pick') loadItems();
    if (tab === 'pl') renderPlaylists();
  }
  document.querySelectorAll('.lf-tabs button').forEach(function(b){
    b.addEventListener('click', function(){ show(b.getAttribute('data-tab')); });
  });

  function open(){ cur.lastFocus = document.activeElement; modal.classList.add('on'); loadItems(); renderPlaylists(); }
  function close(){ modal.classList.remove('on'); if (cur.lastFocus && cur.lastFocus.focus) cur.lastFocus.focus(); }
  document.getElementById('lf-close').addEventListener('click', close);
  modal.addEventListener('click', function(e){ if (e.target === modal) close(); });
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape' && modal.classList.contains('on')) close(); });

  // 令牌与 action 必须**成对**（框架按 action 名校验 ✗）→ 调用处显式传对应令牌 ✓
  function req(body, token){
    body.append('_ajax_csrf_token', token || T_LIST);
    return fetch(AJAX, { method:'POST', body:body, credentials:'same-origin' }).then(function(r){ return r.json(); });
  }
  // 统一取错误文案：框架失败响应是 {success:false, data:{message:'…'}} ✓
  function errText(j){
    if (!j) return '无响应';
    if (j.data && typeof j.data === 'object') return j.data.message || JSON.stringify(j.data);
    return (j.data || j.message || '未知错误').toString();
  }

  // 上传
  document.getElementById('lf-do-upload').addEventListener('click', function(){
    var f = document.getElementById('lf-file');
    var msg = document.getElementById('lf-msg-up');
    if (!f.files || !f.files.length) { msg.className='lf-msg err'; msg.textContent='请选择文件'; return; }
    var i = 0, okCount = 0;
    msg.className = 'lf-msg'; msg.textContent = '上传中…';
    (function next(){
      if (i >= f.files.length) { msg.className='lf-msg ok'; msg.textContent='完成：成功 ' + okCount + ' / ' + f.files.length; return; }
      var fd = new FormData();
      fd.append('action', 'litafile_upload');
      fd.append('file', f.files[i]);
      fd.append('title', document.getElementById('lf-title').value);
      fd.append('artist', document.getElementById('lf-artist').value);
      fd.append('password', document.getElementById('lf-pw').value);
      fd.append('playlist_id', document.getElementById('lf-pl').value || '0');
      req(fd, T_UP).then(function(j){
        if (j && j.success) { insert(j.data.shortcode); okCount++; }
        else { msg.className='lf-msg err'; msg.textContent = '失败：' + errText(j); }
        i++; next();
      }).catch(function(){ msg.className='lf-msg err'; msg.textContent='网络错误'; });
    })();
  });

  // 媒体库
  function loadItems(){
    var box = document.getElementById('lf-list');
    box.innerHTML = '<div class="lf-item">加载中…</div>';
    var fd = new FormData();
    fd.append('action','litafile_items');
    fd.append('search', document.getElementById('lf-search').value);
    fd.append('kind', document.getElementById('lf-kind').value);
    req(fd, T_LIST).then(function(j){
      if (!j || !j.success) { box.innerHTML = '<div class="lf-item">加载失败：' + errText(j) + '</div>'; return; }
      if (!j.data.items.length) { box.innerHTML = '<div class="lf-item">没有匹配的条目</div>'; return; }
      box.innerHTML = '';
      j.data.items.forEach(function(it){
        var d = document.createElement('div'); d.className = 'lf-item';
        var icon = it.kind === 'image' ? '🖼️' : (it.kind === 'audio' ? '🎵' : (it.kind === 'video' ? '🎬' : '📄'));
        d.innerHTML = '<span>' + icon + '</span><span class="nm"></span>' + (it.has_password ? '<span style="color:#c0392b">🔒</span>' : '');
        d.querySelector('.nm').textContent = (it.title || it.filename);
        var b = document.createElement('button'); b.type='button'; b.className='button button-small'; b.textContent='插入';
        b.addEventListener('click', function(){ insert(it.shortcode); });
        d.appendChild(b);
        box.appendChild(d);
      });
    });
  }
  document.getElementById('lf-reload').addEventListener('click', loadItems);
  document.getElementById('lf-search').addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); loadItems(); } });

  // 歌单
  function renderPlaylists(){
    var box = document.getElementById('lf-pl-list');
    if (!PLAYLISTS.length) { box.innerHTML = '<div class="lf-item">还没有歌单（去「📁 媒体 → 歌单」创建）</div>'; return; }
    box.innerHTML = '';
    PLAYLISTS.forEach(function(p){
      var d = document.createElement('div'); d.className = 'lf-item';
      var s = document.createElement('span'); s.className = 'nm'; s.textContent = '🎧 ' + p.name + ' (' + p.count + ')';
      var b = document.createElement('button'); b.type='button'; b.className='button button-small'; b.textContent='插入歌单';
      b.addEventListener('click', function(){ insert('[litafile_playlist id=' + p.id + ']'); });
      d.appendChild(s); d.appendChild(b); box.appendChild(d);
    });
  }

  // 工具栏按钮（与旧 cloud-drive 插件**完全同款**的做法：先等编辑器实例就绪，再挂到「清除格式」右侧 ✓）
  var timer = setInterval(function(){
    if (!window.quillInstance) return;        // 编辑器还没就绪 → 下轮再看（别急着 clearInterval ✗）
    var tb = document.querySelector('.ql-toolbar');
    if (!tb) return;
    clearInterval(timer);
    if (tb.querySelector('#lf-btn')) return;  // 已存在（防重复插入 ✓）
    var b = document.createElement('button');
    b.type = 'button'; b.id = 'lf-btn'; b.className = 'lf-ebtn';   // 自定义类，别用 ql-clean ✗
    b.textContent = '📁 媒体';
    b.title = '插入媒体 / 文件 / 歌单';
    b.addEventListener('click', open);
    var clean = tb.querySelector('.ql-clean');
    if (clean) clean.parentNode.insertBefore(b, clean.nextSibling); else tb.appendChild(b);
  }, 300);
  window.LitaFileEditor = { open: open, insert: insert };
})();
</script>
HTML;
    echo "\n";
}
