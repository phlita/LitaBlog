<?php
/**
 * litafile/admin/ui.php — 后台统一外观（一套 CSS + 几个渲染小助手）
 *
 * 2026-09-16 用户要求：后端 UI 优化 / 重新排版 ✗
 *   改版要点：
 *     ① 不再到处写 inline style ✗ → 全部走类名 ✓
 *     ② 去掉与框架后台重复的页面标题 ✓（框架已显示菜单名，插件只留一条"工具条"）
 *     ③ 统计与筛选合并成一条工具条 ✓；宽屏（≥1100px）两栏：左操作 / 右列表 ✓
 *     ④ 每行操作降噪：预览·下载·复制短代码为主，编辑/密码折叠，删除做危险色 ✓
 *     ⑤ 颜色尽量复用框架后台的 CSS 变量（`--border-color` 等），取不到时用内置回退值 ✓
 *
 * 约定：所有类名以 `lf-` 开头 ✓；样式只在 litafile 页面输出一次（menu.php 里 echo 一次 ✓）。
 */

if (!defined('ABSPATH')) exit;

/** 后台样式表（返回一整段 <style>） */
function litafile_admin_css() {
    return <<<HTML
<style id="litafile-admin-css">
.lf{--bd:var(--border-color,#e3e5e8);--fg:#1f2328;--mut:#6b7280;--mut2:#8a8f98;--bg:#fff;--soft:#f6f7f9;--acc:#2f6feb;
    --acc-soft:#eef3fd;--ok:#18794e;--warn:#9a6700;--warn-soft:#fff8e6;--dgr:#b42318;--rad:12px;--rad-s:8px;
    color:var(--fg);font-size:13px;line-height:1.6}
.lf *{box-sizing:border-box}
.lf a{color:var(--acc);text-decoration:none}
.lf a:hover{text-decoration:underline}

/* 工具条：统计 pills + 筛选 */
.lf-bar{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;
    background:var(--bg);border:1px solid var(--bd);border-radius:var(--rad);padding:12px 14px;margin:14px 0}
.lf-stats{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.lf-pill{display:inline-flex;align-items:center;gap:6px;background:var(--soft);border:1px solid var(--bd);
    border-radius:999px;padding:4px 11px;font-size:12px;color:#4b5563;white-space:nowrap}
.lf-pill b{color:var(--fg);font-size:13px}
.lf-pill.is-acc{background:var(--acc-soft);border-color:#d6e2fb;color:#1b4bb8}
.lf-filter{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.lf-filter input[type=search]{min-width:200px}   /* 太窄会像"半截输入框" ✗ */

/* 输入控件统一 */
.lf input[type=text],.lf input[type=search],.lf input[type=url],.lf input[type=password],.lf select,.lf textarea{
    border:1px solid var(--bd);border-radius:var(--rad-s);padding:7px 10px;background:#fff;font-size:13px;font-family:inherit;
    max-width:100%}
.lf input[type=file]{font-size:13px}
.lf input:focus,.lf select:focus,.lf textarea:focus{outline:2px solid var(--acc-soft);border-color:var(--acc)}

/* 布局：宽屏两栏 */
.lf-grid{display:grid;grid-template-columns:1fr;gap:14px;align-items:start}
@media (min-width:1100px){.lf-grid{grid-template-columns:340px minmax(0,1fr)}}
.lf-col-side,.lf-col-main{display:flex;flex-direction:column;gap:14px;min-width:0}

/* 上排两张操作卡并列（≥780px），窄屏自动堆叠。
   ⚠️ 为什么媒体库不用 .lf-grid 两栏（2026-09-16 实测）：框架后台内容区只有 **880px** ✓，
      强行左 340 + 右 540 → 右侧表格被固定列宽吃掉，**文件名会断成三行** ✗
      ⇒ 媒体库改"上排两卡 + 下方全宽列表" ✓，表格终于有 880px 可用 ✓ */
.lf-cardsrow{display:grid;grid-template-columns:1fr;gap:14px;align-items:start;margin:14px 0}
@media (min-width:780px){.lf-cardsrow{grid-template-columns:1fr 1fr}}

/* 卡片 */
.lf-card{background:var(--bg);border:1px solid var(--bd);border-radius:var(--rad);padding:14px 16px}
.lf-card>h2{margin:0 0 10px;font-size:14px;font-weight:600;display:flex;align-items:center;gap:8px}
.lf-card>h2 .lf-hint{color:var(--mut2);font-weight:400;font-size:12px}
.lf-card .lf-body{padding:0}
.lf-fields{display:flex;flex-direction:column;gap:8px}
.lf-fields .lf-line{display:flex;gap:8px;flex-wrap:wrap}
.lf-fields .lf-line>*{flex:1 1 140px;min-width:0}
.lf-note{color:var(--mut2);font-size:12px;margin:8px 0 0}

/* 按钮（在框架 .button 基础上微调） */
.lf .button{white-space:nowrap}
.lf-btn{display:inline-flex;align-items:center;gap:6px}
.lf-danger{color:var(--dgr)!important;border-color:#f0d5d3!important}
.lf-danger:hover{background:#fdf3f2!important}

/* 列表表格 */
.lf-table{width:100%;border-collapse:separate;border-spacing:0;font-size:13px}
.lf-table th{text-align:left;color:var(--mut);font-weight:600;font-size:12px;padding:8px 10px;border-bottom:1px solid var(--bd);background:var(--soft)}
.lf-table td{padding:10px;border-bottom:1px solid #f0f1f3;vertical-align:top}
.lf-table tr:last-child td{border-bottom:0}
.lf-table tr:hover td{background:#fcfcfd}
.lf-ic{font-size:18px;text-align:center;width:44px}
.lf-title{font-weight:600;word-break:break-word}
.lf-title .lf-tag{font-weight:400;font-size:11px;border-radius:999px;padding:1px 7px;margin-left:6px;border:1px solid var(--bd);color:var(--mut)}
.lf-tag.warn{background:var(--warn-soft);border-color:#f2e4bf;color:var(--warn)}
.lf-tag.ok{background:#eafaf1;border-color:#c9eeda;color:var(--ok)}
.lf-tag.dgr{background:#fdf3f2;border-color:#f0d5d3;color:var(--dgr)}
.lf-sub{color:var(--mut2);font-size:12px;word-break:break-all}
.lf-code{display:inline-block;background:var(--soft);border:1px solid var(--bd);border-radius:6px;padding:2px 7px;font-size:12px}
.lf-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.lf-details{margin-top:8px}
.lf-details>summary{cursor:pointer;color:var(--acc);font-size:12px;list-style:none}
.lf-details>summary::-webkit-details-marker{display:none}
.lf-details>summary::before{content:"▸ ";}
.lf-details[open]>summary::before{content:"▾ ";}
.lf-details .lf-fields{margin-top:8px;padding:10px;background:var(--soft);border:1px solid var(--bd);border-radius:var(--rad-s)}

/* 歌单：条目行 / 列表 */
.lf-pl-list{display:flex;flex-direction:column;gap:8px}
.lf-pl-item{display:flex;align-items:center;gap:10px;border:1px solid var(--bd);border-radius:var(--rad-s);padding:9px 11px;background:#fff}
.lf-pl-item.is-cur{border-color:var(--acc);background:var(--acc-soft)}
.lf-pl-item .nm{flex:1 1 auto;min-width:0;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lf-pl-item .cnt{color:var(--mut2);font-size:12px}

/* 页头（去掉与框架重复的大标题，只留一条轻量工具行 ✓） */
.lf-head{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin:10px 0 0}
.lf-head .lf-title-row{display:flex;gap:9px;align-items:center;flex-wrap:wrap}
.lf-head .lf-ver{font-size:12px;color:var(--mut2)}
.lf-head .lf-doc{font-size:12px}

/* 标签页导航 */
.lf-tabs{display:flex;gap:6px;margin:12px 0 0;border-bottom:1px solid var(--bd);flex-wrap:wrap}
.lf-tabs a{padding:8px 14px;font-weight:600;border:1px solid transparent;border-bottom:none;
    border-radius:var(--rad-s) var(--rad-s) 0 0;color:var(--mut);text-decoration:none}
.lf-tabs a:hover{background:var(--soft);text-decoration:none}
.lf-tabs a.on{background:#fff;border-color:var(--bd);color:var(--fg);margin-bottom:-1px;border-bottom:1px solid #fff}

/* 提示条 */
.lf-warn{background:var(--warn-soft);border:1px solid #f2e4bf;border-left:4px solid var(--warn);border-radius:var(--rad-s);
    padding:9px 12px;margin:12px 0;font-size:13px}
.lf-ok{background:#eafaf1;border:1px solid #c9eeda;border-left:4px solid var(--ok);border-radius:var(--rad-s);
    padding:9px 12px;margin:12px 0;font-size:13px}
.lf-err{background:#fdf3f2;border:1px solid #f0d5d3;border-left:4px solid var(--dgr);border-radius:var(--rad-s);
    padding:9px 12px;margin:12px 0;font-size:13px}

/* 分页 */
.lf-pager{display:flex;gap:6px;flex-wrap:wrap;margin-top:12px;align-items:center}

/* 吸底保存条 */
.lf-savebar{position:sticky;bottom:0;background:linear-gradient(180deg,rgba(255,255,255,.6),#fff 45%);
    border-top:1px solid var(--bd);padding:12px 0;margin-top:12px;display:flex;gap:10px;align-items:center}

/* 空态 */
.lf-empty{color:var(--mut2);text-align:center;padding:22px 10px;font-size:13px}

/* API 文档折叠区 */
.lf-pre{background:var(--soft);border:1px solid var(--bd);border-radius:var(--rad-s);padding:12px 14px;
    font-size:12px;line-height:1.65;max-height:520px;overflow:auto;white-space:pre-wrap;margin:10px 0 0}
</style>
HTML;
}

/** 小助手：一行「标签 + 值」的 pill */
function litafile_ui_pill($icon, $label, $value, $accent = false) {
    return '<span class="lf-pill' . ($accent ? ' is-acc' : '') . '">' . $icon . ' ' . e($label)
         . ' <b>' . e((string)$value) . '</b></span>';
}

/** 小助手：页面级提示条（复用于 admin 内部的成功/失败/警告） */
function litafile_ui_notice($msg) {
    $cls = 'lf-ok';
    if (strpos($msg, '⚠️') === 0) $cls = 'lf-err';
    elseif (mb_strpos($msg, '⚠') !== false) $cls = 'lf-warn';
    return '<div class="' . $cls . '">' . e($msg) . '</div>';
}
