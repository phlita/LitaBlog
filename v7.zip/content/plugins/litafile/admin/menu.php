<?php
/**
 * litafile/admin/menu.php — 后台菜单与页面路由
 *
 * 采用「单菜单 + 内部 tab」结构（不依赖 add_submenu_page），三个 tab：
 *   library  媒体库（上传/编辑/密码/删除/复制短代码）
 *   playlists 歌单管理
 *   settings 设置 + 目录保护重写
 *
 * 所有写操作：verifyCsrfToken($_POST['csrf_token'], 'litafile_xxx') + current_user_can('manage_options')
 * 注意：框架的 verifyCsrfToken 默认**一次性**（验证后即销毁）→ 每个动作一个独立 action 名 ✓
 */

if (!defined('ABSPATH')) exit;

/** 菜单 */
function litafile_admin_menu() {
    add_menu_page('媒体与文件', '📁 媒体', 'manage_options', 'litafile', 'litafile_admin_page', '', 76);
}
add_action('admin_menu', 'litafile_admin_menu');

/** 页面 URL（tab 切换用） */
function litafile_admin_url($tab = 'library', $extra = []) {
    $q = array_merge(['page' => 'litafile', 'tab' => $tab], $extra);
    return rtrim(SITE_URL, '/') . '/admin/admin.php?' . http_build_query($q);
}

/** 页面入口：处理 POST → 渲染当前 tab */
function litafile_admin_page() {
    if (!function_exists('current_user_can') || !current_user_can('manage_options')) {
        echo '<div class="wrap"><p>权限不足。</p></div>';
        return;
    }
    $tab = (string)($_GET['tab'] ?? 'library');
    $msg = '';

    // ── 统一 POST 分发（每个动作一个 CSRF action 名）────────────────────────
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $token = (string)($_POST['csrf_token'] ?? '');
        $act   = (string)($_POST['litafile_action'] ?? '');

        $need = [
            'upload'      => 'litafile_upload',
            'add_url'     => 'litafile_add_url',
            'save_item'   => 'litafile_save_item',
            'set_pw'      => 'litafile_set_pw',
            'delete_item' => 'litafile_delete_item',
            'save_settings' => 'litafile_settings',
            'rewrite_protection' => 'litafile_rewrite',
            'pl_new'      => 'litafile_pl_new',
            'pl_add'      => 'litafile_pl_add',
            'pl_remove'   => 'litafile_pl_remove',
            'pl_reorder'  => 'litafile_pl_reorder',
            'pl_default'  => 'litafile_pl_default',
            'pl_delete'   => 'litafile_pl_delete',
        ];
        if (isset($need[$act]) && verifyCsrfToken($token, $need[$act])) {
            $r = litafile_admin_handle($act);
            $msg = is_string($r) ? $r : '';
        } else {
            $msg = '⚠️ 安全令牌校验失败（表单可能已过期），请重新提交。';
        }
    }

    $status = litafile_legacy_status();
    // 2026-09-16 UI 改版：整页包在 .lf 里（一套类名，不再到处 inline style ✓）
    echo '<div class="wrap litafile-admin lf">';
    echo litafile_admin_css();   // 样式只输出一次 ✓

    // 页头：**不再重复框架的页面大标题** ✗，只留一条轻量工具行（版本 + 文档入口）✓
    echo '<div class="lf-head"><div class="lf-title-row">'
       . '<span class="lf-ver">litafile v' . e(LITAFILE_VERSION) . ' · 媒体与文件</span>'
       . '</div><div class="lf-doc"><a href="' . e(litafile_admin_url('settings')) . '">Agent API 调用说明 →</a></div></div>';

    if ($msg !== '') {
        echo litafile_ui_notice($msg);
    }

    // 兼容提示：老插件仍激活 → 提示（不自动停用；现在不再"让位"了，会重复注册 ✗）
    foreach (['cloud-drive' => 'Cloud Drive（网盘）', 'lita-music' => 'Lita Music（音乐）'] as $slug => $label) {
        if (!empty($status[$slug])) {
            echo '<div class="lf-warn">⚠️ 检测到老插件 <b>' . e($label) . '</b> 仍处于激活状态：'
               . '它会与本插件重复注册短代码/菜单，建议到「插件」页停用它 ✓（数据不会被删除 ✓）。</div>';
        }
    }

    litafile_admin_tabs($tab);
    switch ($tab) {
        case 'playlists': litafile_admin_page_playlists($status); break;
        case 'settings':  litafile_admin_page_settings($status);  break;
        default:          litafile_admin_page_library();          break;
    }
    echo '</div>';
}

/** tab 导航（类名化，样式在 ui.php ✓） */
function litafile_admin_tabs($cur) {
    $tabs = [
        'library'   => '📚 媒体库',
        'playlists' => '🎧 歌单',
        'settings'  => '⚙️ 设置',
    ];
    echo '<nav class="lf-tabs">';
    foreach ($tabs as $k => $label) {
        echo '<a href="' . e(litafile_admin_url($k)) . '" class="' . ($cur === $k ? 'on' : '') . '">' . $label . '</a>';
    }
    echo '</nav>';
}

/** 处理具体动作 → 返回提示文本 */
function litafile_admin_handle($act) {
    $uid = (int)($_SESSION['user_id'] ?? 0);

    if ($act === 'upload') {
        $ok = 0; $errs = [];
        $pw = (string)($_POST['litafile_pw'] ?? '');
        $title = (string)($_POST['litafile_title'] ?? '');
        $artist = (string)($_POST['litafile_artist'] ?? '');
        $pl = (int)($_POST['litafile_playlist'] ?? 0);
        $files = $_FILES['litafile_files'] ?? null;
        if (!$files || empty($files['name'][0])) return '⚠️ 没有选择文件。';
        $n = count($files['name']);
        for ($i = 0; $i < $n; $i++) {
            $one = [
                'name' => $files['name'][$i], 'type' => $files['type'][$i], 'tmp_name' => $files['tmp_name'][$i],
                'error' => $files['error'][$i], 'size' => $files['size'][$i],
            ];
            $r = litafile_handle_upload($one, [
                'password' => $pw, 'title' => ($n === 1 ? $title : ''), 'artist' => ($n === 1 ? $artist : ''),
                'uploader_id' => $uid, 'playlist_id' => $pl,
            ]);
            if ($r['ok']) $ok++; else $errs[] = $files['name'][$i] . '：' . $r['error'];
        }
        $m = "已上传 {$ok} 个文件" . ($errs ? '；失败 ' . count($errs) . ' 个（' . implode('；', array_slice($errs, 0, 3)) . '）' : '。');
        return $errs ? '⚠️ ' . $m : $m;
    }

    if ($act === 'add_url') {
        $r = litafile_handle_external((string)($_POST['litafile_url'] ?? ''), [
            'title' => (string)($_POST['litafile_title'] ?? ''),
            'artist' => (string)($_POST['litafile_artist'] ?? ''),
            'uploader_id' => $uid,
            'playlist_id' => (int)($_POST['litafile_playlist'] ?? 0),
        ]);
        return $r['ok'] ? '已添加外链条目 #' . $r['id'] . '。' : '⚠️ ' . $r['error'];
    }

    if ($act === 'save_item') {
        $id = (int)($_POST['id'] ?? 0);
        if (!litafile_get_item($id)) return '⚠️ 条目不存在。';
        litafile_update_item($id, [
            'title'       => sanitize_text_field((string)($_POST['title'] ?? '')),
            'artist'      => sanitize_text_field((string)($_POST['artist'] ?? '')),
            'description' => sanitize_text_field((string)($_POST['description'] ?? '')),
        ]);
        return '已保存 #' . $id . ' 的信息。';
    }

    if ($act === 'set_pw') {
        $id = (int)($_POST['id'] ?? 0);
        $pw = (string)($_POST['new_password'] ?? '');
        if (!litafile_get_item($id)) return '⚠️ 条目不存在。';
        litafile_set_password($id, $pw);
        return $pw === '' ? '已清除 #' . $id . ' 的密码（公开）。' : '已为 #' . $id . ' 设置密码。';
    }

    if ($act === 'delete_item') {
        $id = (int)($_POST['id'] ?? 0);
        $item = litafile_get_item($id);
        if (!$item) return '⚠️ 条目不存在。';
        litafile_delete_item($id, true);
        $note = (($item['storage'] ?? 'litafile') === 'litafile') ? '' : '（旧目录文件已保留，未删除物理文件）';
        return '已删除 #' . $id . '。' . $note;
    }

    if ($act === 'save_settings') {
        $mode = (($_POST['mode'] ?? '0') === '1') ? '1' : '0';
        litafile_update_settings([
            'mode'                => $mode,
            'player_enabled'      => empty($_POST['player_enabled']) ? 0 : 1,
            'player_autoplay'     => empty($_POST['player_autoplay']) ? 0 : 1,
            'player_mode'         => in_array($_POST['player_mode'] ?? 'list', ['list', 'shuffle', 'repeat-one'], true) ? $_POST['player_mode'] : 'list',
            // ⚠️ 背景音乐**必须"自动播放"也勾选才有效** ✓（用户明确要求 ✓）→
            //    这里强制归零，避免出现"勾了 BGM 但前置没勾"的不一致状态 ✓
            //    （前端在未勾自动播放时把该 checkbox 置灰不提交 ✓，这里再兜一次 ✓）
            'bgm_autoplay'        => (empty($_POST['player_autoplay']) || empty($_POST['bgm_autoplay'])) ? 0 : 1,
            'bgm_volume'          => max(0, min(100, (int)($_POST['bgm_volume'] ?? 35))),
            // PJAX 导航开关（默认关 ✓；开了换页不重载文档 → 音乐零中断 ✓）
            'pjax'                => empty($_POST['pjax']) ? 0 : 1,
            'api_allow_query_key' => empty($_POST['api_allow_query_key']) ? 0 : 1,
            // ⚠️ 2026-09-16（P2）：这个值会拼进响应头 → 保存时净化（只接受 `*` 或一个 http(s) 来源 ✓）
            'api_cors_origin'     => litafile_sanitize_cors_origin((string)($_POST['api_cors_origin'] ?? '*')),
        ]);
        // ⚠️ 这里原来写的是 `litafile_rewrite_protection()` —— **全项目没有这个函数** ✗
        //    → Call to undefined function → 致命错误 → 后台"点保存设置就白屏" ✓（2026-09-16 用户报障）
        //    真名：storage.php 的 litafile_write_dir_protection($dir, $deny_all) ✓（$dir=null 用默认存储目录）
        litafile_write_dir_protection(null, $mode === '1');
        return '设置已保存（已同步重写上传目录的保护文件）。';
    }

    if ($act === 'rewrite_protection') {
        $deny = (litafile_get_settings()['mode'] ?? '0') === '1';
        litafile_write_dir_protection(null, $deny);   // 同上：真名是这个，原写法是未定义函数 ✗
        return '已重写 content/uploads/litafile/ 的 .htaccess 与 web.config。';
    }

    if ($act === 'pl_new') {
        $id = litafile_playlist_create((string)($_POST['name'] ?? '新歌单'), !empty($_POST['is_default']));
        return $id > 0 ? "已创建歌单 #{$id}。" : '⚠️ 创建失败。';
    }
    if ($act === 'pl_default') {
        litafile_playlist_update((int)($_POST['playlist_id'] ?? 0), null, true);
        return '已设为默认歌单（全局播放器使用它）。';
    }
    if ($act === 'pl_delete') {
        litafile_playlist_delete((int)($_POST['playlist_id'] ?? 0));
        return '已删除歌单（媒体条目保留在媒体库中）。';
    }
    if ($act === 'pl_add') {
        $pid = (int)($_POST['playlist_id'] ?? 0);
        $iid = (int)($_POST['item_id'] ?? 0);
        return litafile_playlist_add($pid, $iid) ? '已加入歌单。' : '⚠️ 加入失败（可能已在歌单内）。';
    }
    if ($act === 'pl_remove') {
        litafile_playlist_remove((int)($_POST['playlist_id'] ?? 0), (int)($_POST['item_id'] ?? 0));
        return '已从歌单移出。';
    }
    if ($act === 'pl_reorder') {
        $pid = (int)($_POST['playlist_id'] ?? 0);
        $order = array_map('intval', explode(',', (string)($_POST['order'] ?? '')));
        litafile_playlist_reorder($pid, $order);
        return '顺序已保存。';
    }
    return '⚠️ 未知操作。';
}
