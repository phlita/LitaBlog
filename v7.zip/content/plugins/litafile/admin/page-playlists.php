<?php
/**
 * litafile/admin/page-playlists.php — 歌单管理
 *
 * 2026-09-16 UI 改版：宽屏两栏 —— 左「歌单列表 + 新建」，右「当前歌单（加歌 / 排序 / 移出）」✓
 * 功能不变：多歌单、可排序（服务端算顺序的上移/下移按钮，不用拖拽 JS ✓）、只收音频 ✓
 * **表单字段 / action / CSRF 令牌全部原样保留** ✓
 */

if (!defined('ABSPATH')) exit;

function litafile_admin_page_playlists($status) {
    $pls = litafile_get_playlists();
    $cur = (int)($_GET['pl'] ?? 0);
    if ($cur <= 0 && $pls) $cur = (int)$pls[0]['id'];
    $act = e(litafile_admin_url('playlists'));

    echo '<div class="lf-grid">';

    // ── 左：歌单列表 + 新建 ──────────────────────────────────────────────────
    echo '<aside class="lf-col-side">';

    echo '<div class="lf-card"><h2>🎧 歌单 <span class="lf-hint">共 ' . count($pls) . ' 个 · 点选切换</span></h2>';
    if (!$pls) {
        echo '<div class="lf-empty">还没有歌单，先在下面新建一个 ✓</div>';
    } else {
        echo '<div class="lf-pl-list">';
        foreach ($pls as $p) {
            $on  = ((int)$p['id'] === $cur);
            $cnt = count(litafile_playlist_items($p['id']));
            echo '<a class="lf-pl-item' . ($on ? ' is-cur' : '') . '" href="'
               . e(litafile_admin_url('playlists', ['pl' => (int)$p['id']])) . '">'
               . '<span class="nm">' . e($p['name']) . ((int)$p['is_default'] ? ' ⭐' : '') . '</span>'
               . '<span class="cnt">' . $cnt . ' 首</span></a>';
        }
        echo '</div>';
    }
    echo '</div>';

    echo '<div class="lf-card"><h2>➕ 新建歌单</h2>';
    echo '<form method="post" action="' . $act . '" class="lf-fields">';
    csrf_token_field('litafile_pl_new');
    echo '<input type="hidden" name="litafile_action" value="pl_new">'
       . '<input type="text" name="name" placeholder="歌单名称" required>'
       . '<label class="lf-note" style="margin:0"><input type="checkbox" name="is_default" value="1"> 设为默认（全局播放器读取它）</label>'
       . '<div><button type="submit" class="button button-primary">创建歌单</button></div>';
    echo '</form></div>';

    echo '</aside>';

    // ── 右：当前歌单 ─────────────────────────────────────────────────────────
    echo '<section class="lf-col-main">';

    $pl = $cur > 0 ? litafile_get_playlist($cur) : null;
    if (!$pl) {
        echo '<div class="lf-card"><div class="lf-empty">左侧还没有歌单；先在左栏新建一个，再从媒体库把音频加进来 ✓</div></div>';
        echo '</section></div>';
        return;
    }

    $items = litafile_playlist_items($cur);
    $ids   = array_map(function ($i) { return (int)$i['id']; }, $items);

    echo '<div class="lf-card"><h2>🎧 ' . e($pl['name'])
       . ((int)$pl['is_default'] ? '<span class="lf-tag warn">默认</span>' : '')
       . '<span class="lf-hint">' . count($items) . ' 首 · 全局播放器只读默认歌单里的音频</span></h2>';
    echo '<div class="lf-actions">';
    if (!(int)$pl['is_default']) {
        echo '<form method="post" action="' . e(litafile_admin_url('playlists', ['pl' => $cur])) . '" style="display:inline">';
        csrf_token_field('litafile_pl_default');
        echo '<input type="hidden" name="litafile_action" value="pl_default"><input type="hidden" name="playlist_id" value="' . $cur . '">'
           . '<button type="submit" class="button button-small">设为默认</button></form>';
    }
    echo '<form method="post" action="' . $act . '" style="display:inline" onsubmit="return confirm(\'删除该歌单？媒体条目会保留在媒体库。\')">';
    csrf_token_field('litafile_pl_delete');
    echo '<input type="hidden" name="litafile_action" value="pl_delete"><input type="hidden" name="playlist_id" value="' . $cur . '">'
       . '<button type="submit" class="button button-small lf-danger">删除歌单</button></form>';
    echo '</div></div>';

    // 加入条目（只收音频 ✓）
    $recent = litafile_list_items(['per_page' => 200, 'page' => 1, 'kind' => 'audio']);
    echo '<div class="lf-card"><h2>➕ 加入歌曲 <span class="lf-hint">歌单只收音频</span></h2>';
    echo '<form method="post" action="' . e(litafile_admin_url('playlists', ['pl' => $cur])) . '" class="lf-fields">';
    csrf_token_field('litafile_pl_add');
    echo '<input type="hidden" name="litafile_action" value="pl_add"><input type="hidden" name="playlist_id" value="' . $cur . '">';
    echo '<div class="lf-line"><select name="item_id" style="flex:1 1 320px">';
    foreach ($recent['items'] as $it) {
        $lbl = ($it['title'] !== '' ? $it['title'] : $it['filename']);
        echo '<option value="' . (int)$it['id'] . '">' . litafile_kind_icon($it['kind']) . ' ' . e($lbl) . '</option>';
    }
    echo '</select><button type="submit" class="button button-primary" style="flex:0 0 auto">加入歌单</button></div>';
    if (!$recent['items']) {
        echo '<p class="lf-note">媒体库里还没有音频文件。先去「📚 媒体库」上传音乐，再回来加入 ✓</p>';
    }
    echo '</form></div>';

    // 当前歌单内容
    echo '<div class="lf-card"><h2>🎵 歌单内容 <span class="lf-hint">用 ↑ ↓ 调整播放顺序</span></h2>';
    if (!$items) {
        echo '<div class="lf-empty">这个歌单还是空的 ✓</div></div>';
        echo '</section></div>';
        return;
    }

    echo '<table class="lf-table"><thead><tr>'
       . '<th style="width:42px">#</th><th class="lf-ic">类型</th><th>歌曲</th><th style="width:150px">操作</th>'
       . '</tr></thead><tbody>';

    foreach ($items as $idx => $it) {
        $iid = (int)$it['id'];
        $up  = $ids;
        if ($idx > 0) { $t = $up[$idx - 1]; $up[$idx - 1] = $up[$idx]; $up[$idx] = $t; }
        $dn  = $ids;
        if ($idx < count($ids) - 1) { $t = $dn[$idx + 1]; $dn[$idx + 1] = $dn[$idx]; $dn[$idx] = $t; }

        echo '<tr><td class="lf-sub">' . ($idx + 1) . '</td>'
           . '<td class="lf-ic">' . litafile_kind_icon($it['kind']) . '</td>'
           . '<td><div class="lf-title">' . e($it['title'] !== '' ? $it['title'] : $it['filename']) . '</div>'
           . '<div class="lf-sub">' . e($it['filename'])
           . ($it['artist'] !== '' ? ' ｜ ' . e($it['artist']) : '')
           . (($it['source'] ?? 'local') === 'remote' ? ' ｜ 外链' : '') . '</div></td>'
           . '<td><div class="lf-actions">';

        foreach ([['↑', $up, $idx === 0], ['↓', $dn, $idx === count($ids) - 1]] as $b) {
            echo '<form method="post" action="' . e(litafile_admin_url('playlists', ['pl' => $cur])) . '" style="display:inline">';
            csrf_token_field('litafile_pl_reorder');
            echo '<input type="hidden" name="litafile_action" value="pl_reorder"><input type="hidden" name="playlist_id" value="' . $cur . '">'
               . '<input type="hidden" name="order" value="' . e(implode(',', $b[1])) . '">'
               . '<button type="submit" class="button button-small"' . ($b[2] ? ' disabled' : '') . '>' . $b[0] . '</button></form>';
        }
        echo '<form method="post" action="' . e(litafile_admin_url('playlists', ['pl' => $cur])) . '" style="display:inline">';
        csrf_token_field('litafile_pl_remove');
        echo '<input type="hidden" name="litafile_action" value="pl_remove"><input type="hidden" name="playlist_id" value="' . $cur . '">'
           . '<input type="hidden" name="item_id" value="' . $iid . '">'
           . '<button type="submit" class="button button-small lf-danger">移出</button></form>';
        echo '</div></td></tr>';
    }
    echo '</tbody></table></div>';

    echo '</section></div>';
}
