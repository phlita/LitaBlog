# LitaFile（📁 媒体与文件）

> cloud-drive（网盘）+ lita-music（音乐播放器）的合并版 —— 一个插件管住"文件 + 媒体"。

## 它做什么

| 能力 | 说明 |
|---|---|
| 📚 媒体库 | 后台上传（可多选）、编辑标题/艺术家/描述、搜索、按类型筛选、分页 |
| 🔐 文件密码 | 给任意条目设下载密码（会话免密 1 小时；5 次错误锁 10 分钟） |
| 💾 双模式 | **直链省资源**（无密码文件由 Web 服务器直出，0 PHP 进程）／**完整保护**（全部经令牌校验 + PHP 流式输出，支持 Range 拖动） |
| 📄 短代码 | `[litafile id=N]`（自动内嵌图片/音视频，其它出下载卡片）、`[litafile_playlist id=N]` |
| 🎧 全局播放器 | 悬浮播放器读取「默认歌单」的音频，顺序/随机/单曲循环；播放位置存本机 localStorage |
| 🔀 媒体互斥 | **全页所有 audio/video 自动互斥**（含文章内嵌与播放器）——旧版两个插件各管一半 ✗ |
| 🔗 外链条目 | 可以只登记外部 URL（不占本站空间），带内网地址拦截（SSRF 防护） |
| 🤖 Agent API | `?agent_api=files`（**与旧版结构一致**）＋ `?agent_api=litafile`（新，含歌单） |

## 怎么用

1. 后台 **📁 媒体** → 「上传文件」（或「添加外部链接」）；音频类可顺手加入歌单。
2. 在文章里插入短代码：媒体库里每个条目都有「复制短代码」按钮；编辑器工具栏也有 **📁 媒体** 按钮（上传 / 从媒体库选 / 插入歌单，一个弹层搞定）。
3. 歌单：**📁 媒体 → 🎧 歌单** 里新建、加歌、上下移排序、设为默认（播放器读默认歌单）。
4. 设置：**📁 媒体 → ⚙️ 设置** 里切换模式、播放器开关、Agent API 选项、目录保护重写、旧数据导入。

## 从旧插件迁移（推荐流程）

1. 装好 litafile → **设置页点「开始导入（幂等）」**（重复点也不会重复导入）。
2. 老文章无需改动：`[download id=N]`、`[lita_music ...]`、旧下载链接 `?cloud_download=&token=`、旧计数 `?cd_count=` **都还能用**。
3. 到「插件」页停用 `cloud-drive` 与 `lita-music`（**数据不会被删**）。
   > 两者仍激活时 litafile 会自动"让位"（不抢短代码/菜单），但为了菜单干净建议停用。
4. 确认一切正常后，旧目录 `content/uploads/cloud/`、`content/uploads/music/` 里的文件**可以保留不动**（DB 里以 `storage` 字段区分，原地引用）。

## 文件与目录

```
content/plugins/litafile/          插件代码（本目录）
content/uploads/litafile/          新上传文件的存放处（自动创建，含 .htaccess + web.config 保护）
content/uploads/cloud/  music/     旧文件所在处（只读引用，不搬动、不删除）
```

## Agent API 速查

```bash
# 上传（Admin Key）
curl -H "Authorization: Bearer <ADMIN_KEY>" -F "file=@a.mp3" \
  "http://站点/?agent_api=files&action=upload"

# 列表 / 下载 / 删除
curl -H "Authorization: Bearer <KEY>" "http://站点/?agent_api=files&action=list&page=1&per_page=20"
curl -H "Authorization: Bearer <KEY>" "http://站点/?agent_api=files&action=download&id=12&mode=url"
curl -X DELETE -H "Authorization: Bearer <ADMIN_KEY>" "http://站点/?agent_api=files&id=12"

# 新形态（含歌单）
curl -H "Authorization: Bearer <ADMIN_KEY>" "http://站点/?agent_api=litafile&resource=playlists&action=list"
```
> 密钥在 **设置 → Agent API** 相关选项里（沿用旧的 `lita_agent_api_key_admin` / `lita_agent_api_key_comment`）。
> 主机若丢弃 `Authorization` 头，可在设置里开启 `?apikey=` 兜底（默认关闭：密钥会进访问日志）。

## 安全设计要点

- 上传：**白名单扩展名** + 危险扩展名兜底 + 落盘名不沿用原名（`Ymd_His_随机hex.ext`，按年月分目录）。
- 下载：HMAC 令牌 + `hash_equals` 常量时间校验；`Content-Disposition` 剥离引号/CRLF（防头注入）。
- 目录保护：`.htaccess`（Apache）与 `web.config`（IIS）**同时写**，并关闭目录列举。
  > 旧版只写 `.htaccess`，生产是 IIS 时等于没有保护 ✗ —— 这是本次合并顺手修掉的缺口之一。
- 外链条目：仅 http(s)，拒绝内网/回环地址。
- 后台动作：`verifyCsrfToken` + `current_user_can('manage_options')`；AJAX 用会话绑定令牌（非一次性，支持弹层连续上传）。

## 卸载行为

卸载会删掉 `litafile_*` 三张表与设置项，**绝不删除 `content/uploads/**` 里的文件**，也**不动**旧插件的表与设置。
