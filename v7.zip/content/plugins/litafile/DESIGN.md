# litafile — 设计文档（cloud-drive + lita-music 合并版）

> 版本：v0.1（设计稿，2026-09-16）
> 目标读者：后续实现者（我）/ 站长
> 一句话：**一个插件管住"文件 + 媒体"** —— 上传/管理/下载/密码保护（云盘能力）+ 全局播放器/歌单/文章内嵌（音乐能力）。

---

## 0. 命名与约定（必须先定，后面全依赖它）

| 项 | 取值 |
|---|---|
| 插件 slug / 目录 | `litafile` → `content/plugins/litafile/` |
| 主文件 | **必须是 `litafile/litafile.php`**（核心 `load.php` 按 `<slug>/<slug>.php` require，名字错了插件根本加载不了 ✗） |
| 函数前缀 | `litafile_*`（对外 API：`litafile_get_item()` 等） |
| 常量前缀 | `LITAFILE_*` |
| DB 表前缀 | `litafile_`（沿用现有扁平表名风格，不搞 `wp_`） |
| option 键 | `litafile_settings`、`litafile_playlists`（旧键兼容读取，见 §8） |
| 短代码 | **保留** `[download]`、`[lita_music]`（存量文章不能破）；**新增**统一标签 `[litafile]` / `[litafile_playlist]` |
| Agent API | **保留** `?agent_api=files`（老 key/老调用方不破）；**新增** `?agent_api=litafile` |
| 旧路由 | **保留** `?cloud_download=`、`?cd_count=`（存量链接不破） |
| 存储目录 | `content/uploads/litafile/`（新文件都进这里；**旧文件不动**，见 §3） |

---

## 1. 需求：合并矩阵

| 能力 | 来源 | 合并后 |
|---|---|---|
| 上传/删除/编辑元数据（文件名、描述、密码） | cloud-drive | ✅ 统一"媒体库"页（支持批量上传、搜索、分页、筛选 kind） |
| 文件密码保护 + 会话免密 + 爆破锁定 | cloud-drive | ✅ 统一（所有类型都能设密码） |
| 下载 token（HMAC）+ 双段 Content-Disposition | cloud-drive | ✅ 统一 |
| 直链省资源 / 完整保护 双模式 | cloud-drive | ✅ 统一（按"文件"粒度也能覆盖，见 §7） |
| Range 流式输出（视频拖动） | cloud-drive | ✅ 统一（保护模式下走 PHP；直链模式交给 Web 服务器） |
| 下载计数 | cloud-drive | ✅ 统一（内嵌不计、下载计） |
| 文章内嵌媒体（img/audio/video） | cloud-drive | ✅ 统一渲染器（`litafile_render_media()`） |
| 下载卡片（`[download id=N]`） | cloud-drive | ✅ 统一渲染器（`litafile_render_card()`） |
| Agent API（AI 上传/下载/列表/删除） | cloud-drive | ✅ 统一 + 扩展歌单管理 |
| 全局悬浮播放器 + 播放状态存 localStorage | lita-music | ✅ 统一（**只放 audio 项**，视频不入全局） |
| 歌单（顺序/随机/单曲循环） | lita-music | ✅ 统一（从 option 升级为表，见 §2） |
| `[lita_music]` 卡片/列表短代码 | lita-music | ✅ 统一（作为 `[litafile_playlist]` 的别名行为） |
| 编辑器按钮（Quill 工具栏） | 两者各一个 ✗ | ✅ **合并为一个**「📁 媒体」按钮（两张弹层合成一个：上传新文件 / 选已有 / 选歌单）→ 修掉"两个按钮抢同一位置"的问题 |
| 媒体互斥暂停 | 只有 lita-music 有 ✗ | ✅ **提升为核心能力**：统一管全页所有 `<audio>/<video>`（含 cloud 内嵌的 ✗ 现在不管） |

**合并后不做的（明确不做，避免范围膨胀）**：不做多用户网盘配额、不做点播流媒体转码、不做付费下载（要付费交给 litapay/member 插件）。

---

## 2. 数据模型（SQLite，`get_db()`）

### 2.1 `litafile_items`（核心表，替代 `cloud_files`）

```sql
CREATE TABLE IF NOT EXISTS litafile_items (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT NOT NULL DEFAULT 'file',   -- image|audio|video|file（由扩展名+MIME 判定）
    filename     TEXT NOT NULL,                  -- 原始文件名（展示用，已净化）
    stored_name  TEXT NOT NULL,                  -- 落盘文件名
    filepath     TEXT NOT NULL,                  -- 相对 storage 的路径，如 2026/09/xxx.mp3
    storage      TEXT NOT NULL DEFAULT 'litafile', -- litafile | cloud | music（旧文件原地引用）
    source       TEXT NOT NULL DEFAULT 'local',  -- local | remote（lita-music 支持外链 URL）
    external_url TEXT DEFAULT '',                -- source=remote 时的 URL
    filesize     INTEGER DEFAULT 0,
    mime_type    TEXT DEFAULT 'application/octet-stream',
    title        TEXT DEFAULT '',                -- 音乐/视频标题（原 lita_music title）
    artist       TEXT DEFAULT '',                -- 艺术家（原 lita_music artist）
    description  TEXT DEFAULT '',
    password     TEXT DEFAULT '',                -- password_hash()；空=无密码
    download_count INTEGER DEFAULT 0,
    play_count     INTEGER DEFAULT 0,            -- 新增：播放计数（内嵌/播放器都算）
    uploader_id  INTEGER DEFAULT 0,
    legacy_id    INTEGER DEFAULT 0,              -- 迁移来源的旧 id（幂等导入用）
    legacy_src   TEXT DEFAULT '',                -- '' | cloud | music
    created      DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified     DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_litafile_kind    ON litafile_items(kind);
CREATE INDEX IF NOT EXISTS idx_litafile_created ON litafile_items(created);
CREATE INDEX IF NOT EXISTS idx_litafile_legacy  ON litafile_items(legacy_src, legacy_id);
```

### 2.2 歌单（升级：从 option JSON 变成表，但**保留旧 option 兼容读取**）

```sql
CREATE TABLE IF NOT EXISTS litafile_playlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT '默认歌单',
    is_default INTEGER DEFAULT 0,
    created DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS litafile_playlist_items (
    playlist_id INTEGER NOT NULL,
    item_id     INTEGER NOT NULL,
    sort_order  INTEGER DEFAULT 0,
    PRIMARY KEY (playlist_id, item_id)
);
```

> 迁移时把 `lita_music_playlist`（JSON 数组）导入成"默认歌单"；导入完成后写入 `litafile_imported_playlist=1`，**不删旧 option**（回滚安全）。

---

## 3. 存储布局与迁移

```
content/uploads/
├── litafile/            ← 新上传全部进这里（沿用云盘的日期分目录）
│   └── 2026/09/<stored_name>
├── cloud/               ← 旧网盘文件：**保持原位**，DB 里 storage='cloud'
└── music/               ← 旧音乐文件：**保持原位**，DB 里 storage='music'
```

- **不搬文件**（零迁移风险：老文章里的直链、老插件的引用都不会断）；`litafile_storage_dir($item)` 按 `storage` 字段解析实际目录。
- 迁移用一个**幂等**函数 `litafile_import_legacy()`：
  1. `cloud_files` 每行 → `litafile_items`（`kind` 用统一判定；`legacy_src='cloud'`；已存在则跳过）；
  2. `lita_music_playlist` 每项 → `litafile_items`（`source=local|remote`、`kind` 按扩展名）+ 加入默认歌单；
  3. 结果写入 option `litafile_import_report`（导入了多少、跳过多少），后台页可见。
- 提供**可选的**"一键归位"维护动作（把旧文件移动进 `litafile/` 并改写 DB 路径）——**默认不执行**，由站长显式点击。

---

## 4. 目录骨架

```
content/plugins/litafile/
├── litafile.php              # 主文件：头部声明 + 常量 + 加载模块 + 钩子注册（唯一入口）
├── includes/
│   ├── schema.php            # 建表/自愈 + 索引（幂等，每次加载自检）
│   ├── items.php             # 数据访问层：CRUD/分页/搜索/统一 kind 判定/统一 MIME 兜底
│   ├── storage.php           # 存储解析：目录/URL/落盘/删除/目录保护(.htaccess + web.config 双写)
│   ├── upload.php            # 统一上传（白名单 + 生成名 + 分目录 + 可选密码）
│   ├── protect.php           # 密码/token/HMAC/会话免密/爆破锁定
│   ├── stream.php            # 流式输出（Range 206/416）+ 下载计数
│   ├── playlists.php         # 歌单读写
│   └── legacy.php            # 兼容层：旧短代码/旧路由/旧 option/旧表 + 迁移导入
├── admin/
│   ├── menu.php              # 菜单树（媒体库 / 歌单 / 设置 / 迁移）
│   ├── page-library.php      # 媒体库：上传(批量)/列表/搜索/筛选/编辑/删除/复制短代码
│   ├── page-playlists.php    # 歌单管理（拖拽排序）
│   ├── page-settings.php     # 模式(直链/保护)、播放器设置、目录保护重写、彻底清理
│   └── editor-button.php     # Quill 单按钮 + 单弹层（上传/选已有/选歌单）
├── public/
│   ├── styles.php            # 统一 CSS（媒体卡片 + 下载卡片 + 播放器）
│   ├── player.php            # 全局播放器（footer/wp_footer 双钩子）+ localStorage 状态
│   ├── media-controller.php  # ★统一媒体互斥（管全页 audio/video，合并两插件各管一半的问题）
│   └── shortcodes.php        # [litafile] / [download] / [lita_music] 渲染
├── uninstall.php             # 卸载契约（见 §9）
├── README.md                 # 使用说明（后台页里也内嵌一份）
└── DESIGN.md                 # 本文件
```

---

## 5. 后端接口

### 5.1 后台页（`add_menu_page('媒体与文件','📁 媒体','manage_options','litafile',…)`）
- **媒体库**：批量上传、列表（kind 筛选/搜索/分页 20）、设置密码、编辑标题/艺术家/描述、删除、复制短代码/直链、显示计数。
- **歌单**：新建歌单、从媒体库挑歌、排序、默认歌单开关。
- **设置**：模式（直链省资源 / 完整保护）、播放器（自动播放、默认模式）、**重写目录保护文件**、导入旧数据、彻底清理。
- 所有写操作：`verifyCsrfToken('litafile_*')` + `current_user_can('manage_options')`。

### 5.2 后端 AJAX（框架 `/ajax.php`，与现有插件同风格）
- `litafile_upload` / `litafile_items`（列表，编辑器弹层用）/ `litafile_playlists`（列表）。
- 准入：`litafile_ajax_guard()` = `is_logged_in() && current_user_can('publish_posts')`；字段 `_ajax_csrf_token`。

### 5.3 Agent API（保持老形态 + 新形态）
- **老**：`?agent_api=files&action=upload|download|list|delete`（鉴权 `lita_agent_api_key_admin`，走 `Authorization: Bearer` / `X-API-Key` / `?apikey=`）→ **行为完全保持**（老 AI 调用方不破），内部改为调用 `litafile_*` 数据层。
- **新**：`?agent_api=litafile&resource=items|playlists&action=…`，请求/响应沿用 `{code,message,data}`；新增按 `kind` 筛选、加歌/移歌。
- 安全收敛（对照 2026-09-16 安全审计）：key 比较用 `hash_equals()`；`ACAO` 收敛到站点域（默认 `*` 可配置）；保留 `?apikey=` 但默认关闭（可在设置里开启，供免费主机兼容）。

### 5.4 前端路由（`init`，优先级 0/1）
- `?litafile_dl={id}&token={hmac}[&inline=1]`：新统一下载/内嵌路由（老 `?cloud_download=` 仍可用）。
- `?litafile_count={id}`：204 beacon 计数（老 `?cd_count=` 仍可用）。

---

## 6. 前端

- **注入点最少化**：样式挂 `wp_head`（一次）；播放器 + 媒体控制器挂 `footer` 与 `wp_footer`（双钩子 + `static $done` 防重复，沿用 lita-music 的成熟做法）。
- **短代码**
  - `[download id=N mode=auto|embed|link]`（行为不变）
  - `[lita_music]` 及其属性（行为不变）
  - `[litafile id=N]`：自动按 kind 渲染（图片/音视频内嵌、其它下载卡片）
  - `[litafile_playlist id=N]`：渲染歌单卡片
- **媒体互斥**：`media-controller.php` 用事件委托监听页面上**所有** `audio`/`video` 的 `play` 事件 → 自动暂停其它（一次注册，覆盖内嵌媒体 + 播放器 + 歌单；修掉"两插件各管一半"的问题）。
- **播放器状态**：`localStorage['litafile_state']`（**新键**，不覆盖旧 `lita_music_state`；首次加载可读取旧键做一次性迁移）；全局变量 `window.LITAFILE_DATA` / `window.LitaFile`。

---

## 7. 安全设计（把 2026-09-16 审计结论直接内建）

1. 上传：**白名单**（image/audio/video/file 各自扩展名表）+ 危险扩展名黑名单兜底 + 生成名 `date_hex.ext`（不沿用原名）+ 禁目录列举。
2. 目录保护：**`.htaccess` 与 `web.config` 同时写**（Apache 与 IIS 都覆盖）—— 现状只有 `.htaccess`，IIS 上等于没有 ✗。
3. 下载：token = `hash_hmac('sha256', id|stored_name, AUTH_KEY)`，校验用 `hash_equals`；双段 `Content-Disposition`（剥离引号/CRLF）。
4. 密码：`password_hash`/`password_verify` + 会话免密（3600s）+ 5 次失败锁 600s（沿用云盘实现）。
5. 计数/写入：所有 SQL 走 `prepare()`；`?litafile_count` 只做原子 `+1` 后 204 退出。
6. 远程外链项（`source=remote`）：不允许 `file://`/内网地址（SSRF 面），仅 http(s)。

---

## 8. 兼容与共存策略（关键！）

老插件 `cloud-drive` / `lita-music` 若**同时激活**，会与本插件重复注册短代码/路由/菜单 ✗。因此：

1. **函数级守卫**：本插件所有对外注册都用 `function_exists()` / `has_shortcode` 式判断，已存在则**让位**（不重复注册 ✗）；
2. **激活时检测**：`litafile_activate()` 读取 `plugins` 表，若检测到 `cloud-drive` / `lita-music` 处于 active → 在后台提示"建议停用"，并提供一键停用按钮（**不自动停用**，避免动用户配置 ✗）；
3. **数据只读兼容**：旧表 `cloud_files` 与旧 option `lita_music_playlist` **永不修改**（迁移是"复制进新表"而非"搬走"）；
4. **短代码/路由/API 别名**：老形态全部保留，内部转发到新实现（这样即使老插件停用，存量文章也照常工作 ✓）。

---

## 9. 卸载契约

`uninstall.php`（经 `do_uninstall_plugin()` 调用）：
- **删除** `litafile_*` 的 option（settings/import_report 等）与 `litafile_items`/`litafile_playlists`/`litafile_playlist_items` 三张表；
- **永不删除** `content/uploads/` 下的任何文件（含 `litafile/`）—— 站长数据优先；
- 旧表 `cloud_files` 与旧 option **不动**；
- 另设"彻底清理"后台动作（显式二次确认）才删文件。

---

## 10. 分阶段实施 + 验收

| 阶段 | 内容 | 验收 |
|---|---|---|
| **M1 骨架** | 主文件 + `schema.php` + 数据层 + 激活/卸载 + 后台菜单空壳 | `php -l` 全绿；插件可激活/停用；三表建成；库为空时首页无异常 |
| **M2 媒体库** | 上传统一（白名单/分目录/密码）+ 列表/编辑/删除 + 目录保护双写 | 后台批量上传成功；`?litafile_dl=` 下载/内嵌正常；直链与保护模式都通 |
| **M3 前端** | 短代码（新旧）+ 渲染器 + 媒体互斥 + 样式 | 文章内嵌 img/audio/video 正常；同页多播放器互斥；`[download]`/`[lita_music]` 行为与旧版一致 |
| **M4 播放器/歌单** | 全局播放器 + 歌单表与后台 + localStorage 迁移 | 播放器跨页续播；歌单顺序/随机/单曲循环正确；旧 `lita_music_state` 能一次性迁移 |
| **M5 兼容/迁移/文档** | 旧短代码别名、旧路由、Agent API 兼容、`litafile_import_legacy()`、README | 关掉老插件后：老文章内嵌/下载/歌单**全部照常**；迁移导入数与旧数据一致（幂等，可重复跑） |

**测试手段**（沿用 2026-09-16 建好的工具链）：
- `help/scripts/lint_with_php_cli.py`（`php -l` 批量）
- PHP CLI 单元测试（新增 `help/scripts/litafile_unit_test.php`）：kind 判定、token/HMAC、密码锁定、存储路径解析、迁移幂等
- `help/scripts/verify_page_cache_live.py --root .../v10`（当前 docroot 若是 v10 则顺带回归）
- 安全面复用 `help/scripts/pentest_v10_memcachesurface.py` 的思路（上传白名单、下载 token、越权删除）

---

## 11. 需你确认的 3 个决策点（我已按"推荐值"假设，若要改说一声即可）

1. **旧文件是否搬进新目录**：推荐**不搬**（零风险，DB 记 `storage` 区分）；另提供可选"一键归位"。
2. **歌单存储**：推荐**升级为表**（可按需扩展多歌单）；旧 option 保留只读兼容 + 一次性导入。
3. **老插件处置**：推荐**提示 + 一键停用**（不自动停用）；若你希望"激活 litafile 就自动停用它们"，我改成自动。
