<?php
if (!defined('ABSPATH') || !is_admin()) {
    exit;
}

$db = get_db();
$message = '';
$msg_type = 'success';

// 1. 处理表单动作 (添加/删除目标站)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['distribute_action'])) {
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'litadistribute_settings_nonce')) {
        $message = '安全验证失败。';
        $msg_type = 'error';
    } else {
        if ($_POST['distribute_action'] === 'add') {
            $name = trim(filter_input(INPUT_POST, 'site_name', FILTER_SANITIZE_STRING));
            $url = trim(filter_input(INPUT_POST, 'site_url', FILTER_SANITIZE_URL));
            $key = trim($_POST['api_key'] ?? '');

            if (empty($name) || empty($url) || empty($key)) {
                $message = '所有字段均为必填。';
                $msg_type = 'error';
            } else {
                $stmt = $db->prepare('INSERT INTO litadistribute_targets (site_name, site_url, api_key) VALUES (?, ?, ?)');
                if ($stmt->execute([$name, $url, $key])) {
                    $message = '目标站添加成功！';
                    $msg_type = 'success';
                }
            }
        } elseif ($_POST['distribute_action'] === 'delete') {
            $id = intval($_POST['target_id'] ?? 0);
            if ($id > 0) {
                $stmt = $db->prepare('DELETE FROM litadistribute_targets WHERE id = ?');
                $stmt_map = $db->prepare('DELETE FROM litadistribute_post_map WHERE target_site_id = ?');
                if ($stmt->execute([$id])) {
                    $stmt_map->execute([$id]);
                    $message = '目标站删除成功。';
                    $msg_type = 'success';
                }
            }
        }
    }
}

// 2. 加载目标站列表
$stmt_list = $db->query('SELECT * FROM litadistribute_targets ORDER BY id DESC');
$targets = $stmt_list->fetchAll(PDO::FETCH_ASSOC);

$local_key = get_option('litadistribute_local_key');
$local_api_endpoint = rtrim(SITE_URL, '/') . '/?lita_api=distribute_receive';
?>

<div class="content">
    <h1>多站点内容同步分发设置</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-<?php echo $msg_type === 'success' ? 'success' : 'danger'; ?>">
            <?php echo e($message); ?>
        </div>
    <?php endif; ?>

    <!-- 展现接收端配置信息，方便用户复制到其他分发源网站 -->
    <div style="background-color: #fcfcfc; border: 1px solid var(--border-color); padding: 15px; border-radius: 6px; margin-bottom: 30px;">
        <h3 style="margin-top:0;">📡 本站接收信息（供其他站分发到本站时填写）</h3>
        <p style="margin: 5px 0;"><strong>接收端 API 接口地址:</strong> <code><?php echo e($local_api_endpoint); ?></code></p>
        <p style="margin: 5px 0;"><strong>通讯认证密钥 (API Key):</strong> <code><?php echo e($local_key); ?></code></p>
        <small style="color: #666; display:block; margin-top:5px;">提示：请将以上信息填入在发送站点的“目标站列表”中，即可激活发送站到本站的直接传输通道。</small>
    </div>

    <div class="categories-container" style="display:flex; gap:30px;">
        <!-- 新增目标站 -->
        <div class="add-category" style="flex: 1;">
            <h2>添加新目标站点</h2>
            <form method="post" action="">
                <input type="hidden" name="distribute_action" value="add">
                <?php csrf_token_field('litadistribute_settings_nonce'); ?>
                
                <div class="form-group">
                    <label for="site_name">网站名称:</label>
                    <input type="text" id="site_name" name="site_name" placeholder="例如：我的备用站" required>
                </div>

                <div class="form-group">
                    <label for="site_url">API 接收地址:</label>
                    <input type="url" id="site_url" name="site_url" placeholder="形式如 https://site.com/?lita_api=distribute_receive" required>
                </div>

                <div class="form-group">
                    <label for="api_key">通信密钥 (API Key):</label>
                    <input type="text" id="api_key" name="api_key" placeholder="填写对方网站生成的 API Key" required>
                </div>

                <button type="submit" class="button">添加目标站</button>
            </form>
        </div>

        <!-- 目标站管理列表 -->
        <div class="categories-list" style="flex: 1.5;">
            <h2>已配置的目标分发站</h2>
            <?php if (empty($targets)): ?>
                <p>暂无目标站点。您撰写的文章仅保留在本地。</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>网站名称</th>
                            <th>API 地址</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($targets as $target): ?>
                            <tr>
                                <td><strong><?php echo e($target['site_name']); ?></strong></td>
                                <td><code style="font-size:0.85em;"><?php echo e($target['site_url']); ?></code></td>
                                <td>
                                    <form method="post" style="display: inline;" onsubmit="return confirm('确定要删除该目标站？关联的分发文章后续将无法再同步更新。');">
                                        <input type="hidden" name="distribute_action" value="delete">
                                        <input type="hidden" name="target_id" value="<?php echo $target['id']; ?>">
                                        <?php csrf_token_field('litadistribute_settings_nonce'); ?>
                                        <button type="submit" class="button btn-danger" style="padding: 3px 8px; font-size: 0.85em;">删除</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>