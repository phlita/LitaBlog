<?php
/**
 * Plugin Name: LitaDistribute
 * Plugin URI: https://lita.eu.org/
 * Description: 跨跨站点文章分发系统。支持在一个网站上撰写日记或文章，一键同步分发到其他独立运行的博客站点。
 * Version: 1.1.0
 * Author: 芙里塔
 * Author URI: https://lita.eu.org/
 */

if (!defined('ABSPATH')) {
    exit;
}

define('LITADISTRIBUTE_DIR', __DIR__ . '/');
define('LITADISTRIBUTE_URL', SITE_URL . '/content/plugins/litadistribute/');

// 加载依赖
require_once LITADISTRIBUTE_DIR . 'includes/db-schema.php';
require_once LITADISTRIBUTE_DIR . 'includes/functions-api.php';
require_once LITADISTRIBUTE_DIR . 'includes/functions-sender.php';

// 注册激活钩子
register_activation_hook(__FILE__, 'litadistribute_activate');

function litadistribute_activate() {
    litadistribute_create_tables();

    // 初始化本站唯一的本地 API 密钥
    if (get_option('litadistribute_local_key') === false || get_option('litadistribute_local_key') === '') {
        $random_key = bin2hex(random_bytes(24));
        update_option('litadistribute_local_key', $random_key);
    }
}

// 初始化钩子
function litadistribute_init() {
    // 1. 拦截外部发入本站的 API 请求
    if (isset($_GET['lita_api']) && $_GET['lita_api'] === 'distribute_receive') {
        litadistribute_handle_incoming_api();
        exit;
    }

    // 2. 核心优化：前置拦截本地后台的“删除文章”POST请求，实现删除同步
    if (is_admin() && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && isset($_POST['content_id'])) {
        $post_id = intval($_POST['content_id']);
        if ($post_id > 0) {
            // 在核心数据库执行 DELETE 之前，优先把副站数据销毁
            litadistribute_handle_local_delete($post_id);
        }
    }
}
add_action('init', 'litadistribute_init');

// 后台菜单注册
function litadistribute_register_menu() {
    add_menu_page(
        '多站分发设置',
        '多站分发',
        'manage_options',
        'litadistribute-settings',
        'litadistribute_render_settings_page'
    );
}
add_action('admin_menu', 'litadistribute_register_menu');

function litadistribute_render_settings_page() {
    require_once LITADISTRIBUTE_DIR . 'admin/settings-page.php';
}