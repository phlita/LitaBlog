<?php
if (!defined('ABSPATH')) {
    exit;
}

// 在后台写文章页渲染分发选择列表
function litadistribute_render_meta_box($post_type, $post_data) {
    if ($post_type !== 'post') return;

    $db = get_db();
    $stmt = $db->query('SELECT * FROM litadistribute_targets ORDER BY site_name ASC');
    $targets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($targets)) {
        return;
    }

    $post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    // 获取当前文章已发出的分发站点 ID
    $mapped_targets_ids = [];
    $is_distribute_only = false;
    if ($post_id > 0) {
        $stmt_map = $db->prepare('SELECT target_site_id FROM litadistribute_post_map WHERE local_post_id = ?');
        $stmt_map->execute([$post_id]);
        $mapped_targets_ids = $stmt_map->fetchAll(PDO::FETCH_COLUMN);

        $is_distribute_only = (get_post_meta($post_id, '_litadistribute_only', true) === '1');
    }

    echo '<div class="litapay-meta-box-section" style="border: 1px solid var(--border-color); padding: 15px; border-radius: 6px; background-color: #fff; margin-top: 15px;">';
    echo '<h4 style="margin-top:0; margin-bottom:10px; border-bottom:1px dashed #eee; padding-bottom:5px;">分发到其他网站</h4>';
    
    echo '<div class="checkbox-group">';
    foreach ($targets as $target) {
        $checked = in_array($target['id'], $mapped_targets_ids) ? 'checked' : '';
        echo '<label style="display:block; margin-bottom: 5px; cursor:pointer;">';
        echo '<input type="checkbox" name="distribute_targets[]" value="' . $target['id'] . '" ' . $checked . '> ';
        echo e($target['site_name']);
        echo '</label>';
    }
    echo '</div>';

    $only_checked = $is_distribute_only ? 'checked' : '';
    echo '<div style="margin-top: 12px; padding-top: 10px; border-top: 1px dashed #eee;">';
    echo '<label style="display:inline-flex; align-items:center; cursor:pointer; color: #a35d55; font-weight: bold;">';
    echo '<input type="checkbox" name="litadistribute_only" value="1" ' . $only_checked . ' style="margin-right: 6px;"> ';
    echo '仅分发到子站（本地不发布）';
    echo '</label>';
    echo '</div>';
    
    echo '</div>';
}
add_action('add_meta_boxes', 'litadistribute_render_meta_box', 10, 2);

// 保存文章时触发分发逻辑
function litadistribute_save_post_handler($post_id, $post_data) {
    if (defined('DOING_AJAX') && DOING_AJAX) {
        return;
    }

    if (($post_data['type'] ?? 'post') !== 'post') {
        return;
    }

    $db = get_db();
    
    $distribute_only = isset($_POST['litadistribute_only']) ? 1 : 0;
    if ($distribute_only) {
        $db->prepare("UPDATE posts SET status = 'draft' WHERE id = ?")->execute([$post_id]);
        update_post_meta($post_id, '_litadistribute_only', '1');
    } else {
        update_post_meta($post_id, '_litadistribute_only', '0');
    }

    $selected_targets = isset($_POST['distribute_targets']) && is_array($_POST['distribute_targets']) 
        ? array_map('intval', $_POST['distribute_targets']) 
        : [];

    $stmt_map = $db->prepare('SELECT target_site_id, remote_post_id FROM litadistribute_post_map WHERE local_post_id = ?');
    $stmt_map->execute([$post_id]);
    $existing_maps = $stmt_map->fetchAll(PDO::FETCH_KEY_PAIR);

    foreach ($existing_maps as $target_id => $remote_post_id) {
        if (!in_array($target_id, $selected_targets)) {
            litadistribute_send_api_request($target_id, [
                'action' => 'delete',
                'remote_post_id' => $remote_post_id
            ]);
            $stmt_del = $db->prepare('DELETE FROM litadistribute_post_map WHERE local_post_id = ? AND target_site_id = ?');
            $stmt_del->execute([$post_id, $target_id]);
        }
    }

    if (empty($selected_targets)) {
        return;
    }

    $categories = get_post_categories($post_id);
    $tags = get_post_tags($post_id);

    $cat_names = array_column($categories, 'name');
    $tag_names = array_column($tags, 'name');

    $remote_status = $distribute_only ? 'publish' : ($post_data['status'] ?? 'publish');

    $post_payload = [
        'title'      => $post_data['title'],
        'content'    => $post_data['content'],
        'excerpt'    => $post_data['excerpt'] ?? '',
        'status'     => $remote_status,
        'categories' => $cat_names,
        'tags'       => $tag_names
    ];

    foreach ($selected_targets as $target_id) {
        $action = isset($existing_maps[$target_id]) ? 'update' : 'publish';
        $remote_post_id = $existing_maps[$target_id] ?? 0;

        $request_data = [
            'action'         => $action,
            'remote_post_id' => $remote_post_id,
            'post_data'      => $post_payload
        ];

        $response = litadistribute_send_api_request($target_id, $request_data);
        
        if ($response && $response['success']) {
            if ($action === 'publish' && isset($response['remote_post_id'])) {
                $stmt_ins = $db->prepare('
                    INSERT INTO litadistribute_post_map (local_post_id, target_site_id, remote_post_id)
                    VALUES (?, ?, ?)
                ');
                $stmt_ins->execute([$post_id, $target_id, intval($response['remote_post_id'])]);
            }
        }
    }
}
add_action('save_post', 'litadistribute_save_post_handler', 15, 2);


/**
 * 核心新增：前置拦截本地删除行为并向远程同步销毁指令
 */
function litadistribute_handle_local_delete($post_id) {
    $db = get_db();
    
    // 1. 查询该文章在所有副站的分发映射记录
    $stmt_map = $db->prepare('SELECT target_site_id, remote_post_id FROM litadistribute_post_map WHERE local_post_id = ?');
    $stmt_map->execute([$post_id]);
    $maps = $stmt_map->fetchAll(PDO::FETCH_ASSOC);

    if (empty($maps)) {
        return; // 无分发记录，无需向远端发送请求
    }

    // 2. 逐一向副站发送逻辑/物理删除请求
    foreach ($maps as $map) {
        $target_id = intval($map['target_site_id']);
        $remote_post_id = intval($map['remote_post_id']);

        litadistribute_send_api_request($target_id, [
            'action' => 'delete',
            'remote_post_id' => $remote_post_id
        ]);
    }

    // 3. 清理本地映射关联表
    $stmt_del_map = $db->prepare('DELETE FROM litadistribute_post_map WHERE local_post_id = ?');
    $stmt_del_map->execute([$post_id]);
}


// cURL 核心请求发送器
function litadistribute_send_api_request($target_id, $data) {
    $db = get_db();
    $stmt = $db->prepare('SELECT * FROM litadistribute_targets WHERE id = ?');
    $stmt->execute([$target_id]);
    $target = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$target) return false;

    $url = $target['site_url'];
    $api_key = $target['api_key'];
    $timestamp = time();

    $json_body = json_encode($data, JSON_UNESCAPED_UNICODE);
    $signature = hash_hmac('sha256', $json_body . $timestamp, $api_key);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_body);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // H-5:启用证书链校验(php.ini 已配 curl.cainfo=cacert.pem)
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json; charset=utf-8',
        'X-Lita-Timestamp: ' . $timestamp,
        'X-Lita-Signature: ' . $signature
    ]);

    $response_body = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code === 200 && $response_body) {
        return json_decode($response_body, true);
    }
    return false;
}