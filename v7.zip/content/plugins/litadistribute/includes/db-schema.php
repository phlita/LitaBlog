<?php
if (!defined('ABSPATH')) {
    exit;
}

function litadistribute_create_tables() {
    $db = get_db();
    
    $tables = [
        // 目标接收站点配置表
        "CREATE TABLE IF NOT EXISTS litadistribute_targets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            site_name TEXT NOT NULL,
            site_url TEXT NOT NULL,
            api_key TEXT NOT NULL
        )",
        
        // 分发文章映射关联表（用于记录文章在各接收端对应的远程文章 ID）
        "CREATE TABLE IF NOT EXISTS litadistribute_post_map (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_post_id INTEGER NOT NULL,
            target_site_id INTEGER NOT NULL,
            remote_post_id INTEGER NOT NULL,
            UNIQUE(local_post_id, target_site_id)
        )"
    ];

    try {
        $db->beginTransaction();
        foreach ($tables as $sql) {
            $db->exec($sql);
        }
        $db->commit();
    } catch (PDOException $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("LitaDistribute DB Schema Error: " . $e->getMessage());
    }
}