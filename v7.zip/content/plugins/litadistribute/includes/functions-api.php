<?php
if (!defined('ABSPATH')) {
    exit;
}

function litadistribute_handle_incoming_api() {
    header('Content-Type: application/json; charset=utf-8');

    // 1. 验证签名请求头
    $headers = getallheaders();
    $timestamp = isset($headers['X-Lita-Timestamp']) ? intval($headers['X-Lita-Timestamp']) : 0;
    $received_signature = isset($headers['X-Lita-Signature']) ? $headers['X-Lita-Signature'] : '';

    // 防重放攻击校验 (时间误差在5分钟以内)
    if (abs(time() - $timestamp) > 300) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => '请求已过期']);
        exit;
    }

    $local_key = get_option('litadistribute_local_key');
    if (empty($local_key)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => '接收端未启用API密钥设置']);
        exit;
    }

    $raw_body = file_get_contents('php://input');
    
    // HMAC 签名比对
    $expected_signature = hash_hmac('sha256', $raw_body . $timestamp, $local_key);
    if (!hash_equals($expected_signature, $received_signature)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => '接口签名验证未通过']);
        exit;
    }

    $payload = json_decode($raw_body, true);
    if (!$payload) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => '无效的数据格式']);
        exit;
    }

    $action = $payload['action'] ?? '';
    $post_data = $payload['post_data'] ?? [];

    $db = get_db();

    try {
        switch ($action) {
            case 'publish':
                // 自动处理分类和标签：若本地不存在对应名字的分类和标签则自动创建
                $categories_ids = litadistribute_process_terms($post_data['categories'] ?? [], 'category');
                $tags_ids = litadistribute_process_terms($post_data['tags'] ?? [], 'tag');

                $db->beginTransaction();

                // 写入 posts 表
                $stmt = $db->prepare('
                    INSERT INTO posts (title, content, excerpt, author, status, type, slug, created, modified)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ');
                
                // 默认将外部发布文章的作者归属于本地第一个管理员账号（ID: 1）
                $stmt->execute([
                    $post_data['title'],
                    $post_data['content'],
                    $post_data['excerpt'] ?? '',
                    1,
                    $post_data['status'] ?? 'publish',
                    'post',
                    create_slug($post_data['title'])
                ]);

                $new_post_id = $db->lastInsertId();

                // 更新 slug
                $stmt_slug = $db->prepare('UPDATE posts SET slug = ? WHERE id = ?');
                $stmt_slug->execute([(string)$new_post_id, $new_post_id]);

                // 关联分类
                if (!empty($categories_ids)) {
                    $stmt_cat = $db->prepare('INSERT INTO post_categories (post_id, category_id) VALUES (?, ?)');
                    foreach ($categories_ids as $cat_id) {
                        $stmt_cat->execute([$new_post_id, $cat_id]);
                    }
                }

                // 关联标签
                if (!empty($tags_ids)) {
                    $stmt_tag = $db->prepare('INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)');
                    foreach ($tags_ids as $tag_id) {
                        $stmt_tag->execute([$new_post_id, $tag_id]);
                    }
                }

                $db->commit();
                echo json_encode(['success' => true, 'remote_post_id' => $new_post_id]);
                break;

            case 'update':
                $remote_post_id = intval($payload['remote_post_id'] ?? 0);
                if ($remote_post_id <= 0) {
                    throw new Exception('缺失有效的远程文章ID');
                }

                // 校验该文章在本地是否存在
                $stmt_check = $db->prepare('SELECT id FROM posts WHERE id = ?');
                $stmt_check->execute([$remote_post_id]);
                if (!$stmt_check->fetch()) {
                    throw new Exception('本地不存在该文章，无法更新');
                }

                $categories_ids = litadistribute_process_terms($post_data['categories'] ?? [], 'category');
                $tags_ids = litadistribute_process_terms($post_data['tags'] ?? [], 'tag');

                $db->beginTransaction();

                $stmt = $db->prepare('
                    UPDATE posts 
                    SET title = ?, content = ?, excerpt = ?, status = ?, modified = CURRENT_TIMESTAMP
                    WHERE id = ?
                ');
                $stmt->execute([
                    $post_data['title'],
                    $post_data['content'],
                    $post_data['excerpt'] ?? '',
                    $post_data['status'] ?? 'publish',
                    $remote_post_id
                ]);

                // 清理旧分类标签关联
                $db->prepare('DELETE FROM post_categories WHERE post_id = ?')->execute([$remote_post_id]);
                $db->prepare('DELETE FROM post_tags WHERE post_id = ?')->execute([$remote_post_id]);

                // 重新关联新分类
                if (!empty($categories_ids)) {
                    $stmt_cat = $db->prepare('INSERT INTO post_categories (post_id, category_id) VALUES (?, ?)');
                    foreach ($categories_ids as $cat_id) {
                        $stmt_cat->execute([$remote_post_id, $cat_id]);
                    }
                }

                // 重新关联新标签
                if (!empty($tags_ids)) {
                    $stmt_tag = $db->prepare('INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)');
                    foreach ($tags_ids as $tag_id) {
                        $stmt_tag->execute([$remote_post_id, $tag_id]);
                    }
                }

                $db->commit();
                echo json_encode(['success' => true, 'remote_post_id' => $remote_post_id]);
                break;

            case 'delete':
                $remote_post_id = intval($payload['remote_post_id'] ?? 0);
                if ($remote_post_id > 0) {
                    $db->beginTransaction();
                    $db->prepare('DELETE FROM posts WHERE id = ?')->execute([$remote_post_id]);
                    $db->prepare('DELETE FROM post_categories WHERE post_id = ?')->execute([$remote_post_id]);
                    $db->prepare('DELETE FROM post_tags WHERE post_id = ?')->execute([$remote_post_id]);
                    $db->commit();
                }
                echo json_encode(['success' => true]);
                break;

            default:
                throw new Exception('未知的 API 操作指令');
        }
    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

// 辅助方法：确保分类/标签在本地数据库存在并返回其对应 ID 数组
function litadistribute_process_terms($terms_names, $type) {
    if (empty($terms_names)) {
        return [];
    }
    $db = get_db();
    $ids = [];

    foreach ($terms_names as $name) {
        $name = trim($name);
        if ($name === '') continue;

        if ($type === 'category') {
            $stmt = $db->prepare('SELECT id FROM categories WHERE name = ?');
            $stmt->execute([$name]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $ids[] = $row['id'];
            } else {
                $slug = create_slug($name);
                $stmt_ins = $db->prepare('INSERT INTO categories (name, slug) VALUES (?, ?)');
                $stmt_ins->execute([$name, $slug]);
                $ids[] = $db->lastInsertId();
            }
        } else { // tag
            $stmt = $db->prepare('SELECT id FROM tags WHERE name = ?');
            $stmt->execute([$name]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $ids[] = $row['id'];
            } else {
                $slug = create_slug($name);
                $stmt_ins = $db->prepare('INSERT INTO tags (name, slug) VALUES (?, ?)');
                $stmt_ins->execute([$name, $slug]);
                $ids[] = $db->lastInsertId();
            }
        }
    }
    return $ids;
}