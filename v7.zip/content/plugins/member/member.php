<?php
/**
 * Plugin Name: Member
 * Plugin URI:  https://blog.lita.eu.org
 * Description: 会员阅读体系：积分(余额/累计) + 会员等级(按累计) + 积分购买阅读权限(单篇/分类/全站) + 充值码兑换积分(复用 LitaPay 充值码)。全部数据本地存储，零外联。
 * Version:     2.0
 * Author:      Lita
 * Author URI:  https://lita.eu.org
 */

if (!defined('ABSPATH')) exit;

define('MEMBER_VERSION', '2.0');
define('MEMBER_PLUGIN_DIR', __DIR__ . '/');
define('MEMBER_PLUGIN_URL', rtrim(SITE_URL, '/') . '/content/plugins/member/');

// 核心模块（前后台共用）
require_once MEMBER_PLUGIN_DIR . 'functions-core.php';
require_once MEMBER_PLUGIN_DIR . 'functions-access.php';
require_once MEMBER_PLUGIN_DIR . 'ajax-handlers.php';
require_once MEMBER_PLUGIN_DIR . 'template-functions.php';

// 后台模块
if (is_admin()) {
    require_once MEMBER_PLUGIN_DIR . 'admin-menu.php';
    require_once MEMBER_PLUGIN_DIR . 'post-meta.php';
}

register_activation_hook(__FILE__, 'member_activate');
register_deactivation_hook(__FILE__, 'member_deactivate');

/**
 * 激活：建表 + 默认配置
 */
function member_activate() {
    member_create_tables();
    member_ensure_recharge_table();
    update_option('member_version', MEMBER_VERSION);
    update_option('member_level_vip_min', 1000);
    update_option('member_level_svip_min', 5000);
    update_option('member_recharge_rate', 1);
    update_option('member_global_price', 0);
    update_option('member_category_prices', '{}');
    update_option('member_restrict_posting', '1');
}

/**
 * 停用：保留用户积分与购买记录数据，仅停止功能
 */
function member_deactivate() {
    // 无清理动作
}

/**
 * 初始化：短代码、AJAX、内容门禁、前端资源
 */
function member_init() {
    // 幂等建表：升级后即使未重新激活也保证表存在
    member_create_tables();

    add_shortcode('member_user_center', 'member_user_center_shortcode');

    member_register_ajax_handlers();
    member_handle_frontend_posts();   // 无 JS 时的前台 PRG 保底通道

    // 发帖权限：开启后仅管理员可发文（堵"投进定价分类=变相定价"旁路）
    if (get_option('member_restrict_posting', '1') === '1') {
        add_filter('user_has_cap', 'member_maybe_deny_publish', 99, 3);
    }

    // 内容门禁：优先级高于其他内容插件(litapay 20 / cloud-drive 30)
    add_filter('the_content', 'member_filter_post_content', 40, 2);

    // 资源与浮窗注入：优先走主题钩子（v7/v10 系列主题都会触发）
    add_action('header', 'member_enqueue_frontend_styles');   // 兼容带 header 钩子的主题（提前加载样式）
    add_action('wp_footer', 'member_enqueue_frontend_styles');
    add_action('wp_footer', 'member_enqueue_frontend_scripts');
    add_action('footer', 'member_enqueue_frontend_styles');
    add_action('footer', 'member_enqueue_frontend_scripts');

    // 兜底（2026-09-16）：若某个主题**一个钩子都不触发**（header/footer/wp_footer 全没有），
    // 上面的注入会整体失效 → 面板无样式、浮窗不出现。内容区一定会渲染，所以在 the_content
    // 末尾再补一次（样式/脚本函数内部都有 static 只输出一次的保护，不会重复）。
    // 注意：这里**不能**用 is_admin() 做守卫 —— 本框架的 is_admin() 是"当前用户是管理员"
    // （能力判定），不是"后台页面"；用它会把管理员自己排除掉（实测过：0 字节输出）。
    add_filter('the_content', function ($content) {
        member_enqueue_frontend_styles();
        member_enqueue_frontend_scripts();
        return $content;
    }, 99);
}
add_action('init', 'member_init');
