<?php
/**
 * Member 插件：模板辅助、短代码与前端资源
 *
 * 兼容性设计：
 *  - 插件自身通过 wp_footer/footer 注入"积分浮窗"（折叠式充值框），
 *    任何 v7 主题都能显示，不依赖主题模板是否调用本插件函数。
 *  - 同时保留 [member_user_center] 短代码与 member_render_user_panel()，
 *    供想放"完整静态面板"的页面使用。
 *  - member_user_points_badge() 保留兼容（若主题仍想手动放徽章）。
 */
if (!defined('ABSPATH')) exit;

/* ---------------- 顶部积分徽章（保留兼容，供主题按需调用） ---------------- */

if (!function_exists('member_user_points_badge')) {
    function member_user_points_badge() {
        if (!is_logged_in()) {
            return '';
        }
        $m = member_get_membership();
        // 等级配色：normal/vip/svip 三个修饰类由插件 CSS 自带（见 member-frontend.css「自包含层」），
        // 因此不论主题是否提供会员皮肤，等级标识的表现都一致。
        $lvl_cls = (!empty($m['key']) && $m['key'] !== 'normal') ? ' member-badge--' . e($m['key']) : '';
        return '<span class="member-badge' . $lvl_cls . '">积分 ' . (int) $m['points']
             . ' · ' . e($m['label']) . '</span>';
    }
}

/* ---------------- 完整静态面板（短代码 [member_user_center]） ---------------- */

if (!function_exists('member_render_user_panel')) {
    function member_render_user_panel() {
        // 样式兜底：短代码可能被放在钩子之外的位置（小工具/模板），这里直接确保样式已输出
        // （函数内部 static 保护，重复调用只输出一次）。
        if (function_exists('member_enqueue_frontend_styles')) {
            member_enqueue_frontend_styles();
        }
        if (!is_logged_in()) {
            $login = rtrim(defined('SITE_URL') ? SITE_URL : '', '/');
            return '<div class="member-user-panel">'
                 . '<h3>用户中心</h3>'
                 . '<p class="member-login-prompt"><a href="' . e($login) . '/admin/login.php">登录</a> 后查看积分与会员。</p>'
                 . '</div>';
        }

        $m   = member_get_membership();
        $msg = member_consume_flash();

        // 已定价分类 + 是否已购
        $uid  = member_current_user_id();
        $cats = array();
        foreach (member_priced_categories() as $c) {
            $c['owned'] = member_has_purchase($uid, 'category', $c['id']);
            $cats[] = $c;
        }

        $member_panel = array(
            'username' => $_SESSION['username'] ?? '',
            'points'   => $m['points'],
            'total'    => $m['total'],
            'label'    => $m['label'],
            'vip_min'  => member_level_vip_min(),
            'svip_min' => member_level_svip_min(),
            'rate'     => member_recharge_rate(),
            'redeem_token' => function_exists('generateCsrfToken') ? generateCsrfToken('member_redeem') : '',
            'global_price' => member_get_global_price(),
            'has_global'   => member_has_global_access(),
            'global_token' => function_exists('generateCsrfToken') ? generateCsrfToken('member_global') : '',
            'cats'      => $cats,
            'cat_token' => function_exists('generateCsrfToken') ? generateCsrfToken('member_category') : '',
            'flash'     => $msg,
        );

        ob_start();
        require MEMBER_PLUGIN_DIR . 'user-center-panel.php';
        return ob_get_clean();
    }
}

if (!function_exists('member_user_center_shortcode')) {
    function member_user_center_shortcode() {
        return member_render_user_panel();
    }
}

/* ---------------- 浮动积分浮窗（折叠式充值，随插件注入，任意主题可见） ---------------- */

if (!function_exists('member_floating_widget_markup')) {
    function member_floating_widget_markup() {
        if (!is_logged_in()) {
            return '';
        }
        $m          = member_get_membership();
        $token      = function_exists('generateCsrfToken') ? generateCsrfToken('member_redeem') : '';
        $rate       = member_recharge_rate();
        $global_px  = member_get_global_price();
        $has_global = member_has_global_access();
        $token_g    = function_exists('generateCsrfToken') ? generateCsrfToken('member_global') : '';
        $uid        = member_current_user_id();
        $cats       = member_priced_categories();
        $token_c    = function_exists('generateCsrfToken') ? generateCsrfToken('member_category') : '';

        $html  = '<div id="member-widget" class="member-widget">';
        // 浮窗徽章同样带等级修饰类（跨主题一致）
        $lvl_cls = (!empty($m['key']) && $m['key'] !== 'normal') ? ' member-badge--' . e($m['key']) : '';
        $html .= '<button type="button" class="member-widget-trigger member-badge' . $lvl_cls . '" id="member-widget-toggle" aria-expanded="false">';
        $html .= '积分 <span class="mw-points">' . (int) $m['points'] . '</span>';
        $html .= ' · <span class="mw-level">' . e($m['label']) . '</span>';
        $html .= ' <span class="mw-arrow">▾</span>';
        $html .= '</button>';
        $html .= '<div class="member-widget-body">';
        $html .= '<div class="member-widget-card">';
        $html .= '<p class="member-widget-row">累计积分 <b class="mw-total">' . (int) $m['total'] . '</b></p>';

        // 全站会员（通行证）入口
        if ($global_px > 0) {
            $html .= '<div class="member-separator">全站会员</div>';
            if ($has_global) {
                $html .= '<p class="member-widget-hint" style="color:#5cb85c;">已解锁全站会员 ✓ 全部会员文章可读</p>';
            } else {
                $html .= '<p class="member-widget-hint">消耗 <b>' . (int) $global_px . '</b> 积分解锁全部会员文章（单篇/分类）</p>';
                $html .= '<form class="member-ajax-form member-global-form" method="post" action="">';
                $html .= '<input type="hidden" name="action" value="member_global">';
                $html .= '<input type="hidden" name="_ajax_csrf_token" value="' . e($token_g) . '">';
                $html .= '<button type="submit" class="member-btn member-global-btn">开通全站会员</button>';
                $html .= '</form>';
                $html .= '<div class="member-message-area"></div>';
            }
        }

        // 分类会员入口
        if (!empty($cats)) {
            $html .= '<div class="member-separator">分类会员</div>';
            $shown = 0;
            foreach ($cats as $cat) {
                if ($shown >= 6) { break; }
                $shown++;
                $html .= member_render_category_buy_row($cat, $uid, $token_c);
            }
            if (count($cats) > 6) {
                $html .= '<p class="member-widget-hint" style="text-align:center;">…更多分类见后台定价列表</p>';
            }
            $html .= '<div class="member-separator">充值码</div>';
        }

        $html .= '<p class="member-widget-hint">输入充值码兑换积分（1 : ' . (float) $rate . '）</p>';
        $html .= '<form class="member-ajax-form member-redeem-form" method="post" action="">';
        $html .= '<input type="hidden" name="action" value="member_redeem">';
        $html .= '<input type="hidden" name="_ajax_csrf_token" value="' . e($token) . '">';
        $html .= '<input type="text" name="code" class="member-code-input" placeholder="请输入充值码" required autocomplete="off">';
        $html .= '<button type="submit" class="member-btn member-redeem-btn">兑换积分</button>';
        $html .= '</form>';
        $html .= '<div class="member-message-area"></div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        return $html;
    }
}

/**
 * 分类会员购买行（已购=绿字，未购=按钮表单）
 * 供浮窗与静态面板共用。
 */
if (!function_exists('member_render_category_buy_row')) {
    function member_render_category_buy_row($cat, $uid, $token_c) {
        $owned = member_has_purchase((int) $uid, 'category', $cat['id']);
        if ($owned) {
            return '<p class="member-cat-row"><span class="member-cat-name">' . e($cat['name']) . '</span>'
                 . '<span class="member-cat-owned">已解锁</span></p>';
        }
        return '<form class="member-ajax-form member-category-form member-cat-row" method="post" action="">'
             . '<input type="hidden" name="action" value="member_category">'
             . '<input type="hidden" name="category_id" value="' . (int) $cat['id'] . '">'
             . '<input type="hidden" name="_ajax_csrf_token" value="' . e($token_c) . '">'
             . '<span class="member-cat-name">' . e($cat['name']) . '</span>'
             . '<button type="submit" class="member-btn member-cat-btn">' . (int) $cat['points'] . ' 分</button>'
             . '</form>'
             . '<div class="member-message-area"></div>';
    }
}

/* ---------------- 前端资源（样式 + 浮窗 + 脚本） ---------------- */

if (!function_exists('member_enqueue_frontend_styles')) {
    function member_enqueue_frontend_styles() {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        echo '<link rel="stylesheet" href="' . e(MEMBER_PLUGIN_URL . 'member-frontend.css') . '" />' . "\n";
    }
}

if (!function_exists('member_enqueue_frontend_scripts')) {
    function member_enqueue_frontend_scripts() {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;

        // 浮窗标记（登录用户）
        echo member_floating_widget_markup();

        $ajax_url = rtrim(defined('SITE_URL') ? SITE_URL : '', '/') . '/ajax.php';
        ?>
<script>
(function () {
    var ajaxUrl = '<?php echo e($ajax_url); ?>';

    // 折叠开关（事件委托：不依赖注入顺序，任何时刻点击都生效）
    document.addEventListener('click', function (e) {
        var t = e.target && e.target.closest ? e.target.closest('#member-widget-toggle') : null;
        if (!t) { return; }
        e.preventDefault();
        var widget = document.getElementById('member-widget');
        if (!widget) { return; }
        var open = widget.classList.toggle('open');
        t.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // 数值刷新：同时更新完整面板与浮窗
    function refreshNumbers(payload) {
        var sets = {
            '.member-points-value': 'points',
            '.mw-points': 'points',
            '.member-total-value': 'total',
            '.mw-total': 'total',
            '.member-level-value': 'label',
            '.mw-level': 'label'
        };
        for (var sel in sets) {
            if (!sets.hasOwnProperty(sel)) { continue; }
            var el = document.querySelector(sel);
            if (el && typeof payload[sets[sel]] !== 'undefined') {
                el.textContent = payload[sets[sel]];
            }
        }
    }

    // AJAX 表单（事件委托：无论表单在页面哪里、何时注入都能捕获）
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form || !form.classList || !form.classList.contains('member-ajax-form')) { return; }
        var msg = form.nextElementSibling;
        var btn = form.querySelector('button[type="submit"]');
        if (!msg || !btn) { return; }

        e.preventDefault();
        msg.style.display = 'none';
        msg.className = 'member-message-area';

        var originalText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '处理中...';

        fetch(ajaxUrl, {
            method: 'POST',
            body: new FormData(form)
        })
        .then(function (res) { return res.json(); })
        .then(function (res) {
            var ok = !!(res && res.success);
            var payload = (res && res.data) ? res.data : {};
            msg.textContent = ok ? (payload.message || '操作成功')
                                 : (payload.message || payload.error || '操作失败');
            msg.classList.add(ok ? 'success' : 'error');

            if (ok) {
                if (form.classList.contains('member-purchase-form')
                    || form.classList.contains('member-global-form')
                    || form.classList.contains('member-category-form')) {
                    location.reload();
                    return;
                }
                refreshNumbers(payload);
                var ci = form.querySelector('input[name="code"]');
                if (ci) { ci.value = ''; }
            }
        })
        .catch(function () {
            msg.textContent = '网络异常，请稍后重试。';
            msg.classList.add('error');
        })
        .finally(function () {
            msg.style.display = 'block';
            btn.disabled = false;
            btn.textContent = originalText;
        });
    });
})();
</script>
        <?php
    }
}
