<?php
/**
 * Member 插件：用户中心面板模板
 * 依赖变量 $member_panel（由 template-functions.php 的 member_render_user_panel() 注入）。
 * 结构沿用本站 LitaPay 用户中心：外层块 -> h3 问候 -> 数值卡片 -> 操作卡片。
 */
if (!defined('ABSPATH')) exit;
?>
<div class="member-user-panel">
    <h3>欢迎, <?php echo e($member_panel['username']); ?>!</h3>

    <?php if (!empty($member_panel['flash'])): $f = $member_panel['flash']; ?>
    <div class="member-message-area <?php echo $f['type'] === 'success' ? 'success' : 'error'; ?>"><?php echo e($f['text']); ?></div>
    <?php endif; ?>

    <div class="member-points-card">
        <h4>我的积分（可用）</h4>
        <p class="member-points-amount"><span class="member-points-value"><?php echo (int) $member_panel['points']; ?></span></p>
    </div>

    <div class="member-level-card">
        <h4>累计积分 · 会员等级</h4>
        <p class="member-level-line">
            <span class="member-level-value member-level-value--<?php echo e($member_panel['key'] ?? 'normal'); ?>"><?php echo e($member_panel['label']); ?></span>
            <span class="member-total-hint">累计 <span class="member-total-value"><?php echo (int) $member_panel['total']; ?></span></span>
        </p>
        <?php $next = null; $levels = member_levels();
        foreach ($levels as $k => $lv) { if ($lv['min'] > $member_panel['total']) { $next = $lv; break; } }
        if ($next): ?>
        <p class="member-next-hint">距 <?php echo e($next['label']); ?> 还差 <?php echo (int) ($next['min'] - $member_panel['total']); ?> 累计积分</p>
        <?php endif; ?>
    </div>

    <div class="member-separator">充值码兑换积分</div>
    <div class="member-redeem-card">
        <p class="member-redeem-tip">输入充值码，按 <?php echo (float) $member_panel['rate']; ?> : 1 兑换积分（累计积分同步增加）</p>
        <form class="member-ajax-form member-redeem-form" method="post" action="">
            <input type="hidden" name="action" value="member_redeem">
            <input type="hidden" name="_ajax_csrf_token" value="<?php echo e($member_panel['redeem_token']); ?>">
            <input type="text" name="code" class="member-code-input" placeholder="请输入充值码" required autocomplete="off">
            <button type="submit" class="button member-btn member-redeem-btn">兑换积分</button>
        </form>
        <div class="member-message-area"></div>
    </div>

    <?php if (!empty($member_panel['global_price'])): ?>
    <div class="member-separator">全站会员</div>
    <div class="member-redeem-card">
        <?php if (!empty($member_panel['has_global'])): ?>
        <p class="member-login-prompt" style="color:#5cb85c;">已解锁全站会员 ✓ 全部会员文章可读</p>
        <?php else: ?>
        <p class="member-login-prompt">消耗 <b><?php echo (int) $member_panel['global_price']; ?></b> 积分开通全站会员，即可解锁全部积分文章（单篇 / 分类）。</p>
        <form class="member-ajax-form member-global-form" method="post" action="">
            <input type="hidden" name="action" value="member_global">
            <input type="hidden" name="_ajax_csrf_token" value="<?php echo e($member_panel['global_token']); ?>">
            <button type="submit" class="button member-btn member-global-btn">开通全站会员</button>
        </form>
        <div class="member-message-area"></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($member_panel['cats'])): ?>
    <div class="member-separator">分类会员</div>
    <?php foreach ($member_panel['cats'] as $cat): ?>
        <?php echo member_render_category_buy_row($cat, member_current_user_id(), $member_panel['cat_token']); ?>
    <?php endforeach; ?>
    <?php endif; ?>

    <div class="member-separator">积分用途</div>
    <p class="member-login-prompt">积分用于解锁会员文章阅读权限：<br>单篇文章 · 分类文章 · 全站内容</p>
</div>
