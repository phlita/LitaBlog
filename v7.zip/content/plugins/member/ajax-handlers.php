<?php
/**
 * Member 插件：请求处理
 *
 * 两条通道，共用同一套业务逻辑与 CSRF 令牌：
 *   1) AJAX 通道：JS 提交到 {SITE_URL}/ajax.php，带 action + _ajax_csrf_token，
 *      由框架统一校验 CSRF 与登录态后触发 wp_ajax_member_*。
 *   2) PRG 通道：未启用 JS 时表单原生提交到当前页，由 member_handle_frontend_posts()
 *      在 init 阶段处理（DOING_AJAX 未定义时才接管），处理成功后重定向回原页。
 */
if (!defined('ABSPATH')) exit;

/* ==================== 一、AJAX 通道 ==================== */

if (!function_exists('member_register_ajax_handlers')) {
    function member_register_ajax_handlers() {
        add_action('wp_ajax_member_purchase', 'member_ajax_purchase');
        add_action('wp_ajax_member_redeem', 'member_ajax_redeem');
        add_action('wp_ajax_member_global', 'member_ajax_global');
        add_action('wp_ajax_member_category', 'member_ajax_category');
    }
}

if (!function_exists('member_ajax_purchase')) {
    function member_ajax_purchase() {
        if (!is_logged_in()) {
            wp_send_json_error(array('message' => '请先登录。'), 403);
        }
        $post_id = (int) ($_POST['post_id'] ?? 0);
        $result  = member_purchase_for_post(member_current_user_id(), $post_id);
        if ($result['success']) {
            wp_send_json_success($result);
        }
        wp_send_json_error($result, 400);
    }
}

if (!function_exists('member_ajax_redeem')) {
    function member_ajax_redeem() {
        if (!is_logged_in()) {
            wp_send_json_error(array('message' => '请先登录。'), 403);
        }
        $code   = trim((string) ($_POST['code'] ?? ''));
        $result = member_redeem_code(member_current_user_id(), $code);
        if ($result['success']) {
            wp_send_json_success($result);
        }
        wp_send_json_error($result, 400);
    }
}

if (!function_exists('member_ajax_global')) {
    function member_ajax_global() {
        if (!is_logged_in()) {
            wp_send_json_error(array('message' => '请先登录。'), 403);
        }
        $result = member_buy_global_access(member_current_user_id());
        if ($result['success']) {
            wp_send_json_success($result);
        }
        wp_send_json_error($result, 400);
    }
}

if (!function_exists('member_ajax_category')) {
    function member_ajax_category() {
        if (!is_logged_in()) {
            wp_send_json_error(array('message' => '请先登录。'), 403);
        }
        $cat_id = (int) ($_POST['category_id'] ?? 0);
        $result = member_buy_category_access(member_current_user_id(), $cat_id);
        if ($result['success']) {
            wp_send_json_success($result);
        }
        wp_send_json_error($result, 400);
    }
}

/* ==================== 二、前台 PRG 保底通道 ==================== */

if (!function_exists('member_handle_frontend_posts')) {
    function member_handle_frontend_posts() {
        // AJAX 请求（v7/ajax.php 顶部已 define DOING_AJAX）：只走 wp_ajax 通道
        if (defined('DOING_AJAX')) {
            return;
        }
        // 后台请求不接管
        if (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') !== false) {
            return;
        }
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
            return;
        }

        $action = $_POST['action'] ?? '';
        if (!in_array($action, array('member_purchase', 'member_redeem', 'member_global', 'member_category'), true)) {
            return;
        }

        $back = $_SERVER['REQUEST_URI'] ?? (defined('SITE_URL') ? SITE_URL : '/');

        if (!is_logged_in()) {
            redirect(rtrim(defined('SITE_URL') ? SITE_URL : '', '/') . '/admin/login.php');
        }

        $token = $_POST['_ajax_csrf_token'] ?? '';
        if (!function_exists('verifyCsrfToken') || !verifyCsrfToken($token, $action, false)) {
            member_flash('error', '安全校验失败，请刷新后重试。');
            redirect($back);
        }

        $user_id = member_current_user_id();
        if ($action === 'member_purchase') {
            $post_id = (int) ($_POST['post_id'] ?? 0);
            $result  = member_purchase_for_post($user_id, $post_id);
        } elseif ($action === 'member_global') {
            $result = member_buy_global_access($user_id);
        } elseif ($action === 'member_category') {
            $cat_id = (int) ($_POST['category_id'] ?? 0);
            $result = member_buy_category_access($user_id, $cat_id);
        } else {
            $code   = trim((string) ($_POST['code'] ?? ''));
            $result = member_redeem_code($user_id, $code);
        }

        // 成功：正文解锁/积分到账即是反馈，直接回原页；失败：闪信提示
        if (!$result['success']) {
            member_flash('error', $result['message']);
        }
        redirect($back);
    }
}
