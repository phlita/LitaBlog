<?php
/**
 * Member 插件：卸载清理
 * 删除购买记录表与插件配置；用户的积分 usermeta（member_points / member_total_points）
 * 默认保留，如需清除请手动删除这两类 meta 记录。
 */
if (!defined('ABSPATH')) {
    exit;
}
if (!function_exists('get_db')) {
    exit;
}

try {
    $db = get_db();
    $db->exec('DROP TABLE IF EXISTS member_purchases');
    $stmt = $db->prepare(
        "DELETE FROM options WHERE name IN (
            'member_version','member_level_vip_min','member_level_svip_min',
            'member_recharge_rate','member_global_price','member_category_prices',
            'member_restrict_posting',
            'member_exchange_enabled','member_exchange_cost','member_checkin_reward'
        )"
    );
    $stmt->execute();
    // 清除文章定价 meta
    $stmt2 = $db->prepare("DELETE FROM postmeta WHERE meta_key = 'member_post_points'");
    $stmt2->execute();
} catch (Exception $e) {
    // 静默失败
}
