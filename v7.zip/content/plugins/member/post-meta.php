<?php
/**
 * Member 插件：文章编辑页的"积分定价"元框
 *
 * 渲染：挂 do_meta_boxes（admin/views/content.php 在文章表单内触发）
 * 保存：挂 save_post（admin/content.php 保存后触发，从 $_POST 读字段）
 * 单篇定价在这里设置，不再需要"范围定价"页里挑选文章。
 */
if (!defined('ABSPATH') || !is_admin()) {
    return;
}

if (!function_exists('member_render_price_meta_box')) {
    function member_render_price_meta_box($post_type, $context, $post_data) {
        // 仅管理员可设置帖子积分价格（双重防护：member.php 的 is_admin() 已限制加载本文件）
        if (!is_admin()) {
            return;
        }
        if ($context !== 'normal') {
            return;
        }
        if (!in_array($post_type, array('post', 'page'), true)) {
            return;
        }
        $post_id = isset($post_data['id']) ? (int) $post_data['id'] : 0;
        $current = $post_id ? (int) get_post_meta($post_id, 'member_post_points', true) : 0;
        ?>
        <div class="form-group member-meta-box-section">
            <h4>Member 积分定价</h4>
            <label for="member_post_points" style="display:inline-block; margin-right:5px;">
                <strong>解锁所需积分:</strong>
            </label>
            <input type="number" id="member_post_points" name="member_post_points"
                   value="<?php echo e($current); ?>" min="0" step="1"
                   class="form-control" style="display:inline-block; width:auto; max-width:100px; vertical-align:middle;"
                   placeholder="0">
            <p class="description" style="margin-top:5px;">
                设置后，本文需用积分购买才能阅读（0 = 免费）。默认按本页最便宜的解锁项扣费。
            </p>
        </div>
        <?php
    }
}
add_action('do_meta_boxes', 'member_render_price_meta_box', 11, 3);

if (!function_exists('member_save_price_meta')) {
    function member_save_price_meta($post_id, $post_data) {
        // 仅管理员可写入积分价格：非管理员即使伪造 member_post_points 字段也直接忽略
        if (!is_admin()) {
            return;
        }
        $post_id = (int) $post_id;
        if (!$post_id) {
            return;
        }
        // 仅当表单包含本字段时写入（避免误清其他流程）
        if (!isset($_POST['member_post_points'])) {
            return;
        }
        $value = max(0, (int) $_POST['member_post_points']);
        update_post_meta($post_id, 'member_post_points', $value);
    }
}
add_action('save_post', 'member_save_price_meta', 10, 2);
