<?php
/**
 * Member 插件：「积分调整」页（POST 处理 + 渲染）
 * 正数：入账（余额 + 累计，累计决定等级）；负数：出账（仅余额）。
 */
if (!defined('ABSPATH') || !is_admin()) {
    echo '<p>非法访问。</p>';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['member_adjust_points'])) {
    if (!isset($_POST['member_points_csrf']) || !verifyCsrfToken($_POST['member_points_csrf'], 'member_admin_points')) {
        set_flash_message('安全验证失败，请重试。', 'error');
    } else {
        $username = sanitize_text_field($_POST['member_target_username'] ?? '');
        $delta    = (int) ($_POST['member_points_delta'] ?? 0);

        if ($username === '' || $delta === 0) {
            set_flash_message('请输入用户名，且调整量不能为 0。', 'error');
        } else {
            $db    = get_db();
            $stmt  = $db->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
            $stmt->execute(array($username));
            $target = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$target) {
                set_flash_message('未找到用户：' . e($username), 'error');
            } else {
                $uid = (int) $target['id'];
                if ($delta > 0) {
                    $new = member_credit_points($uid, $delta);   // 余额 + 累计
                } else {
                    $new = member_debit_points($uid, -$delta);   // 仅余额
                }
                set_flash_message(
                    '已为用户 ' . e($username) . ' 调整积分 ' . $delta . '，当前可用积分：' . $new
                    . '（累计：' . member_get_total_points($uid) . '）',
                    'success'
                );
            }
        }
    }
    header('Location: admin.php?page=member-points');
    exit;
}
?>
<?php display_flash_message(); ?>
<div class="card">
    <h3>积分调整</h3>
    <p class="description">
        正数 = 入账（可用积分与累计积分同步增加，累计决定等级）；
        负数 = 出账（仅扣可用积分，不影响等级）。
    </p>
    <form method="POST" action="admin.php?page=member-points" class="litapay-settings-form">
        <input type="hidden" name="member_points_csrf" value="<?php echo generateCsrfToken('member_admin_points'); ?>">

        <div class="form-group">
            <label for="member_target_username">用户名</label>
            <input type="text" id="member_target_username" name="member_target_username"
                   class="form-control" style="width: 200px;" placeholder="如 admin" required>
        </div>

        <div class="form-group">
            <label for="member_points_delta">调整积分（正加负减）</label>
            <input type="number" id="member_points_delta" name="member_points_delta"
                   class="form-control" style="width: 140px;" value="100" required>
        </div>

        <p><button type="submit" name="member_adjust_points" class="button btn-primary">执行调整</button></p>
    </form>
</div>
