<?php
/**
 * Member 插件：数据层与业务逻辑
 *
 * 积分模型（行业标准口径）：
 *   member_points        可用积分（余额）——充值/发放增加；购买阅读权消耗
 *   member_total_points  累计获得总额——只增不减，决定会员等级
 * 存储复用框架已有 usermeta / options；仅购买记录建自有表 member_purchases。
 * 全部本地读写，无任何外部网络请求。
 */
if (!defined('ABSPATH')) exit;

/* ==================== 建表 ==================== */

if (!function_exists('member_create_tables')) {
    function member_create_tables() {
        $db = get_db();
        $sql = "CREATE TABLE IF NOT EXISTS member_purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            scope_type TEXT NOT NULL,                -- 'post' | 'category' | 'all'
            scope_id INTEGER NOT NULL DEFAULT 0,     -- post_id / category_id / 0(all)
            points_paid INTEGER NOT NULL DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )";
        try {
            $db->exec($sql);
            $db->exec('CREATE INDEX IF NOT EXISTS idx_member_purchases_user ON member_purchases(user_id)');
            $db->exec('CREATE INDEX IF NOT EXISTS idx_member_purchases_scope ON member_purchases(scope_type, scope_id)');
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}

/* ==================== 等级门槛配置 ==================== */

if (!function_exists('member_level_vip_min')) {
    function member_level_vip_min() {
        return (int) get_option('member_level_vip_min', 1000);
    }
}

if (!function_exists('member_level_svip_min')) {
    function member_level_svip_min() {
        return (int) get_option('member_level_svip_min', 5000);
    }
}

/* ==================== 充值汇率（litapay 金额→积分） ==================== */

if (!function_exists('member_recharge_rate')) {
    function member_recharge_rate() {
        $r = (float) get_option('member_recharge_rate', 1);
        return $r > 0 ? $r : 1;
    }
}

/* ==================== 范围定价存取 ==================== */

if (!function_exists('member_get_global_price')) {
    function member_get_global_price() {
        return (int) get_option('member_global_price', 0);
    }
}

if (!function_exists('member_set_global_price')) {
    function member_set_global_price($points) {
        return update_option('member_global_price', max(0, (int) $points));
    }
}

if (!function_exists('member_get_category_prices')) {
    function member_get_category_prices() {
        $raw = get_option('member_category_prices', '{}');
        $arr = json_decode($raw, true);
        return is_array($arr) ? $arr : array();
    }
}

if (!function_exists('member_set_category_price')) {
    function member_set_category_price($category_id, $points) {
        $cat_id = (int) $category_id;
        if ($cat_id <= 0) {
            return false;
        }
        $prices = member_get_category_prices();
        $points = (int) $points;
        if ($points <= 0) {
            unset($prices[$cat_id]);
        } else {
            $prices[$cat_id] = $points;
        }
        return update_option('member_category_prices', json_encode($prices));
    }
}

/* ==================== 用户标识 ==================== */

if (!function_exists('member_current_user_id')) {
    function member_current_user_id() {
        return (int) ($_SESSION['user_id'] ?? 0);
    }
}

/* ==================== 积分（余额 / 累计） ==================== */

if (!function_exists('member_get_points')) {
    function member_get_points($user_id = null) {
        if ($user_id === null) {
            $user_id = member_current_user_id();
        }
        if (!$user_id) {
            return 0;
        }
        $raw = get_user_meta($user_id, 'member_points', true);
        return is_numeric($raw) ? (int) $raw : 0;
    }
}

if (!function_exists('member_set_points')) {
    function member_set_points($user_id, $value) {
        $user_id = (int) $user_id;
        if (!$user_id) {
            return false;
        }
        update_user_meta($user_id, 'member_points', max(0, (int) $value));
        return true;
    }
}

if (!function_exists('member_get_total_points')) {
    function member_get_total_points($user_id = null) {
        if ($user_id === null) {
            $user_id = member_current_user_id();
        }
        if (!$user_id) {
            return 0;
        }
        $raw = get_user_meta($user_id, 'member_total_points', true);
        return is_numeric($raw) ? (int) $raw : 0;
    }
}

/**
 * 入账：可用余额与累计总额同时增加（充值 / 后台发放）
 * 累计总额只增不减，等级由它驱动。
 */
if (!function_exists('member_credit_points')) {
    function member_credit_points($user_id, $qty) {
        $user_id = (int) $user_id;
        $qty = (int) $qty;
        if (!$user_id || $qty <= 0) {
            return 0;
        }
        $new_bal   = member_get_points($user_id) + $qty;
        $new_total = member_get_total_points($user_id) + $qty;
        update_user_meta($user_id, 'member_points', $new_bal);
        update_user_meta($user_id, 'member_total_points', $new_total);
        return $new_bal;
    }
}

/**
 * 出账：仅扣可用余额，不影响累计总额（购买阅读权）
 */
if (!function_exists('member_debit_points')) {
    function member_debit_points($user_id, $qty) {
        $user_id = (int) $user_id;
        $qty = (int) $qty;
        if (!$user_id || $qty <= 0) {
            return 0;
        }
        $new_bal = max(0, member_get_points($user_id) - $qty);
        update_user_meta($user_id, 'member_points', $new_bal);
        return $new_bal;
    }
}

/* ==================== 会员等级（按累计总额） ==================== */

if (!function_exists('member_levels')) {
    function member_levels() {
        return array(
            'normal' => array('label' => '普通会员', 'min' => 0),
            'vip'    => array('label' => 'VIP 会员',  'min' => member_level_vip_min()),
            'svip'   => array('label' => 'SVIP 会员', 'min' => member_level_svip_min()),
        );
    }
}

if (!function_exists('member_get_membership')) {
    function member_get_membership($user_id = null) {
        $total  = member_get_total_points($user_id);
        $levels = member_levels();
        $current = 'normal';
        foreach ($levels as $key => $lv) {
            if ($total >= $lv['min']) {
                $current = $key;
            }
        }
        return array(
            'key'    => $current,
            'label'  => $levels[$current]['label'],
            'total'  => $total,
            'points' => member_get_points($user_id),
        );
    }
}

/* ==================== 发帖权限（仅管理员） ==================== */

/**
 * user_has_cap 过滤器：非管理员一律失去 publish_posts 能力。
 * 效果（框架同款判定）：
 *   - admin/content.php 整个发文/编辑界面对非管理员关闭（其顶部就校验 publish_posts）
 *   - 前台"快捷发文"UI 同样因 current_user_can('publish_posts') 为 false 而不再出现
 * 这同时堵死"作者把文章投进已积分定价分类 = 变相给自己的文章定价"的旁路。
 */
if (!function_exists('member_maybe_deny_publish')) {
    function member_maybe_deny_publish($has_cap, $capability, $user_role) {
        if ($user_role === 'administrator') {
            return $has_cap; // 管理员不受影响
        }
        if ($capability === 'publish_posts') {
            return false;
        }
        return $has_cap;
    }
}

/* ==================== 闪信（前台 PRG 通道提示） ==================== */

if (!function_exists('member_flash')) {
    function member_flash($type, $text) {
        $_SESSION['member_msg'] = array('type' => $type, 'text' => $text);
    }
}

if (!function_exists('member_consume_flash')) {
    function member_consume_flash() {
        if (empty($_SESSION['member_msg'])) {
            return null;
        }
        $msg = $_SESSION['member_msg'];
        unset($_SESSION['member_msg']);
        return $msg;
    }
}
