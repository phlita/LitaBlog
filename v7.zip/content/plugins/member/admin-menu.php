<?php
/**
 * Member 插件：后台菜单
 * 菜单结构：会员 -> 常规设置 / 范围定价 / 积分调整
 */
if (!defined('ABSPATH')) exit;

function member_register_admin_menus() {
    add_menu_page(
        'Member 会员设置',
        '会员',
        'manage_options',
        'member-main',
        'member_render_settings_page',
        '',
        76
    );

    add_submenu_page('member-main', 'Member 常规设置', '常规设置', 'manage_options', 'member-main', 'member_render_settings_page');
    add_submenu_page('member-main', 'Member 范围定价', '范围定价', 'manage_options', 'member-pricing', 'member_render_pricing_page');
    add_submenu_page('member-main', 'Member 充值码管理', '充值码管理', 'manage_options', 'member-codes', 'member_render_codes_page');
    add_submenu_page('member-main', 'Member 积分调整', '积分调整', 'manage_options', 'member-points', 'member_render_points_page');
}
add_action('admin_menu', 'member_register_admin_menus');

function member_render_settings_page() {
    if (!is_admin()) {
        echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
        return;
    }
    require_once MEMBER_PLUGIN_DIR . 'settings-page.php';
}

function member_render_pricing_page() {
    if (!is_admin()) {
        echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
        return;
    }
    require_once MEMBER_PLUGIN_DIR . 'pricing-page.php';
}

function member_render_points_page() {
    if (!is_admin()) {
        echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
        return;
    }
    require_once MEMBER_PLUGIN_DIR . 'points-page.php';
}

function member_render_codes_page() {
    if (!is_admin()) {
        echo '<div class="alert alert-danger">您没有权限访问此页面。</div>';
        return;
    }
    require_once MEMBER_PLUGIN_DIR . 'recharge-codes.php';
}
