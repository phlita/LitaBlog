<?php
/**
 * Member 插件：「常规设置」页（POST 处理 + 渲染）
 * 等级门槛（按累计积分）与充值汇率。
 */
if (!defined('ABSPATH') || !is_admin()) {
    echo '<p>非法访问。</p>';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['member_save_settings'])) {
    if (!isset($_POST['member_settings_csrf']) || !verifyCsrfToken($_POST['member_settings_csrf'], 'member_admin_settings')) {
        set_flash_message('安全验证失败，请重试。', 'error');
    } else {
        $vip  = (int) ($_POST['member_level_vip_min'] ?? 1000);
        $svip = (int) ($_POST['member_level_svip_min'] ?? 5000);
        if ($vip <= 0) { $vip = 1000; }
        if ($svip <= $vip) { $svip = $vip + 1000; }
        update_option('member_level_vip_min', $vip);
        update_option('member_level_svip_min', $svip);

        $rate = (float) ($_POST['member_recharge_rate'] ?? 1);
        if ($rate <= 0) { $rate = 1; }
        update_option('member_recharge_rate', $rate);

        update_option('member_restrict_posting', isset($_POST['member_restrict_posting']) ? '1' : '0');

        set_flash_message('Member 设置已保存。', 'success');
    }
    header('Location: admin.php?page=member-main');
    exit;
}

$vip     = member_level_vip_min();
$svip    = member_level_svip_min();
$rate    = member_recharge_rate();
$restrict = get_option('member_restrict_posting', '1') === '1';
?>
<?php display_flash_message(); ?>
<div class="card">
    <h3>常规设置</h3>
    <p class="description">会员等级由「累计获得积分」决定，充值/发放只增不减，消费不降级。</p>

    <div class="form-group">
        <label>
            <input type="checkbox" name="member_restrict_posting" value="1" <?php checked($restrict, true, true); ?>>
            仅管理员可发布/编辑文章
        </label>
        <p class="description">
            开启后非管理员将失去 publish_posts 能力：发文/编辑后台页与前台快捷发文均不可用，
            同时堵死"作者把文章投进已积分定价分类 = 变相给自己文章定价"的旁路。
        </p>
    </div>
    <form method="POST" action="admin.php?page=member-main" class="litapay-settings-form">
        <input type="hidden" name="member_settings_csrf" value="<?php echo generateCsrfToken('member_admin_settings'); ?>">

        <div class="form-group">
            <label for="member_level_vip_min">VIP 门槛（累计积分）</label>
            <input type="number" id="member_level_vip_min" name="member_level_vip_min"
                   value="<?php echo e($vip); ?>" min="1" step="1" class="form-control" style="width: 140px;">
        </div>

        <div class="form-group">
            <label for="member_level_svip_min">SVIP 门槛（累计积分）</label>
            <input type="number" id="member_level_svip_min" name="member_level_svip_min"
                   value="<?php echo e($svip); ?>" min="1" step="1" class="form-control" style="width: 140px;">
            <p class="description">须大于 VIP 门槛。</p>
        </div>

        <div class="form-group">
            <label for="member_recharge_rate">充值汇率（充值码金额 → 积分）</label>
            <input type="number" id="member_recharge_rate" name="member_recharge_rate"
                   value="<?php echo e($rate); ?>" min="0.01" step="0.01" class="form-control" style="width: 120px;">
            <p class="description">例如充值码面额 50，汇率 1 时到账 50 积分。充值码复用 LitaPay 码表。</p>
        </div>

        <p><button type="submit" name="member_save_settings" class="button btn-primary">保存设置</button></p>
    </form>
</div>
