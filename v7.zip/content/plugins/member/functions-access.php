<?php
/**
 * Member 插件：阅读权限门禁、购买解锁、充值码兑换积分
 *
 * 权限模型（独立于 LitaPay）：
 *   管理员可对三类"内容单元"定价：单篇(post_meta member_post_points)、
 *   分类(options member_category_prices)、全站(options member_global_price)。
 *   文章的访问选项 = 覆盖它的全部定价单元；任买其一即解锁该文。
 *   购买记录永久有效，存自有表 member_purchases。
 */
if (!defined('ABSPATH')) exit;

/* ==================== 充值码表（与 LitaPay 共用，缺失时自动创建） ==================== */

if (!function_exists('member_ensure_recharge_table')) {
    function member_ensure_recharge_table() {
        try {
            $db = get_db();
            $db->exec("CREATE TABLE IF NOT EXISTS litapay_recharge_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                amount REAL NOT NULL,
                status INTEGER DEFAULT 0,
                used_by_user_id INTEGER,
                used_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                notes TEXT
            )");
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}

if (!function_exists('member_generate_recharge_codes')) {
    function member_generate_recharge_codes($amount, $count, $notes = null) {
        member_ensure_recharge_table();
        try {
            $db = get_db();
            $ins = $db->prepare('INSERT INTO litapay_recharge_codes (code, amount, notes) VALUES (?, ?, ?)');
            $created = array();
            for ($i = 0; $i < (int) $count; $i++) {
                for ($try = 0; $try < 15; $try++) {
                    $code = 'M' . strtoupper(bin2hex(random_bytes(5)));
                    try {
                        $ins->execute(array($code, (float) $amount, $notes === null ? null : $notes));
                        $created[] = array('code' => $code, 'amount' => (float) $amount);
                        break;
                    } catch (Exception $e) {
                        // 唯一键冲突则重试
                    }
                }
            }
            return $created;
        } catch (Exception $e) {
            return array();
        }
    }
}

/* ==================== 分类会员（按分类购买） ==================== */

/**
 * 已定价分类清单（含名称与价格），供"分类会员"购买入口使用
 * @return array [ {id, name, points} ... ] 按名称排序
 */
if (!function_exists('member_priced_categories')) {
    function member_priced_categories() {
        $map = member_get_category_prices();
        if (empty($map)) {
            return array();
        }
        $ids = array_map('intval', array_keys($map));
        try {
            $db = get_db();
            $in = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $db->prepare("SELECT id, name FROM categories WHERE id IN ($in) ORDER BY name");
            $stmt->execute($ids);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $rows = array();
        }
        $out = array();
        foreach ($rows as $r) {
            $cid = (int) $r['id'];
            if (isset($map[$cid]) && (int) $map[$cid] > 0) {
                $out[] = array('id' => $cid, 'name' => $r['name'], 'points' => (int) $map[$cid]);
            }
        }
        return $out;
    }
}

/**
 * 购买分类会员：解锁该分类全部文章（永久）
 */
if (!function_exists('member_buy_category_access')) {
    function member_buy_category_access($user_id, $cat_id) {
        $user_id = (int) $user_id;
        $cat_id  = (int) $cat_id;
        if (!$user_id) {
            return array('success' => false, 'message' => '请先登录。');
        }
        if (!$cat_id) {
            return array('success' => false, 'message' => '参数错误。');
        }
        $prices = member_get_category_prices();
        $price  = isset($prices[$cat_id]) ? (int) $prices[$cat_id] : 0;
        if ($price <= 0) {
            return array('success' => false, 'message' => '该分类未开放会员购买。');
        }
        if (member_has_purchase($user_id, 'category', $cat_id)) {
            return array('success' => false, 'message' => '您已拥有该分类会员。');
        }
        if (member_get_points($user_id) < $price) {
            return array('success' => false, 'message' => '积分不足，需要 ' . $price . ' 积分。当前余额：' . member_get_points($user_id));
        }
        try {
            $db = get_db();
            $stmt = $db->prepare(
                'INSERT INTO member_purchases (user_id, scope_type, scope_id, points_paid) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute(array($user_id, 'category', $cat_id, $price));
        } catch (Exception $e) {
            return array('success' => false, 'message' => '购买记录写入失败，请稍后重试。');
        }
        $new_balance = member_debit_points($user_id, $price);
        return array(
            'success' => true,
            'message' => '分类会员开通成功！已扣除 ' . $price . ' 积分，该分类全部文章已解锁。',
            'points'  => $new_balance,
        );
    }
}

/* ==================== 文章所属分类 ==================== */

if (!function_exists('member_get_post_category_ids')) {
    function member_get_post_category_ids($post_id) {
        $post_id = (int) $post_id;
        if (!$post_id) {
            return array();
        }
        try {
            $db = get_db();
            $stmt = $db->prepare('SELECT category_id FROM post_categories WHERE post_id = ?');
            $stmt->execute(array($post_id));
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $ids = array();
            foreach ($rows as $r) {
                $ids[] = (int) $r['category_id'];
            }
            return $ids;
        } catch (Exception $e) {
            return array();
        }
    }
}

/* ==================== 文章的有效访问选项 ==================== */

if (!function_exists('member_post_access_options')) {
    function member_post_access_options($post_id) {
        $post_id = (int) $post_id;
        if (!$post_id) {
            return array();
        }
        $options = array();

        // 1) 单篇自身定价
        $self = (int) get_post_meta($post_id, 'member_post_points', true);
        if ($self > 0) {
            $options[] = array('type' => 'post', 'id' => $post_id, 'price' => $self);
        }

        // 2) 所属分类定价
        $cat_prices = member_get_category_prices();
        if (!empty($cat_prices)) {
            foreach (member_get_post_category_ids($post_id) as $cat_id) {
                if (isset($cat_prices[$cat_id]) && (int) $cat_prices[$cat_id] > 0) {
                    $options[] = array('type' => 'category', 'id' => $cat_id, 'price' => (int) $cat_prices[$cat_id]);
                }
            }
        }

        // 注意：全站价不在此注入——"全站通行证"只解锁"需要积分的文章"，
        // 不把未定价的免费文章误锁进积分墙。是否已购全站由 member_has_access 单独判定。

        // 按价格升序，供"买最便宜覆盖项"使用
        usort($options, function ($a, $b) {
            return $a['price'] <=> $b['price'];
        });
        return $options;
    }
}

/* ==================== 购买记录 ==================== */

if (!function_exists('member_has_purchase')) {
    function member_has_purchase($user_id, $scope_type, $scope_id) {
        $user_id = (int) $user_id;
        if (!$user_id) {
            return false;
        }
        try {
            $db = get_db();
            $stmt = $db->prepare(
                'SELECT COUNT(*) FROM member_purchases
                 WHERE user_id = ? AND scope_type = ? AND scope_id = ?'
            );
            $stmt->execute(array($user_id, $scope_type, (int) $scope_id));
            return (int) $stmt->fetchColumn() > 0;
        } catch (Exception $e) {
            return false;
        }
    }
}

if (!function_exists('member_has_global_access')) {
    function member_has_global_access($user_id = null) {
        if ($user_id === null) {
            $user_id = member_current_user_id();
        }
        return member_has_purchase((int) $user_id, 'all', 0);
    }
}

if (!function_exists('member_has_access')) {
    function member_has_access($user_id, $post_id) {
        $user_id = (int) $user_id;
        if (!$user_id) {
            return false;
        }
        $options = member_post_access_options($post_id);
        if (empty($options)) {
            return true; // 未定价内容，视为免费
        }
        // 已购全站通行证：解锁所有"需要积分"的文章
        if (member_has_global_access($user_id)) {
            return true;
        }
        foreach ($options as $opt) {
            if (member_has_purchase($user_id, $opt['type'], $opt['id'])) {
                return true;
            }
        }
        return false;
    }
}

/**
 * 购买全站通行证（type=all, id=0）
 */
if (!function_exists('member_buy_global_access')) {
    function member_buy_global_access($user_id) {
        $user_id = (int) $user_id;
        if (!$user_id) {
            return array('success' => false, 'message' => '请先登录。');
        }
        $price = member_get_global_price();
        if ($price <= 0) {
            return array('success' => false, 'message' => '全站会员未开放购买。');
        }
        if (member_has_global_access($user_id)) {
            return array('success' => false, 'message' => '您已拥有全站会员。');
        }
        if (member_get_points($user_id) < $price) {
            return array('success' => false, 'message' => '积分不足，需要 ' . $price . ' 积分。当前余额：' . member_get_points($user_id));
        }
        try {
            $db = get_db();
            $stmt = $db->prepare(
                'INSERT INTO member_purchases (user_id, scope_type, scope_id, points_paid) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute(array($user_id, 'all', 0, $price));
        } catch (Exception $e) {
            return array('success' => false, 'message' => '购买记录写入失败，请稍后重试。');
        }
        $new_balance = member_debit_points($user_id, $price);
        return array(
            'success' => true,
            'message' => '全站会员开通成功！已扣除 ' . $price . ' 积分，全部会员文章已解锁。',
            'points'  => $new_balance,
        );
    }
}

/**
 * 最便宜的"未购买"解锁项
 */
if (!function_exists('member_best_buy_option')) {
    function member_best_buy_option($user_id, $post_id) {
        $options = member_post_access_options($post_id);
        foreach ($options as $opt) {
            if (!member_has_purchase($user_id, $opt['type'], $opt['id'])) {
                return $opt;
            }
        }
        return false; // 全覆盖项均已购买（理论上不会走到）
    }
}

/**
 * 执行购买：扣积分余额 + 写购买记录（永久）
 */
if (!function_exists('member_purchase_for_post')) {
    function member_purchase_for_post($user_id, $post_id) {
        $user_id = (int) $user_id;
        $post_id = (int) $post_id;
        if (!$user_id) {
            return array('success' => false, 'message' => '请先登录。');
        }
        if (!$post_id) {
            return array('success' => false, 'message' => '参数错误。');
        }
        if (member_has_access($user_id, $post_id)) {
            return array('success' => false, 'message' => '您已拥有本文阅读权限。');
        }

        $opt = member_best_buy_option($user_id, $post_id);
        if (!$opt) {
            return array('success' => false, 'message' => '无可购项或已全部购买。');
        }

        $price = (int) $opt['price'];
        if ($price <= 0) {
            return array('success' => false, 'message' => '定价异常，请联系管理员。');
        }
        if (member_get_points($user_id) < $price) {
            return array('success' => false, 'message' => '积分不足，需要 ' . $price . ' 积分。当前余额：' . member_get_points($user_id));
        }

        // 先写购买记录，再扣余额（若扣款失败回滚记录）
        try {
            $db = get_db();
            $stmt = $db->prepare(
                'INSERT INTO member_purchases (user_id, scope_type, scope_id, points_paid) VALUES (?, ?, ?, ?)'
            );
            $stmt->execute(array($user_id, $opt['type'], $opt['id'], $price));
        } catch (Exception $e) {
            return array('success' => false, 'message' => '购买记录写入失败，请稍后重试。');
        }

        $new_balance = member_debit_points($user_id, $price);
        return array(
            'success' => true,
            'message' => '解锁成功！已扣除 ' . $price . ' 积分。',
            'points'  => $new_balance,
            'scope'   => $opt['type'],
        );
    }
}

/* ==================== 充值码 → 积分（复用 litapay 码表） ==================== */

if (!function_exists('member_redeem_code')) {
    function member_redeem_code($user_id, $code) {
        $user_id = (int) $user_id;
        $code    = trim((string) $code);
        if (!$user_id) {
            return array('success' => false, 'message' => '请先登录。');
        }
        if ($code === '') {
            return array('success' => false, 'message' => '请输入充值码。');
        }

        try {
            $db = get_db();
            $stmt = $db->prepare(
                'SELECT id, amount, status FROM litapay_recharge_codes WHERE code = ? LIMIT 1'
            );
            $stmt->execute(array($code));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return array('success' => false, 'message' => '充值系统不可用，请稍后重试。');
        }

        if (!$row) {
            return array('success' => false, 'message' => '充值码无效。');
        }
        if ((int) $row['status'] !== 0) {
            return array('success' => false, 'message' => '充值码已被使用或已停用。');
        }

        $rate  = member_recharge_rate();
        $qty   = (int) round((float) $row['amount'] * $rate);
        if ($qty <= 0) {
            return array('success' => false, 'message' => '充值码金额异常。');
        }

        try {
            $upd = $db->prepare(
                "UPDATE litapay_recharge_codes SET status = 1, used_by_user_id = ?, used_at = datetime('now') WHERE id = ? AND status = 0"
            );
            $upd->execute(array($user_id, (int) $row['id']));
            if ($upd->rowCount() !== 1) {
                return array('success' => false, 'message' => '充值码状态已变化，请刷新重试。');
            }
        } catch (Exception $e) {
            return array('success' => false, 'message' => '充值码核销失败，请稍后重试。');
        }

        $new_balance = member_credit_points($user_id, $qty);
        $mm = member_get_membership($user_id);
        return array(
            'success' => true,
            'message' => '充值成功！积分 +' . $qty . '。',
            'points'  => $new_balance,
            'total'   => $mm['total'],
            'label'   => $mm['label'],
        );
    }
}

/* ==================== 内容门禁（the_content 过滤） ==================== */

if (!function_exists('member_filter_post_content')) {
    function member_filter_post_content($content, $post_id_from_filter = null) {
        $post_id = $post_id_from_filter;
        if (!$post_id) {
            global $main_object;
            if (isset($main_object['id']) && !empty($main_object['type'])) {
                $post_id = (int) $main_object['id'];
            }
        }
        $post_id = (int) $post_id;
        if (!$post_id) {
            return $content;
        }

        $options = member_post_access_options($post_id);
        if (empty($options)) {
            return $content; // 免费
        }

        // 管理员与已购用户直接放行
        if (is_admin() || !is_logged_in()) {
            if (is_admin()) {
                return $content;
            }
            // 未登录：显示登录锁
            return member_render_lock_box($post_id, $options, false);
        }

        $user_id = member_current_user_id();
        if (member_has_access($user_id, $post_id)) {
            return $content;
        }

        return member_render_lock_box($post_id, $options, true);
    }
}

/**
 * 渲染锁区（替换正文）
 */
if (!function_exists('member_render_lock_box')) {
    function member_render_lock_box($post_id, $options, $logged_in) {
        // 展示最便宜的解锁项
        $best = !empty($options) ? $options[0] : false;
        $price = $best ? (int) $best['price'] : 0;

        $login = rtrim(defined('SITE_URL') ? SITE_URL : '', '/');

        $html  = '<div class="member-lock">';
        $html .= '<p class="member-lock-title">本文为会员阅读内容</p>';
        $html .= '<p class="member-lock-desc">消耗 <b>' . $price . '</b> 积分即可解锁本文' . ($best && $best['type'] === 'category' ? '（含同分类文章）' : '') . '。</p>';

        if (!$logged_in) {
            $html .= '<p class="member-login-prompt"><a href="' . e($login) . '/admin/login.php">登录</a> 后可使用积分解锁。</p>';
        } else {
            // 前台 PRG 通道失败时的闪信
            $msg = member_consume_flash();
            if ($msg) {
                $html .= '<div class="member-message-area ' . ($msg['type'] === 'success' ? 'success' : 'error') . '">' . e($msg['text']) . '</div>';
            }
            $token = function_exists('generateCsrfToken') ? generateCsrfToken('member_purchase') : '';
            $html .= '<form class="member-ajax-form member-purchase-form" method="post" action="">';
            $html .= '<input type="hidden" name="action" value="member_purchase">';
            $html .= '<input type="hidden" name="post_id" value="' . (int) $post_id . '">';
            $html .= '<input type="hidden" name="_ajax_csrf_token" value="' . e($token) . '">';
            $html .= '<button type="submit" class="button member-btn member-purchase-btn">花费 ' . $price . ' 积分解锁</button>';
            $html .= '</form>';
            $html .= '<div class="member-message-area"></div>';
        }

        $html .= '</div>';
        return $html;
    }
}
