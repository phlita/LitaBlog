<?php
/**
 * Member 插件：「范围定价」页（POST 处理 + 渲染）
 * 全站 / 分类定价在此管理；单篇文章定价请在文章编辑页的
 * "Member 积分定价"元框内设置。
 */
if (!defined('ABSPATH') || !is_admin()) {
    echo '<p>非法访问。</p>';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['member_pricing_csrf']) || !verifyCsrfToken($_POST['member_pricing_csrf'], 'member_admin_pricing')) {
        set_flash_message('安全验证失败，请重试。', 'error');
        header('Location: admin.php?page=member-pricing');
        exit;
    }

    if (isset($_POST['member_save_global'])) {
        member_set_global_price((int) ($_POST['member_global_price'] ?? 0));
        set_flash_message('全站定价已保存（0 = 关闭全站购买）。', 'success');
        header('Location: admin.php?page=member-pricing');
        exit;
    }

    if (isset($_POST['member_add_category'])) {
        $cat_id = (int) ($_POST['member_category_id'] ?? 0);
        $points = (int) ($_POST['member_category_points'] ?? 0);
        if ($cat_id <= 0 || $points <= 0) {
            set_flash_message('请选择分类且积分须大于 0。', 'error');
        } else {
            member_set_category_price($cat_id, $points);
            set_flash_message('分类定价已保存。', 'success');
        }
        header('Location: admin.php?page=member-pricing');
        exit;
    }

    if (isset($_POST['member_remove_category'])) {
        member_set_category_price((int) ($_POST['member_category_id'] ?? 0), 0);
        set_flash_message('已移除该分类定价。', 'success');
        header('Location: admin.php?page=member-pricing');
        exit;
    }
}

$global_price = member_get_global_price();
$cat_prices   = member_get_category_prices();
$db           = get_db();
$categories   = array();
try {
    $categories = $db->query('SELECT id, name, slug FROM categories ORDER BY name LIMIT 500')->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $categories = array();
}
?>
<?php display_flash_message(); ?>

<div class="card">
    <h3>全站定价</h3>
    <p class="description">购买后解锁本站全部付费文章。0 = 不开放全站购买。</p>
    <form method="POST" action="admin.php?page=member-pricing" class="litapay-settings-form">
        <input type="hidden" name="member_pricing_csrf" value="<?php echo generateCsrfToken('member_admin_pricing'); ?>">
        <input type="number" name="member_global_price" value="<?php echo e($global_price); ?>" min="0" step="1" class="form-control" style="width: 120px;">
        <button type="submit" name="member_save_global" class="button btn-primary">保存全站价</button>
    </form>
</div>

<div class="card">
    <h3>分类定价</h3>
    <p class="description">购买某个分类后，解锁该分类下的全部文章。</p>
    <form method="POST" action="admin.php?page=member-pricing" class="litapay-settings-form">
        <input type="hidden" name="member_pricing_csrf" value="<?php echo generateCsrfToken('member_admin_pricing'); ?>">
        <div class="form-group">
            <label for="member_category_id">分类</label>
            <select name="member_category_id" id="member_category_id" class="form-control">
                <?php if (empty($categories)): ?><option value="0">暂无分类</option><?php endif; ?>
                <?php foreach ($categories as $c): ?>
                <option value="<?php echo (int) $c['id']; ?>"><?php echo e($c['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <label for="member_category_points">解锁所需积分</label>
            <input type="number" name="member_category_points" id="member_category_points" value="200" min="1" step="1" class="form-control" style="width: 120px;">
            <button type="submit" name="member_add_category" class="button btn-primary">添加/更新分类价</button>
        </div>
    </form>

    <?php if (!empty($cat_prices)): ?>
    <h4>已定价分类</h4>
    <table class="widefat striped" style="margin-top:10px;">
        <thead><tr><th>分类</th><th>积分</th><th>操作</th></tr></thead>
        <tbody>
        <?php foreach ($cat_prices as $cid => $cpoints): $cname = '分类 #' . $cid; foreach ($categories as $c) { if ((int) $c['id'] === (int) $cid) { $cname = $c['name']; break; } } ?>
            <tr>
                <td><?php echo e($cname); ?></td>
                <td><?php echo (int) $cpoints; ?></td>
                <td>
                    <form method="POST" action="admin.php?page=member-pricing" style="display:inline;">
                        <input type="hidden" name="member_pricing_csrf" value="<?php echo generateCsrfToken('member_admin_pricing'); ?>">
                        <input type="hidden" name="member_category_id" value="<?php echo (int) $cid; ?>">
                        <button type="submit" name="member_remove_category" class="button">移除</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
