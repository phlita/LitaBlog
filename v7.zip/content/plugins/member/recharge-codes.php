<?php
/**
 * Member 插件：「充值码管理」页（生成 + 列表）
 * 生成的充值码写入 litapay_recharge_codes（与 LitaPay 共用同一码池）。
 * 表不存在时自动按 LitaPay 结构创建，因此不依赖 LitaPay 是否启用。
 */
if (!defined('ABSPATH') || !is_admin()) {
    echo '<p>非法访问。</p>';
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['member_generate_codes'])) {
    if (!isset($_POST['member_codes_csrf']) || !verifyCsrfToken($_POST['member_codes_csrf'], 'member_admin_codes')) {
        set_flash_message('安全验证失败，请重试。', 'error');
    } else {
        $count  = (int) ($_POST['generate_count'] ?? 0);
        $amount = filter_var($_POST['generate_amount'] ?? 0, FILTER_VALIDATE_FLOAT);
        $notes  = isset($_POST['generate_notes']) ? sanitize_text_field($_POST['generate_notes']) : null;

        if ($count < 1 || $count > 100 || $amount === false || $amount <= 0) {
            set_flash_message('生成数量须在 1-100，面额须大于 0。', 'error');
        } else {
            $generated = member_generate_recharge_codes($amount, $count, $notes);
            if (!empty($generated)) {
                $_SESSION['member_last_generated_codes'] = $generated;
                set_flash_message('已生成 ' . count($generated) . ' 个充值码。', 'success');
            } else {
                set_flash_message('生成充值码失败，请检查日志。', 'error');
            }
        }
    }
    header('Location: admin.php?page=member-codes');
    exit;
}

$db = get_db();
$codes = array();
try {
    $codes = $db->query(
        'SELECT id, code, amount, status, used_by_user_id, used_at, created_at, notes
         FROM litapay_recharge_codes ORDER BY id DESC LIMIT 60'
    )->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $codes = array();
}
$last_generated = $_SESSION['member_last_generated_codes'] ?? array();
unset($_SESSION['member_last_generated_codes']);
?>
<?php display_flash_message(); ?>

<?php if (!empty($last_generated)): ?>
<div class="card">
    <h3>本次生成的充值码</h3>
    <textarea class="form-control" rows="5" readonly onclick="this.select()"><?php
        foreach ($last_generated as $g) {
            echo e($g['code'] . "\t面额 " . rtrim(rtrim(number_format((float) $g['amount'], 2, '.', ''), '0'), '.') . "\n");
        }
    ?></textarea>
</div>
<?php endif; ?>

<div class="card">
    <h3>批量生成充值码</h3>
    <form method="POST" action="admin.php?page=member-codes" class="litapay-settings-form">
        <input type="hidden" name="member_codes_csrf" value="<?php echo generateCsrfToken('member_admin_codes'); ?>">

        <div class="form-group">
            <label for="generate_count">数量（1-100）</label>
            <input type="number" id="generate_count" name="generate_count" value="10" min="1" max="100" step="1"
                   class="form-control" style="width: 120px;">
        </div>

        <div class="form-group">
            <label for="generate_amount">单张面额（充值码金额 → 按汇率转积分）</label>
            <input type="number" id="generate_amount" name="generate_amount" value="10" min="0.01" step="0.01"
                   class="form-control" style="width: 120px;">
        </div>

        <div class="form-group">
            <label for="generate_notes">备注（可选）</label>
            <input type="text" id="generate_notes" name="generate_notes" class="form-control" style="width: 240px;">
        </div>

        <p><button type="submit" name="member_generate_codes" class="button btn-primary">生成充值码</button></p>
    </form>
</div>

<div class="card">
    <h3>充值码列表（最近 60 条）</h3>
    <table class="widefat striped" style="margin-top:10px;">
        <thead><tr><th>ID</th><th>充值码</th><th>面额</th><th>状态</th><th>使用者</th><th>使用时间</th><th>创建时间</th></tr></thead>
        <tbody>
        <?php if (empty($codes)): ?>
            <tr><td colspan="7">暂无充值码。使用上方表单生成。</td></tr>
        <?php endif; ?>
        <?php foreach ($codes as $c): $st = (int) $c['status']; ?>
            <tr>
                <td><?php echo (int) $c['id']; ?></td>
                <td><code><?php echo e($c['code']); ?></code></td>
                <td><?php echo rtrim(rtrim(number_format((float) $c['amount'], 2, '.', ''), '0'), '.'); ?></td>
                <td><?php echo $st === 0 ? '<span style="color:#5cb85c;">可用</span>' : ($st === 1 ? '<span style="color:#d9534f;">已使用</span>' : '<span>停用</span>'); ?></td>
                <td><?php echo $c['used_by_user_id'] ? '#' . (int) $c['used_by_user_id'] : '-'; ?></td>
                <td><?php echo e($c['used_at'] ?? '-'); ?></td>
                <td><?php echo e($c['created_at'] ?? '-'); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
