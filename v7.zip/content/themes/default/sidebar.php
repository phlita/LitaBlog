<?php
defined('CORE') || die('Direct access not allowed.');
// This file is usually included by footer.php or another template file.
// It assumes $template_data is available in the scope where it's included.
?>
<?php if (isset($template_data['widgets']) && is_array($template_data['widgets']) && !empty($template_data['widgets'])) : ?>
<aside class="sidebar">
<?php foreach ($template_data['widgets'] as $widget) : ?>
<div class="widget widget-<?php echo isset($widget['type']) ? e($widget['type']) : 'text'; ?>">
<?php if (isset($widget['title']) && !empty($widget['title'])) : ?>
<h3 class="widget-title"><?php echo e($widget['title']); ?></h3>
<?php endif; ?>
<div class="widget-content">
<?php
$content = isset($widget['content']) ? $widget['content'] : '';
$type = isset($widget['type']) ? $widget['type'] : 'text';
if ($type === 'text') {
echo nl2br(e($content)); // Escape text content and add line breaks
} elseif ($type === 'html') {
 echo litablog_purify_html($content); // 引入二次输出过滤
} else {
// Handle potential future widget types here
echo e($content); // Default to escaped text
}
?>
</div>
</div>
<?php endforeach; ?>
</aside>
<?php endif; ?>