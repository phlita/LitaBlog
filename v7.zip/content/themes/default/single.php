<?php defined('CORE') || die('Direct access not allowed.');
/**
* The template for displaying all single posts and pages.
*/
require_once __DIR__ . '/header.php';
?>
<?php if (isset($template_data['post']) && !empty($template_data['post'])) : ?>
<?php $post = $template_data['post']; ?>
<article id="post-<?php echo $post['id']; ?>" class="single-post">
<header class="entry-header">
<h1 class="post-title"><?php echo e($post['title']); ?></h1>
<div class="post-meta">
<span class="posted-on">
<time datetime="<?php echo date('c', strtotime($post['created'])); ?>">
<?php echo e($post['formatted_datetime']); ?>
</time>
</span>
</div><!-- .post-meta -->
</header><!-- .entry-header -->
<div class="entry-content">
<?php echo $post['content']; // Output raw post content (assuming it's safe HTML from editor) ?>
</div><!-- .entry-content -->
<footer class="entry-footer">
<?php // Maybe add post navigation (prev/next) links here if function exists ?>
</footer><!-- .entry-footer -->
</article><!-- #post-<?php echo $post['id']; ?> -->

<?php // Comments Section ?>
<?php if (isset($template_data['enable_comments']) && $template_data['enable_comments']) : ?>
<div class="comments-area">
<?php if (isset($template_data['comments']) && !empty($template_data['comments'])) : ?>
<h2 class="comments-title">
<span class="comment-count">
<?php
$comment_count = count($template_data['comments']);
if ($comment_count == 1) {
echo '1';
} else {
echo $comment_count;
}
?>
</span> Comments
</h2>
<ol class="comment-list">
<?php foreach ($template_data['comments'] as $comment) : ?>
<li id="comment-<?php echo $comment['id']; ?>" class="comment">
<article class="comment-body">
<footer class="comment-meta">
<div class="comment-author vcard">
<?php // Display author name (user or guest) ?>
<b><?php echo e($comment['author_name']); ?></b>
</div>
<div class="comment-metadata">
<a href="#comment-<?php echo $comment['id']; ?>">
<time datetime="<?php echo date('c', strtotime($comment['created'])); ?>">
<?php echo e($comment['formatted_datetime']); ?>
</time>
</a>
<?php // Add edit/delete links for admins/owners ?>
<?php if (
isset($template_data['is_logged_in']) && $template_data['is_logged_in'] && 
(isset($template_data['is_admin']) && $template_data['is_admin'])
): ?>
<span class="comment-actions">
<a href="#" class="delete-comment" data-comment-id="<?php echo $comment['id']; ?>" data-csrf="<?php echo e(generateCsrfToken('delete_comment_' . $comment['id'])); ?>">删除</a>
</span>
<?php endif; ?>
</div>
</footer>
<div class="comment-content">
<?php echo nl2br(e($comment['content'])); ?>
</div>
</article>
</li>
<?php endforeach; ?>
</ol>
<?php else: ?>
<h2 class="comments-title"><span class="comment-count">0</span> Comments</h2>
<ol class="comment-list"></ol>
<?php endif; ?>

<?php // Comment Form ?>
<div id="respond" class="comment-respond">
<?php if (isset($template_data['is_logged_in']) && $template_data['is_logged_in'] && isset($template_data['current_user'])) : ?>
<?php // E-7:评论区仅登录用户渲染可提交表单(匿名命中整页缓存,无有效 CSRF session,故不输出可写表单) ?>
<h3 id="reply-title" class="comment-reply-title">Leave a Comment</h3>

<!-- Fix #1: Make sure the action URL is absolute and correct -->
<form action="<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>" method="post" id="commentform" class="comment-form">
<p class="logged-in-as">您已登录为：<strong><?php echo e(user_display_name($template_data['current_user'])); ?></strong>. <a href="<?php echo SITE_URL; ?>/admin/logout.php?csrf_token=<?php echo generateCsrfToken('user_logout'); ?>">登出?</a></p>

<p class="comment-form-comment">
<label for="comment">Comment <span class="required">*</span></label>
<textarea id="comment" name="content" cols="45" rows="8" required="required"></textarea>
</p>
<p class="form-submit">
<input name="submit" type="submit" id="submit" class="submit" value="Post Comment">
<input type="hidden" name="action" value="add">
<input type="hidden" name="post_id" value="<?php echo $post['id']; ?>" id="comment_post_ID">
<!-- Fix #2: Add CSRF token for security if available -->
<?php if (function_exists('csrf_token_field')) csrf_token_field('add_comment'); ?>
</p>

<!-- 添加AJAX提交状态指示器 -->
<div id="comment-status" style="display: none;">
<p class="comment-waiting">正在提交评论，请稍候...</p>
</div>
</form>
<?php else : ?>
<h3 id="reply-title" class="comment-reply-title">Leave a Comment</h3>
<p class="comment-login-tip">请 <a href="<?php echo SITE_URL; ?>/admin/login.php">登录</a> 后参与评论。</p>
<?php endif; ?>
</div><!-- #respond -->
</div><!-- .comments-area -->
<?php endif; // end enable_comments check ?>

<?php else : ?>
<p>Sorry, the requested post could not be found.</p>
<?php
// Explicitly set 404 header if we reach here, though router should handle it
if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
?>
<?php endif; ?>

<!-- 添加JavaScript，在footer.php之前 -->
<script>
document.addEventListener('DOMContentLoaded', function() {
// 获取评论表单
const commentForm = document.getElementById('commentform');
if (commentForm) {
commentForm.addEventListener('submit', function(e) {
e.preventDefault(); // 阻止表单默认提交

// 显示提交状态
const statusDiv = document.getElementById('comment-status');
const submitBtn = document.getElementById('submit');

statusDiv.style.display = 'block';
submitBtn.disabled = true;
submitBtn.value = '提交中...';

// 创建FormData对象
const formData = new FormData(commentForm);

// Fix #3: Hardcode the URL if needed instead of using commentForm.action
// which could potentially be wrong
const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

// 发送AJAX请求
fetch(commentUrl, {
method: 'POST',
body: formData,
headers: {
'X-Requested-With': 'XMLHttpRequest'
}
})
.then(response => {
// Fix #4: Check if response is OK before parsing JSON
if (!response.ok) {
throw new Error('Server responded with status: ' + response.status);
}
return response.json();
})
.then(data => {
// 重置状态
statusDiv.style.display = 'none';
submitBtn.disabled = false;
submitBtn.value = 'Post Comment';

if (data.success) {
// 评论成功

// 清空评论框
document.getElementById('comment').value = '';

// 如果是非登录用户，也清空名称和邮箱
const authorInput = document.getElementById('author');
const emailInput = document.getElementById('email');
if (authorInput) authorInput.value = '';
if (emailInput) emailInput.value = '';

// 创建新评论元素并添加到评论列表
addNewComment();

// 显示成功消息
showNotification('评论已成功提交', 'success');
} else {
// 评论失败
showNotification(data.error || '评论提交失败', 'error');
}
})
.catch(error => {
console.error('Error:', error);
statusDiv.style.display = 'none';
submitBtn.disabled = false;
submitBtn.value = 'Post Comment';
showNotification('提交时发生错误，请稍后重试: ' + error.message, 'error');
});
});
}

// 处理评论删除
document.addEventListener('click', function(e) {
if (e.target && e.target.classList.contains('delete-comment')) {
e.preventDefault();

if (confirm('确定要删除这条评论吗？')) {
const commentId = e.target.getAttribute('data-comment-id');
const commentElement = document.getElementById('comment-' + commentId);
const csrfToken = e.target.getAttribute('data-csrf'); // 获取 Token
// 创建删除请求的表单数据
const formData = new FormData();
formData.append('action', 'delete');
formData.append('comment_id', commentId);
formData.append('csrf_token', csrfToken); // 追加 Token
// Fix #5: Use hardcoded URL here too
const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

// 发送删除请求
fetch(commentUrl, {
method: 'POST',
body: formData,
headers: {
'X-Requested-With': 'XMLHttpRequest'
}
})
.then(response => {
// Fix #6: Check if response is OK before parsing JSON
if (!response.ok) {
throw new Error('Server responded with status: ' + response.status);
}
return response.json();
})
.then(data => {
if (data.success) {
// 删除成功，移除评论元素
if (commentElement) {
commentElement.style.opacity = '0';
setTimeout(() => {
commentElement.remove();

// 更新评论计数
updateCommentCount(-1);

showNotification('评论已成功删除', 'success');
}, 300);
}
} else {
showNotification(data.error || '删除评论失败', 'error');
}
})
.catch(error => {
console.error('Error:', error);
showNotification('删除时发生错误: ' + error.message, 'error');
});
}
}
});

// 添加新评论到列表
function addNewComment() {
// 由于后端只返回成功状态，我们将使用表单数据创建新评论
const content = document.getElementById('comment').value;

// 获取作者信息
let authorName;
const authorInput = document.getElementById('author');

if (authorInput && authorInput.value) {
// 非登录用户
authorName = authorInput.value;
} else {
// 已登录用户
const loggedInEl = document.querySelector('.logged-in-as strong');
authorName = loggedInEl ? loggedInEl.textContent : 'Anonymous';
}

// 创建评论时间
const now = new Date();
const formattedDate = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();

// 创建评论HTML
const commentHtml = `
<li id="comment-temp-${now.getTime()}" class="comment new-comment">
<article class="comment-body">
<footer class="comment-meta">
<div class="comment-author vcard">
<b>${escapeHtml(authorName)}</b>
</div>
<div class="comment-metadata">
<a href="#comment-temp-${now.getTime()}">
<time datetime="${now.toISOString()}">
${formattedDate}
</time>
</a>
</div>
</footer>
<div class="comment-content">
${escapeHtml(content).replace(/\n/g, '<br>')}
</div>
</article>
</li>
`;

// 添加到评论列表
const commentList = document.querySelector('.comment-list');
if (commentList) {
// 检查是否存在评论列表，如果不存在则创建
if (commentList.children.length === 0) {
// 可能之前没有评论，需要初始化评论列表
const commentsTitle = document.querySelector('.comments-title');
if (commentsTitle) {
commentsTitle.innerHTML = '<span class="comment-count">1</span> Comments';
}
} else {
// 更新评论计数
updateCommentCount(1);
}

// 将新评论添加到列表顶部
commentList.insertAdjacentHTML('afterbegin', commentHtml);

// 给新评论添加高亮效果
const newComment = document.querySelector('.new-comment');
if (newComment) {
setTimeout(() => {
newComment.scrollIntoView({ behavior: 'smooth', block: 'center' });
}, 100);

// 3秒后移除高亮类
setTimeout(() => {
newComment.classList.remove('new-comment');
}, 3000);
}
}
}

// 更新评论计数
function updateCommentCount(change) {
const countEl = document.querySelector('.comment-count');
if (countEl) {
const currentCount = parseInt(countEl.textContent, 10) || 0;
countEl.textContent = currentCount + change;
}
}

// HTML转义函数
function escapeHtml(text) {
const map = {
'&': '&amp;',
'<': '&lt;',
'>': '&gt;',
'"': '&quot;',
"'": '&#039;'
};
return text.replace(/[&<>"']/g, m => map[m]);
}

// 通知系统
function showNotification(message, type = 'info') {
// 检查是否已有通知容器
let container = document.querySelector('.notification-container');

if (!container) {
// 创建通知容器
container = document.createElement('div');
container.className = 'notification-container';
document.body.appendChild(container);

// 添加样式
const style = document.createElement('style');
style.textContent = `
.notification-container {
position: fixed;
top: 20px;
right: 20px;
z-index: 10000;
}
.notification {
margin-bottom: 10px;
padding: 12px 16px;
border-radius: 4px;
color: white;
font-size: 14px;
box-shadow: 0 2px 8px rgba(0,0,0,0.2);
animation: fadeIn 0.3s ease;
min-width: 200px;
max-width: 300px;
}
.notification.success { background-color: #4CAF50; }
.notification.error { background-color: #F44336; }
.notification.info { background-color: #2196F3; }
@keyframes fadeIn {
from { opacity: 0; transform: translateY(-10px); }
to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeOut {
from { opacity: 1; transform: translateY(0); }
to { opacity: 0; transform: translateY(-10px); }
}
.new-comment {
animation: highlight 3s ease;
}
@keyframes highlight {
0%, 40% { background-color: rgba(255, 248, 212, 0.6); }
100% { background-color: transparent; }
}
`;
document.head.appendChild(style);
}

// 创建通知
const notification = document.createElement('div');
notification.className = `notification ${type}`;
notification.textContent = message;

// 添加到容器
container.appendChild(notification);

// 3秒后移除
setTimeout(() => {
notification.style.animation = 'fadeOut 0.3s ease forwards';
setTimeout(() => {
notification.remove();
}, 300);
}, 3000);
}

// Fix #7: Add a check at the beginning to verify SITE_URL is defined properly
(function checkEnvironment() {
// Check if the site URL seems correct
const siteUrl = '<?php echo defined("SITE_URL") ? SITE_URL : ""; ?>';
if (!siteUrl) {
console.warn('Warning: SITE_URL is not defined. Comment functionality may not work correctly.');
}
})();

});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>