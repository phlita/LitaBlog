<?php defined('CORE') || die('Direct access not allowed.');
require_once __DIR__ . '/header.php';
?>
<div class="main-wrapper"><main class="content-area">
<?php if (!empty($template_data['archive_title'])): ?>
    <h1 class="archive-title"><?php echo e($template_data['archive_title']); ?></h1>
<?php endif; ?>
<div class="posts-wrapper"><div class="posts-content">
<?php if (!empty($template_data['posts'])): ?>
    <div class="posts-list">
    <?php foreach ($template_data['posts'] as $post): ?>
        <article class="post" id="post-<?php echo (int) $post['id']; ?>">
            <h3 class="post-title"><a href="<?php echo Permalink::get_post_link($post['id']); ?>"><?php echo e($post['title']); ?></a></h3>
            <div class="post-meta"><span class="post-date"><?php echo e($post['formatted_date'] ?? ''); ?></span></div>
        </article>
    <?php endforeach; ?>
    </div>
    <?php if (isset($template_data['pagination'])) echo $template_data['pagination']; ?>
<?php else: ?>
    <p>暂无内容。</p>
<?php endif; ?>
</div>
<?php require_once __DIR__ . '/sidebar.php'; ?>
</div></main></div>
<?php require_once __DIR__ . '/footer.php'; ?>
