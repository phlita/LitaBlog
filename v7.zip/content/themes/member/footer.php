<?php defined('CORE') || die('Direct access not allowed.'); ?>
<footer class="site-footer">
    <div class="footer-inner">
        <p class="footer-brand"><?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : 'Blog'; ?></p>
        <p class="footer-copy">
            © <?php echo date('Y'); ?> <?php echo isset($template_data['site_title']) ? e($template_data['site_title']) : 'Blog'; ?>
            <?php if (!empty($template_data['is_admin'])): ?>
                <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/">管理</a>
            <?php elseif (!empty($template_data['is_logged_in'])): ?>
                <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/logout.php?csrf_token=<?php echo function_exists('generateCsrfToken') ? generateCsrfToken('user_logout') : ''; ?>">登出</a>
            <?php else: ?>
                <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/login.php">登录</a>
            <?php endif; ?>
        </p>
        <p class="footer-tags">会员体系 · 积分阅读 · 分类会员 · 全站通行</p>
    </div>
</footer>
<div id="back-to-top" title="返回顶部">↑</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var btn = document.getElementById('back-to-top');
    window.addEventListener('scroll', function () {
        btn.classList.toggle('show', window.pageYOffset > 600);
    });
    btn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
</script>
<?php do_action('wp_footer'); ?>
</div>
</body>
</html>
