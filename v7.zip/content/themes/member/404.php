<?php defined('CORE') || die('Direct access not allowed.');
require_once __DIR__ . '/header.php';
?>
<div class="main-wrapper"><main class="content-area">
<h1 class="archive-title">404</h1>
<p><?php echo e($template_data['error_message'] ?? '抱歉，页面未找到。'); ?></p>
</div></main></div>
<?php require_once __DIR__ . '/footer.php'; ?>
