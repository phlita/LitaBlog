<?php defined('CORE') || die('Direct access not allowed.');
require_once __DIR__ . '/header.php';
?>
<?php if (!empty($template_data['post'])): $post = $template_data['post']; ?>
<article id="post-<?php echo (int) $post['id']; ?>" class="single-post">
    <header class="entry-header">
        <h1 class="post-title"><?php echo e($post['title']); ?></h1>
        <div class="post-meta"><time datetime="<?php echo date('c', strtotime($post['created'] ?? 'now')); ?>"><?php echo e($post['formatted_datetime'] ?? ''); ?></time></div>
    </header>
    <div class="entry-content"><?php echo $post['content']; ?></div>
</article>

<?php if (!empty($template_data['enable_comments'])): ?>
<div class="comments-area">
    <h2 class="comments-title"><?php echo count($template_data['comments'] ?? []); ?> 条评论</h2>
    <ol class="comment-list">
    <?php foreach (($template_data['comments'] ?? []) as $comment): ?>
        <li id="comment-<?php echo (int) $comment['id']; ?>" class="comment">
            <div class="comment-author"><b><?php echo e($comment['author_name'] ?? ''); ?></b></div>
            <div class="comment-content"><?php echo nl2br(e($comment['content'] ?? '')); ?></div>
        </li>
    <?php endforeach; ?>
    </ol>
    <?php if (!empty($template_data['is_logged_in'])): ?>
    <form class="comment-form" action="<?php echo e(rtrim(defined('SITE_URL') ? SITE_URL : '', '/') . '/includes/comments.php'); ?>" method="post">
        <p><textarea name="content" rows="4" required></textarea></p>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="post_id" value="<?php echo (int) $post['id']; ?>">
        <?php if (function_exists('csrf_token_field')) csrf_token_field('add_comment'); ?>
        <p><button type="submit" class="button member-comment-btn">发表评论</button></p>
    </form>
    <?php else: ?>
    <p class="member-login-prompt"><a href="<?php echo e(rtrim(defined('SITE_URL') ? SITE_URL : '', '/') . '/admin/login.php'); ?>">登录</a> 后参与评论。</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php else: ?>
<p>抱歉，文章未找到。</p>
<?php endif; ?>
<?php require_once __DIR__ . '/footer.php'; ?>
