<?php defined('CORE') || die('Direct access not allowed.');
require_once __DIR__ . '/header.php';
?>
<?php if (!empty($template_data['post'])): $post = $template_data['post']; ?>
<article id="post-<?php echo (int) $post['id']; ?>" class="single-post page">
    <header class="entry-header"><h1 class="post-title"><?php echo e($post['title']); ?></h1></header>
    <div class="entry-content"><?php echo $post['content']; ?></div>
</article>
<?php else: ?>
<p>抱歉，页面未找到。</p>
<?php endif; ?>
<?php require_once __DIR__ . '/footer.php'; ?>
