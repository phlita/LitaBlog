<?php defined('CORE') || die('Direct access not allowed.'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>
<?php
$page_title = isset($template_data['site_title']) ? e($template_data['site_title']) : 'Blog';
if (isset($template_data['request_type'])) {
    if ($template_data['request_type'] === 'single' && isset($template_data['post']['title'])) {
        $page_title = e($template_data['post']['title']) . ' | ' . $page_title;
    } elseif (!empty($template_data['archive_title'])) {
        $page_title = $template_data['archive_title'] . ' | ' . $page_title;
    } elseif ($template_data['request_type'] === '404') {
        $page_title = '页面未找到 | ' . $page_title;
    }
}
echo $page_title;
?>
</title>
<link rel="stylesheet" href="<?php echo isset($template_data['theme_url']) ? e($template_data['theme_url']) : ''; ?>/style.css" />
<?php do_action('header'); ?>
</head>
<body>
<div class="member-topline" aria-hidden="true"></div>
<div class="container">
<header class="site-header">
    <div class="brand">
        <span class="brand-mark" aria-hidden="true">◆</span>
        <h1 class="site-title"><a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>"><?php echo e($template_data['site_title']); ?></a></h1>
    </div>

    <p class="site-description"><?php echo e($template_data['site_description']); ?></p>

    <nav class="main-navigation"><ul>
    <?php foreach (($template_data['nav_menu'] ?? []) as $menu_item): ?>
        <li><a href="<?php echo isset($menu_item['url']) ? e($menu_item['url']) : '#'; ?>"><?php echo isset($menu_item['name']) ? e($menu_item['name']) : ''; ?></a></li>
    <?php endforeach; ?>
    </ul></nav>

    <div class="site-tags" aria-hidden="true">
        <span class="site-tag site-tag--gold">VIP 会员</span>
        <span class="site-tag site-tag--violet">SVIP 会员</span>
        <span class="site-tag site-tag--cyan">积分阅读</span>
    </div>
</header>
