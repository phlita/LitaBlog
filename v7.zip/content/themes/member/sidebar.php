<?php defined('CORE') || die('Direct access not allowed.'); ?>
<?php if (isset($template_data['widgets']) && is_array($template_data['widgets']) && !empty($template_data['widgets'])): ?>
<aside class="sidebar">
<?php foreach ($template_data['widgets'] as $widget): ?>
    <div class="widget widget-<?php echo isset($widget['type']) ? e($widget['type']) : 'text'; ?>">
    <?php if (!empty($widget['title'])): ?><h3 class="widget-title"><?php echo e($widget['title']); ?></h3><?php endif; ?>
    <div class="widget-content">
    <?php
    $content = $widget['content'] ?? '';
    $type    = $widget['type'] ?? 'text';
    if ($type === 'text') {
        echo nl2br(e($content));
    } elseif ($type === 'html') {
        echo function_exists('litablog_purify_html') ? litablog_purify_html($content) : $content;
    } else {
        echo e($content);
    }
    ?>
    </div></div>
<?php endforeach; ?>
</aside>
<?php endif; ?>
