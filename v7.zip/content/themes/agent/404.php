<?php defined('CORE') || die('Direct access not allowed.'); ?>
<?php require_once __DIR__ . '/header.php'; ?>
<h2>404</h2>
<p>页面不存在</p>
<?php require_once __DIR__ . '/footer.php'; ?>
