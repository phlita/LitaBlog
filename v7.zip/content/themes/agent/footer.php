<?php defined('CORE') || die('Direct access not allowed.'); ?>
</main>
<footer>
<a href="<?php echo e($template_data['site_url'] ?? '/'); ?>"><?php echo e($template_data['site_title'] ?? ''); ?></a>
<span>·</span>
<span class="api-hint">AI: curl -H "Accept: application/json" URL</span>
</footer>
<?php echo do_action('footer'); ?>
</body>
</html>
