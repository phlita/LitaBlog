<?php defined('CORE') || die('Direct access not allowed.'); ?>
<?php require_once __DIR__ . '/header.php'; ?>

<?php if (isset($template_data['archive_title'])): ?>
<h2><?php echo e($template_data['archive_title']); ?></h2>
<?php endif; ?>

<?php if (!empty($template_data['posts'])): ?>
<?php foreach ($template_data['posts'] as $post): ?>
<article>
<h2><a href="<?php echo Permalink::get_post_link($post['id']); ?>"><?php echo e($post['title']); ?></a></h2>
<time><?php echo $post['formatted_date'] ?? ''; ?></time>
</article>
<?php endforeach; ?>
<?php if (isset($template_data['pagination'])) echo $template_data['pagination']; ?>
<?php else: ?>
<p>暂无内容</p>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
