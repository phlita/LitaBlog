<?php defined('CORE') || die('Direct access not allowed.'); ?>
<?php require_once __DIR__ . '/header.php'; ?>

<?php if (isset($template_data['post']) && !empty($template_data['post'])): ?>
<?php $post = $template_data['post']; ?>
<article>
<h1><?php echo e($post['title']); ?></h1>
<time datetime="<?php echo date('c', strtotime($post['created'])); ?>"><?php echo e($post['formatted_datetime'] ?? $post['created']); ?></time>
<div class="content"><?php echo $post['content']; ?></div>
</article>

<?php if (!empty($template_data['comments'])): ?>
<section class="comments">
<h2>评论 (<?php echo count($template_data['comments']); ?>)</h2>
<?php foreach ($template_data['comments'] as $c): ?>
<div class="comment">
<strong><?php echo e($c['author_name'] ?? '匿名'); ?></strong>
<time><?php echo $c['created_at'] ?? ''; ?></time>
<p><?php echo e($c['content'] ?? ''); ?></p>
</div>
<?php endforeach; ?>
</section>
<?php endif; ?>
<?php else: ?>
<p>文章不存在</p>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
