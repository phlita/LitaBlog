<?php
defined('CORE') || die('Direct access not allowed.');

// ═══════════════════════════════════════════════════
// AI 检测: Accept: application/json 或 ?format=json
// ═══════════════════════════════════════════════════
$is_agent = false;
$accept = $_SERVER['HTTP_ACCEPT'] ?? '';
if (strpos($accept, 'application/json') !== false && strpos($accept, 'text/html') === false) {
    $is_agent = true;
}
if (($_GET['format'] ?? '') === 'json') {
    $is_agent = true;
}

// ═══════════════════════════════════════════════════
// AI 读取: 同一个 URL, 返回 JSON
// 写操作由 lita-agent-api 插件处理 (?agent_api=posts)
// ═══════════════════════════════════════════════════
if ($is_agent) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    
    $json = [
        'site' => [
            'title' => $template_data['site_title'] ?? '',
            'description' => $template_data['site_description'] ?? '',
            'url' => $template_data['site_url'] ?? '',
        ],
    ];
    
    // 搜索结果
    if (($template_data['request_type'] ?? '') === 'search') {
        $json['type'] = 'search';
        $json['query'] = $template_data['search_query'] ?? '';
        $json['results'] = array_map(function($p) {
            return [
                'id' => intval($p['id']),
                'title' => $p['title'],
                'date' => $p['created'] ?? '',
                'url' => rtrim($template_data['site_url'] ?? '', '/') . Permalink::get_post_link($p['id']),
            ];
        }, $template_data['posts'] ?? []);
        $json['count'] = count($json['results']);
    }
    // 文章列表
    elseif (isset($template_data['posts'])) {
        $json['type'] = 'list';
        $json['posts'] = array_map(function($p) {
            return [
                'id' => intval($p['id']),
                'title' => $p['title'],
                'date' => $p['created'] ?? '',
                'url' => ($GLOBALS['template_data']['site_url'] ?? '') . Permalink::get_post_link($p['id']),
            ];
        }, $template_data['posts']);
        $json['pagination'] = $template_data['pagination'] ?? null;
    }
    // 单篇文章
    elseif (isset($template_data['post'])) {
        $p = $template_data['post'];
        $json['type'] = 'post';
        $json['post'] = [
            'id' => intval($p['id']),
            'title' => $p['title'],
            'content' => $p['content'],
            'content_plain' => strip_tags($p['content']),
            'date' => $p['created'] ?? '',
            'url' => ($template_data['site_url'] ?? '') . Permalink::get_post_link($p['id']),
        ];
    }
    // 404
    elseif (($template_data['request_type'] ?? '') === '404') {
        http_response_code(404);
        $json['type'] = 'error';
        $json['error'] = 'Not found';
    }
    
    // API 入口提示
    $json['_api'] = [
        'write' => ($template_data['site_url'] ?? '') . '/?agent_api=posts',
        'comment' => ($template_data['site_url'] ?? '') . '/?agent_api=comments',
        'auth' => 'Authorization: Bearer <key>',
        'docs' => '后台 → Agent API 设置页查看完整文档',
    ];
    
    echo json_encode($json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// ═══════════════════════════════════════════════════
// 人类访问: 正常 HTML
// ═══════════════════════════════════════════════════
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php
$page_title = e($template_data['site_title'] ?? 'Blog');
if (($template_data['request_type'] ?? '') === 'single' && isset($template_data['post'])) {
    $page_title = e($template_data['post']['title']) . ' | ' . $page_title;
}
echo $page_title;
?></title>
<link rel="stylesheet" href="<?php echo e($template_data['theme_url'] ?? ''); ?>/style.css">
<?php if (($template_data['request_type'] ?? '') === 'single' && isset($template_data['post'])): ?>
<link rel="canonical" href="<?php echo Permalink::get_post_link($template_data['post']['id']); ?>">
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"BlogPosting","headline":<?php echo json_encode($template_data['post']['title']); ?>,"datePublished":"<?php echo $template_data['post']['created'] ?? ''; ?>","articleBody":<?php echo json_encode(strip_tags($template_data['post']['content'])); ?>}
</script>
<?php endif; ?>
<?php echo do_action('header'); ?>
</head>
<body>
<header>
<h1><a href="<?php echo e($template_data['site_url'] ?? '/'); ?>"><?php echo e($template_data['site_title'] ?? 'Blog'); ?></a></h1>
<?php if (!empty($template_data['site_description'])): ?>
<p class="desc"><?php echo e($template_data['site_description']); ?></p>
<?php endif; ?>
<nav>
<?php foreach (($template_data['nav_menu'] ?? []) as $item): ?>
<a href="<?php echo e($item['url'] ?? '#'); ?>"><?php echo e($item['name'] ?? ''); ?></a>
<?php endforeach; ?>
</nav>
</header>
<main>
