<?php defined('CORE') || die('Direct access not allowed.'); ?>
<aside>
<?php if (!empty($template_data['widgets'])): ?>
<?php foreach ($template_data['widgets'] as $widget): ?>
<div class="widget">
<h3><?php echo e($widget['title'] ?? ''); ?></h3>
<?php
// L-5:widget 输出二次过滤(入库虽经 litablog_purify_html,输出再加一道纵深防御)。
$w_type = $widget['type'] ?? 'text';
$w_content = $widget['content'] ?? '';
if ($w_type === 'html') {
    echo function_exists('litablog_purify_html') ? litablog_purify_html($w_content) : $w_content;
} else {
    echo nl2br(e($w_content));
}
?>
</div>
<?php endforeach; ?>
<?php endif; ?>
</aside>
