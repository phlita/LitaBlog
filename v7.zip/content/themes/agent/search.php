<?php defined('CORE') || die('Direct access not allowed.'); ?>
<?php require_once __DIR__ . '/header.php'; ?>

<h2>搜索: <?php echo e($template_data['search_query'] ?? ''); ?></h2>

<?php if (!empty($template_data['posts'])): ?>
<?php foreach ($template_data['posts'] as $post): ?>
<article>
<h3><a href="<?php echo Permalink::get_post_link($post['id']); ?>"><?php echo e($post['title']); ?></a></h3>
<time><?php echo $post['formatted_date'] ?? ''; ?></time>
</article>
<?php endforeach; ?>
<?php if (isset($template_data['pagination'])) echo $template_data['pagination']; ?>
<?php else: ?>
<p>无结果</p>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
