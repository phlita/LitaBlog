<?php
/**
* The template for displaying single posts or pages in Jian theme
*/
require_once __DIR__ . '/header.php';
?>

<?php require_once __DIR__ . '/sidebar.php'; // Include sidebar ?>
<main class="main-content" id="main">
<?php if (isset($template_data['post']) && !empty($template_data['post'])) : ?>
<?php $post = $template_data['post']; ?>
<article id="post-<?php echo $post['id']; ?>" class="single-post">
<header class="entry-header">
<h1 class="post-title"><?php echo e($post['title']); ?></h1>
<div class="post-meta">
<span class="posted-on">
<time datetime="<?php echo date('c', strtotime($post['created'])); ?>">
<?php echo e($post['formatted_datetime']); ?>
</time>
</span>
<?php if (isset($template_data['author']['username'])): ?>
<span class="byline"><?php echo e($template_data['author']['display_name']); ?></span>
<?php endif; ?>
<?php
if (isset($template_data['tags']) && !empty($template_data['tags'])) {
echo '<span class="tag-links">标签 / ';
$tag_links = [];
foreach($template_data['tags'] as $tag) {
// ★2026-09-17（与 v10 同步 ✓）：改用 Permalink::get_tag_link($tag['id']) ——
//   URL 用**数值 id** ✓；顺带修掉旧写法的一个真 bug ✗：拿 e() 当 URL 编码用，
//   名字含 & / # / 空格时链接会断开 ✓（现在由 urlencode 负责 ✓）
$tag_links[] = '<a href="' . e(Permalink::get_tag_link($tag['id'])) . '">' . e($tag['name']) . '</a>';
}
echo implode(', ', $tag_links);
echo '</span>';
}
?>
</div>
</header>
<div class="entry-content">
<?php echo $post['content']; ?>
</div>
<footer class="entry-footer">
</footer>
</article>

<?php if (isset($template_data['enable_comments']) && $template_data['enable_comments']) : ?>
<div id="comments" class="comments-area">
<?php if (isset($template_data['comments']) && is_array($template_data['comments']) && !empty($template_data['comments'])) : ?>

<ol class="comment-list">
<?php foreach ($template_data['comments'] as $comment) : ?>
<li id="comment-<?php echo $comment['id']; ?>" class="comment">
<article class="comment-body">
<footer class="comment-meta">
<span class="comment-author"><?php echo e($comment['author_name']); ?></span>
<span class="comment-metadata">
<a href="#comment-<?php echo $comment['id']; ?>">
<time datetime="<?php echo date('c', strtotime($comment['created'])); ?>">
<?php echo e($post['formatted_datetime']); ?>
</time>
</a></span>
<?php if (isset($template_data['is_logged_in'], $template_data['is_admin']) && $template_data['is_logged_in'] && $template_data['is_admin']): ?>
<span class="comment-actions">
<!-- Fixed: Added data-csrf token to allow deletion under jian theme -->
<a href="#" class="delete-comment" data-comment-id="<?php echo $comment['id']; ?>" data-csrf="<?php echo e(generateCsrfToken('delete_comment_' . $comment['id'])); ?>">删除</a>
</span>
<?php endif; ?>

</footer>
<div class="comment-content">
<?php echo nl2br(e($comment['content'])); ?>
</div>
</article>
</li>
<?php endforeach; ?>
</ol>
<?php endif; ?>

<div id="respond" class="comment-respond">

<form action="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/includes/comments.php" method="post" id="commentform" class="comment-form">
<?php if (isset($template_data['is_logged_in']) && $template_data['is_logged_in'] && isset($template_data['current_user'])) : ?>
<p class="logged-in-as">您已登录为：<strong><?php echo e(user_display_name($template_data['current_user'])); ?></strong>. <a href="<?php echo isset($template_data['site_url']) ? e($template_data['site_url']) : ''; ?>/admin/logout.php?csrf_token=<?php echo generateCsrfToken('user_logout'); ?>">登出?</a></p>
<?php else : ?>
<p class="comment-notes">评论：</p>
<?php endif; ?>
<p class="comment-form-comment">
<textarea id="comment" name="content" cols="12" rows="3" required="required"></textarea>
</p>
<p class="form-submit">
<input name="submit" type="submit" id="submit" class="submit" value="提交评论">
<input type="hidden" name="action" value="add">
<input type="hidden" name="post_id" value="<?php echo $post['id']; ?>" id="comment_post_ID">
<?php if (function_exists('csrf_token_field')) csrf_token_field('add_comment'); ?>
</p>
<div id="comment-status" style="display: none; margin-top: 10px; color: var(--color-text-light);">
<p class="comment-waiting">正在提交...</p>
</div>
</form>
</div>
</div>
<?php endif; ?>
<?php else : ?>
<p>抱歉，无法找到您请求的文章或页面。</p>
<?php
if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
?>
<?php endif; ?>
</main>
<script>
document.addEventListener('DOMContentLoaded', function() {
const commentForm = document.getElementById('commentform');
if (commentForm) {
commentForm.addEventListener('submit', function(e) {
e.preventDefault();

const statusDiv = document.getElementById('comment-status');
const submitBtn = document.getElementById('submit');

statusDiv.style.display = 'block';
submitBtn.disabled = true;
submitBtn.value = '提交中...';

const formData = new FormData(commentForm);
const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

fetch(commentUrl, {
method: 'POST',
body: formData,
headers: {
'X-Requested-With': 'XMLHttpRequest'
}
})
.then(response => {
if (!response.ok) {
throw new Error('Server responded with status: ' + response.status);
}
return response.json();
})
.then(data => {
statusDiv.style.display = 'none';
submitBtn.disabled = false;
submitBtn.value = 'Post Comment';

if (data.success) {
document.getElementById('comment').value = '';
addNewComment();
showNotification('评论已成功提交', 'success');
} else {
showNotification(data.error || '评论提交失败', 'error');
}
})
.catch(error => {
console.error('Error:', error);
statusDiv.style.display = 'none';
submitBtn.disabled = false;
submitBtn.value = 'Post Comment';
showNotification('提交时发生错误，请稍后重试: ' + error.message, 'error');
});
});
}

document.addEventListener('click', function(e) {
if (e.target && e.target.classList.contains('delete-comment')) {
e.preventDefault();

if (confirm('确定要删除这条评论吗？')) {
const commentId = e.target.getAttribute('data-comment-id');
const commentElement = document.getElementById('comment-' + commentId);
// Fixed: Retrieve data-csrf token correctly from theme link
const csrfToken = e.target.getAttribute('data-csrf');

const formData = new FormData();
formData.append('action', 'delete');
formData.append('comment_id', commentId);
formData.append('csrf_token', csrfToken); // Append the CSRF token

const commentUrl = '<?php echo htmlspecialchars(SITE_URL . '/includes/comments.php'); ?>';

fetch(commentUrl, {
method: 'POST',
body: formData,
headers: {
'X-Requested-With': 'XMLHttpRequest'
}
})
.then(response => {
if (!response.ok) {
throw new Error('Server responded with status: ' + response.status);
}
return response.json();
})
.then(data => {
if (data.success) {
if (commentElement) {
commentElement.style.opacity = '0';
setTimeout(() => {
commentElement.remove();
updateCommentCount(-1);
showNotification('评论已成功删除', 'success');
}, 300);
}
} else {
showNotification(data.error || '删除评论失败', 'error');
}
})
.catch(error => {
console.error('Error:', error);
showNotification('删除时发生错误: ' + error.message, 'error');
});
}
}
});

function addNewComment() {
const content = document.getElementById('comment').value;
let authorName;
const authorInput = document.getElementById('author');

if (authorInput && authorInput.value) {
authorName = authorInput.value;
} else {
const loggedInEl = document.querySelector('.logged-in-as strong');
authorName = loggedInEl ? loggedInEl.textContent : 'Anonymous';
}

const now = new Date();
const formattedDate = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();

const commentHtml = `
<li id="comment-temp-${now.getTime()}" class="comment new-comment">
<article class="comment-body">
<footer class="comment-meta">
<div class="comment-author vcard">
<b>\${escapeHtml(authorName)}</b>
</div>
<div class="comment-metadata">
<a href="#comment-temp-\${now.getTime()}">
<time datetime="\${now.toISOString()}">
\${formattedDate}
</time>
</a>
</div>
</footer>
<div class="comment-content">
\${escapeHtml(content).replace(/\\n/g, '<br>')}
</div>
</article>
</li>
`;

const commentList = document.querySelector('.comment-list');
if (commentList) {
if (commentList.children.length === 0) {
const commentsTitle = document.querySelector('.comments-title');
if (commentsTitle) {
commentsTitle.innerHTML = '<span class="comment-count">1</span> Comments';
}
} else {
updateCommentCount(1);
}

commentList.insertAdjacentHTML('afterbegin', commentHtml);
const newComment = document.querySelector('.new-comment');
if (newComment) {
setTimeout(() => {
newComment.scrollIntoView({ behavior: 'smooth', block: 'center' });
}, 100);
setTimeout(() => {
newComment.classList.remove('new-comment');
}, 3000);
}
}
}

function updateCommentCount(change) {
const countEl = document.querySelector('.comment-count');
if (countEl) {
const currentCount = parseInt(countEl.textContent, 10) || 0;
countEl.textContent = currentCount + change;
}
}

function escapeHtml(text) {
const map = {
'&': '&amp;',
'<': '&lt;',
'>': '&gt;',
'"': '&quot;',
"'": '&#039;'
};
return text.replace(/[&<>"']/g, m => map[m]);
}

function showNotification(message, type = 'info') {
let container = document.querySelector('.notification-container');

if (!container) {
container = document.createElement('div');
container.className = 'notification-container';
document.body.appendChild(container);

const style = document.createElement('style');
style.textContent = `
.notification-container {
position: fixed;
top: 20px;
right: 20px;
z-index: 10000;
}
.notification {
margin-bottom: 10px;
padding: 12px 16px;
border-radius: 4px;
color: white;
font-size: 14px;
box-shadow: 0 2px 8px rgba(0,0,0,0.2);
animation: fadeIn 0.3s ease;
min-width: 200px;
max-width: 300px;
}
.notification.success { background-color: #4CAF50; }
.notification.error { background-color: #F44336; }
.notification.info { background-color: #2196F3; }
@keyframes fadeIn {
from { opacity: 0; transform: translateY(-10px); }
to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeOut {
from { opacity: 1; transform: translateY(0); }
to { opacity: 0; transform: translateY(-10px); }
}
.new-comment {
animation: highlight 3s ease;
}
@keyframes highlight {
0%, 40% { background-color: rgba(255, 248, 212, 0.6); }
100% { background-color: transparent; }
}
`;
document.head.appendChild(style);
}

const notification = document.createElement('div');
notification.className = `notification \${type}`;
notification.textContent = message;

container.appendChild(notification);

setTimeout(() => {
notification.style.animation = 'fadeOut 0.3s ease forwards';
setTimeout(() => {
notification.remove();
}, 300);
}, 3000);
}

(function checkEnvironment() {
const siteUrl = '<?php echo defined("SITE_URL") ? SITE_URL : ""; ?>';
if (!siteUrl) {
console.warn('Warning: SITE_URL is not defined.');
}
})();

});
</script>
<?php require_once __DIR__ . '/footer.php'; ?>