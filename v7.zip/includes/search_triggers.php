<?php
// 禁止 web 直访：本文件只应由安装器/引导链 require（返回触发器 SQL 数组）。
if (isset($_SERVER['SCRIPT_FILENAME']) && basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

/**
 * search_triggers.php - 中文 2-gram 搜索索引触发器（数据库层自动维护，与主题无关）
 *
 * 移植自 v10 同名文件（v7 E-1 搜索优化）。
 *
 * 原理：帖子标题按 2 字符切分（bigram）存入 search_index 表，
 * 搜索词同样切 2-gram 精确命中索引（PRIMARY KEY(term_id, post_id)），
 * 50 万数据下搜索从 LIKE 全扫（106s）降为索引精确查找（毫秒级）。
 * 2-gram 对中文 2 字词完全有效（"性能"→gram"性能"），这是 FTS5 trigram 做不到的。
 *
 * 压缩设计（A+B+C）：
 *   A. 字典编码：term 文本 → term_dict.id 整数。search_index 只存 term_id（INTEGER 4B），
 *      消除 gram 重复文本（当前 172 万行仅 829 个不同词，行宽 40B→16B，数据体积 -60%）。
 *   B. 不建 idx_si_post 反向索引（省 ~20MB）。删帖清理走全扫（低频操作可接受）。
 *   C. 只索引 title（权重 3），不索引 excerpt（省 ~38% 行数；摘要关键词不参与搜索）。
 *
 * 本文件返回 [表DDL数组, 触发器SQL数组]，供 install / 迁移 / 回填脚本共用。
 */

/** 搜索索引触发器名称清单（批量挂起/恢复用） */
if (!function_exists('search_trigger_names')) {
    function search_trigger_names() {
        return ['search_index_ai', 'search_index_au', 'search_index_ad'];
    }
}

$search_table_ddl = [
// 词字典：gram 文本 → 整数 id（去重存储，消除重复）
"CREATE TABLE IF NOT EXISTS term_dict (
id INTEGER PRIMARY KEY AUTOINCREMENT,
term TEXT NOT NULL UNIQUE
)",
// 帖子索引：只存 term_id + post_id（字典编码，行宽最小）
"CREATE TABLE IF NOT EXISTS search_index (
term_id INTEGER NOT NULL,
post_id INTEGER NOT NULL,
weight INTEGER NOT NULL DEFAULT 1,
PRIMARY KEY (term_id, post_id)
)",
// gram 命中计数（term_id → 含该词的已发布帖子数），搜索 COUNT 变 O(1)
"CREATE TABLE IF NOT EXISTS search_term_counts (
term_id INTEGER PRIMARY KEY,
cnt INTEGER NOT NULL DEFAULT 0
)",
];

// title 2-gram 切分（只索引标题，权重 3；substr 限 100 字符）
$grams_title = "
    SELECT DISTINCT g FROM (
        WITH RECURSIVE grams(i, g) AS (
            SELECT 1, substr(new.title, 1, 2)
            UNION ALL
            SELECT i+1, substr(new.title, i+1, 2) FROM grams WHERE i < length(substr(new.title, 1, 100)) - 1
        )
        SELECT g FROM grams WHERE length(g) >= 2
    )";

$search_trigger_sqls = [
// 发帖：①词入字典 ②写索引 ③计数+1
"CREATE TRIGGER IF NOT EXISTS search_index_ai AFTER INSERT ON posts
WHEN new.status = 'publish' AND new.type = 'post'
BEGIN
    INSERT OR IGNORE INTO term_dict (term)
    SELECT g FROM ($grams_title);
    INSERT INTO search_index (term_id, post_id, weight)
    SELECT td.id, new.id, 3
    FROM ($grams_title) g
    JOIN term_dict td ON td.term = g.g;
    INSERT INTO search_term_counts (term_id, cnt)
    SELECT td.id, 1
    FROM ($grams_title) g
    JOIN term_dict td ON td.term = g.g
    ON CONFLICT(term_id) DO UPDATE SET cnt = cnt + 1;
END;",
// 更新标题/状态：先无条件清旧索引，再按状态建新索引
"CREATE TRIGGER IF NOT EXISTS search_index_au AFTER UPDATE OF title, status, type ON posts
BEGIN
    UPDATE search_term_counts SET cnt = cnt - 1
    WHERE term_id IN (SELECT term_id FROM search_index WHERE post_id = old.id);
    DELETE FROM search_index WHERE post_id = old.id;
    DELETE FROM search_term_counts WHERE cnt <= 0;
    INSERT OR IGNORE INTO term_dict (term)
    SELECT g FROM ($grams_title) WHERE new.status = 'publish' AND new.type = 'post';
    INSERT INTO search_index (term_id, post_id, weight)
    SELECT td.id, new.id, 3
    FROM ($grams_title) g
    JOIN term_dict td ON td.term = g.g
    WHERE new.status = 'publish' AND new.type = 'post';
    INSERT INTO search_term_counts (term_id, cnt)
    SELECT td.id, 1
    FROM ($grams_title) g
    JOIN term_dict td ON td.term = g.g
    WHERE new.status = 'publish' AND new.type = 'post'
    ON CONFLICT(term_id) DO UPDATE SET cnt = cnt + 1;
END;",
// 删帖：清索引 + 计数-1
"CREATE TRIGGER IF NOT EXISTS search_index_ad BEFORE DELETE ON posts
BEGIN
    UPDATE search_term_counts SET cnt = cnt - 1
    WHERE term_id IN (SELECT term_id FROM search_index WHERE post_id = old.id);
    DELETE FROM search_index WHERE post_id = old.id;
    DELETE FROM search_term_counts WHERE cnt <= 0;
END;",
];

return [$search_table_ddl, $search_trigger_sqls];
