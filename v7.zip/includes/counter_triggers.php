<?php
// 禁止 web 直访：本文件只应由安装器/引导链 require（返回触发器 SQL 数组）。
if (isset($_SERVER['SCRIPT_FILENAME']) && basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

/**
 * counter_triggers.php - v7(Blog)计数器触发器定义
 *
 * 移植/裁剪自 v10 计数器思路,适配 blog 语义。
 * 维护目标:categories.post_count / tags.post_count(该分类/标签下 publish+type=post 的文章数)。
 * 对应消费点:functions.php get_term_posts_count() —— 前台分类/标签页 total_posts。
 *
 * 为什么用「受影响集重算」而非「增量 ±1」:
 *   v7 删帖链路顺序不统一(admin/index.php 先删 post_categories 再删 posts;
 *   lita-agent-api / litadistribute 先删 posts 再删关联),增量触发器在两种顺序下
 *   会产生双重扣减或漏扣。重算方案:每次写事件只对「受影响的分类/标签」做一次精确
 *   COUNT(幂等),天然免疫顺序差异,绝不漂移。写路径(后台发/改/删/改分类)低频,
 *   单分类重算 1-5ms 完全可接受;读路径(前台)由 get_term_posts_count 读列 O(1)。
 *
 * 前置(由 db_counter_backfill.php / 安装流程执行):
 *   ALTER TABLE categories ADD COLUMN post_count INTEGER NOT NULL DEFAULT 0;
 *   ALTER TABLE tags      ADD COLUMN post_count INTEGER NOT NULL DEFAULT 0;
 *   并做一次存量重算。
 *
 * 事件覆盖:
 *   - post_categories 增/删(cnt_pc_ai/bd) → 重算该分类
 *   - post_tags      增/删(cnt_pt_ai/bd) → 重算该标签
 *   - posts type/status 切换(cnt_posts_au) → 重算该帖全部关联分类/标签
 *   - posts 删除(cnt_posts_bd) → 关联若仍在则重算(若已被 pc/pt 先删,集合为空=无操作,不双重)
 *   - posts 新增不需处理:admin 先 INSERT posts 再建关联,由随后的 cnt_pc_ai 重算覆盖
 */
if (!defined('CORE')) {
    exit;
}

/** 计数器触发器名称清单 */
if (!function_exists('counter_trigger_names')) {
    function counter_trigger_names() {
        return ['cnt_pc_ai', 'cnt_pc_bd', 'cnt_pt_ai', 'cnt_pt_bd', 'cnt_posts_au', 'cnt_posts_bd'];
    }
}

return [
// --- 分类:post_categories 增/删 → 重算该分类 ---
"CREATE TRIGGER IF NOT EXISTS cnt_pc_ai AFTER INSERT ON post_categories
BEGIN
    UPDATE categories SET post_count = (
        SELECT COUNT(DISTINCT pc.post_id) FROM post_categories pc
        JOIN posts p ON p.id = pc.post_id
        WHERE pc.category_id = new.category_id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id = new.category_id;
END;",
"CREATE TRIGGER IF NOT EXISTS cnt_pc_bd AFTER DELETE ON post_categories
BEGIN
    UPDATE categories SET post_count = (
        SELECT COUNT(DISTINCT pc.post_id) FROM post_categories pc
        JOIN posts p ON p.id = pc.post_id
        WHERE pc.category_id = old.category_id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id = old.category_id;
END;",
// --- 标签:post_tags 增/删 → 重算该标签 ---
"CREATE TRIGGER IF NOT EXISTS cnt_pt_ai AFTER INSERT ON post_tags
BEGIN
    UPDATE tags SET post_count = (
        SELECT COUNT(DISTINCT pt.post_id) FROM post_tags pt
        JOIN posts p ON p.id = pt.post_id
        WHERE pt.tag_id = new.tag_id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id = new.tag_id;
END;",
"CREATE TRIGGER IF NOT EXISTS cnt_pt_bd AFTER DELETE ON post_tags
BEGIN
    UPDATE tags SET post_count = (
        SELECT COUNT(DISTINCT pt.post_id) FROM post_tags pt
        JOIN posts p ON p.id = pt.post_id
        WHERE pt.tag_id = old.tag_id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id = old.tag_id;
END;",
// --- 帖子 type/status 切换 → 重算该帖全部关联分类/标签(关联行仍在) ---
"CREATE TRIGGER IF NOT EXISTS cnt_posts_au AFTER UPDATE OF type, status ON posts
WHEN (old.type IS NOT new.type) OR (old.status IS NOT new.status)
BEGIN
    UPDATE categories SET post_count = (
        SELECT COUNT(DISTINCT pc.post_id) FROM post_categories pc
        JOIN posts p ON p.id = pc.post_id
        WHERE pc.category_id = categories.id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id IN (SELECT category_id FROM post_categories WHERE post_id = new.id);
    UPDATE tags SET post_count = (
        SELECT COUNT(DISTINCT pt.post_id) FROM post_tags pt
        JOIN posts p ON p.id = pt.post_id
        WHERE pt.tag_id = tags.id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id IN (SELECT tag_id FROM post_tags WHERE post_id = new.id);
END;",
// --- 帖子删除 → 关联若仍在则重算(AFTER:帖已删,COUNT 不含它=正确回落)。
//     应用层契约:先删 posts 再删关联(admin/index.php 已按此;agent-api/litadistribute 同)。
//     若关联先删(非契约路径),posts_bd 集合空=无操作,列会残留→依赖回填脚本修正。 ---
"CREATE TRIGGER IF NOT EXISTS cnt_posts_bd AFTER DELETE ON posts
BEGIN
    UPDATE categories SET post_count = (
        SELECT COUNT(DISTINCT pc.post_id) FROM post_categories pc
        JOIN posts p ON p.id = pc.post_id
        WHERE pc.category_id = categories.id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id IN (SELECT category_id FROM post_categories WHERE post_id = old.id);
    UPDATE tags SET post_count = (
        SELECT COUNT(DISTINCT pt.post_id) FROM post_tags pt
        JOIN posts p ON p.id = pt.post_id
        WHERE pt.tag_id = tags.id AND p.type = 'post' AND p.status = 'publish'
    ) WHERE id IN (SELECT tag_id FROM post_tags WHERE post_id = old.id);
END;",
];
