<?php
/**
* Bootstrap file
*/

// 禁止 web 直访：load.php 是引导文件，只应由入口脚本 require。
// 直访会让"一个匿名请求就跑完 config → functions → 插件 init 钩子"的整条引导链。
// 判定依据：直访时 SCRIPT_FILENAME 就是本文件；被 require 时它是入口脚本。
if (isset($_SERVER['SCRIPT_FILENAME']) && basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

if (!defined('CORE')) {
    define('CORE', true);
}

require_once dirname(__FILE__) . '/../config.php';

// ===== 调试开关统一（2026-09-16）=========================================
// 全站唯一的调试开关 = **config.php 里的 DEBUG**（上面的 require 已把它加载好）。
// 历史问题：index.php 的注释让站长改 LITABLOG_DEBUG，但该常量全站从未被定义 ✗；
// 而 functions.php 的 litablog_debug() 只认 DEBUG → 出现"改了开关却没生效"。
// 现在统一到 DEBUG，并保留对旧名的兼容映射，避免既有配置失效：
//   · DEBUG=true  → 回显错误 + error_reporting(E_ALL)（本地调试）
//   · DEBUG=false → display_errors=0 + error_reporting(0)（生产，绝不回显路径/SQL/配置，A-7）
// 同时修正原写法 `display_errors='on'`：它与 A-7 直接矛盾，只靠 error_reporting(0) 兜着 ——
// 一旦某个插件/主题把 error_reporting 调回 E_ALL，就会把路径/SQL 泄露给访客。
// =======================================================================
if (!defined('DEBUG') && defined('LITABLOG_DEBUG')) {
define('DEBUG', (bool) LITABLOG_DEBUG);
}
if (defined('DEBUG') && DEBUG) {
ini_set('display_errors', '1');
error_reporting(E_ALL);
} else {
ini_set('display_errors', '0');
error_reporting(0);
}

$http_host = $_SERVER['HTTP_HOST'] ?? '';
$http_host = preg_replace('/:\d+$/', '', $http_host);

function get_safe_client_ip() {
// C-7 修复：不再无条件信任 HTTP_CF_CONNECTING_IP。
//
// 原实现在函数开头直接采用该头（第 21-23 行），**不校验请求是否真的来自 Cloudflare**。
// 非 Cloudflare 部署（直连/其它 CDN）下，攻击者可任意伪造此头，
// 使登录限流、爆破锁定（login_attempts 按 IP 记录）完全失效 —— 换头即可无限重试。
//
// 现逻辑：先判断直连方是否为「可信代理」（私有网段内网网关，或 TRUSTED_PROXIES 中显式配置的 IP），
// 只有确认请求经由可信代理转发时，才采用 CF 头 / XFF 头中的客户端 IP。

$remote = $_SERVER['REMOTE_ADDR'] ?? '';
$cf_ip  = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';
$xff    = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';

// 没有任何代理头 → 直连，直接返回
if ($cf_ip === '' && $xff === '') {
return $remote;
}

// 判断直连方是否可信
$private_pattern = '/^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.|127\.)/';
$trusted = (bool)preg_match($private_pattern, $remote);

if (!$trusted && defined('TRUSTED_PROXIES') && is_array(TRUSTED_PROXIES)) {
foreach (TRUSTED_PROXIES as $proxy) {
if ($remote === $proxy) { $trusted = true; break; }
}
}

// 直连方不可信 → 忽略一切代理头，返回真实直连 IP（防伪造）
if (!$trusted) {
return $remote;
}

// 直连方可信 → 优先 Cloudflare 头，其次 XFF 首个 IP
if ($cf_ip !== '' && filter_var($cf_ip, FILTER_VALIDATE_IP)) {
return $cf_ip;
}

$ips = array_map('trim', explode(',', $xff));
$client_ip = $ips[0] ?? '';
return filter_var($client_ip, FILTER_VALIDATE_IP) ? $client_ip : $remote;
}

$_SERVER['REMOTE_ADDR'] = get_safe_client_ip();

$is_secure = false;
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
$is_secure = true;
} elseif (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') {
$is_secure = true;
} elseif (($_SERVER['HTTP_CF_VISITOR'] ?? '') === '{"scheme":"https"}') {
$is_secure = true;
}

$cookie_domain = ''; 
$cookie_path = '/';
session_name('MYAPPSESSID');

// E-4 Session 条件化启动:仅「前台 index.php 渲染 + 无 Cookie 的匿名 GET」跳过 session。
// 匿名静态流量不建 session 文件、不 Set-Cookie → 零 I/O 浪费,且下个请求可命中整页缓存。
// 后台(/admin)、内部入口(/includes)、POST、带 Cookie 的请求一律照常启动,功能零影响。
$script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
// 目录部分:纯字符串截取(不能用 dirname——Windows 下 dirname('/index.php') 返回 '\',rtrim 清不掉)
// ⚠️ 2026-09-16 同步 v10：原判定 `$script_dir === ''` 假设站点部署在**根目录**。
// 子目录部署（如 /v7/）下 SCRIPT_NAME=/v7/index.php → $script_dir='/v7' → 被判成"非前台入口"
// → 匿名访客照样启动会话（下发 Set-Cookie）→ 之后每个请求都带 Cookie → **整页缓存永不命中** ✗
// 改为按脚本名判断：前台入口 = 任意层级下的 index.php，且不在 /admin/、/includes/ 之下。
$is_front_entry = (basename($script_name) === 'index.php')
    && strpos($script_name, '/admin/') === false
    && strpos($script_name, '/includes/') === false;
$is_anon_read   = $is_front_entry
    && empty($_COOKIE)
    && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET';

if (session_status() === PHP_SESSION_NONE && !$is_anon_read) {
session_set_cookie_params([
'lifetime' => 0,
'path'     => $cookie_path,
'domain'   => $cookie_domain,
'secure'   => $is_secure,
'httponly' => true,
'samesite' => 'Lax'
]);
// use_strict_mode=0(2026-09-10 调整,原 '1'):strict 模式下"浏览器持有服务器不认识的旧 ID"
// (重装/换机/浏览器 cookie 异常场景,免费主机用户高发)会导致每请求签发新 session 却
// 永远不被浏览器采用 → CSRF token 永远对不上 → 登录/注册"总是失败"。
// 关闭后服务器收编客户端任意 ID(沿用重建),症状消失;会话固定攻击由登录成功时的
// session_regenerate_id(true) 在提权瞬间兜底。实测案例:it.dashu.eu.org 注册/登录全挂,
// 清浏览器站点数据即愈——但这不该要求用户做。
ini_set('session.use_strict_mode', '0');
session_start();
}

if (!headers_sent()) {
header_remove('X-Powered-By');
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

$csp = "default-src 'self'; "
. "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; "
. "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
. "img-src 'self' data:; "
. "font-src 'self' https://cdn.jsdelivr.net; "
. "connect-src 'self'; "
. "frame-ancestors 'self'; "
. "base-uri 'self'; "
. "form-action 'self';";
header('Content-Security-Policy: ' . $csp); 
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

if ($is_secure) {
header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
}
}

require_once ABSPATH . '/includes/router.php';
require_once ABSPATH . '/includes/permalink.php';
require_once ABSPATH . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'functions.php';
require_once ABSPATH . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'db_wrapper.php';
// E-1 移植:通用文件缓存层(cache_get/set/remember + search_index_enabled 探测)
require_once ABSPATH . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'cache_layer.php';
// 整页缓存工具(所有入口共享,写操作统一用 pc_purge() 失效)。require_once 防 index.php 已加载。
require_once dirname(__FILE__) . '/page_cache.php';

$site_timezone = get_option('site_timezone', 'Asia/Shanghai');
date_default_timezone_set($site_timezone);

$db = get_db();

if (!isset($_SESSION['user_id']) && isset($_COOKIE['lita_remember'])) {
$parts = explode(':', $_COOKIE['lita_remember'], 2);
if (count($parts) === 2) {
$selector = $parts[0];
$validator = $parts[1];
$hashed_validator = hash('sha256', $validator);

try {
$db = get_db();

// D-1 修复：记住我 token 改用独立表 remember_tokens（selector 主键，O(log N) 精准命中）。
//
// 原实现：`SELECT user_id, meta_value FROM usermeta WHERE meta_key='remember_tokens'`
// 会把**全部用户**的 token blob 一次性取回，再逐行反序列化、逐个比对；
// 命中后还要把整块 blob 重新序列化写回（update_user_meta）。
// 50 万用户时，每个携带 remember Cookie 的请求都要搬运并解析全部用户的 token，
// 造成百 MB 级内存抖动与秒级延迟，且随用户量线性劣化。
//
// 现实现：按 selector 主键一次查询命中；轮换 validator 只 UPDATE 该行。
// 建表改为「一次性守卫」：option 标志记住已初始化，未初始化才执行 DDL 并落标志。
// （原实现每请求都跑 CREATE TABLE/INDEX IF NOT EXISTS——读路径混入写，
//   SQLite 单写者模型下与真正的写操作抢锁；标志化后 schema 检查只在首次发生。）
// E-3 统一：schema 自愈收敛到 litablog_ensure_remember_tokens_schema()（原实现在本文件用 option
// 守卫、在 admin/login.php 两条路径裸跑 DDL，同类问题三种写法；现在只有一处实现）。
litablog_ensure_remember_tokens_schema();

$stmt = $db->prepare("SELECT user_id, hashed_validator, expires FROM remember_tokens WHERE selector = :sel");
$stmt->bindValue(':sel', $selector, PDO::PARAM_STR);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$matched_user_id = null;
$matched_expires = 0;

if ($row && (int)$row['expires'] > time()) {
if (hash_equals($row['hashed_validator'], $hashed_validator)) {
$matched_user_id = (int)$row['user_id'];
$matched_expires = (int)$row['expires'];
}
} elseif ($row) {
// 惰性清理：仅当真的「读到」一条过期 token 时才删这一行（单行条件 DELETE）。
// 认证安全性不受影响——上方 expires > time() 校验本就拒绝过期 token，
// 删除只是延迟回收存储；正常流量下该分支几乎不触发，写锁占用≈0。
$stmt_del = $db->prepare("DELETE FROM remember_tokens WHERE selector = :sel AND expires <= :t");
$stmt_del->bindValue(':sel', $selector, PDO::PARAM_STR);
$stmt_del->bindValue(':t', time(), PDO::PARAM_INT);
$stmt_del->execute();
}

if ($matched_user_id) {
$user = get_user($matched_user_id);
if ($user && $user['status'] === 'active') {
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

// 轮换 validator：只更新该行（避免整 blob 重写）
$new_validator = bin2hex(random_bytes(24));
$new_hashed_validator = hash('sha256', $new_validator);

$stmt_upd = $db->prepare("UPDATE remember_tokens SET hashed_validator = :hv WHERE selector = :sel");
$stmt_upd->bindValue(':hv', $new_hashed_validator, PDO::PARAM_STR);
$stmt_upd->bindValue(':sel', $selector, PDO::PARAM_STR);
$stmt_upd->execute();

setcookie(
'lita_remember',
$selector . ':' . $new_validator,
$matched_expires,
'/',
'',
$is_secure,
true
);
}
}

// 过期 token 清理已改为「读到过期行才删」（上方 elseif 分支），
// 热路径不再执行任何无条件 DELETE。表增长速率 = "记住我"登录次数，
// 个人博客量级下数年 ~千行，无回收压力；如需主动回收可挂到登录写操作上。
} catch (Exception $e) {
error_log("Auto login database error.");
}
}
}

if (!defined('PLUGINS_LOADED')) {
define('PLUGINS_LOADED', true);
$active_plugins = get_active_plugins();
foreach ($active_plugins as $plugin) {
$plugin_file = ABSPATH . 'content/plugins/' . $plugin['slug'] . '/' . $plugin['slug'] . '.php';
if (file_exists($plugin_file)) {
require_once $plugin_file;
}
}
}
do_action('init');

// 统计信息自维护（SQLite 官方推荐做法：连接关闭前调用 PRAGMA optimize）
// 背景（2026-09-13 实测踩坑）：安装时 ANALYZE 的是空库，随后灌入数万测试数据，
// sqlite_stat1 过期 → 规划器放着新建的 idx_posts_sticky 不用，退回老索引 + TEMP B-TREE，
// 置顶查询 41ms；补一次 ANALYZE 后同一查询 0.09ms（约 450 倍）。
// PRAGMA optimize 会在"改动量足够"时才真正 ANALYZE，空跑成本微秒级。
register_shutdown_function(function () {
    try {
        if (function_exists('get_db')) {
            get_db()->exec('PRAGMA optimize;');
        }
    } catch (Throwable $e) {
        // 静默：统计优化失败绝不能影响响应
    }
});
?>