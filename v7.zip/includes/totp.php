<?php
/**
 * LitaBlog 极简 TOTP (2FA) 验证助手 (符合 RFC 6238 规范)
 */
 if (!defined('CORE')) {
    http_response_code(403);
    exit('Direct access not allowed.');
}
class LitaTOTP {
    
    // 生成一个安全的 16 位 Base32 随机密钥
    public static function generateSecret($length = 16) {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= $alphabet[random_int(0, 31)];
        }
        return $secret;
    }

    // 将 Base32 字符串还原为二进制
    private static function base32Decode($secret) {
        $secret = strtoupper($secret);
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $buf = '';
        $v = 0;
        $v_bits = 0;
        for ($i = 0, $len = strlen($secret); $i < $len; $i++) {
            $c = $secret[$i];
            $p = strpos($alphabet, $c);
            if ($p === false) continue;
            $v = ($v << 5) | $p;
            $v_bits += 5;
            if ($v_bits >= 8) {
                $v_bits -= 8;
                $buf .= chr(($v >> $v_bits) & 255);
            }
        }
        return $buf;
    }

    // 验证用户输入的 6 位动态密码 (支持 ±1 个时间步长的时钟容差)
    public static function verifyCode($secret, $code, $discrepancy = 1) {
        $secret_binary = self::base32Decode($secret);
        $time_slice = floor(time() / 30); // 30 秒为一个步长

        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            if (hash_equals(self::calculateCode($secret_binary, $time_slice + $i), $code)) {
                return true;
            }
        }
        return false;
    }

    // 根据二进制密钥和时间步长计算 6 位哈希值
    private static function calculateCode($secret_binary, $time_slice) {
        $time_bytes = pack('N*', 0, $time_slice);
        $hmac = hash_hmac('sha1', $time_bytes, $secret_binary, true);
        $offset = ord($hmac[19]) & 0xf;
        $hashpart = substr($hmac, $offset, 4);
        $value = unpack('N', $hashpart);
        $value = $value[1] & 0x7fffffff;
        $otp = $value % 1000000;
        return str_pad($otp, 6, '0', STR_PAD_LEFT);
    }

    // 拼装用于生成二维码的 OTPAuth 标准协议 URL
    public static function getQrCodeUrl($label, $secret, $issuer = 'LitaBlog') {
        return 'otpauth://totp/' . rawurlencode($issuer . ':' . $label) . '?secret=' . $secret . '&issuer=' . rawurlencode($issuer);
    }
}