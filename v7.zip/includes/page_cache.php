<?php
// 禁止 web 直访：本文件只应由 index.php require。
if (isset($_SERVER['SCRIPT_FILENAME']) && basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

/**
 * page_cache.php — 前台整页静态缓存(面向免费主机配额:Daily Hits/CPU/RAM/I/O/Entry Process)
 *
 * 设计目标:匿名 GET 流量 99% 不进 PHP 业务栈。
 *   - 命中:readfile() 直接吐静态 HTML → 0 include / 0 SQL / 0 session / <5ms
 *   - Miss:index.php 正常渲染后 ob 捕获,原子写入(temp + rename)
 *
 * 绕过条件(保持实时):非 GET、带任何 Cookie(登录/已建会话)、后台/内部入口。
 * 因此登录用户、管理员、提交过评论的用户都走实时渲染,无缓存串号风险。
 * 缓存页不包含任何可写表单(评论区仅登录用户可见),因此无 CSRF/session 兼容问题。
 *
 * 失效(2026-09 起改为「TTL 自愈」模型,写路径零缓存操作):
 *   - 不再于写操作后自动全清(pc_purge 调用点已全部移除);
 *   - 各页 filemtime 天然错开,过期后由下个匿名请求惰性重建并原子覆盖,
 *     消除了原「写后全清 → 全站同时 miss → 并发全栈渲染」的惊群;
 *   - 匿名访客内容最多滞后 TTL(首页 60s/列表 120s/单篇 600s);
 *   - 作者与登录用户带 Cookie 直连实时渲染,永不受缓存滞后影响;
 *   - pc_purge() 保留为手动清空入口(后台按钮/CLI/直接删 content/cache/page/ 均可)。
 *   - 缓存目录:content/cache/page/(已有 content/cache/.htaccess Require all denied 保护)
 *   - TTL 分层:首页 60s / 列表(分类·标签·作者)120s / 单篇·页面 600s / 搜索 60s
 *   - 404 一律不缓存(避免缓存文件爆炸)
 *
 * 用法:
 *   index.php 顶部(require load.php 之前): require ...page_cache.php; pc_serve();(命中自行 exit)
 *   渲染段用 ob_start() 包裹,结束后调用 pc_store($template_data['request_type'])
 *   写操作无需调用任何缓存失效函数;需要立即生效时手动调用 pc_purge()。
 */
if (!defined('PC_CACHE_DIR')) {
    // 不依赖 ABSPATH(config 常量),serve 阶段 config 尚未加载
    define('PC_CACHE_DIR', dirname(__DIR__) . '/content/cache/page');
}
if (!defined('PC_TTL_HOME'))    define('PC_TTL_HOME',    60);
if (!defined('PC_TTL_LIST'))    define('PC_TTL_LIST',    120);
if (!defined('PC_TTL_SINGLE'))  define('PC_TTL_SINGLE',  600);
if (!defined('PC_TTL_SEARCH'))  define('PC_TTL_SEARCH',  60);

/**
 * 站点基路径（支持子目录部署，如 /v7/）。2026-09-16 同步 v10。
 *
 * ⚠️ 原实现把 REQUEST_URI 的 path 直接当路由路径 → 子目录部署下 /v7/ 会被 rtrim 成 '/v7'，
 * 既不等于 '' 也不等于 '/index.php' → 首页被误判成 single（TTL 600s + 键退回完整 URI）；
 * /v7/admin/xxx 这类路径的前缀拦截也会落空（前缀不再是串首）。
 * pc_serve() 只由 index.php 调用，所以 SCRIPT_NAME 的目录就是基路径。
 */
function pc_base_path() {
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    if ($script === '' || $script === false) return '';
    $dir = str_replace('\\', '/', dirname($script));
    if ($dir === '/' || $dir === '.' || $dir === '') return '';
    return rtrim($dir, '/');
}

/** 请求路径去掉站点基路径后的相对路径（以 / 开头）。 */
function pc_rel_path() {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    if ($path === null || $path === false) $path = '/';
    $base = pc_base_path();
    if ($base !== '' && stripos($path, $base) === 0) {
        $path = substr($path, strlen($base));
    }
    if ($path === '' || $path === false) $path = '/';
    return $path[0] === '/' ? $path : '/' . $path;
}

/**
 * 该请求是否允许走整页缓存(匿名读请求)。
 * @return bool
 */
function pc_is_cacheable_request() {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') return false;
    if (!empty($_COOKIE))  return false; // 登录 / 曾建会话 → 必须实时
    if (!empty($_POST))    return false;
    if (!empty($_FILES))   return false;
    if (PHP_SAPI === 'cli') return false;

    // 子目录部署安全（2026-09-16 同步 v10）：按 SCRIPT_NAME 去掉站点基路径再判，
    // 否则 /v7/admin/... 的前缀判断会落空（原实现假设站点在根目录）。
    $lower = strtolower(pc_rel_path());
    // 后台 / 内部 / 接口一律不缓存(它们不经 index.php 渲染,但双保险)
    if (strpos($lower, '/admin/') === 0 || strpos($lower, '/includes/') === 0) return false;
    $base = strtolower(basename($lower) ?: '');
    if (in_array($base, ['test001.php', 'ajax.php', 'install.php', 'probe_page.php', 'probe_page2.php', 'probe_render.php'])) return false;
    return true;
}

/**
 * 唯一 URL 语法表(P0-2 语法白名单,2026-09 重构)。
 *
 * 设计:本站 URL 类型完全固定——home / home分页 / 单篇 / 分类 / 标签 / 搜索。
 * 「每个合法 URL 一个缓存文件」的合法 URL = **能被下表语法精确匹配的 URL**;
 * 不在语法内的任何参数/组合(含 ?p=abc1 文件风暴、?p=1&page=2 组合枚举、
 * ?author/?year/?month 这类代码中不存在对应页面类型的死参数)一律 type=out,不缓存。
 *
 * 此函数是 pc_url_sane / pc_request_type / pc_key 三者的唯一真相源,
 * 新增页面类型(如未来的作者归档)只改这里,三处判断自动同步,杜绝双真相源漂移。
 * @return array{type:string,params:array<string,string>}
 *   type ∈ home|home_page|single|category|tag|search|out(out=不在语法内,永不缓存)
 */
function pc_parse_url() {
    $uri  = $_SERVER['REQUEST_URI'] ?? '/';
    $qs   = parse_url($uri, PHP_URL_QUERY) ?? '';
    // 去掉站点基路径（2026-09-16 同步 v10）：子目录部署（/v7/）下只有这样首页才算 home，
    // 否则 rtrim 得到 '/v7' → 被误判成 single（TTL 600s + 键退回完整 URI）。
    $path = rtrim(pc_rel_path(), '/');
    parse_str($qs, $q);

    // 搜索:任何形态一律不缓存(动态性强、缓存价值低,既定设计)
    if (isset($q['s'])) {
        return ['type' => 'search', 'params' => []];
    }

    // 单篇语法:?p=N(纯数字且为唯一参数;page/year 等对单篇无意义,带即 out)
    if (isset($q['p'])) {
        // ?p[]=1 这类数组参数会让 (string) 强转触发 PHP 警告，先判标量
        if (!is_scalar($q['p'])) return ['type' => 'out', 'params' => []];
        if (count($q) === 1 && preg_match('/^\d{1,6}$/', (string)$q['p']) && (int)$q['p'] > 0) {
            return ['type' => 'single', 'params' => ['p' => (string)(int)$q['p']]];
        }
        return ['type' => 'out', 'params' => []];
    }

    // 分类/标签语法:?category=<id>[&page=N] / ?tag=<id>[&page=N]
    // ★2026-09-17（与 v10 同步 ✓）：术语 URL 已改为**数值 id** ✓；但下面的白名单**同时放行文本** ✓
    //   （`[\p{L}\p{N}_-]{1,60}` ✓），因为 router 仍支持"非数字 = 旧 slug" ✓ —— 老链接/旧缓存还能用 ✓
    foreach (['category', 'tag'] as $t) {
        if (isset($q[$t])) {
            $rest = $q;
            unset($rest[$t]);
            $page = null;
            foreach (['page', 'paged'] as $pk) {
                if (isset($rest[$pk])) { $page = $rest[$pk]; unset($rest[$pk]); break; }
            }
            if (!empty($rest)) return ['type' => 'out', 'params' => []];
            if (!is_scalar($q[$t])) return ['type' => 'out', 'params' => []];
            if ($page !== null && !is_scalar($page)) return ['type' => 'out', 'params' => []];
            // slug 放行中文等非 ASCII（2026-09-16 同步 v10；本库版块/标签 slug 就有中文，如"分享"）：
            // 原实现只放行 [a-z0-9_-] → 中文 slug 全被判 out → 这类页面永不缓存 ✗（v10 单元测试抓到的同款问题）
            if (!preg_match('/^[\p{L}\p{N}_-]{1,60}$/u', (string)$q[$t])) return ['type' => 'out', 'params' => []];
            if ($page !== null && (!preg_match('/^\d{1,4}$/', (string)$page) || (int)$page > 2000)) {
                return ['type' => 'out', 'params' => []];
            }
            $params = [$t => (string)$q[$t]];
            if ($page !== null) { $params['page'] = (string)(int)$page; }
            return ['type' => $t, 'params' => $params];
        }
    }

    // 首页分页语法:?page=N 或 ?paged=N(唯一参数)
    if (isset($q['page']) || isset($q['paged'])) {
        if (count($q) !== 1) return ['type' => 'out', 'params' => []];
        $k = isset($q['page']) ? 'page' : 'paged';
        if (!is_scalar($q[$k])) return ['type' => 'out', 'params' => []];
        $v = (string)$q[$k];
        if ($v === '' || !preg_match('/^\d{1,4}$/', $v) || (int)$v > 2000) {
            return ['type' => 'out', 'params' => []];
        }
        return ['type' => 'home_page', 'params' => [$k => (string)(int)$v]];
    }

    // 无参数:根路径=home;非根伪静态路径维持旧行为标为 single(Router 侧会定 404,不落盘)
    if (empty($q)) {
        if ($path === '' || $path === '/index.php') return ['type' => 'home', 'params' => []];
        if ($path !== '') return ['type' => 'single', 'params' => []];
    }
    return ['type' => 'out', 'params' => []];
}

/**
 * 轻量 URL 分类(不连库,仅用于 serve 阶段挑选 TTL)。
 * 从 pc_parse_url() 语法表派生,不再独立解析(消除双真相源漂移)。
 * @return string home|list|single|search|out
 */
function pc_request_type() {
    $g = pc_parse_url();
    switch ($g['type']) {
        case 'home':       return 'home';
        case 'home_page':  return 'list';
        case 'single':     return 'single';
        case 'category':
        case 'tag':        return 'list';
        case 'search':     return 'search';
    }
    return 'out'; // 不在语法内 → pc_ttl() 默认 0 → 永不 serve/store
}

/** 由请求类型映射 TTL(秒);404 与未知返回 0=不缓存 */
function pc_ttl($type) {
    switch ($type) {
        case 'home':   return PC_TTL_HOME;
        case 'list':
        case 'category':
        case 'tag':
        case 'author':
        case 'year':
        case 'month':  return PC_TTL_LIST;
        case 'single':
        case 'page':   return PC_TTL_SINGLE;
        case 'search': return PC_TTL_SEARCH;
    }
    return 0;
}

/**
 * 缓存键(语法规范化版):md5(类型 + 语法内规范化参数)。
 *   - 单篇键只含 p(单篇页语义上仅由 p 决定)→ ?p=01 与 ?p=1 同键,去重复副本;
 *   - 其余类型键含排序后的语法内参数 → 参数顺序不同的同页同键;
 *   - out/search 不应到达此处(上游已拦截),兜底退回完整 URI 保持旧行为。
 */
function pc_key() {
    $g = pc_parse_url();
    if ($g['type'] === 'out' || $g['type'] === 'search') {
        return md5($_SERVER['REQUEST_URI'] ?? '/');
    }
    if ($g['type'] === 'single' && empty($g['params'])) {
        // 伪静态无参路径形态:键退回完整 URI,避免所有路径共享一个键
        return md5($_SERVER['REQUEST_URI'] ?? '/');
    }
    $canonical = $g['type'];
    foreach ($g['params'] as $k => $v) {
        $canonical .= '|' . $k . '=' . $v;
    }
    return md5($canonical);
}

/**
 * URL 形态白名单(P0-2 语法白名单版):从 pc_parse_url() 派生。
 * 只有「固定页面类型的语法精确匹配」才算合法 URL(才值得一个缓存文件):
 *   - ?p=abc1 / ?year=abc / ?author=x 等非法值与死参数 → out → 不缓存(风暴根治);
 *   - ?p=1&page=2 等类型外组合 → out → 不缓存(组合枚举根治);
 *   - false 的语义是「不缓存」而非「拒绝请求」,非法 URL 仍正常动态渲染。
 * @return bool true=可缓存
 */
function pc_url_sane() {
    $t = pc_parse_url()['type'];
    return $t !== 'out' && $t !== 'search';
}

/**
 * P0-3 低频缓存垃圾回收:删除 7 天以上未被访问的整页缓存文件。
 * 触发:pc_serve() 命中前按「距上次 GC>24h + 随机 5%」执行,避免热点路径与并发重复遍历。
 * 效果:爬虫扫出的 URL 变体、过期未重建的旧页,长期不占磁盘配额。
 */
function pc_maybe_gc() {
    $stamp = PC_CACHE_DIR . '/.gc.stamp';
    if (is_file($stamp) && (time() - @filemtime($stamp)) < 86400) {
        return; // 24h 内已清理过,节流
    }
    if (mt_rand(1, 20) !== 1) {
        return; // 仅 5% 请求成为执行者,分散成本
    }
    @touch($stamp); // 先标记,防并发
    $cutoff = time() - 604800; // 7 天
    if (!is_dir(PC_CACHE_DIR)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(PC_CACHE_DIR, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $file) {
        $p = $file->getPathname();
        if ($file->isFile() && @filemtime($p) < $cutoff) {
            @unlink($p);
        } elseif ($file->isDir()) {
            @rmdir($p);
        }
    }
}

/** 缓存文件路径(按 key 前 2 位分桶,避免单目录堆积) */
function pc_file($key = null) {
    $key = $key !== null ? $key : pc_key();
    return PC_CACHE_DIR . '/' . substr($key, 0, 2) . '/' . $key . '.html';
}

/**
 * 命中服务:校验通过且文件新鲜则直接输出并 exit。未命中返回 false 走正常渲染。
 */
function pc_serve() {
    if (!pc_is_cacheable_request()) return false;
    if (!pc_url_sane()) return false; // 文件风暴防护:搜索/异常分页/未知参数不 serve
    pc_maybe_gc(); // P0-3 低频清理过期缓存(命中前,节流+随机,零热点影响)
    $ttl = pc_ttl(pc_request_type());
    if ($ttl <= 0) return false;
    $f = pc_file();
    if (!is_file($f)) return false;
    if (time() - @filemtime($f) >= $ttl) return false; // 过期:交给渲染重建(惰性)

    // 与 load.php 实时渲染一致的安全头
    header('Content-Type: text/html; charset=UTF-8');
    if (!headers_sent()) {
        header_remove('X-Powered-By');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; style-src \'self\' \'unsafe-inline\' https://cdn.jsdelivr.net; img-src \'self\' data:; font-src \'self\' https://cdn.jsdelivr.net; connect-src \'self\'; frame-ancestors \'self\'; base-uri \'self\'; form-action \'self\';');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    }
    readfile($f);
    exit;
}

/**
 * 安全闸：这段 HTML 是否允许落盘（2026-09-16 同步 v10）。
 *
 * 为什么要有：本框架前台**可写表单**里的 `csrf_token_field()` 是**会话绑定**令牌。
 * 一旦随 HTML 落盘，别的访客拿到的是"别人的令牌"→ 提交必然 CSRF 失败；令牌本身也等于泄露。
 * v7/v8 现状是 E-7 路线（评论区仅登录用户渲染表单）+ 页脚快捷发帖块也有 is_logged_in 门控，
 * 所以匿名页面本就没有令牌 → 本闸**不影响缓存命中**，属纵深保险：
 * 万一日后主题/插件给访客渲染了 csrf_token_field()，也不会把别人的令牌冻进缓存。
 * 判据只认**真有令牌值**的痕迹与已登录文案（不用 CSS 类名/JS 字符串，v10 首版那样误判过 ✗）。
 */
function pc_is_safe_to_store($html) {
    if (preg_match('/name=["\']csrf_token["\'][^>]*value=["\'][0-9a-fA-F]{32,}/i', $html)) return false;
    if (stripos($html, '您已登录为') !== false) return false;
    return true;
}

/**
 * 渲染完成后存储(由 index.php 在渲染结束调用)。
 * @param string $request_type 真实请求类型(home/single/category/tag/search/.../404)
 */
function pc_store($request_type) {
    if (!pc_is_cacheable_request()) return;
    if (!pc_url_sane()) return; // 文件风暴防护:搜索/异常分页不落盘
    if ($request_type === '404' || empty($request_type)) return; // 404 不缓存
    if (!function_exists('http_response_code') || http_response_code() !== 200) return; // 跳转/错误不缓存
    $html = ob_get_clean(); // 取走渲染缓冲(注意:此后缓冲已关闭,必须自行回显)
    if ($html === false) return; // 无内容可输出
    $ttl = pc_ttl($request_type);
    if ($ttl > 0 && strlen($html) >= 64 && pc_is_safe_to_store($html)) {
        pc_write($html, $ttl); // E-9:仅足够内容才落盘
    }
    echo $html; // E-9 关键修复:回显 miss 渲染内容。此前 ob_get_clean() 取走缓冲后未 echo,
                // 导致「匿名首访(miss)→ 渲染内容被吞 → 返回空 200」;只有二次起缓存命中才正常。
}

/**
 * 原子写入缓存文件(临时文件 + rename)。并发下最后写入者胜,无损坏。
 */
function pc_write($html, $ttl) {
    if ($ttl <= 0) return;
    $dir = PC_CACHE_DIR;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return;
    $key = pc_key();
    $sub = $dir . '/' . substr($key, 0, 2);
    if (!is_dir($sub) && !@mkdir($sub, 0755, true)) return;
    $tmp = $sub . '/.' . $key . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (@file_put_contents($tmp, $html, LOCK_EX) === false) return;
    @rename($tmp, $sub . '/' . $key . '.html');
}

/**
 * 手动全清缓存(非自动:常规写路径已改为 TTL 惰性过期自愈,不调用本函数)。
 * 适用:后台"清空缓存"按钮、CLI 维护脚本、调试;或直接删除 content/cache/page/ 目录等效。
 */
function pc_purge() {
    if (!is_dir(PC_CACHE_DIR)) return;
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator(PC_CACHE_DIR, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $file) {
        $p = $file->getPathname();
        if ($file->isFile()) { @unlink($p); }
        elseif ($file->isDir()) { @rmdir($p); }
    }
}
