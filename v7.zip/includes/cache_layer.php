<?php
/**
 * cache_layer.php - 核心层文件缓存（通用，与主题/前端无关）
 *
 * 用途：缓存低频变化的查询结果（搜索结果、索引可用性探测等），
 * 避免 50 万+ 数据量下每次请求实时重算。
 *
 * ⚠️ 覆盖范围(重要)：本层是**全站唯一**的对象/查询级缓存引擎。
 *    以下缓存已统一走本层(同一存储、同一原子写协议、同一失效入口):
 *      - 搜索结果 / 表探测            → cache_remember / cache_get(核心自用)
 *      - options 全表快照            → 键 options_full(functions.php get_option,60s)
 *      - 激活插件清单                → 键 active_plugins(functions.php get_active_plugins,300s)
 *      - 文章/置顶计数               → 键 total_posts_* / sticky_total(60s)
 *    唯一例外(设计如此,不并入):
 *      - 整页静态缓存  → includes/page_cache.php(独立,readfile 直出,自有 GC/失效语义,
 *        缓存的是渲染产物 HTML 而非查询结果,体积/失效粒度/服务方式均不同)。
 *    因此「用 Redis 替代文件缓存」类插件经 cache_get/cache_set 钩子可接管上述全部键。
 *
 * 机制：
 *   - 缓存文件存放在 content/cache/<键标签>-<md5(键)>.json（标签供 flush 分诊）
 *   - 每个缓存项带过期时间戳，读取时检查 TTL，过期删除并重建
 *   - 显式失效用 cache_delete(键)；写操作粗粒度失效用 cache_flush()
 *   - 线程安全：写文件用唯一临时文件 + rename（原子替换）
 */

// 禁止 web 直访：本文件只应由 load.php / 入口脚本 require。
if (isset($_SERVER['SCRIPT_FILENAME']) && basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    http_response_code(403);
    exit('Direct access not allowed.');
}
if (!defined('CORE')) {
    http_response_code(403);
    exit('Direct access not allowed.');
}

/** 缓存目录（content/cache/，可写） */
function cache_dir() {
    $dir = ABSPATH . 'content/cache/';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return $dir;
}

/**
 * 缓存键 → 物理文件名：<键标签>-<md5(键)>.json。
 * 键标签 = 键前 40 字符去除不安全字符。把键前缀带进文件名是刻意的：
 * cache_flush() 需要按「键前缀」决定保护/清除，而纯 md5 文件名无法反推键
 * （旧实现的 search_ 保护判断因比对的是 md5 串而从未生效）。
 * 标签仅用于 flush 分诊，唯一性由 md5(完整键) 保证。
 * @param string $key 缓存键
 * @return string 绝对文件路径
 */
function cache_key_file($key) {
    $tag = preg_replace('/[^A-Za-z0-9_]/', '', substr((string)$key, 0, 40));
    if ($tag === '' || $tag === false) {
        $tag = 'k';
    }
    return cache_dir() . $tag . '-' . md5($key) . '.json';
}

/**
 * 读取缓存
 * @param string $key 缓存键
 * @param int    $ttl 有效秒数（默认 60）
 * @param bool   $stale 允许读过期值（stale-if-error，用于并发等待场景，不删除文件）
 * @return mixed|null 命中返回数据（数组），未命中/过期返回 null
 */
function cache_get($key, $ttl = 60, $stale = false) {
    // X-1 扩展点:允许插件接管缓存读取(如 Redis/Memcached/APCu,多机部署时文件缓存不同步)。
    // 插件返回非 null 即接管;无插件注册时仅一次 isset() 查找,零开销。
    // 注意:插件实现内不得再调用 cache_get(),否则无限递归。
    if (function_exists('apply_filters')) {
        $v = apply_filters('cache_get', null, $key, $ttl, $stale);
        if ($v !== null) {
            return $v;
        }
    }

    $file = cache_key_file($key);
    if (!is_file($file)) {
        return null;
    }
    $data = @json_decode(@file_get_contents($file), true);
    if (!is_array($data) || !isset($data['exp'], $data['val'])) {
        return null;
    }
    if ($data['exp'] < time()) {
        if ($stale) {
            return $data['val']; // 读过期值（不删除，供并发兜底）
        }
        @unlink($file);
        return null;
    }
    return $data['val'];
}

/**
 * 写入缓存
 * @param string $key 缓存键
 * @param mixed  $val 数据（可 json 编码）
 * @param int    $ttl 有效秒数
 */
function cache_set($key, $val, $ttl = 60) {
    // X-1 扩展点:允许插件接管缓存写入(与 cache_get 同)。
    // 插件返回 true 表示已自行写入,核心不再写文件;返回 null/false 则回落到文件缓存。
    if (function_exists('apply_filters')) {
        $done = apply_filters('cache_set', null, $key, $val, $ttl);
        if ($done === true) {
            return;
        }
    }

    $file = cache_key_file($key);
    $payload = json_encode(['exp' => time() + $ttl, 'val' => $val]);
    // 原子写入：先写临时文件再 rename，避免并发读半文件
    $tmp = $file . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $payload, LOCK_EX) !== false) {
        @rename($tmp, $file);
    }

    // 概率触发过期清扫（见 cache_gc 说明）：约 1/100 次写入扫一遍目录，
    // 补上"被永久豁免的 search_* 缓存从不回收"这个缺口。
    try {
        if (random_int(1, 100) === 1) {
            cache_gc();
        }
    } catch (Throwable $e) {
        // 清扫失败绝不能影响写入（random_int 在极老 PHP 上可能抛错）
    }
}

/**
 * 过期缓存清扫（概率触发的惰性 GC）。
 *
 * 为什么必须有它：
 *   cache_get() 只在「再次读到同一个 key 且已过期」时删文件（cache_layer.php:86），
 *   而 search_<md5(关键词)> 这类键被 cache_flush_protected() **永久豁免**、
 *   且爬虫扫描过的关键词不会再被读到 → 那些 search_*.json 永远不会被删除。
 *   攻击者用不同关键词刷 s= 参数即可无界增长目录（磁盘/inode 型 DoS，成本几乎为零）。
 *   实测：报告只提到"glob 变慢"，实际是"文件永不回收"，性质更严重。
 *
 * 策略：删除 mtime 超过 $max_age 的缓存文件。默认 7200s（远大于最长 TTL 600s），
 * 因此不会误删仍可能被 stale 读取的文件；只清"至少两小时没人碰过"的陈旧项。
 *
 * @param int $max_age 秒
 * @return int 删除的文件数
 */
function cache_gc($max_age = 7200) {
    $dir = cache_dir();
    if (!is_dir($dir)) {
        return 0;
    }
    $now = time();
    $removed = 0;
    foreach (glob($dir . '*.json') ?: [] as $f) {
        $mtime = @filemtime($f);
        if ($mtime === false) {
            continue;
        }
        // 跳过仍在写入的临时文件（*.tmp.<pid> 不以 .json 结尾，天然不会命中）
        if (($now - (int)$mtime) > $max_age) {
            if (@unlink($f)) {
                $removed++;
            }
        }
    }
    return $removed;
}

/**
 * 精确删除单个缓存键（写操作后的显式失效入口）。
 * 与 cache_flush 的区别：只删指定键，不扫描目录。
 * @param string $key 与 cache_get/cache_set 相同的键
 */
function cache_delete($key) {
    $file = cache_key_file($key);
    if (is_file($file)) {
        @unlink($file);
    }
}

/**
 * cache_flush 时受保护的前缀清单（这些键有自己的显式失效入口，不随写操作全清）：
 *   - search_ 前缀 / _table_exists 后缀 : 搜索结果 600s TTL 自然过期；表探测与内容写入无关
 *                                        ⚠ 它们不参与 cache_flush，回收完全依赖 cache_gc() 的
 *                                        概率清扫 —— 少了那个清扫，爬虫扫过的不重复关键词
 *                                        会永久堆积（见 cache_gc 注释）。
 *   - options_full                      : 仅 update_option() 显式失效（cache_delete）
 *   - active_plugins                    : 仅 activate/deactivate_plugin() 显式失效
 *   - total_posts_ / sticky_total       : 计数类，60s TTL 自然过期（发帖滞后 ≤60s 可接受）
 * 判定基于文件名中的键标签（'-' 前、'.json' 前的部分），见 cache_key_file()。
 * @param string $base 缓存文件基础名（含 .json）
 * @return bool true=受保护，cache_flush 应跳过
 */
function cache_flush_protected($base) {
    $dot = strrpos($base, '.json');
    $dash = strrpos($base, '-');
    if ($dot === false || $dash === false) {
        return false; // 无标签格式（旧 md5 裸名文件）→ 视为可清除（自动清理遗留）
    }
    $tag = substr($base, 0, $dash);
    if (strpos($tag, 'search_') === 0
        || substr($tag, -14) === '_table_exists'
        || strpos($tag, 'options_full') === 0
        || strpos($tag, 'active_plugins') === 0
        || strpos($tag, 'total_posts_') === 0
        || strpos($tag, 'sticky_total') === 0) {
        return true;
    }
    return false;
}

/**
 * 失效缓存（写操作后调用）
 *
 * 策略：
 *   - 受保护前缀（见 cache_flush_protected）不删除，各自走显式失效或 TTL；
 *   - 其他缓存需要即时失效，删除。
 *
 * 若需要强制全清（如插件启用/停用、数据结构变更），传 $force=true。
 */
function cache_flush($force = false) {
    $dir = cache_dir();
    if (!is_dir($dir)) {
        return;
    }
    foreach (glob($dir . '*.json') ?: [] as $f) {
        $base = basename($f);
        if (!$force && cache_flush_protected($base)) {
            continue; // 受保护键：搜索/探测/options/插件/计数
        }
        @unlink($f);
    }
}

/**
 * 带缓存的聚合查询辅助函数（含进程锁，防止多进程并发重算雪崩）
 * 用法：返回数组给回调缓存；TTL 默认 60s
 *
 * 并发保护：多个 php-cgi 进程同时命中未过期缓存时，
 * 只有一个进程重建（获取 flock），其他进程等待锁释放后读新值；
 * 若锁等待超时（如重建进程卡住），则返回旧值（stale）而不是重复重算。
 */
function cache_remember($key, $ttl, callable $fn) {
    $cached = cache_get($key, $ttl);
    if ($cached !== null) {
        return $cached;
    }

    // 进程锁：防止并发重算（Apache 多进程场景）
    // 关键：拿不到锁时【立即】读 stale 返回，绝不阻塞等锁
    $lock_file = cache_dir() . '.lock_' . md5($key);
    $fp = @fopen($lock_file, 'c');
    if ($fp && flock($fp, LOCK_EX | LOCK_NB)) {
        // 拿到锁：重建缓存（二次检查，避免上锁期间已被其他进程填充）
        $val = cache_get($key, $ttl);
        if ($val === null) {
            $val = $fn();
            if ($val !== null) {
                cache_set($key, $val, $ttl);
            }
        }
        flock($fp, LOCK_UN);
        @fclose($fp);
        return $val;
    }

    // 没拿到锁（另一个进程正在重建）：立即读旧值（stale）返回，不等待
    if ($fp) {
        @fclose($fp);
    }
    $stale = cache_get($key, 0, true);
    if ($stale !== null) {
        return $stale; // stale-if-error：立即返回，绝不阻塞
    }
    // 完全无旧值（首次）：为避免并发同时重算，尝试短暂等待后重试一次
    usleep(200000); // 200ms
    $retry = cache_get($key, $ttl);
    if ($retry !== null) {
        return $retry;
    }
    // 仍无值：兜底直接算（此场景罕见）
    $val = $fn();
    if ($val !== null) {
        cache_set($key, $val, $ttl);
    }
    return $val;
}

/**
 * 2-gram 搜索索引是否可用（search_index 表存在性探测，缓存 60s）
 * @return bool
 */
function search_index_enabled() {
    $exists = cache_remember('search_index_table_exists', 60, function () {
        try {
            $db = get_db();
            $stmt = $db->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name='search_index'");
            return $stmt && $stmt->fetchColumn() ? 1 : 0;
        } catch (Exception $e) {
            return 0;
        }
    });
    return (bool)$exists;
}
