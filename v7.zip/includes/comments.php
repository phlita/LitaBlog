<?php
/**
* Comment handler (Strictly Web & AJAX)
*/

// 禁止 GET 直访：本文件是**评论提交端点**，只接受 POST。
// ⚠️ 修复背景（2026-09-16 实测）：原判定用 `SCRIPT_FILENAME basename === __FILE__` 识别"直访"，
// 但**前台所有主题的评论表单 action 与 JS fetch 的 URL 正是本文件** → 合法提交同样被 403，
// 表现为"前端发布评论失败"。改为按请求方法判定：GET 直访依旧 403（保留反暴露目标），POST 放行
// （POST 路径已有 CSRF 校验：action=add 校验 add_comment 令牌；delete 校验权限+令牌）。
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(403);
    exit('Direct access not allowed.');
}

require_once dirname(__FILE__) . '/load.php';


if (session_status() === PHP_SESSION_NONE) {
session_start();
}

$wants_json = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
// E-7:整页缓存架构下,前台评论区仅登录用户可见;匿名 POST 评论一律拒绝(缓存页无有效 CSRF session)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add' && !is_logged_in()) {
if ($wants_json) {
http_response_code(403);
echo json_encode(['success' => false, 'error' => '请先登录后再评论']); exit;
}
exit('请先登录后再评论');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'add_comment')) {
if ($wants_json) {
http_response_code(403);
echo json_encode(['success' => false, 'error' => '安全验证失败，请刷新页面后重新提交']); exit;
}
exit('CSRF Verification Failed');
}
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
$action = $_POST['action'];

if (get_option('enable_comments', '1') !== '1') {
if ($wants_json) {
http_response_code(403);
echo json_encode(['success' => false, 'error' => '评论功能已关闭']); exit;
}
exit('评论功能已关闭');
}

// L-3 修复：30s 限流对「实际提交者」生效（含登录用户）。
// 说明：E-7(17行)已拒绝一切匿名 POST 评论 → 能走到评论写入的只有登录用户，
//       旧代码 if(!is_logged_in()) 是死代码 → 登录用户可无限刷屏(且直接 approved 过审)。
//       改为：登录用户按 user_id 查最近评论时间限流(跨设备同防)；匿名兜底仍走 session。
$last_comment_time = 0;
if (is_logged_in()) {
    try {
        $db = get_db();
        $last_comment_time = (int)$db->query('SELECT COALESCE(MAX(created),0) FROM comments WHERE user_id = ' . (int)$_SESSION['user_id'])->fetchColumn();
        // created 为 DATETIME 文本(Y-m-d H:i:s)，转时间戳比较
        $last_comment_time = $last_comment_time ? strtotime((string)$last_comment_time) : 0;
    } catch (Exception $e) { $last_comment_time = 0; }
} else {
    $last_comment_time = $_SESSION['last_comment_time'] ?? 0;
}
if (time() - $last_comment_time < 30) { // 限制 30 秒内只能评论一次(所有提交者)
if ($wants_json) {
http_response_code(429);
echo json_encode(['success' => false, 'error' => '您说话太快了，请休息 30 秒后再试']); exit;
}
exit('发言太快');
}
if (is_logged_in()) {
    // 写入一条「限流哨兵」记录：直接记录本次评论时间,无需额外表——由下方 INSERT 承担。
    // 为避免竞态,这里仅当本次请求将成功插入时才有意义;session 值仅作匿名兜底。
    $_SESSION['last_comment_time'] = time();
}

/*
// --- 替换原有的 Session 限制逻辑 ---
if (!is_logged_in()) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $rate_limits = safe_unserialize(get_option('comment_rate_limits', ''));
    if (!is_array($rate_limits)) {
        $rate_limits = [];
    }
    $now = time();
    // 清理 30 秒过期的 IP 记录
    $rate_limits = array_filter($rate_limits, function($timestamp) use ($now) {
        return ($now - $timestamp) < 30;
    });
    if (isset($rate_limits[$ip])) {
        if ($wants_json) {
            http_response_code(429);
            echo json_encode(['success' => false, 'error' => '您说话太快了，请休息 30 秒后再试']); exit;
        }
        exit('发言太快');
    }
    $rate_limits[$ip] = $now;
    update_option('comment_rate_limits', serialize($rate_limits));
}
------
if (!is_logged_in()) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $rate_limits = json_decode(get_option('comment_rate_limits', '{}'), true);
    if (($rate_limits[$ip] ?? 0) > time() - 30) {
        if ($wants_json) { http_response_code(429); echo json_encode(['success' => false, 'error' => '您说话太快了，请休息 30 秒']); exit; }
        exit('发言太快');
    }
    $rate_limits[$ip] = time();
    foreach($rate_limits as $k => $v) { if($v < time() - 60) unset($rate_limits[$k]); }
    update_option('comment_rate_limits', json_encode($rate_limits));
}
*/


switch ($action) {
case 'add':
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
if (!$post_id || !get_post($post_id)) { $error = '文章不存在'; break; }
$content = isset($_POST['content']) ? trim($_POST['content']) : '';
//$content = litablog_purify_html($content);
$content = strip_tags($content); // 评论内容强制去标签
$content = mb_substr($content, 0, 1000, 'UTF-8'); // 限制长度
if (empty($content)) { $error = '评论不能为空'; break; }

$db = get_db();
$user_id = null;
$author = isset($_POST['author']) ? trim($_POST['author']) : 'Anonymous';
$author = strip_tags($author); // 评论者姓名去标签
$author = mb_substr($author, 0, 50, 'UTF-8');
$email = null;
$status = 'pending';

if (is_logged_in()) {
$user_id = $_SESSION['user_id'];
$status = 'approved';
$author = null; // 数据库联表读取真实 username
}

try {
$stmt = $db->prepare('INSERT INTO comments (post_id, user_id, author, email, content, status) VALUES (?, ?, ?, ?, ?, ?)');
if ($stmt->execute([$post_id, $user_id, $author, $email, $content, $status])) {
// E-6 已移除写后全清:整页缓存靠 TTL 惰性过期自愈,避免评论洪峰触发全清惊群。
if ($wants_json) {
http_response_code(201); echo json_encode(['success' => true, 'message' => '评论提交成功']); exit;
}
header('Location: ' . SITE_URL . '/?p=' . $post_id . '#comments'); exit;
} else { $error = '写入失败'; }
} catch (Exception $e) { $error = '数据库异常'; }
break;

case 'delete':
if (!is_logged_in() || !is_admin()) { $error = '权限不足'; break; }
$comment_id = isset($_POST['comment_id']) ? (int)$_POST['comment_id'] : 0;
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'], 'delete_comment_' . $comment_id)) {
        $error = '安全令牌验证失败，请刷新页面重试。';
        break;
    }
if (delete_comment($comment_id)) {
if ($wants_json) { echo json_encode(['success' => true]); exit; }
header('Location: ' . get_safe_redirect_url(SITE_URL)); exit;
} else { $error = '删除失败'; }
break;

}
}

if (isset($error)) {
if ($wants_json) {
http_response_code(400); echo json_encode(['success' => false, 'error' => $error]); exit;
}
//$redirect_url = $_SERVER['HTTP_REFERER'] ?? SITE_URL;
$redirect_url = get_safe_redirect_url(SITE_URL);
$redirect_url .= (strpos($redirect_url, '?') === false ? '?' : '&') . 'error=' . urlencode($error);
header('Location: ' . $redirect_url); exit;
}
header('Location: ' . SITE_URL); exit;