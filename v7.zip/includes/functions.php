<?php
/**
* Core functions
*/
if (!defined('CORE')) {
http_response_code(403);
exit('Direct access not allowed.');
}

// Database connection
function get_db() {
static $db = null;
if ($db === null) {
try {
$config_file = dirname(__FILE__) . '/../config.php';
if (!file_exists($config_file)) {
throw new Exception('Blog is not installed');
}

if (!defined('DB_FILE')) {
require_once $config_file;
}

if (!file_exists(DB_FILE)) {
throw new Exception('Database file not found');
}

$db = new PDO('sqlite:' . DB_FILE);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 性能优化（移植自 v10）：journal_mode=WAL 仅在当前非 WAL 时设置。
// 对已是 WAL 的库重复执行该 PRAGMA 可能触发多余 checkpoint（大库下代价高）。
$jm = $db->query('PRAGMA journal_mode')->fetchColumn();
if ($jm !== 'wal') {
    $db->exec('PRAGMA journal_mode = WAL;');
}
$db->exec('PRAGMA synchronous = NORMAL;');
// D-2 修复：busy_timeout 5000 → 10000ms。
// 原值在写并发洪峰时容易触发 SQLITE_BUSY（database is locked），
// 而全项目 try/catch 会把它静默吞成空数组/失败，导致页面悄悄变空或写入"失败"。
// 加大等待窗口配合 DB 类的重试（见 db_wrapper.php），显著降低锁超时概率。
$db->exec('PRAGMA busy_timeout = 10000;');
$db->exec('PRAGMA cache_size = -16000;');
$db->exec('PRAGMA foreign_keys=ON;');
} catch (PDOException $e) {
die('Database connection failed: Connection refused.');
} catch (Exception $e) {
die('Configuration error: Check config.php permissions.');
}
}
return $db;
}

// Unified Debug System (Mitigates V-19)
function litablog_debug($message) {
if (defined('DEBUG') && DEBUG) {
error_log('[LitaBlog DEBUG] ' . $message);
}
}

// Unified Safe Unserialization (Mitigates V-03)
function safe_unserialize($str) {
if (!is_string($str)) {
return $str;
}
// Prevent PHP Object Injection by ensuring allowed_classes is false
return @unserialize($str, ['allowed_classes' => false]);
}

// Safe wrapper for replacing deprecated FILTER_SANITIZE_STRING (Mitigates V-18)
/*
function sanitize_text_field($str) {
if (is_array($str)) {
return array_map('sanitize_text_field', $str);
}
return htmlspecialchars(trim((string)$str), ENT_QUOTES, 'UTF-8');
}*/

function sanitize_text_field($str) {
    if (is_array($str)) {
        return array_map('sanitize_text_field', $str);
    }
    // 存储时只做清洗，不转实体（输出时再转）
    $str = trim((string)$str);
    $str = strip_tags($str);  // 去除 HTML 标签
    $str = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $str); // 去除控制字符
    return $str;
}


function sanitize_textarea_field($str) {
return sanitize_text_field($str);
}

function sanitize_email_field($email) {
return filter_var(trim((string)$email), FILTER_SANITIZE_EMAIL);
}

function get_option($name, $default = '') {
// D-7 修复：改用全局数组缓存（原为函数内 static 变量）。
// 原因：update_option 无法访问 get_option 的 static 变量，
// 导致同一次请求内「先 update_option 再 get_option」读到旧值（配置漂移），
// 例如后台保存设置后立刻读取仍显示旧配置。
if (!isset($GLOBALS['litablog_option_cache'])) {
$GLOBALS['litablog_option_cache'] = [];
// 统一缓存层(P1-B 迁移):options 全表快照走 cache_layer(键 options_full,60s,
// 原子写+dogpile 防护),由 update_option 显式 cache_delete 失效。
// 文件损坏/缺失静默回落查库。
$cached_options = function_exists('cache_get') ? cache_get('options_full', 60) : null;
if (is_array($cached_options) && !empty($cached_options)) {
$GLOBALS['litablog_option_cache'] = $cached_options;
return isset($GLOBALS['litablog_option_cache'][$name]) ? $GLOBALS['litablog_option_cache'][$name] : $default;
}
try {
$db = get_db();
$stmt = $db->query('SELECT name, value FROM options');
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($results as $row) {
$GLOBALS['litablog_option_cache'][$row['name']] = $row['value'];
}
// 统一缓存层:原子写文件缓存(60s);失败静默下次仍查库
if (function_exists('cache_set') && !empty($GLOBALS['litablog_option_cache'])) {
cache_set('options_full', $GLOBALS['litablog_option_cache'], 60);
}
} catch (PDOException $e) {
$GLOBALS['litablog_option_cache'] = [];
}
}
return isset($GLOBALS['litablog_option_cache'][$name]) ? $GLOBALS['litablog_option_cache'][$name] : $default;
}

/**
 * 失效 options 快照缓存 —— 任何**绕过 update_option()** 直接写 options 表之后的统一收尾。
 *
 * 为什么必须有：get_option() 走 options_full 文件快照（60s TTL）+ 请求内静态数组；
 * 只调 cache_delete 还不够（同请求内静态数组仍是旧值），所以要一并 unset 让它重新装载。
 * 2026-09-16 实测复现的 bug：后台"关闭评论"保存后，前台最长 60s 仍读到 '1' →
 * 访客照样能匿名评论（后台却已显示关闭，因为 admin 视图直查库）。
 */
function litablog_options_cache_invalidate() {
    // 请求内静态缓存：unset（不能置空数组 —— get_option 用 isset 判断是否已装载）
    unset($GLOBALS['litablog_option_cache']);
    // 进程外快照文件
    if (function_exists('cache_delete')) {
        cache_delete('options_full');
    }
}

/**
 * 会影响前台整页输出的选项名单（改动后必须清整页缓存）。2026-09-16 同步 v10。
 */
function litablog_render_affecting_options() {
    return ['enable_comments', 'current_theme', 'posts_per_page', 'site_title',
            'site_description', 'nav_menu', 'permalink_type', 'site_timezone'];
}

/**
 * 清空整页缓存（pc_purge 的容错包装）。2026-09-16 同步 v10。
 * 注意：admin/*.php 上下文里 index.php 没跑过，page_cache.php 可能尚未加载，
 * 因此这里按需 require（该文件独立、无框架依赖，且有直访守卫）。
 */
function litablog_purge_page_cache() {
    if (!function_exists('pc_purge')) {
        $f = dirname(__FILE__) . '/page_cache.php';
        if (is_file($f)) {
            require_once $f;
        }
    }
    if (function_exists('pc_purge')) {
        pc_purge();
    }
}

function update_option($name, $value) {
try {
$db = get_db();
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
$ok = $stmt->execute([$name, $value]);
// D-7 修复：同步刷新请求内缓存，保证 update 后立即可读到新值
if ($ok && isset($GLOBALS['litablog_option_cache']) && is_array($GLOBALS['litablog_option_cache'])) {
$GLOBALS['litablog_option_cache'][$name] = $value;
}
// P1-B:失效 options 快照(统一缓存层 cache_delete),保证后续请求读到新值
if ($ok) {
if (function_exists('cache_delete')) {
cache_delete('options_full');
}
}
// 2026-09-16 同步 v10：**渲染相关**选项变化时清整页缓存。
// 整页缓存是 TTL 自愈模型（写路径本不做失效），但这些选项会整体改变页面输出：
// 关/开评论、换主题、改每页篇数… 不清的话匿名访客最长 TTL（单篇 600s）内仍看到旧页面
//（v10 实测：重新打开评论后，访客仍拿到"没有评论框"的缓存单篇页 ✗）。
if ($ok && function_exists('litablog_render_affecting_options')
&& in_array($name, litablog_render_affecting_options(), true)) {
litablog_purge_page_cache();
}
return $ok;
} catch (PDOException $e) {
return false;
}
}

function get_post_meta($post_id, $meta_key = '', $single = true) {
$db = get_db();
try {
if (empty($meta_key)) {
$stmt = $db->prepare("SELECT meta_key, meta_value FROM postmeta WHERE post_id = :post_id");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$all_meta = array();
foreach ($results as $row) {
$value = safe_unserialize($row['meta_value']);
if ($value === false && $row['meta_value'] !== 'b:0;') {
$value = $row['meta_value'];
}
if (isset($all_meta[$row['meta_key']])) {
if (!is_array($all_meta[$row['meta_key']])) {
$all_meta[$row['meta_key']] = array($all_meta[$row['meta_key']]);
}
$all_meta[$row['meta_key']][] = $value;
} else {
$all_meta[$row['meta_key']] = array($value);
}
}
foreach($all_meta as $key => &$values) {
if(count($values) === 1) {
$values = $values[0];
}
}
return $all_meta;
} else {
$stmt = $db->prepare("SELECT meta_value FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($results)) {
return $single ? '' : array();
}

$values = array();
foreach ($results as $value) {
$unserialized_value = safe_unserialize($value);
if ($unserialized_value === false && $value !== 'b:0;') {
$values[] = $value;
} else {
$values[] = $unserialized_value;
}
}

if ($single) {
return $values[0];
}
return $values;
}
} catch (PDOException $e) {
error_log("Error in get_post_meta: " . $e->getMessage());
return $single ? '' : array();
}
}

function update_post_meta($post_id, $meta_key, $meta_value, $prev_value = '') {
$db = get_db();
try {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;
$current_meta = get_post_meta($post_id, $meta_key, false);

if (empty($current_meta)) {
return add_post_meta($post_id, $meta_key, $meta_value);
} else {
if (!empty($prev_value)) {
$prev_value_serialized = (is_array($prev_value) || is_object($prev_value)) ? serialize($prev_value) : $prev_value;
$stmt = $db->prepare("UPDATE postmeta SET meta_value = :meta_value WHERE post_id = :post_id AND meta_key = :meta_key AND meta_value = :prev_value");
$stmt->bindValue(':prev_value', $prev_value_serialized, PDO::PARAM_STR);
} else {
delete_post_meta($post_id, $meta_key);
return add_post_meta($post_id, $meta_key, $meta_value);
}
}
} catch (PDOException $e) {
error_log("Error in update_post_meta: " . $e->getMessage());
return false;
}
}

function add_post_meta($post_id, $meta_key, $meta_value, $unique = false) {
$db = get_db();
try {
if ($unique) {
$existing = get_post_meta($post_id, $meta_key, true);
if (!empty($existing) || ($existing === '0' && $meta_value !== 0) ) {
return false;
}
}

$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("INSERT INTO postmeta (post_id, meta_key, meta_value) VALUES (:post_id, :meta_key, :meta_value)");
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);

if ($stmt->execute()) {
return $db->lastInsertId();
}
return false;
} catch (PDOException $e) {
error_log("Error in add_post_meta: " . $e->getMessage());
return false;
}
}

function delete_post_meta($post_id, $meta_key, $meta_value = '') {
$db = get_db();
try {
if (!empty($meta_value)) {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("DELETE FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key AND meta_value = :meta_value");
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
} else {
$stmt = $db->prepare("DELETE FROM postmeta WHERE post_id = :post_id AND meta_key = :meta_key");
}
$stmt->bindValue(':post_id', $post_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
} catch (PDOException $e) {
error_log("Error in delete_post_meta: " . $e->getMessage());
return false;
}
}

/**
 * 全站唯一的"用户显示名"取值函数：优先昵称(display_name)，为空则回落账号(username)。
 * 皮肤一律用它渲染用户名（与作者页/列表页的 SQL 口径 COALESCE(NULLIF(display_name,''),username) 一致）。
 * 支持传：用户数组 / 用户对象 / 昵称字符串（第二参数给账号名作回落）。
 */
function user_display_name($user, $fallback_username = '') {
    $dn = '';
    $un = $fallback_username;
    if (is_array($user)) {
        $dn = $user['display_name'] ?? '';
        $un = $user['username'] ?? $un;
    } elseif (is_object($user)) {
        $dn = $user->display_name ?? '';
        $un = $user->username ?? $un;
    } else {
        $dn = (string) $user;
    }
    $dn = is_string($dn) ? trim($dn) : '';
    return $dn !== '' ? $dn : (string) $un;
}

function get_user($user_id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$user_id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return false;
}
}

function get_username($user_id) {
$user = get_user($user_id);
return $user ? $user['username'] : 'Unknown';
}

function get_user_meta($user_id, $meta_key = '', $single = false) {
$db = get_db();
try {
if (empty($meta_key)) {
$stmt = $db->prepare("SELECT meta_key, meta_value FROM usermeta WHERE user_id = :user_id");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$all_meta = array();
foreach ($results as $row) {
$value = safe_unserialize($row['meta_value']);
if ($value === false && $row['meta_value'] !== 'b:0;') {
$value = $row['meta_value'];
}
if (!isset($all_meta[$row['meta_key']])) {
$all_meta[$row['meta_key']] = array();
}
$all_meta[$row['meta_key']][] = $value;
}
return $all_meta;
} else {
$stmt = $db->prepare("SELECT meta_value FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($results)) {
return $single ? '' : array();
}

$values = array();
foreach ($results as $value) {
$unserialized_value = safe_unserialize($value);
if ($unserialized_value === false && $value !== 'b:0;') {
$values[] = $value;
} else {
$values[] = $unserialized_value;
}
}

if ($single) {
return $values[0];
}
return $values;
}
} catch (PDOException $e) {
error_log("Error in get_user_meta: " . $e->getMessage());
return $single ? '' : array();
}
}

function add_user_meta($user_id, $meta_key, $meta_value, $unique = false) {
$db = get_db();
try {
if ($unique) {
$existing = get_user_meta($user_id, $meta_key, true);
if ($existing !== '' && !empty($existing)) {
return false;
}
}

$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("INSERT INTO usermeta (user_id, meta_key, meta_value) VALUES (:user_id, :meta_key, :meta_value)");
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);

if ($stmt->execute()) {
return $db->lastInsertId();
}
return false;
} catch (PDOException $e) {
error_log("Error in add_user_meta: " . $e->getMessage());
return false;
}
}

function update_user_meta($user_id, $meta_key, $meta_value, $prev_value = '') {
$db = get_db();
try {
$current_meta_values = get_user_meta($user_id, $meta_key, false);

if (empty($current_meta_values)) {
return (bool)add_user_meta($user_id, $meta_key, $meta_value);
} else {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;

if (!empty($prev_value)) {
$prev_value_serialized = (is_array($prev_value) || is_object($prev_value) || is_bool($prev_value)) ? serialize($prev_value) : $prev_value;
$stmt = $db->prepare("UPDATE usermeta SET meta_value = :meta_value WHERE user_id = :user_id AND meta_key = :meta_key AND meta_value = :prev_value");
$stmt->bindValue(':prev_value', $prev_value_serialized, PDO::PARAM_STR);
} else {
delete_user_meta($user_id, $meta_key);
return (bool)add_user_meta($user_id, $meta_key, $meta_value);
}
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
}
} catch (PDOException $e) {
error_log("Error in update_user_meta: " . $e->getMessage());
return false;
}
}

function delete_user_meta($user_id, $meta_key, $meta_value = '') {
$db = get_db();
try {
if (!empty($meta_value)) {
$meta_value_serialized = (is_array($meta_value) || is_object($meta_value) || is_bool($meta_value)) ? serialize($meta_value) : $meta_value;
$stmt = $db->prepare("DELETE FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key AND meta_value = :meta_value");
$stmt->bindValue(':meta_value', $meta_value_serialized, PDO::PARAM_STR);
} else {
$stmt = $db->prepare("DELETE FROM usermeta WHERE user_id = :user_id AND meta_key = :meta_key");
}
$stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
$stmt->bindValue(':meta_key', $meta_key, PDO::PARAM_STR);
return $stmt->execute();
} catch (PDOException $e) {
error_log("Error in delete_user_meta: " . $e->getMessage());
return false;
}
}

/**
 * E-1 移植(v10):搜索结果 600s 文件缓存包裹。
 * LIKE 全扫与索引冷路径都受保护;匿名 ?s= 同词不重复全扫(防连接池打满)。
 */
function search_blog_posts(string $query, int $limit = 10, int $offset = 0): array {
$results = ['posts' => [], 'total_posts' => 0];
$query = mb_substr(trim($query), 0, 30, 'UTF-8');
if ($query === '') {
return $results;
}
if (function_exists('cache_get') && function_exists('cache_set')) {
$cache_key = 'search_' . md5($query . '_' . $limit . '_' . $offset);
$cached = cache_get($cache_key, 600);
if ($cached !== null) {
return $cached;
}
$results = do_search_blog_posts($query, $limit, $offset);
if (!empty($results['posts']) || $results['total_posts'] > 0) {
// X-1 扩展点:缓存 TTL 可被插件调整(默认 600)
$ttl = function_exists('apply_filters') ? apply_filters('search_cache_ttl', 600) : 600;
cache_set($cache_key, $results, (int)$ttl);
}
return $results;
}
return do_search_blog_posts($query, $limit, $offset);
}

/**
 * 搜索实际执行(LIKE fallback;2-gram 索引可用且词≥2字时走 do_search_blog_posts_indexed)
 */
function do_search_blog_posts(string $query, int $limit = 10, int $offset = 0): array {
$results = ['posts' => [], 'total_posts' => 0];
$query = mb_substr(trim($query), 0, 30, 'UTF-8');
if (empty($query)) {
return $results;
}

// X-1 扩展点:允许插件接管搜索(如外部分词服务 Xunsearch/Meilisearch/ES)。
// 插件返回非 null 的 ['posts'=>[], 'total_posts'=>N] 即表示接管,核心不再执行内置搜索。
// 无插件注册时 apply_filters 仅一次 isset() 数组查找,零开销。
if (function_exists('apply_filters')) {
$handled = apply_filters('search_handler', null, $query, $limit, $offset);
if (is_array($handled) && isset($handled['posts']) && isset($handled['total_posts'])) {
return $handled;
}
}

// E-1:2-gram 索引可用且词长≥2 → 走索引(毫秒级);否则 LIKE 全扫(单字词/索引缺失时 fallback)
// 2026-09-19 修复（三棵树统一）：2-gram 索引**只索引 title**，原实现命中 0 也直接 return
// ⇒ "只在正文出现的词"永远搜不到（v10 同款缺陷，已在同一轮修掉）。
// 现改为：命中 0 → 继续往下落到 LIKE 兜底（title/content/excerpt 全覆盖，外层有搜索缓存）。
if (function_exists('search_index_enabled') && search_index_enabled()
&& mb_strlen($query, 'UTF-8') >= 2) {
$indexed = do_search_blog_posts_indexed($query, $limit, $offset);
if (!empty($indexed['posts']) || (int)($indexed['total_posts'] ?? 0) > 0) {
return $indexed;
}
}

try {
$db = get_db();
$search_term_like = '%' . $query . '%';

$count_sql = "
SELECT COUNT(DISTINCT p.id)
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post'
AND (
p.title LIKE :search_query_like
OR p.content LIKE :search_query_like
OR p.excerpt LIKE :search_query_like
)";

$stmt_count = $db->prepare($count_sql);
$stmt_count->bindValue(':search_query_like', $search_term_like, PDO::PARAM_STR);
$stmt_count->execute();
$results['total_posts'] = (int) $stmt_count->fetchColumn();

if ($results['total_posts'] > 0) {
$posts_sql = "
SELECT
p.*,
COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username,
GROUP_CONCAT(DISTINCT char(30) || c.id || char(31) || c.name || char(31) || c.slug || char(30)) AS categories_data,
GROUP_CONCAT(DISTINCT char(30) || t.id || char(31) || t.name || char(31) || t.slug || char(30)) AS tags_data,
(CASE WHEN p.title LIKE :search_query_exact_title THEN 100 ELSE 0 END) +
(CASE WHEN p.title LIKE :search_query_like THEN 50 ELSE 0 END) +
(LENGTH(p.content) - LENGTH(REPLACE(LOWER(p.content), LOWER(:search_query_raw), ''))) / LENGTH(:search_query_raw_len) * 10 AS relevance
FROM posts p
LEFT JOIN users u ON p.author = u.id
LEFT JOIN post_categories pc ON p.id = pc.post_id
LEFT JOIN categories c ON pc.category_id = c.id
LEFT JOIN post_tags pt ON p.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE p.status = 'publish' AND p.type = 'post'
AND (
p.title LIKE :search_query_like
OR p.content LIKE :search_query_like
OR p.excerpt LIKE :search_query_like
)
GROUP BY p.id
ORDER BY relevance DESC, p.created DESC
LIMIT :limit OFFSET :offset
";
$stmt_posts = $db->prepare($posts_sql);
$stmt_posts->bindValue(':search_query_like', $search_term_like, PDO::PARAM_STR);
$stmt_posts->bindValue(':search_query_exact_title', $query, PDO::PARAM_STR);
$stmt_posts->bindValue(':search_query_raw', $query, PDO::PARAM_STR);
$stmt_posts->bindValue(':search_query_raw_len', mb_strlen($query, 'UTF-8'), PDO::PARAM_INT);
$stmt_posts->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt_posts->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt_posts->execute();
$posts_raw = $stmt_posts->fetchAll(PDO::FETCH_ASSOC);

$posts_processed = hydrate_terms($posts_raw);
$results['posts'] = $posts_processed;
}
} catch (PDOException $e) {
error_log("Search blog posts error for query '{$query}': " . $e->getMessage());
}
return $results;
}

/**
 * E-1 移植(v10):2-gram 索引搜索实现(中文 bigram 精确命中 search_index,走 PRIMARY KEY 毫秒级)。
 * 策略:严格交集(全部 gram 命中,相关性最高);为空时宽松(≥1 gram 按权重/命中数降序)。
 */
function do_search_blog_posts_indexed(string $query, int $limit = 10, int $offset = 0): array {
$results = ['posts' => [], 'total_posts' => 0];
$query = mb_substr(trim($query), 0, 30, 'UTF-8');
$qlen = mb_strlen($query, 'UTF-8');
if ($qlen < 2) {
return $results;
}

// 切 2-gram(去重)
$grams = [];
for ($i = 0; $i < $qlen - 1; $i++) {
$g = mb_substr($query, $i, 2, 'UTF-8');
if ($g !== '') {
$grams[$g] = 1;
}
}
$grams = array_keys($grams);
$n = count($grams);

try {
$db = get_db();

// 字典编码:grams 文本 → term_ids(压缩索引的核心映射)
$ph = implode(',', array_fill(0, $n, '?'));
$stmt_td = $db->prepare("SELECT id, term FROM term_dict WHERE term IN ($ph)");
foreach ($grams as $i => $g) {
$stmt_td->bindValue($i + 1, $g, PDO::PARAM_STR);
}
$stmt_td->execute();
$term_ids = [];
foreach ($stmt_td->fetchAll(PDO::FETCH_ASSOC) as $r) {
$term_ids[$r['id']] = $r['term'];
}
// 保留输入顺序的 gram 对应 term_id(无词典词的 gram 跳过)
$matched_ids = [];
foreach ($grams as $g) {
$found = array_search($g, $term_ids, true);
if ($found !== false) {
$matched_ids[] = (int)$found;
}
}
if (empty($matched_ids)) {
return $results; // 词全不在词典,无结果
}
$ids = array_values(array_unique($matched_ids));
$n = count($ids);
$ph = implode(',', array_fill(0, $n, '?'));

// ① 计数:单 gram 走触发器 O(1) 计数;多 gram 交集精确 COUNT
if ($n === 1) {
$count_sql = "SELECT cnt FROM search_term_counts WHERE term_id = ?";
} else {
$count_sql = "SELECT COUNT(*) FROM (
SELECT post_id FROM search_index
WHERE term_id IN ($ph) GROUP BY post_id HAVING COUNT(DISTINCT term_id) >= ?
)";
}
$stmt_count = $db->prepare($count_sql);
foreach ($ids as $i => $id) {
$stmt_count->bindValue($i + 1, $id, PDO::PARAM_INT);
}
if ($n > 1) {
$stmt_count->bindValue($n + 1, $n, PDO::PARAM_INT);
}
$stmt_count->execute();
$results['total_posts'] = (int)$stmt_count->fetchColumn();
if ($n === 1 && $results['total_posts'] === 0) {
// term_counts 无记录(如旧库未回填):回退索引 COUNT
$stmt_fb = $db->prepare("SELECT COUNT(DISTINCT post_id) FROM search_index WHERE term_id = ?");
$stmt_fb->execute([$ids[0]]);
$results['total_posts'] = (int)$stmt_fb->fetchColumn();
}

if ($results['total_posts'] === 0) {
return $results;
}

// ② 列表:主 term 走索引反序(最新在前)+ EXISTS 校验其余 gram,LIMIT 提前终止 → 毫秒级
$list_sql = "SELECT si.post_id, si.weight AS relevance FROM search_index si
WHERE si.term_id = ?";
for ($i = 1; $i < $n; $i++) {
$list_sql .= " AND EXISTS (SELECT 1 FROM search_index s{$i} WHERE s{$i}.term_id = ? AND s{$i}.post_id = si.post_id)";
}
$list_sql .= " ORDER BY si.post_id DESC LIMIT ? OFFSET ?";
$stmt_posts = $db->prepare($list_sql);
$pi = 1;
$stmt_posts->bindValue($pi++, $ids[0], PDO::PARAM_INT);
for ($i = 1; $i < $n; $i++) {
$stmt_posts->bindValue($pi++, $ids[$i], PDO::PARAM_INT);
}
$stmt_posts->bindValue($pi++, $limit, PDO::PARAM_INT);
$stmt_posts->bindValue($pi++, $offset, PDO::PARAM_INT);
$stmt_posts->execute();
$hits = $stmt_posts->fetchAll(PDO::FETCH_ASSOC);

if (empty($hits)) {
return $results;
}
$hit_ids = array_column($hits, 'post_id');
$in_place = implode(',', array_fill(0, count($hit_ids), '?'));

// ③ 取帖子详情(仅本页结果,主键批量 IN)
$posts_sql = "SELECT p.*, COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username
FROM posts p
LEFT JOIN users u ON p.author = u.id
WHERE p.id IN ($in_place)";
$stmt_p = $db->prepare($posts_sql);
$stmt_p->execute($hit_ids);
$by_id = [];
foreach ($stmt_p->fetchAll(PDO::FETCH_ASSOC) as $pr) {
$by_id[$pr['id']] = $pr;
}
// 保持 hits 顺序
$posts_raw = [];
foreach ($hits as $h) {
if (isset($by_id[$h['post_id']])) {
$posts_raw[] = $by_id[$h['post_id']];
}
}

if (empty($posts_raw)) {
return $results;
}

// ③ 分类/标签聚合(仅本页结果,与 LIKE 路径一致)
$ids2 = array_column($posts_raw, 'id');
$in2 = implode(',', array_fill(0, count($ids2), '?'));
$cat_sql = "SELECT pc.post_id, GROUP_CONCAT(c.id || char(31) || c.name || char(31) || c.slug, char(30)) AS categories_data
FROM post_categories pc JOIN categories c ON c.id = pc.category_id
WHERE pc.post_id IN ($in2) GROUP BY pc.post_id";
$stmt2 = $db->prepare($cat_sql);
$stmt2->execute($ids2);
$cat_map = [];
foreach ($stmt2->fetchAll(PDO::FETCH_ASSOC) as $r) {
$cat_map[$r['post_id']] = $r['categories_data'];
}
$tag_sql = "SELECT pt.post_id, GROUP_CONCAT(t.id || char(31) || t.name || char(31) || t.slug, char(30)) AS tags_data
FROM post_tags pt JOIN tags t ON t.id = pt.tag_id
WHERE pt.post_id IN ($in2) GROUP BY pt.post_id";
$stmt3 = $db->prepare($tag_sql);
$stmt3->execute($ids2);
$tag_map = [];
foreach ($stmt3->fetchAll(PDO::FETCH_ASSOC) as $r) {
$tag_map[$r['post_id']] = $r['tags_data'];
}
foreach ($posts_raw as &$pr) {
$pr['categories_data'] = $cat_map[$pr['id']] ?? '';
$pr['tags_data'] = $tag_map[$pr['id']] ?? '';
}
unset($pr);

// ④ 组装(与 LIKE 路径一致的输出结构)
$posts_processed = hydrate_terms($posts_raw);
$results['posts'] = $posts_processed;
} catch (PDOException $e) {
error_log("Search index error for query '{$query}': " . $e->getMessage());
}
return $results;
}

/**
 * E-3 修复：remember_tokens 表结构的**唯一入口**（守卫式，一次性）。
 *
 * 原状况（报告 E-3）：同一件事有三种处理方式 ——
 *   - load.php:169  用 `get_option('remember_tokens_schema_ready')` 守卫 ✓
 *   - admin/login.php:106 / :232 在登录成功路径**裸跑** CREATE TABLE IF NOT EXISTS：
 *     读路径混入写，SQLite 单写者模型下并发登录会与真正的写操作抢锁。
 * 现统一到本函数：只有首次（或库被重建后标志还在但表没了之外的正常情况）才执行 DDL 并落标志。
 * 失败静默：schema 自愈不能阻断登录流程（真建不了表，后续查询会自然报错）。
 */
function litablog_ensure_remember_tokens_schema() {
    if (get_option('remember_tokens_schema_ready')) {
        return;
    }
    try {
        $db = get_db();
        $db->exec("CREATE TABLE IF NOT EXISTS remember_tokens (
            selector TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            hashed_validator TEXT NOT NULL,
            expires INTEGER NOT NULL
        )");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_remember_tokens_user ON remember_tokens (user_id)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_remember_tokens_expires ON remember_tokens (expires)");
        update_option('remember_tokens_schema_ready', '1');
    } catch (Throwable $e) {
        error_log('ensure remember_tokens schema failed: ' . $e->getMessage());
    }
}

// ============================================================
// A-1 修复：分类/标签聚合结果 → 数组的**唯一实现**
// ------------------------------------------------------------
// 背景：home / category / tag / 两条搜索路径原先各自逐字复制一遍解析逻辑（共 4 处），
// 且用 ':' 与 ',' 当分隔符 —— 分类名或标签名里含这两个字符就会错位/串段
// （外层 explode(',') 最脆：名字含逗号直接拆错段）。
// 现在：SQL 端改用控制字符分隔（记录 char(30)、字段 char(31)），解析只在本文件里做一次。
// 兼容三种串：
//   ① 新格式：\x1f 字段分隔 + \x1e 记录分隔（多数路径）
//   ② 哨兵格式：\x1e记录\x1e,\x1e记录\x1e（搜索 LIKE 路径必须用单参数 DISTINCT，
//      而 SQLite 的 group_concat(DISTINCT x, y) 会报 "DISTINCT aggregates must have
//      exactly one argument"，所以把记录用 \x1e 包起来、让默认的 ',' 分隔符变成无关紧要）
//   ③ 旧格式：':' 字段 + ',' 记录（仅用于兼容历史输出）
// ============================================================
define('TERM_SEP_ITEM', "\x1e");   // 记录之间
define('TERM_SEP_FIELD', "\x1f");  // 字段之间

/** 解析单条聚合串 → [['id'=>int,'name'=>string,'slug'=>string], ...] */
function parse_terms_data($raw) {
    $out = [];
    if (!is_string($raw) || $raw === '') {
        return $out;
    }
    $field_sep = (strpos($raw, TERM_SEP_FIELD) !== false) ? TERM_SEP_FIELD : ':';
    if (strpos($raw, TERM_SEP_ITEM) !== false) {
        $chunks = explode(TERM_SEP_ITEM, $raw);
    } elseif ($field_sep === TERM_SEP_FIELD) {
        $chunks = [$raw];                      // 新格式但只有一条记录
    } else {
        $chunks = explode(',', $raw);          // 旧格式
    }
    foreach ($chunks as $chunk) {
        $chunk = trim($chunk, ",\x1e\x1f");    // 去哨兵/分隔符残留
        if ($chunk === '') {
            continue;
        }
        $parts = explode($field_sep, $chunk, 3);
        if (count($parts) === 3) {
            $out[] = ['id' => (int)$parts[0], 'name' => $parts[1], 'slug' => $parts[2]];
        }
    }
    return $out;
}

/** 批量：把 posts 里的 categories_data / tags_data 解析为 categories / tags 并移除聚合键 */
function hydrate_terms(array $posts) {
    $out = [];
    foreach ($posts as $p) {
        $p['categories'] = parse_terms_data($p['categories_data'] ?? '');
        $p['tags']       = parse_terms_data($p['tags_data'] ?? '');
        unset($p['categories_data'], $p['tags_data']);
        $out[] = $p;
    }
    return $out;
}

// ============================================================
// Remember-Me 时长统一配置（登录下拉框 + 服务端白名单的唯一来源）
// 键 = 天数（-1 = 永久），值 = 前端统一显示文案。
// 新增/调整时长只需改这里：两处登录分支与登录视图自动同步。
// ============================================================
function litablog_remember_options() {
    return [
        1   => '1 天',
        7   => '1 周',
        30  => '1 月',
        90  => '1 季',
        180 => '半年',
        366 => '1 年',
        -1  => '永久',
    ];
}

// 天数 → 实际秒数。"永久"落地为 20 年远期有限值（cookie 与 DB expires 均不接受
// 无限值；安全性由 load.php 每次自动登录的 validator 轮换 + 每用户保留最近
// 5 个 token 的既有机制保证）。
function litablog_remember_seconds($days) {
    $days = (int)$days;
    if ($days === -1) {
        return 20 * 366 * 86400;
    }
    return $days * 86400;
}

function get_post($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM posts WHERE id = ?');
$stmt->execute([$post_id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return false;
}
}

function create_post($title, $content, $author_id, $status = 'draft') {
try {
$db = get_db();
$stmt = $db->prepare('
INSERT INTO posts (title, content, author, status, slug)
VALUES (?, ?, ?, ?, ?)
');
$slug = create_slug($title);
$ok = $stmt->execute([$title, $content, $author_id, $status, $slug]);
// E-6 已移除写后全清:整页缓存靠 TTL 惰性过期自愈(匿名访客最多滞后 60-600s,
// 作者带 Cookie 永远实时);消除写路径的递归删除开销与并发重建惊群。
return $ok;
} catch (PDOException $e) {
return false;
}
}

function update_post($post_id, $data) {
try {
$db = get_db();
$allowed_fields = [
'title', 'content', 'excerpt', 'status', 'slug', 
'type', 'author', 'modified', 'sticky_order'
];

$fields = [];
$values = [];
foreach ($data as $key => $value) {
//if (in_array($key, $allowed_fields, true)) {
if (in_array($key, $allowed_fields, true) && preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $key)) {
$fields[] = "`$key` = ?";
$values[] = $value;
}
}
if (empty($fields)) {
return false;
}
$values[] = $post_id;

$sql = 'UPDATE posts SET ' . implode(', ', $fields) . ' WHERE id = ?';
$stmt = $db->prepare($sql);
$ok = $stmt->execute($values);
// E-6 已移除写后全清:整页缓存靠 TTL 惰性过期自愈(见 create_post 处注)。
return $ok;
} catch (PDOException $e) {
error_log("SQL Error in update_post: " . $e->getMessage());
return false;
}
}

function create_slug($text) {
$text = preg_replace('~[^\pL\d]+~u', '-', $text);
if (function_exists('transliterator_transliterate')) {
$text = transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
} else {
$text = str_replace(
array('á','à','ã','â','ª','ä','é','è','ê','ë','í','ì','î','ï','ó','ò','õ','ô','º','ö','ú','ù','û','ü','ý','ÿ','ñ','ç','Á','À','Ã','Â','É','È','Ê','Ë','Í','Ì','Î','Ï','Ó','Ò','Õ','Ô','Ö','Ú','Ù','Û','Ü','Ý','Ñ','Ç'),
array('a','a','a','a','a','a','e','e','e','e','i','i','i','i','o','o','o','o','o','o','u','u','u','u','y','y','n','c','A','A','A','A','E','E','E','E','I','I','I','I','O','O','O','O','O','U','U','U','U','Y','N','C'),
$text
);
}

$text = preg_replace('~[^-\w]+~', '', $text);
$text = trim($text, '-');
$text = preg_replace('~-+~', '-', $text);
$text = strtolower($text);
return $text ?: 'n-a';
}

function get_posts($args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'type' => 'post',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

try {
$db = get_db();
if (!$db) {
return [];
}

$where = [];
$values = [];

if (!empty($args['status'])) {
$where[] = 'status = ?';
$values[] = $args['status'];
}

if (!empty($args['type'])) {
$where[] = 'type = ?';
$values[] = $args['type'];
}

$sql = 'SELECT * FROM posts';
if ($where) {
$sql .= ' WHERE ' . implode(' AND ', $where);
}

$allowed_orderby = ['created', 'modified', 'title', 'id'];
if (!in_array($args['orderby'], $allowed_orderby, true)) {
$args['orderby'] = 'created';
}

$args['order'] = strtoupper($args['order']);
if (!in_array($args['order'], ['ASC', 'DESC'], true)) {
$args['order'] = 'DESC';
}

$sql .= " ORDER BY {$args['orderby']} {$args['order']}";

if (isset($args['limit']) && (int)$args['limit'] !== -1) {
$args['limit'] = max(1, (int)$args['limit']);
$args['offset'] = max(0, (int)$args['offset']);

$sql .= ' LIMIT ? OFFSET ?';
$values[] = $args['limit'];
$values[] = $args['offset'];
}
$stmt = $db->prepare($sql);
$stmt->execute($values);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function is_logged_in() {
    if (!isset($_SESSION['user_id'])) return false;
    // 实时校验DB，防止被封禁或降级的用户利用旧 Session 继续操作
    $user = get_user($_SESSION['user_id']);
    if (!$user || $user['status'] !== 'active') {
        unset($_SESSION['user_id'], $_SESSION['role']);
        return false;
    }
    $_SESSION['role'] = $user['role']; 
    return true;
}

function is_admin() {
return current_user_can('manage_options');
}

function redirect($url) {
header("Location: $url");
exit;
}

function e($text) {
return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

function get_post_comments($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT c.*, 
COALESCE(NULLIF(u.display_name, \'\'), u.username, c.author) as author_name,
c.user_id
FROM comments c
LEFT JOIN users u ON c.user_id = u.id
WHERE c.post_id = ? AND c.status = "approved"
ORDER BY c.created DESC
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function add_comment($post_id, $content, $author = null, $email = null) {
if (get_option('enable_comments', '1') !== '1') {
return false;
}

try {
$db = get_db();
$user_id = null;

if (is_logged_in()) {
$user_id = $_SESSION['user_id'];
$author = null;
$email = null;
$status = 'approved';
} else {
$status = 'pending';
}

$stmt = $db->prepare('
INSERT INTO comments (post_id, user_id, author, email, content, status) 
VALUES (?, ?, ?, ?, ?, ?)
');

$ok = $stmt->execute([$post_id, $user_id, $author, $email, $content, $status]);
// E-6 已移除写后全清:评论对匿名访客最多滞后 TTL(≤600s),登录用户实时可见。
return $ok;
} catch (PDOException $e) {
return false;
}
}

function delete_comment($comment_id, $user_id = null) {
try {
$db = get_db();
if (!is_admin() && $user_id) {
$stmt = $db->prepare('DELETE FROM comments WHERE id = ? AND user_id = ?');
$ok = $stmt->execute([$comment_id, $user_id]);
} else if (is_admin()) {
$stmt = $db->prepare('DELETE FROM comments WHERE id = ?');
$ok = $stmt->execute([$comment_id]);
} else {
$ok = false;
}
// E-6 已移除写后全清:同上,TTL 惰性过期自愈。
return $ok;
} catch (PDOException $e) {
return false;
}
}

function get_post_categories($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT c.* 
FROM categories c
JOIN post_categories pc ON c.id = pc.category_id
WHERE pc.post_id = ?
ORDER BY c.name
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (PDOException $e) {
return [];
}
}

function get_post_tags($post_id) {
try {
$db = get_db();
$stmt = $db->prepare('
SELECT t.* 
FROM tags t
JOIN post_tags pt ON t.id = pt.tag_id
WHERE pt.post_id = ?
ORDER BY t.name
');
$stmt->execute([$post_id]);
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function get_total_posts($args = []) {
$defaults = [
'status' => 'publish',
'type' => 'post'
];
$args = array_merge($defaults, $args);

// D-4 修复 + 统一缓存层迁移：COUNT(*) 结果加 60s 缓存(键 total_posts_*)。
// 首页/列表每页渲染都会实时 COUNT 全表（50 万行时每次几十 ms 级全扫），
// 而帖子数量短时间不会变化 —— 60s 缓存即可消除绝大部分重复全扫。
// 发帖/删帖后无需主动失效（最多滞后 60s，可接受）；cache_flush 保护该前缀。
$cache_key = 'total_posts_' . md5(($args['status'] ?? '') . '_' . ($args['type'] ?? ''));
$cached_count = function_exists('cache_get') ? cache_get($cache_key, 60) : null;
if ($cached_count !== null && is_numeric($cached_count)) {
return (int)$cached_count;
}

try {
$db = get_db();
$where = [];
$values = [];

if ($args['status']) {
$where[] = 'status = ?';
$values[] = $args['status'];
}

if ($args['type']) {
$where[] = 'type = ?';
$values[] = $args['type'];
}

$sql = 'SELECT COUNT(*) as count FROM posts';
if ($where) {
$sql .= ' WHERE ' . implode(' AND ', $where);
}

$stmt = $db->prepare($sql);
$stmt->execute($values);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
$count = (int)$result['count'];

// 写入缓存（统一缓存层原子写，静默失败不影响主流程）
if (function_exists('cache_set')) {
cache_set($cache_key, $count, 60);
}
return $count;
} catch (PDOException $e) {
return 0;
}
}

function get_pagination($current_page, $total_items, $per_page = 10, $params = []) {
if ($total_items <= 0) return '';

$total_pages = ceil($total_items / $per_page);
if ($total_pages <= 1) return '';

$current_params = $_GET;
$params = array_merge($current_params, $params);

$html = '<div class="pagination">';

if ($current_page > 1) {
$prev_params = array_merge($params, ['page' => $current_page - 1]);
$html .= sprintf(
'<a href="?%s" class="prev-page">上一页</a>',
http_build_query($prev_params)
);
}

// 页码窗口：当前页前后各 2 页 + 首尾 + 省略号（避免大数量级页面输出全部页码）
// 对齐 v10（v10/includes/functions.php:1193-1217）；原 v7 暴力 for 循环会把全部页码一次性输出。
$window = 2;
$range = [];
for ($i = 1; $i <= $total_pages; $i++) {
if ($i == 1 || $i == $total_pages || abs($i - $current_page) <= $window) {
$range[] = $i;
}
}
$prev_num = 0;
foreach ($range as $i) {
if ($prev_num && $i - $prev_num > 1) {
$html .= '<span class="page-ellipsis">&hellip;</span>';
}
if ($i == $current_page) {
$html .= sprintf('<span class="current-page">%d</span>', $i);
} else {
$page_params = array_merge($params, ['page' => $i]);
$html .= sprintf(
'<a href="?%s" class="page-numbers">%d</a>',
http_build_query($page_params),
$i
);
}
$prev_num = $i;
}

if ($current_page < $total_pages) {
$next_params = array_merge($params, ['page' => $current_page + 1]);
$html .= sprintf(
'<a href="?%s" class="next-page">下一页</a>',
http_build_query($next_params)
);
}

$html .= '</div>';
return $html;
}

function is_single() {
global $current_post;
return isset($current_post) && !empty($current_post);
}

function get_post_title() {
global $current_post;
return is_single() ? $current_post['title'] : '';
}

function is_category() {
global $current_category;
return isset($current_category) && !empty($current_category);
}

function get_category_name() {
global $current_category;
return is_category() ? $current_category['name'] : '';
}

function get_category_by_slug($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM categories WHERE slug = ?');
$stmt->execute([$slug]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

/**
 * 按 **id** 取分类（★2026-09-17 与 v10 同步 ✓）—— URL 改用 id 后的**主路径** ✓。
 *
 * 为什么：`name`/`slug` 是给人看的纯文本（多语言原文原样存 ✓），URL/查询是给机器用的 ✓；
 * 机器用**唯一数值 id** 最简单 ✓ —— 没有编码、重名、Unicode 归一化、缓存白名单这些连带问题 ✓。
 * ⚠️ 保留 `get_category_by_slug()` ✓ —— 旧链接（`?category=<旧 slug>`）要继续能打开 ✓。
 */
function get_category_by_id($id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM categories WHERE id = ?');
$stmt->execute([(int)$id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

// Fixed PHP 8 empty-args array-key check warning
function get_posts_by_category($category_slug, $args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

$allowed_orderby = ['created', 'modified', 'title', 'id'];
if (!in_array($args['orderby'], $allowed_orderby, true)) {
$args['orderby'] = 'created';
}
$args['order'] = strtoupper($args['order']);
if (!in_array($args['order'], ['ASC', 'DESC'], true)) {
$args['order'] = 'DESC';
}

try {
$db = get_db();
$sql = '
SELECT DISTINCT p.*
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = ? AND p.status = ?
ORDER BY p.' . $args['orderby'] . ' ' . $args['order'] . '
LIMIT ? OFFSET ?
';

$stmt = $db->prepare($sql);
$stmt->execute([
$category_slug,
$args['status'],
$args['limit'],
$args['offset']
]);

return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

// Fixed PHP 8 empty-args array-key check warning
function get_posts_by_tag($tag_slug, $args = []) {
$defaults = [
'limit' => 10,
'offset' => 0,
'status' => 'publish',
'orderby' => 'created',
'order' => 'DESC'
];
$args = array_merge($defaults, $args);

$allowed_orderby = ['created', 'modified', 'title', 'id'];
if (!in_array($args['orderby'], $allowed_orderby, true)) {
$args['orderby'] = 'created';
}
$args['order'] = strtoupper($args['order']);
if (!in_array($args['order'], ['ASC', 'DESC'], true)) {
$args['order'] = 'DESC';
}

try {
$db = get_db();
$sql = '
SELECT DISTINCT p.*
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = ? AND p.status = ?
ORDER BY p.' . $args['orderby'] . ' ' . $args['order'] . '
LIMIT ? OFFSET ?
';

$stmt = $db->prepare($sql);
$stmt->execute([
$tag_slug,
$args['status'],
$args['limit'],
$args['offset']
]);

return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function get_tag_by_slug($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM tags WHERE slug = ?');
$stmt->execute([$slug]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

/**
 * 按 **id** 取标签（★2026-09-17 与 v10 同步 ✓）—— URL 改用 id 后的**主路径** ✓（与 get_category_by_id 对称 ✓）。
 * ⚠️ 保留 `get_tag_by_slug()` ✓ —— 旧链接（`?tag=<旧 slug>`）要继续能打开 ✓。
 */
function get_tag_by_id($id) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM tags WHERE id = ?');
$stmt->execute([(int)$id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return null;
}
}

function get_category_posts_count($category_slug) {
try {
$db = get_db();
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = ? AND p.status = "publish"
';
$stmt = $db->prepare($sql);
$stmt->execute([$category_slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int)$result['count'];
} catch (PDOException $e) {
return 0;
}
}

function get_tag_posts_count($tag_slug) {
try {
$db = get_db();
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = ? AND p.status = "publish"
';
$stmt = $db->prepare($sql);
$stmt->execute([$tag_slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int)$result['count'];
} catch (PDOException $e) {
return 0;
}
}

function get_plugins() {
try {
$db = get_db();
$stmt = $db->query('SELECT * FROM plugins ORDER BY name');
return $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
return [];
}
}

function get_active_plugins() {
// E-5 + 统一缓存层迁移:插件清单缓存 300s(键 active_plugins,原子写+dogpile 防护),
// activate/deactivate 时显式 cache_delete 失效;cache_flush 保护该键。
static $cached = null;
if ($cached !== null) {
return $cached;
}
$arr = function_exists('cache_get') ? cache_get('active_plugins', 300) : null;
if (is_array($arr)) {
$cached = $arr;
return $arr;
}
try {
$db = get_db();
$stmt = $db->prepare('SELECT * FROM plugins WHERE status = ? ORDER BY name');
$stmt->execute(['active']);
$plugins = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
$cached = [];
return [];
}
// 写缓存(统一缓存层原子写,失败静默,下次仍查库)
if (function_exists('cache_set')) {
cache_set('active_plugins', $plugins, 300);
}
$cached = $plugins;
return $plugins;
}

function activate_plugin($slug) {
litablog_debug('activate_plugin called for: ' . $slug);
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['active', $slug]);

if ($result) {
if ($result && function_exists('cache_delete')) {
cache_delete('active_plugins'); // E-5:插件状态变更 → 统一缓存层显式失效
}
$plugin_file_path_for_hook = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
if (file_exists($plugin_file_path_for_hook)) {
require_once $plugin_file_path_for_hook;
}
do_activation_hook($plugin_file_path_for_hook);
return true;
}
return false;
} catch (PDOException $e) {
error_log('activate_plugin PDOException: ' . $e->getMessage());
return false;
}
}

function deactivate_plugin($slug) {
try {
$db = get_db();
$stmt = $db->prepare('UPDATE plugins SET status = ?, modified = CURRENT_TIMESTAMP WHERE slug = ?');
$result = $stmt->execute(['inactive', $slug]);

if ($result) {
if ($result && function_exists('cache_delete')) {
cache_delete('active_plugins'); // E-5:插件状态变更 → 统一缓存层显式失效
}
$plugin_file_path_for_hook = ABSPATH . 'content/plugins/' . $slug . '/' . $slug . '.php';
if (file_exists($plugin_file_path_for_hook)) {
include_once $plugin_file_path_for_hook;
}
do_deactivation_hook($plugin_file_path_for_hook);
return true;
}
return false;
} catch (PDOException $e) {
return false;
}
}

function is_plugin_active($slug) {
try {
$db = get_db();
$stmt = $db->prepare('SELECT status FROM plugins WHERE slug = ?');
$stmt->execute([$slug]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result && $result['status'] === 'active';
} catch (PDOException $e) {
return false;
}
}

global $wp_actions, $wp_filters, $wp_current_filter;
$wp_actions = array();
$wp_filters = array();
$wp_current_filter = array();

function add_action($hook_name, $callback, $priority = 10, $accepted_args = 1) {
global $wp_actions;
if (!isset($wp_actions[$hook_name])) {
$wp_actions[$hook_name] = array();
}
if (!isset($wp_actions[$hook_name][$priority])) {
$wp_actions[$hook_name][$priority] = array();
}
$wp_actions[$hook_name][$priority][] = array(
'function' => $callback,
'accepted_args' => $accepted_args
);
ksort($wp_actions[$hook_name]);
return true;
}

function do_action($hook_name, ...$args) {
global $wp_actions, $wp_current_filter;
$wp_current_filter[] = $hook_name;

if (isset($wp_actions[$hook_name])) {
foreach ($wp_actions[$hook_name] as $priority_level) {
foreach ($priority_level as $hook) {
if (is_callable($hook['function'])) {
$num_args = $hook['accepted_args'];
$call_args = array_slice($args, 0, $num_args);
call_user_func_array($hook['function'], $call_args);
}
}
}
}
array_pop($wp_current_filter);
}

function add_filter($hook_name, $callback, $priority = 10, $accepted_args = 1) {
global $wp_filters;
if (!isset($wp_filters[$hook_name])) {
$wp_filters[$hook_name] = array();
}
if (!isset($wp_filters[$hook_name][$priority])) {
$wp_filters[$hook_name][$priority] = array();
}
$wp_filters[$hook_name][$priority][] = array(
'function' => $callback,
'accepted_args' => $accepted_args
);
ksort($wp_filters[$hook_name]);
return true;
}

function apply_filters($hook_name, $value, ...$args) {
global $wp_filters, $wp_current_filter;
$wp_current_filter[] = $hook_name;

if (isset($wp_filters[$hook_name])) {
foreach ($wp_filters[$hook_name] as $priority_level) {
foreach ($priority_level as $hook) {
if (is_callable($hook['function'])) {
$num_args = $hook['accepted_args'];
$call_args = array_merge(array($value), array_slice($args, 0, $num_args - 1));
$value = call_user_func_array($hook['function'], $call_args);
}
}
}
}
array_pop($wp_current_filter);
return $value;
}

function normalize_plugin_path_for_key($plugin_file_path) {
$path = str_replace('\\', '/', $plugin_file_path);
$abs_path_normalized = rtrim(str_replace('\\', '/', ABSPATH), '/') . '/';
$base_to_remove = $abs_path_normalized . 'content/plugins/';

if (strpos($path, $base_to_remove) === 0) {
return substr($path, strlen($base_to_remove));
}
return $plugin_file_path;
}

global $wp_activation_hooks, $wp_deactivation_hooks;
$wp_activation_hooks = array();
$wp_deactivation_hooks = array();

function register_activation_hook($plugin_file, $callback) {
global $wp_activation_hooks;
if (!is_array($wp_activation_hooks)) $wp_activation_hooks = array();
$plugin_file_key = normalize_plugin_path_for_key($plugin_file);
$wp_activation_hooks[$plugin_file_key] = $callback;
}

function register_deactivation_hook($plugin_file, $callback) {
global $wp_deactivation_hooks;
if (!is_array($wp_deactivation_hooks)) $wp_deactivation_hooks = array();
$plugin_file_key = normalize_plugin_path_for_key($plugin_file);
$wp_deactivation_hooks[$plugin_file_key] = $callback;
}

function do_activation_hook($plugin_file) {
global $wp_activation_hooks;
if (!is_array($wp_activation_hooks)) return;

$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
$plugin_file_key = str_replace('\\', '/', $plugin_file_key);

if (isset($wp_activation_hooks[$plugin_file_key])) {
$callback_to_check = $wp_activation_hooks[$plugin_file_key];
if (is_callable($callback_to_check)) {
call_user_func($callback_to_check);
}
}
}

function do_deactivation_hook($plugin_file) {
global $wp_deactivation_hooks;
$plugin_file_key = str_replace(ABSPATH . 'content/plugins/', '', $plugin_file);
$plugin_file_key = str_replace('\\', '/', $plugin_file_key);
if (isset($wp_deactivation_hooks[$plugin_file_key]) && is_callable($wp_deactivation_hooks[$plugin_file_key])) {
call_user_func($wp_deactivation_hooks[$plugin_file_key]);
}
}

global $wp_uninstall_hooks;
$wp_uninstall_hooks = array();

function register_uninstall_hook($plugin_file, $callback) {
global $wp_uninstall_hooks;
if (!is_array($wp_uninstall_hooks)) $wp_uninstall_hooks = array();
$plugin_file_key = normalize_plugin_path_for_key($plugin_file);
$wp_uninstall_hooks[$plugin_file_key] = $callback;
}

function do_uninstall_plugin($plugin_slug) {
global $wp_uninstall_hooks;

$plugin_dir = ABSPATH . 'content/plugins/' . $plugin_slug;
$uninstall_file = $plugin_dir . '/uninstall.php';
$plugin_main_file_key = $plugin_slug . '/' . $plugin_slug . '.php';

if (!defined('SBP_UNINSTALL_PLUGIN')) {
define('SBP_UNINSTALL_PLUGIN', true);
}

if (file_exists($uninstall_file)) {
include_once $uninstall_file;
} elseif (isset($wp_uninstall_hooks[$plugin_main_file_key]) && is_callable($wp_uninstall_hooks[$plugin_main_file_key])) {
call_user_func($wp_uninstall_hooks[$plugin_main_file_key]);
}
}

global $wp_shortcodes;
$wp_shortcodes = array();

function add_shortcode($tag, $callback) {
global $wp_shortcodes;
if (is_callable($callback)) {
$wp_shortcodes[$tag] = $callback;
}
}

function do_shortcode($content) {
global $wp_shortcodes;
if (empty($wp_shortcodes) || !is_array($wp_shortcodes)) {
return $content;
}
$pattern = '/\[(' . implode('|', array_map('preg_quote', array_keys($wp_shortcodes))) . ')([^\]]*)\](?:(.*?)\[\/\1\])?/s';
return preg_replace_callback($pattern, 'do_shortcode_tag', $content);
}

function do_shortcode_tag($matches) {
global $wp_shortcodes;

$tag = $matches[1];
$attr_string = trim($matches[2]);
$enclosed_content = isset($matches[3]) ? $matches[3] : null;

$atts = array();
if ($attr_string) {
preg_match_all('/([\w-]+)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s\]]+))/s', $attr_string, $attr_matches, PREG_SET_ORDER);
foreach ($attr_matches as $attr_match) {
$key = $attr_match[1];
if (!empty($attr_match[3])) {
$atts[$key] = $attr_match[3];
} elseif (!empty($attr_match[4])) {
$atts[$key] = $attr_match[4];
} else {
$atts[$key] = $attr_match[5];
}
}
}

if (isset($wp_shortcodes[$tag]) && is_callable($wp_shortcodes[$tag])) {
return call_user_func($wp_shortcodes[$tag], $atts, $enclosed_content, $tag);
}
return $matches[0];
}

function generateCsrfToken($action_name = 'default_form_action') {
if (session_status() == PHP_SESSION_NONE) {
session_start();
}
if (empty($_SESSION['csrf_tokens'][$action_name])) {
try {
$_SESSION['csrf_tokens'][$action_name] = bin2hex(random_bytes(32));
} catch (Exception $e) {
//$_SESSION['csrf_tokens'][$action_name] = sha1(uniqid(mt_rand(), true) . CSRF_SALT_FALLBACK);
            // 增强回退：使用更多熵源
            $_SESSION['csrf_tokens'][$action_name] = hash('sha256', 
                microtime(true) . mt_rand() . random_int(0, PHP_INT_MAX) . 
                (CSRF_SALT_FALLBACK ?: bin2hex(random_bytes(16)))
            );
}
}
return $_SESSION['csrf_tokens'][$action_name];
}

function verifyCsrfToken($token_from_form, $action_name = 'default_form_action', $one_time = true) {
if (session_status() == PHP_SESSION_NONE) {
session_start();
}
if (empty($_SESSION['csrf_tokens'][$action_name]) ||
!is_string($token_from_form) ||
!hash_equals($_SESSION['csrf_tokens'][$action_name], $token_from_form)) {
return false;
}

if ($one_time) {
unset($_SESSION['csrf_tokens'][$action_name]);
}
return true;
}

function csrf_token_field($action_name = 'default_form_action', $echo = true) {
$token = generateCsrfToken($action_name);
$field = '<input type="hidden" name="csrf_token" value="' . e($token) . '">';
if ($echo) {
echo $field;
}
return $field;
}

function scan_plugins() {
$plugins_dir = ABSPATH . 'content/plugins';
$plugins = [];

if (!is_dir($plugins_dir)) {
return $plugins;
}

$dirs = scandir($plugins_dir);
foreach ($dirs as $dir) {
if ($dir === '.' || $dir === '..') {
continue;
}

$plugin_dir = $plugins_dir . '/' . $dir;
if (!is_dir($plugin_dir)) {
continue;
}

$main_file = $plugin_dir . '/' . $dir . '.php';
if (!file_exists($main_file)) {
continue;
}

$plugin_data = get_plugin_data($main_file);
if ($plugin_data) {
$plugins[$dir] = $plugin_data;
}
}

return $plugins;
}

function get_plugin_data($plugin_file) {
$default_headers = [
'name' => 'Plugin Name',
'plugin_uri' => 'Plugin URI',
'version' => 'Version',
'description' => 'Description',
'author' => 'Author',
'author_url' => 'Author URI'
];

$plugin_data = [];
$file_contents = file_get_contents($plugin_file);

foreach ($default_headers as $field => $regex) {
if (preg_match('/\s*\*\s*' . preg_quote($regex, '/') . '\s*:\s*(.+)$/mi', $file_contents, $match)) {
$plugin_data[$field] = trim($match[1]);
} else {
$plugin_data[$field] = '';
}
}

return $plugin_data;
}

function get_sidebar_widgets() {
$db = get_db();
$stmt = $db->query("SELECT * FROM sidebar_widgets ORDER BY `order` ASC");
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function update_sidebar_widgets($widgets) {
$db = get_db();
try {
$db->beginTransaction();
$db->exec("DELETE FROM sidebar_widgets");
$stmt = $db->prepare("INSERT INTO sidebar_widgets (title, type, content, `order`) VALUES (?, ?, ?, ?)");
foreach ($widgets as $widget) {
$stmt->execute([
$widget['title'],
$widget['type'],
$widget['content'],
$widget['order']
]);
}
$db->commit();
return true;
} catch (Exception $e) {
$db->rollBack();
return false;
}
}

function get_current_theme() {
$db = get_db();
$stmt = $db->prepare('SELECT value FROM options WHERE name = ?');
$stmt->execute(['current_theme']);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return $result ? $result['value'] : 'default';
}

function get_nav_menu() {
$db = get_db();
$stmt = $db->prepare('SELECT value FROM options WHERE name = ?');
$stmt->execute(['nav_menu']);
$menu_json = $stmt->fetchColumn();    
return $menu_json ? json_decode($menu_json, true) : [];
}

function update_nav_menu($menu_items) {
$db = get_db();
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
$ok = $stmt->execute(['nav_menu', json_encode($menu_items)]);
if ($ok && function_exists('litablog_options_cache_invalidate')) { litablog_options_cache_invalidate(); }
return $ok;
}

global $admin_menu, $admin_submenu;
$admin_menu = array();
$admin_submenu = array();

function add_menu_page($page_title, $menu_title, $capability, $menu_slug, $function = '', $icon_url = '', $position = null) {
global $admin_menu;
if ($capability === 'manage_options' && !is_admin()) {
return false;
}

$hookname = 'admin_page_' . $menu_slug;

if (null === $position) {
$position = count($admin_menu) * 10;
}
// ★2026-09-18 修 bug ✗✓（与 v10 同步 ✓）：**指定了 $position 也必须防撞号** ——
//   本函数是 `$admin_menu[$position] = …` ⇒ 两个插件用同号位时，**后注册的会把前一个整条覆盖**
//   ⇒ 前者的菜单**凭空消失** ✗（实测：litafile / member / lita-music 都传 76 ✓，
//   加载序 = get_active_plugins() 的 `ORDER BY name` ⇒ slug 字母序 ⇒ member 最后 ⇒ 后台只剩「会员」✗）
//   ⇒ 撞号就顺延到下一个空位 ✓（谁都不会丢 ✓）
while (isset($admin_menu[$position])) {
$position++;
}

$admin_menu[$position] = array(
$menu_title,
$capability,
$menu_slug,
$page_title,
$function,
$icon_url
);
ksort($admin_menu);
return $hookname;
}

function add_submenu_page($parent_slug, $page_title, $menu_title, $capability, $menu_slug, $function = '', $position = null) {
global $admin_menu, $admin_submenu;

if ($capability === 'manage_options' && !is_admin()) {
return false;
}

$parent_exists = false;
foreach($admin_menu as $menu_item) {
if ($menu_item[2] === $parent_slug) {
$parent_exists = true;
break;
}
}

if (!isset($admin_submenu[$parent_slug])) {
$admin_submenu[$parent_slug] = array();
}

if (null === $position) {
$position = count($admin_submenu[$parent_slug]) * 10;
while (isset($admin_submenu[$parent_slug][$position])) {
$position += 10;
}
}

$admin_submenu[$parent_slug][$position] = array(
$menu_title,
$capability,
$menu_slug,
$page_title,
$function
);
ksort($admin_submenu[$parent_slug]);
return 'admin_page_' . $menu_slug;
}

function get_theme_url() {
return SITE_URL . '/content/themes/' . get_current_theme();
}

function get_theme_path() {
return THEME_DIR . '/' . get_current_theme();
}

function switch_theme($theme_name) {
$db = get_db();
if (!is_dir(THEME_DIR . '/' . $theme_name)) {
return false;
}
$stmt = $db->prepare('INSERT OR REPLACE INTO options (name, value) VALUES (?, ?)');
$stmt->execute(['current_theme', $theme_name]);
if (function_exists('litablog_options_cache_invalidate')) { litablog_options_cache_invalidate(); }
return true;
}

function get_term_posts_count(string $term_type, string $term_slug): int {
// P3:计数器触发器(见 includes/counter_triggers.php)维护 categories.post_count / tags.post_count,
// 前台读列 O(1)。列缺失(旧库未执行回填脚本)时自动降级为实时 COUNT,双保险。
static $col_available = null; // 本请求内只探测一次
if ($col_available === null) {
try {
$db = get_db();
$probe = $term_type === 'category' ? 'categories' : 'tags';
$found = false;
foreach ($db->query("PRAGMA table_info($probe)") as $c) {
if ($c['name'] === 'post_count') { $found = true; break; }
}
$col_available = $found;
} catch (PDOException $e) {
$col_available = false;
}
}
if ($col_available) {
try {
$db = get_db();
if ($term_type === 'category') {
$stmt = $db->prepare('SELECT post_count FROM categories WHERE slug = ?');
} elseif ($term_type === 'tag') {
$stmt = $db->prepare('SELECT post_count FROM tags WHERE slug = ?');
} else {
return 0;
}
$stmt->bindValue(1, $term_slug, PDO::PARAM_STR);
$stmt->execute();
$v = $stmt->fetchColumn();
return (int)($v === false ? 0 : $v);
} catch (PDOException $e) {
// 列探测通过但读失败(罕见,如表被重建):回落 COUNT
}
}

try {
$db = get_db();
$sql = "";

if ($term_type === 'category') {
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_categories pc ON p.id = pc.post_id
JOIN categories c ON c.id = pc.category_id
WHERE c.slug = :slug AND p.status = "publish" AND p.type = "post"
';
} elseif ($term_type === 'tag') {
$sql = '
SELECT COUNT(DISTINCT p.id) as count
FROM posts p
JOIN post_tags pt ON p.id = pt.post_id
JOIN tags t ON t.id = pt.tag_id
WHERE t.slug = :slug AND p.status = "publish" AND p.type = "post"
';
} else {
return 0;
}

$stmt = $db->prepare($sql);
$stmt->bindValue(':slug', $term_slug, PDO::PARAM_STR);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
return (int) ($result['count'] ?? 0);
} catch (PDOException $e) {
error_log("Error counting posts for {$term_type} '{$term_slug}': " . $e->getMessage());
return 0;
}
}

function format_datetime($datetime, $full = true) {
$date_format = get_option('date_format', 'Y-m-d');
$time_format = get_option('time_format', 'H:i');
$timezone_string = get_option('site_timezone', 'Asia/Shanghai');

try {
$site_timezone = new DateTimeZone($timezone_string);
$dt = new DateTime($datetime, new DateTimeZone('UTC'));
$dt->setTimezone($site_timezone);

$result = [
'formatted_datetime' => $dt->format($date_format . ' ' . $time_format),
'formatted_date' => $dt->format($date_format),
'formatted_time' => $dt->format($time_format),
'iso_datetime' => $dt->format('c'),
'timestamp' => $dt->getTimestamp()
];

return $full ? $result : $result['formatted_datetime'];
} catch (Exception $e) {
error_log("Error formatting datetime '{$datetime}': " . $e->getMessage());
return $full ? [
'formatted_datetime' => $datetime,
'formatted_date' => substr($datetime, 0, 10),
'formatted_time' => substr($datetime, 11, 5),
'iso_datetime' => $datetime,
'timestamp' => time()
] : $datetime;
}
}

function prepare_template_data(string $request_type, $main_object): array {
$template_data = [];
$current_theme_slug = get_current_theme(); 
$template_data['request_type'] = $request_type;
$template_data['site_title'] = get_option('site_title', 'My Blog');
$template_data['site_description'] = get_option('site_description', '');
$template_data['site_url'] = SITE_URL;
$template_data['theme_url'] = rtrim(SITE_URL, '/') . '/content/themes/' . $current_theme_slug;
$template_data['nav_menu'] = get_nav_menu();
$template_data['widgets'] = get_sidebar_widgets();
$template_data['is_logged_in'] = is_logged_in();
$template_data['is_admin'] = is_admin();

switch ($request_type) {
case 'search':
$search_query_raw = $main_object;
$template_data['search_query'] = e($search_query_raw);
$template_data['archive_title'] = '搜索结果："' . e($search_query_raw) . '"';

// E-8 严格分页解析:page 仅接受纯正整数(字母/0/负数/混合串一律归 1);后续 D-5 行仍钳制 1000 防深分页
$page = (isset($_GET['page']) && preg_match('/^[1-9]\d*$/', (string)$_GET['page'])) ? (int)$_GET['page'] : 1;
$posts_per_page = (int) get_option('posts_per_page', 10);
// D-5 修复：限制最大页深，防止恶意构造 ?page=999999 触发超大 OFFSET。
// SQLite 的 OFFSET 需先扫描并跳过前面的行，页码越大越慢 ——
// 匿名访客可用单个请求打满 CPU/IO（低成本 DoS）。
$page = min($page, 1000);
$offset = ($page - 1) * $posts_per_page;

$search_results = search_blog_posts($search_query_raw, $posts_per_page, $offset);
$template_data['posts'] = $search_results['posts'];
$template_data['total_posts'] = $search_results['total_posts'];

if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$search_post_item) {
if (isset($search_post_item['created'])) {
$search_post_item = array_merge(
$search_post_item,
format_datetime($search_post_item['created'])
);
}
}
unset($search_post_item);
}

$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;
$template_data['pagination'] = get_pagination($page, $template_data['total_posts'], $posts_per_page, ['s' => $search_query_raw]);
break;

case 'single':
if ($main_object) {
$template_data['post'] = $main_object;
$template_data['author'] = get_user($main_object['author']);
$template_data['comments'] = get_post_comments($main_object['id']);
$template_data['categories'] = get_post_categories($main_object['id']);
$template_data['tags'] = get_post_tags($main_object['id']);

$post_content = $main_object['content'];
$post_content = do_shortcode($post_content);
$post_content = apply_filters('the_content', $post_content, $main_object['id']);
$template_data['post']['content'] = $post_content;

if (isset($main_object['created'])) {
$template_data['post'] = array_merge(
$template_data['post'],
format_datetime($main_object['created'])
);
}

if (!empty($template_data['comments'])) {
$formatted_comments = [];
foreach ($template_data['comments'] as $comment) {
if (isset($comment['created'])) {
$comment = array_merge(
$comment,
format_datetime($comment['created'])
);
}
$formatted_comments[] = $comment;
}
$template_data['comments'] = $formatted_comments;
}
$template_data['enable_comments'] = (get_option('enable_comments', '1') === '1');

if ($template_data['is_logged_in'] && isset($_SESSION['username'])) {
$template_data['current_user'] = [
'id' => $_SESSION['user_id'] ?? null,
'username' => $_SESSION['username'],
    'display_name' => (get_user($_SESSION['user_id'] ?? 0)['display_name'] ?? ''),
];
} else {
$template_data['current_user'] = null;
}
} else {
$template_data['request_type'] = '404';
$template_data['error_message'] = '文章未找到。';
}
break;

case 'page':
if ($main_object && isset($main_object['type']) && $main_object['type'] === 'page') {
$template_data['post'] = $main_object;
$template_data['author'] = get_user($main_object['author']);
$template_data['comments'] = [];
$template_data['categories'] = [];
$template_data['tags'] = [];
$template_data['enable_comments'] = false;

$page_content = $main_object['content'];
$page_content = do_shortcode($page_content);
$page_content = apply_filters('the_content', $page_content, $main_object['id']);
$template_data['post']['content'] = $page_content;

if (isset($main_object['created'])) {
$template_data['post'] = array_merge(
$template_data['post'],
format_datetime($main_object['created'])
);
}

if ($template_data['is_logged_in'] && isset($_SESSION['username'])) {
$template_data['current_user'] = [
'id' => $_SESSION['user_id'] ?? null,
'username' => $_SESSION['username'],
    'display_name' => (get_user($_SESSION['user_id'] ?? 0)['display_name'] ?? ''),
];
} else {
$template_data['current_user'] = null;
}
} else {
$template_data['request_type'] = '404';
$template_data['error_message'] = '页面未找到。';
}
break;

case 'category':
case 'tag':
// E-8 严格分页解析:page 仅接受纯正整数(字母/0/负数/混合串一律归 1);后续 D-5 行仍钳制 1000 防深分页
$page = (isset($_GET['page']) && preg_match('/^[1-9]\d*$/', (string)$_GET['page'])) ? (int)$_GET['page'] : 1;
$posts_per_page = (int) get_option('posts_per_page', 10);
// D-5 修复：限制最大页深（同上，防深分页 DoS）
$page = min($page, 1000);
$offset = ($page - 1) * $posts_per_page;

if ($main_object && isset($main_object['slug'])) {
$slug = $main_object['slug'];
$template_data['term'] = $main_object;

try {
$db = get_db();
// 性能优化（移植自 v10 两段式）：①JOIN 过滤只取本页 ID（避免大字段搬运+全量 GROUP BY 聚合），
// ②按 ID 补全帖子+作者，③分类/标签聚合仅对本页帖子做 IN 查询。
//
// P-3b 修复（本次评估实测）：归档页 Order By 消除 TEMP B-TREE。
//
// 症状：旧写法 `posts p JOIN post_categories pc_filter JOIN categories c_filter
//       WHERE c_filter.slug=? ORDER BY p.created DESC` —— 规划器被迫用
//       idx_post_categories_category(category_id) 驱动 + rowid 回表（EXPLAIN 显示
//       "SEARCH p USING INTEGER PRIMARY KEY (rowid=?)"），此时 p.created 无从用索引，
//       必然 "USE TEMP B-TREE FOR ORDER BY"：把该分类**全部**帖子排序后只取 10 条。
//       实测（cat-1 共 2,299 帖）4.8ms；该成本与分类体量正比，10 万帖分类会到 ~200ms。
//
// 治本：改用 EXISTS 半连接，让 posts 侧成为驱动器并复用覆盖索引
//       idx_posts_type_status_created(type,status)，ORDER BY p.created DESC 直接沿索引序产出，
//       彻底消除 "USE TEMP B-TREE FOR ORDER BY"（不再排序全部 2,299 行）。
//       子查询侧用 idx_post_categories_post_category(post_id,category_id) 做覆盖命中，
//       每条候选帖一次索引内点查，无回表。
// 实测（cat-1 共 2,299 帖）：浅页 4.85ms → 0.96ms（约 5 倍）；EXPLAIN 确认 TEMP B-TREE 消失。
//       结果集与原 JOIN 写法逐行一致（41/41 组对照全部通过）。
//
// 自适应选择（重要）：EXISTS 的成本随 OFFSET 线性增长——每跳过一个候选行都要跑一次
//       关联子查询。实测交叉点约在 OFFSET 700~1000：
//         OFFSET 0~500  EXISTS 更优（0.96~3.27ms  vs  JOIN 3.4~4.0ms）
//         OFFSET 1000+  JOIN 更优（6.59ms+        vs  JOIN 稳定 4.0ms）
//       故浅页走 EXISTS（吃掉最大收益），深页回退 JOIN（成本与分类总量正比、不随 OFFSET 放大）。
//       阈值取 700：留出安全余量，避免恰好在交叉点附近抖动。
$EXISTS_OFFSET_LIMIT = 700;
$use_exists = ($offset <= $EXISTS_OFFSET_LIMIT);

if ($request_type === 'category') {
$template_data['archive_title'] = '分类：' . e($main_object['name']);
$id_sql = $use_exists
? "
SELECT p.id
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post'
  AND EXISTS (
      SELECT 1 FROM post_categories pc_filter
      JOIN categories c_filter ON pc_filter.category_id = c_filter.id
      WHERE pc_filter.post_id = p.id AND c_filter.slug = :slug
  )
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
"
: "
SELECT p.id
FROM posts p
JOIN post_categories pc_filter ON p.id = pc_filter.post_id
JOIN categories c_filter ON pc_filter.category_id = c_filter.id
WHERE c_filter.slug = :slug AND p.status = 'publish' AND p.type = 'post'
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
";
} else {
$template_data['archive_title'] = '标签：' . e($main_object['name']);
$id_sql = $use_exists
? "
SELECT p.id
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post'
  AND EXISTS (
      SELECT 1 FROM post_tags pt_filter
      JOIN tags t_filter ON pt_filter.tag_id = t_filter.id
      WHERE pt_filter.post_id = p.id AND t_filter.slug = :slug
  )
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
"
: "
SELECT p.id
FROM posts p
JOIN post_tags pt_filter ON p.id = pt_filter.post_id
JOIN tags t_filter ON pt_filter.tag_id = t_filter.id
WHERE t_filter.slug = :slug AND p.status = 'publish' AND p.type = 'post'
ORDER BY p.created DESC
LIMIT :limit OFFSET :offset
";
}

$stmt = $db->prepare($id_sql);
$stmt->bindValue(':slug', $slug, PDO::PARAM_STR);
$stmt->bindValue(':limit', $posts_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$page_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

$posts_raw = [];
if (!empty($page_ids)) {
$in_place = implode(',', array_fill(0, count($page_ids), '?'));
$full_sql = "SELECT p.id, p.title, p.excerpt, p.author, p.status, p.type, p.slug,
p.created, p.modified, p.sticky_order,
COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username
FROM posts p LEFT JOIN users u ON p.author = u.id
WHERE p.id IN ($in_place)";
$stmtf = $db->prepare($full_sql);
$stmtf->execute($page_ids);
$by_id = [];
foreach ($stmtf->fetchAll(PDO::FETCH_ASSOC) as $pr) {
$by_id[$pr['id']] = $pr;
}
foreach ($page_ids as $pid) {
if (isset($by_id[$pid])) {
$posts_raw[] = $by_id[$pid];
}
}
// 分类/标签聚合（仅限本页帖子）
$cat_sql = "SELECT pc.post_id, GROUP_CONCAT(c.id || char(31) || c.name || char(31) || c.slug, char(30)) AS categories_data
FROM post_categories pc JOIN categories c ON c.id = pc.category_id
WHERE pc.post_id IN ($in_place) GROUP BY pc.post_id";
$stmt2 = $db->prepare($cat_sql);
$stmt2->execute($page_ids);
$cat_map = [];
foreach ($stmt2->fetchAll(PDO::FETCH_ASSOC) as $r) { $cat_map[$r['post_id']] = $r['categories_data']; }
$tag_sql = "SELECT pt.post_id, GROUP_CONCAT(t.id || char(31) || t.name || char(31) || t.slug, char(30)) AS tags_data
FROM post_tags pt JOIN tags t ON t.id = pt.tag_id
WHERE pt.post_id IN ($in_place) GROUP BY pt.post_id";
$stmt3 = $db->prepare($tag_sql);
$stmt3->execute($page_ids);
$tag_map = [];
foreach ($stmt3->fetchAll(PDO::FETCH_ASSOC) as $r) { $tag_map[$r['post_id']] = $r['tags_data']; }
foreach ($posts_raw as &$pr) {
$pr['categories_data'] = isset($cat_map[$pr['id']]) ? $cat_map[$pr['id']] : '';
$pr['tags_data'] = isset($tag_map[$pr['id']]) ? $tag_map[$pr['id']] : '';
}
unset($pr);
}

$posts_processed = hydrate_terms($posts_raw);
$template_data['posts'] = $posts_processed;

if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$post) {
if (isset($post['created'])) {
$post = array_merge(
$post,
format_datetime($post['created'])
);
}
}
unset($post);
}
} catch (PDOException $e) {
error_log("Database error fetching posts for {$request_type} '{$slug}': " . $e->getMessage());
$template_data['posts'] = [];
}

$template_data['total_posts'] = get_term_posts_count($request_type, $slug);
$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;

// ★2026-09-17（与 v10 同步 ✓）：分页链接必须**跟着当前 URL 形态** ✓ ——
//   否则第 1 页是 `?tag=6` ✓、第 2 页又变回 `?tag=<旧 slug>` ✗（一半 id 一半文本 ✓，地址栏跳来跳去 ✓）
$pagination_params = [$request_type => ((isset($main_object['id']) && (int)$main_object['id'] > 0) ? (int)$main_object['id'] : $slug)];
$template_data['pagination'] = get_pagination($page, $template_data['total_posts'], $posts_per_page, $pagination_params);
} else {
$template_data['request_type'] = '404';
$template_data['error_message'] = ($request_type === 'category' ? '分类' : '标签') . '未找到。';
}
break;

case 'home':
// E-8 严格分页解析:page 仅接受纯正整数(字母/0/负数/混合串一律归 1);后续 D-5 行仍钳制 1000 防深分页
$page = (isset($_GET['page']) && preg_match('/^[1-9]\d*$/', (string)$_GET['page'])) ? (int)$_GET['page'] : 1;
$posts_per_page = get_option('posts_per_page', 10);
// D-5 修复：限制最大页深（同上，防深分页 DoS）
$page = min($page, 1000);
$offset = ($page - 1) * $posts_per_page;

try {
$db = get_db();
// D-3 修复：列表查询不再 SELECT p.*（避免搬运 content 全文大字段）。
// 首页/分类/标签列表模板只消费 title/excerpt/categories/tags 等，
// content 只在单篇页（single.php）用到，此处投影可显著减少每屏搬运的数据量
// （假设 20KB 正文 × 10 帖 = 每屏少搬 ~200KB）。
//
// 性能优化（移植自 v10 两段式方案，并修正其置顶分页缺陷）：
// v10 原版置顶每页重复出现且普通帖 OFFSET 不减置顶占位（置顶>0 时分页有洞）；
// 此处改为窗口交集公式：全局列表 = [置顶S条, 普通帖...]，page p 窗口 = [(p-1)*10, p*10)，
// 置顶只占窗口与 [0,S) 的交集（即只第 1 页出现），普通帖 OFFSET = max(0, (p-1)*10 - S)，
// 与旧版「ORDER BY sticky标记 + 全局 OFFSET」语义完全一致（S≤10 时）。
// 实测（20万数据）：旧版单条大查询 4484ms → 两段式 43ms；深分页 page500 4790ms → 30ms。
// S（置顶显示数，min(总数,10)）用 60s 缓存（统一缓存层，键 sticky_total），避免每次请求 COUNT 回表。
$sticky_total = null;
$cached_sticky = function_exists('cache_get') ? cache_get('sticky_total', 60) : null;
if ($cached_sticky !== null && is_numeric($cached_sticky)) {
$sticky_total = (int)$cached_sticky;
}
if ($sticky_total === null) {
$sticky_total = (int)$db->query(
"SELECT COUNT(*) FROM posts WHERE status = 'publish' AND type = 'post' AND sticky_order > 0"
)->fetchColumn();
if (function_exists('cache_set')) {
cache_set('sticky_total', $sticky_total, 60);
}
}
$sticky_shown = min($sticky_total, $posts_per_page); // 置顶最多占一页名额
$win_start = ($page - 1) * $posts_per_page;

$posts_raw = [];
// ① 置顶帖（只在第 1 页窗口出现）
// P-1 修复（本次评估实测）：删除 `INDEXED BY idx_posts_type_status_created` 强制索引提示。
//
// 原实现让 SQLite 用 (type,status,created) 索引按 created DESC 走，逐行走访直到凑够
// LIMIT 100 个 sticky_order>0 的行。但置顶帖极度稀疏（实测 33,004 帖中仅 8 帖置顶），
// 导致几乎扫遍整个索引才能凑够 100 行 → 实测 34-49ms（占首页实时渲染 92%）。
// 关闭 INDEXED BY 后 SQLite 自行改用「置顶部分索引 idx_posts_sticky」直接定位 8 行 →
// 实测 0.17-0.23ms，端到端提速约 172 倍。
// 配合 Install/迁移脚本新增：CREATE INDEX idx_posts_sticky ON posts(sticky_order, created) WHERE sticky_order > 0;
// 注意：ORDER BY 必须与索引列同序（sticky_order ASC, created DESC）才能免排序；
//       内层不再需要 LIMIT 100 的「候选池」，因为索引已直接给出最终 8 行。
if ($win_start < $sticky_shown) {
$sticky_sql = "
SELECT x.*, COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username
FROM (
SELECT p.id, p.title, p.excerpt, p.author, p.status, p.type, p.slug,
p.created, p.modified, p.sticky_order
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post' AND p.sticky_order > 0
ORDER BY p.sticky_order ASC, p.created DESC
) x
LEFT JOIN users u ON x.author = u.id
ORDER BY x.sticky_order ASC, x.created DESC
LIMIT :limit
";
$stmt = $db->prepare($sticky_sql);
$stmt->bindValue(':limit', (int)$sticky_shown, PDO::PARAM_INT);
$stmt->execute();
$posts_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ② 普通帖（sticky_order=0，按时间排；两段式深分页优化：先走覆盖索引只取本页 ID，再按 ID 补全）
//
// P-3 修复（本次评估实测）：深分页 keyset（游标）访问路径。
//
// 症状：OFFSET 线性回退 —— SQLite 必须"读出前 N 行再丢弃"，OFFSET 30000 实测 44ms；
//       而 page=1000（D-5 钳制上限）在 20 万帖规模下会到 ~300ms，属低成本 DoS 入口。
// 治本：当"无置顶窗口且页码 > 阈值"时，改用 keyset 分页 —— 先查上一页锚点行
//       （(page-1)*per_page-1 处那条普通帖）的 (created, id)，再以
//       (created, id) < (锚点 created, 锚点 id) 为谓词直接定位，避免 OFFSET 跳过。
//
// 注意：这里必须用 (created, id) 双列游标。created 为 DATETIME 文本且实测有重复
//       （33,005 行中 32,997 个不同值），只用 created 做游标会在同秒帖子上丢行/串页；
//       追加 id 作为第二排序键后字典序唯一，且与 idx_posts_normal(type,status,created)
//       的排序前缀兼容（created 同秒时再按 id 收敛，结果集完全一致）。
//
// 阈值 50：浅页码（前 50 页）沿用 OFFSET，避免为建索引/取锚点多付一次查询；
//           深页码才切 keyset。keyset 单页实测 0.05ms，且与页码无关（不随深度劣化）。
$normal_offset = max(0, $win_start - $sticky_shown);
$keyset_threshold = 50;

$normal_ids = [];
if ($normal_offset > $keyset_threshold * $posts_per_page) {
    // ── keyset 路径：取上一页末行 (created, id) 作为上界游标 ──
    $anchor_offset = $normal_offset - 1;
    $anchor_sql = "
SELECT p.created, p.id
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post' AND p.sticky_order = 0
ORDER BY p.created DESC, p.id DESC
LIMIT 1 OFFSET :offset
";
    $stmt_a = $db->prepare($anchor_sql);
    $stmt_a->bindValue(':offset', (int)$anchor_offset, PDO::PARAM_INT);
    $stmt_a->execute();
    $anchor = $stmt_a->fetch(PDO::FETCH_ASSOC);

    if ($anchor) {
        // 用 SQLite 的行值(row-value)元组比较，而非 (c < ? OR (c = ? AND id < ?))。
        // 关键差异：行值语法可被规划器识别为单一范围约束，直接沿
        // idx_posts_normal(type,status,created DESC,id DESC) 定位；
        // 而 OR 展开写法只约束到 created 列，右侧 id 排序仍需
        // "USE TEMP B-TREE FOR RIGHT PART OF ORDER BY"，实测反而劣化到 50ms+。
        $keyset_sql = "
SELECT p.id
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post' AND p.sticky_order = 0
  AND (p.created, p.id) < (:a_created, :a_id)
ORDER BY p.created DESC, p.id DESC
LIMIT :limit
";
        $stmt = $db->prepare($keyset_sql);
        $stmt->bindValue(':a_created', $anchor['created'], PDO::PARAM_STR);
        $stmt->bindValue(':a_id', (int)$anchor['id'], PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int)$posts_per_page, PDO::PARAM_INT);
        $stmt->execute();
        $normal_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}

if (empty($normal_ids) && $normal_offset <= $keyset_threshold * $posts_per_page) {
    // ── OFFSET 路径（浅页码）：与旧语义完全一致 ──
    $normal_sql = "
SELECT p.id
FROM posts p
WHERE p.status = 'publish' AND p.type = 'post' AND p.sticky_order = 0
ORDER BY p.created DESC, p.id DESC
LIMIT :limit OFFSET :offset
";
    $stmt = $db->prepare($normal_sql);
    $stmt->bindValue(':limit', (int)$posts_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$normal_offset, PDO::PARAM_INT);
    $stmt->execute();
    $normal_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
}

if (!empty($normal_ids)) {
$in_place = implode(',', array_fill(0, count($normal_ids), '?'));
$full_sql = "SELECT p.id, p.title, p.excerpt, p.author, p.status, p.type, p.slug,
p.created, p.modified, p.sticky_order,
COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username
FROM posts p LEFT JOIN users u ON p.author = u.id
WHERE p.id IN ($in_place)";
$stmtf = $db->prepare($full_sql);
$stmtf->execute($normal_ids);
$by_id = [];
foreach ($stmtf->fetchAll(PDO::FETCH_ASSOC) as $pr) {
$by_id[$pr['id']] = $pr;
}
foreach ($normal_ids as $pid) {
if (isset($by_id[$pid])) {
$posts_raw[] = $by_id[$pid];
}
}
}
// ③ 截断到每页名额（第 1 页置顶+普通帖合并可能超出）
$posts_raw = array_slice($posts_raw, 0, $posts_per_page);

// ④ 分类/标签聚合（仅对本页帖子做 IN 查询，替代 5 表全量 GROUP BY 聚合）
if (!empty($posts_raw)) {
$page_ids = array_column($posts_raw, 'id');
$in_place = implode(',', array_fill(0, count($page_ids), '?'));
$cat_sql = "SELECT pc.post_id, GROUP_CONCAT(c.id || char(31) || c.name || char(31) || c.slug, char(30)) AS categories_data
FROM post_categories pc JOIN categories c ON c.id = pc.category_id
WHERE pc.post_id IN ($in_place) GROUP BY pc.post_id";
$stmt2 = $db->prepare($cat_sql);
$stmt2->execute($page_ids);
$cat_map = [];
foreach ($stmt2->fetchAll(PDO::FETCH_ASSOC) as $r) { $cat_map[$r['post_id']] = $r['categories_data']; }
$tag_sql = "SELECT pt.post_id, GROUP_CONCAT(t.id || char(31) || t.name || char(31) || t.slug, char(30)) AS tags_data
FROM post_tags pt JOIN tags t ON t.id = pt.tag_id
WHERE pt.post_id IN ($in_place) GROUP BY pt.post_id";
$stmt3 = $db->prepare($tag_sql);
$stmt3->execute($page_ids);
$tag_map = [];
foreach ($stmt3->fetchAll(PDO::FETCH_ASSOC) as $r) { $tag_map[$r['post_id']] = $r['tags_data']; }
foreach ($posts_raw as &$pr) {
$pr['categories_data'] = isset($cat_map[$pr['id']]) ? $cat_map[$pr['id']] : '';
$pr['tags_data'] = isset($tag_map[$pr['id']]) ? $tag_map[$pr['id']] : '';
}
unset($pr);
}

$posts_processed = hydrate_terms($posts_raw);
$template_data['posts'] = $posts_processed;

if (!empty($template_data['posts'])) {
foreach ($template_data['posts'] as &$post) {
if (isset($post['created'])) {
$post = array_merge(
$post,
format_datetime($post['created'])
);
}
}
unset($post);
}
} catch (PDOException $e) {
error_log("Database error fetching posts for home: " . $e->getMessage());
$template_data['posts'] = [];
}

$total_posts = get_total_posts(['status' => 'publish', 'type' => 'post']);
// E-10 修正首页导航总页数口径:窗口交集公式中「置顶帖仅第 1 页占位显示 min(S, per_page) 个」,
// 其余置顶(S - min(S,per_page))永远不会进入分页序列 → 原 total_posts 口径把全部置顶计入,
// 会导致导航多出尾部空页(如 164 置顶/8794 普通 → 导航 896 页,实际普通帖只撑到 881 页,882-896 全是"暂无更新")。
$sticky_eff = isset($sticky_total) ? min((int)$sticky_total, (int)$posts_per_page) : 0;
$nav_total = (int)$total_posts - (int)($sticky_total ?? 0) + $sticky_eff;
$template_data['total_posts'] = $total_posts;
$template_data['current_page'] = $page;
$template_data['posts_per_page'] = $posts_per_page;
$template_data['archive_title'] = '';
$template_data['pagination'] = get_pagination($page, $nav_total, $posts_per_page);
break;

case '404':
$template_data['error_message'] = '抱歉，页面未找到。';
break;
}

if ($template_data['request_type'] === '404') {
if (!headers_sent()) { header('HTTP/1.0 404 Not Found'); }
}

return $template_data;
}

function get_cached_plugins_data($cache_ttl = 3600) {
$cache_key_data = 'cached_plugins_filesystem_data';
$cache_key_time = 'cached_plugins_filesystem_timestamp';

$cached_data_json = get_option($cache_key_data, null);
$cache_time = (int) get_option($cache_key_time, 0);

if ($cached_data_json !== null && (time() - $cache_time) < $cache_ttl) {
$cached_data = json_decode($cached_data_json, true);
if (is_array($cached_data)) {
return $cached_data;
}
}

$plugins_dir = PLUGIN_DIR;
$plugins = [];

if (!is_dir($plugins_dir)) {
update_option($cache_key_data, json_encode([]));
update_option($cache_key_time, time());
return [];
}

$dirs = @scandir($plugins_dir);
if ($dirs === false) {
update_option($cache_key_data, json_encode([]));
update_option($cache_key_time, time());
return [];
}

foreach ($dirs as $dir) {
if ($dir === '.' || $dir === '..') continue;

$plugin_dir = $plugins_dir . '/' . $dir;
if (!is_dir($plugin_dir)) continue;

$main_file = $plugin_dir . '/' . $dir . '.php';
if (!file_exists($main_file)) continue;

$plugin_data = get_plugin_data($main_file);
if ($plugin_data) {
$plugin_data['slug'] = $dir;
$plugins[$dir] = $plugin_data;
}
}

update_option($cache_key_data, json_encode($plugins));
update_option($cache_key_time, time());

return $plugins;
}

function get_cached_themes_data($cache_ttl = 3600) {
$cache_key_data = 'cached_themes_data';
$cache_key_time = 'cached_themes_timestamp';

$cached_data_json = get_option($cache_key_data, null);
$cache_time = (int) get_option($cache_key_time, 0);

if ($cached_data_json !== null && (time() - $cache_time) < $cache_ttl) {
$cached_data = json_decode($cached_data_json, true);
if (is_array($cached_data)) {
return $cached_data;
}
}

$themes_data = scan_and_get_theme_details();
update_option($cache_key_data, json_encode($themes_data));
update_option($cache_key_time, time());

return $themes_data;
}

function scan_and_get_theme_details(): array {
$themes_data = [];
$themes_dir = THEME_DIR;

if (!is_dir($themes_dir)) {
return [];
}

$dirs = @scandir($themes_dir);
if ($dirs === false) {
return [];
}

foreach ($dirs as $dir) {
if ($dir === "." || $dir === "..") {
continue;
}

$theme_path = $themes_dir . "/" . $dir;
if (!is_dir($theme_path)) {
continue;
}

$theme_info = [
'slug' => $dir,
'name' => $dir,
'description' => '',
'version' => '',
'author' => '',
'theme_uri' => '',
'author_uri' => '',
'screenshot_url' => '',
'is_valid' => true,
'missing_files' => []
];

$required_files = ['index.php', 'single.php'];
foreach ($required_files as $file) {
if (!file_exists($theme_path . "/" . $file)) {
$theme_info['missing_files'][] = $file;
$theme_info['is_valid'] = false;
}
}

$style_file = $theme_path . "/style.css";
if (file_exists($style_file)) {
$style_content = @file_get_contents($style_file);
if ($style_content !== false) {
if (preg_match('/^[ \t\/*#]*Theme Name:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['name'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Description:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['description'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Version:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['version'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Author:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['author'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Theme URI:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['theme_uri'] = trim($match[1]);
}
if (preg_match('/^[ \t\/*#]*Author URI:[ \t]*(.+)$/mi', $style_content, $match)) {
$theme_info['author_uri'] = trim($match[1]);
}
} else {
$theme_info['missing_files'][] = 'style.css (无法读取)';
$theme_info['is_valid'] = false;
}
} else {
$theme_info['missing_files'][] = 'style.css';
$theme_info['is_valid'] = false;
}

$screenshot_found = false;
$screenshot_types = ['png', 'jpg', 'jpeg', 'gif'];
foreach ($screenshot_types as $type) {
$screenshot_filename = "screenshot." . $type;
if (file_exists($theme_path . "/" . $screenshot_filename)) {
$site_url_base = rtrim(SITE_URL, '/');
$theme_info['screenshot_url'] = $site_url_base . '/content/themes/' . $dir . '/' . $screenshot_filename;
$screenshot_found = true;
break;
}
}

$themes_data[$dir] = $theme_info;
}

return $themes_data;
}

function set_flash_message($message, $type = 'info') {
if (session_status() == PHP_SESSION_NONE) {
session_start();
}

if (!isset($_SESSION['flash_messages'])) {
$_SESSION['flash_messages'] = array();
}

if (!isset($_SESSION['flash_messages'][$type])) {
$_SESSION['flash_messages'][$type] = array();
}
$_SESSION['flash_messages'][$type][] = $message;
}

function display_flash_message($echo = true) {
if (session_status() == PHP_SESSION_NONE) {
session_start();
}

$output = '';
if (isset($_SESSION['flash_messages']) && !empty($_SESSION['flash_messages'])) {
foreach ($_SESSION['flash_messages'] as $type => $messages) {
$allowed_types = ['success', 'error', 'warning', 'info', 'danger'];
$alert_type_class = in_array($type, $allowed_types) ? $type : 'info';
if ($alert_type_class === 'error') $alert_type_class = 'danger';

$output .= '<div class="alert alert-' . htmlspecialchars($alert_type_class) . '" role="alert">';
if (count($messages) > 1) {
$output .= '<ul>';
foreach ($messages as $msg) {
$output .= '<li>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</li>';
}
$output .= '</ul>';
} else {
$output .= htmlspecialchars(reset($messages), ENT_QUOTES, 'UTF-8');
}
$output .= '</div>';
}
unset($_SESSION['flash_messages']);
}

if ($echo) {
echo $output;
} else {
return $output;
}
}

global $wp_settings_sections, $wp_settings_fields;
$wp_settings_sections = array();
$wp_settings_fields = array();

function add_settings_section($page, $id, $title, $callback = null) {
global $wp_settings_sections;
if (!isset($wp_settings_sections[$page])) {
$wp_settings_sections[$page] = array();
}
$wp_settings_sections[$page][$id] = array(
'id'       => $id,
'title'    => $title,
'callback' => $callback
);
}

function add_settings_field($page, $section_id, $id, $title, $callback, $args = array()) {
global $wp_settings_fields;
if (!isset($wp_settings_fields[$page])) {
$wp_settings_fields[$page] = array();
}
if (!isset($wp_settings_fields[$page][$section_id])) {
$wp_settings_fields[$page][$section_id] = array();
}
$wp_settings_fields[$page][$section_id][$id] = array(
'id'       => $id,
'title'    => $title,
'callback' => $callback,
'args'     => $args
);
}

function do_settings_sections($page) {
global $wp_settings_sections, $wp_settings_fields;

if (!isset($wp_settings_sections[$page])) {
return;
}

foreach ($wp_settings_sections[$page] as $section) {
echo '<div class="settings-section" id="section-' . e($section['id']) . '">';
if ($section['title']) {
echo '<h2>' . e($section['title']) . '</h2>';
}
if ($section['callback'] && is_callable($section['callback'])) {
call_user_func($section['callback'], $section);
}

if (isset($wp_settings_fields[$page][$section['id']])) {
echo '<table class="form-table">';
do_settings_fields($page, $section['id']);
echo '</table>';
}
echo '</div>';
}
}

function do_settings_fields($page, $section_id) {
global $wp_settings_fields;

if (!isset($wp_settings_fields[$page][$section_id])) {
return;
}

foreach ($wp_settings_fields[$page][$section_id] as $field) {
echo '<tr valign="top">';
echo '<th scope="row"><label for="' . e($field['id']) . '">' . e($field['title']) . '</label></th>';
echo '<td>';
if ($field['callback'] && is_callable($field['callback'])) {
call_user_func($field['callback'], array_merge(['id' => $field['id']], $field['args']));
}
if (isset($field['args']['description']) && !empty($field['args']['description'])) {
echo '<p class="description">' . $field['args']['description'] . '</p>';
}
echo '</td>';
echo '</tr>';
}
}

function render_settings_field_callback($args) {
$option_name = $args['id'];
$type = isset($args['type']) ? $args['type'] : 'text';
$default_value = isset($args['default']) ? $args['default'] : '';
$value = get_option($option_name, $default_value);
$options = isset($args['options']) && is_array($args['options']) ? $args['options'] : [];
$description_id = $option_name . '-description';

switch ($type) {
case 'text':
case 'number':
case 'email':
case 'url':
echo '<input type="' . e($type) . '" id="' . e($option_name) . '" name="' . e($option_name) . '" value="' . e($value) . '" class="regular-text" aria-describedby="' . e($description_id) . '">';
break;
case 'textarea':
echo '<textarea id="' . e($option_name) . '" name="' . e($option_name) . '" rows="5" class="large-text" aria-describedby="' . e($description_id) . '">' . e($value) . '</textarea>';
break;
case 'checkbox':
echo '<input type="checkbox" id="' . e($option_name) . '" name="' . e($option_name) . '" value="1" ' . checked($value, '1', false) . ' aria-describedby="' . e($description_id) . '">';
if (isset($args['label'])) {
echo ' <label for="' . e($option_name) . '">' . e($args['label']) . '</label>';
}
break;
case 'select':
echo '<select id="' . e($option_name) . '" name="' . e($option_name) . '" aria-describedby="' . e($description_id) . '">';
foreach ($options as $val => $label) {
echo '<option value="' . e($val) . '" ' . selected($value, $val, false) . '>' . e($label) . '</option>';
}
echo '</select>';
break;
case 'radio':
if (!empty($options)) {
echo '<fieldset>';
foreach ($options as $val => $label) {
echo '<label style="margin-right: 15px;">';
echo '<input type="radio" name="' . e($option_name) . '" value="' . e($val) . '" ' . checked($value, $val, false) . '> ';
echo e($label);
echo '</label>';
}
echo '</fieldset>';
}
break;
default:
echo '<!-- Field type ' . e($type) . ' not implemented by generic renderer -->';
break;
}
}

function checked($checked, $current = true, $echo = true) {
$result = ($checked == $current) ? ' checked="checked"' : '';
if ($echo) {
echo $result;
}
return $result;
}

function selected($selected, $current = true, $echo = true) {
$result = ($selected == $current) ? ' selected="selected"' : '';
if ($echo) {
echo $result;
}
return $result;
}

function generate_rss_feed_content() {
$feed_title = get_option('site_title', 'My Blog');
$site_url_for_feed = rtrim(SITE_URL, '/');
$feed_link = $site_url_for_feed;
$feed_description = get_option('site_description', 'Latest updates from the blog.');
$feed_language = 'zh-CN';
$feed_items_count = (int) get_option('posts_per_rss', 15);
$feed_ttl = (int) get_option('rss_ttl', 60);

ob_start();

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<rss version="2.0"
xmlns:content="http://purl.org/rss/1.0/modules/content/"
xmlns:wfw="http://wellformedweb.org/CommentAPI/"
xmlns:dc="http://purl.org/dc/elements/1.1/"
xmlns:atom="http://www.w3.org/2005/Atom"
xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
>' . "\n";

echo '<channel>' . "\n";
echo '  <title>' . e($feed_title) . '</title>' . "\n";
echo '  <atom:link href="' . e($site_url_for_feed . '/rss.xml') . '" rel="self" type="application/rss+xml" />' . "\n";
echo '  <link>' . e($feed_link) . '</link>' . "\n";
echo '  <description>' . e($feed_description) . '</description>' . "\n";
echo '  <lastBuildDate>' . date(DATE_RFC2822) . '</lastBuildDate>' . "\n";
echo '  <language>' . e($feed_language) . '</language>' . "\n";
echo '  <sy:updatePeriod>hourly</sy:updatePeriod>' . "\n";
echo '  <sy:updateFrequency>1</sy:updateFrequency>' . "\n";
echo '  <ttl>' . $feed_ttl . '</ttl>' . "\n";

try {
$db = get_db();
$stmt = $db->prepare("
SELECT p.*, COALESCE(NULLIF(u.display_name, ''), u.username) AS author_username
FROM posts p
LEFT JOIN users u ON p.author = u.id
WHERE p.status = 'publish' AND p.type = 'post'
ORDER BY p.created DESC
LIMIT :limit
");
$stmt->bindValue(':limit', $feed_items_count, PDO::PARAM_INT);
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($posts as $post) {
$post_url = Permalink::get_post_link($post['id']);
$post_date_rfc2822 = date(DATE_RFC2822, strtotime($post['created']));

echo '  <item>' . "\n";
echo '    <title>' . e($post['title']) . '</title>' . "\n";
echo '    <link>' . e($post_url) . '</link>' . "\n";
echo '    <pubDate>' . $post_date_rfc2822 . '</pubDate>' . "\n";
echo '    <dc:creator><![CDATA[' . e($post['author_username'] ?? 'Unknown Author') . ']]></dc:creator>' . "\n";
echo '    <guid isPermaLink="true">' . e($post_url) . '</guid>' . "\n";

$description_content = '';
if (!empty($post['excerpt'])) {
$description_content = nl2br(e($post['excerpt']));
} else {
$content_text = strip_tags($post['content']);
$limit = 250;
if (mb_strlen($content_text, 'UTF-8') > $limit) {
$description_content = mb_substr($content_text, 0, $limit, 'UTF-8') . '...';
} else {
$description_content = $content_text;
}
$description_content = nl2br(e($description_content));
}
echo '    <description><![CDATA[' . $description_content . ']]></description>' . "\n";

$categories = get_post_categories($post['id']);
if (!empty($categories)) {
foreach ($categories as $category) {
echo '    <category><![CDATA[' . e($category['name']) . ']]></category>' . "\n";
}
}
echo '  </item>' . "\n";
}
} catch (PDOException $e) {
error_log("RSS Feed Content Generation Error: " . $e->getMessage());
}

echo '</channel>' . "\n";
echo '</rss>' . "\n";

return ob_get_clean();
}

function write_rss_file() {
$rss_content = generate_rss_feed_content();
if ($rss_content === false || empty(trim($rss_content))) {
error_log("Failed to generate RSS content, it was empty.");
return false;
}

$rss_file_path = ABSPATH . 'rss.xml';
if (@file_put_contents($rss_file_path, $rss_content) !== false) {
return true;
} else {
error_log("Failed to write rss.xml file to: " . $rss_file_path);
return false;
}
}

global $wp_scripts_registered, $wp_styles_registered;
global $wp_scripts_enqueued, $wp_styles_enqueued;
global $wp_script_data, $wp_style_data;

$wp_scripts_registered = [];
$wp_styles_registered = [];
$wp_scripts_enqueued = [];
$wp_styles_enqueued = [];
$wp_script_data = [];
$wp_style_data = [];

function wp_register_script($handle, $src, $deps = [], $ver = false, $in_footer = false, $args = []) {
global $wp_scripts_registered, $wp_script_data;
$wp_scripts_registered[$handle] = [
'src' => $src,
'ver' => $ver,
'in_footer' => $in_footer,
'deps' => (array) $deps
];
if (!empty($args)) {
$wp_script_data[$handle] = $args;
}
}

function wp_register_style($handle, $src, $deps = [], $ver = false, $media = 'all') {
global $wp_styles_registered;
$wp_styles_registered[$handle] = [
'src' => $src,
'ver' => $ver,
'media' => $media,
'deps' => (array) $deps
];
}

function wp_enqueue_script($handle) {
global $wp_scripts_registered, $wp_scripts_enqueued;
if (isset($wp_scripts_registered[$handle]) && !in_array($handle, $wp_scripts_enqueued)) {
$wp_scripts_enqueued[] = $handle;
}
}

function wp_enqueue_style($handle) {
global $wp_styles_registered, $wp_styles_enqueued;
if (isset($wp_styles_registered[$handle]) && !in_array($handle, $wp_styles_enqueued)) {
$wp_styles_enqueued[] = $handle;
}
}

function wp_print_head_scripts_and_styles() {
global $wp_styles_registered, $wp_styles_enqueued;
global $wp_scripts_registered, $wp_scripts_enqueued, $wp_script_data;

foreach ($wp_styles_enqueued as $handle) {
if (isset($wp_styles_registered[$handle])) {
$style = $wp_styles_registered[$handle];
$src = $style['src'];
if ($style['ver']) {
$src .= '?ver=' . $style['ver'];
}
echo "<link rel='stylesheet' id='{$handle}-css' href='" . e($src) . "' media='" . e($style['media']) . "' />\n";
}
}

foreach ($wp_scripts_enqueued as $handle) {
if (isset($wp_scripts_registered[$handle]) && !$wp_scripts_registered[$handle]['in_footer']) {
$script = $wp_scripts_registered[$handle];
$src = $script['src'];
if ($script['ver']) {
$src .= '?ver=' . $script['ver'];
}
$extra_attrs = '';
if (isset($wp_script_data[$handle]) && isset($wp_script_data[$handle]['strategy'])) {
if ($wp_script_data[$handle]['strategy'] === 'defer') $extra_attrs .= ' defer';
if ($wp_script_data[$handle]['strategy'] === 'async') $extra_attrs .= ' async';
}
echo "<script src='" . e($src) . "' id='{$handle}-js'{$extra_attrs}></script>\n";
}
}
}

function wp_print_footer_scripts() {
global $wp_scripts_registered, $wp_scripts_enqueued, $wp_script_data;

foreach ($wp_scripts_enqueued as $handle) {
if (isset($wp_scripts_registered[$handle]) && $wp_scripts_registered[$handle]['in_footer']) {
$script = $wp_scripts_registered[$handle];
$src = $script['src'];
if ($script['ver']) {
$src .= '?ver=' . $script['ver'];
}
$extra_attrs = '';
if (isset($wp_script_data[$handle]) && isset($wp_script_data[$handle]['strategy'])) {
if ($wp_script_data[$handle]['strategy'] === 'defer') $extra_attrs .= ' defer';
if ($wp_script_data[$handle]['strategy'] === 'async') $extra_attrs .= ' async';
}
echo "<script src='" . e($src) . "' id='{$handle}-js'{$extra_attrs}></script>\n";
}
}
}

function get_current_admin_page_hook_suffix() {
$current_script = basename($_SERVER['PHP_SELF']);
$page_slug = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
$type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';

if (!empty($page_slug)) {
return $current_script . '_page_' . $page_slug;
} elseif (!empty($type)) {
return $current_script . '_' . $type;
}
return $current_script;
}

function get_roles_and_caps() {
$roles = [
'administrator' => [
'read' => true,
'publish_posts' => true,
'edit_posts' => true,
'edit_others_posts' => true,
'delete_posts' => true,
'manage_options' => true,
],
'user' => [
'read' => true,
'publish_posts' => true,
'edit_posts' => true,
'delete_posts' => true,
],
];
return apply_filters('get_roles_and_caps', $roles);
}

function current_user_can($capability) {
if (!is_logged_in()) {
return false;
}

$user_role = $_SESSION['role'] ?? 'user';
if ($user_role === 'administrator') {
return apply_filters('user_has_cap', true, $capability, $user_role);
}

$roles_map = get_roles_and_caps();
$has_cap = isset($roles_map[$user_role][$capability]) && $roles_map[$user_role][$capability] === true;
return apply_filters('user_has_cap', $has_cap, $capability, $user_role);
}

function litablog_generate_rewrite_rules($permalink_type) {
$htaccess_file = ABSPATH . '.htaccess';
$web_config_file = ABSPATH . 'web.config';

$sub_dir = parse_url(SITE_URL, PHP_URL_PATH);
$sub_dir = $sub_dir ? rtrim($sub_dir, '/') . '/' : '/';

$htaccess_start = "# Begin LitaBlog Rewrite Rules";
$htaccess_end = "# End LitaBlog Rewrite Rules";

$xml_start = "<!-- Begin LitaBlog Rewrite Rules -->";
$xml_end = "<!-- End LitaBlog Rewrite Rules -->";

if ($permalink_type === 'default') {
if (file_exists($htaccess_file) && is_writable($htaccess_file)) {
$content = file_get_contents($htaccess_file);
$start_pos = strpos($content, $htaccess_start);
$end_pos = strpos($content, $htaccess_end);

if ($start_pos !== false && $end_pos !== false && $end_pos > $start_pos) {
$before = substr($content, 0, $start_pos);
$after = substr($content, $end_pos + strlen($htaccess_end));
$content = trim($before . $after);

if (empty($content)) {
@unlink($htaccess_file);
} else {
file_put_contents($htaccess_file, $content . "\n", LOCK_EX);
}
}
}

if (file_exists($web_config_file) && is_writable($web_config_file)) {
$xml_content = file_get_contents($web_config_file);
$start_pos = strpos($xml_content, $xml_start);
$end_pos = strpos($xml_content, $xml_end);

if ($start_pos !== false && $end_pos !== false && $end_pos > $start_pos) {
$before = substr($xml_content, 0, $start_pos);
$after = substr($xml_content, $end_pos + strlen($xml_end));
$xml_content = $before . $after;
$xml_content = preg_replace("/\n\s*\n/", "\n", $xml_content);

$normalized_xml = preg_replace('/\s+/', '', $xml_content);
$empty_skeletons = [
'<?xmlversion="1.0"encoding="UTF-8"?><configuration><system.webServer><rewrite><rules></rules></rewrite></system.webServer></configuration>',
'<?xmlversion="1.0"encoding="UTF-8"?><configuration><system.webServer><rewrite/></system.webServer></configuration>',
'<?xmlversion="1.0"encoding="UTF-8"?><configuration><system.webServer/></configuration>',
'<?xmlversion="1.0"encoding="UTF-8"?><configuration/>',
''
];
if (in_array($normalized_xml, $empty_skeletons, true)) {
@unlink($web_config_file);
} else {
file_put_contents($web_config_file, trim($xml_content) . "\n", LOCK_EX);
}
}
}
return true;
}

$htaccess_rules = "{$htaccess_start}\n";
$htaccess_rules .= "<IfModule mod_rewrite.c>\n";
$htaccess_rules .= "RewriteEngine On\n";
$htaccess_rules .= "RewriteBase " . $sub_dir . "\n";

if ($permalink_type === 'numeric') {
$htaccess_rules .= "RewriteRule ^([0-9]+)\.html$ index.php?p=$1 [L,QSA]\n";
} elseif ($permalink_type === 'post') {
$htaccess_rules .= "RewriteRule ^post/([0-9]+)$ index.php?p=$1 [L,QSA]\n";
}

$htaccess_rules .= "RewriteCond %{REQUEST_FILENAME} !-f\n";
$htaccess_rules .= "RewriteCond %{REQUEST_FILENAME} !-d\n";
$htaccess_rules .= "RewriteRule . index.php [L]\n";
$htaccess_rules .= "</IfModule>\n";
$htaccess_rules .= "{$htaccess_end}";

$xml_rules_block = "{$xml_start}\n";
if ($permalink_type === 'numeric') {
$xml_rules_block .= '<rule name="LitaBlog Numeric Rule" stopProcessing="true">' . "\n";
$xml_rules_block .= '<match url="^([0-9]+)\.html$" />' . "\n";
$xml_rules_block .= '<action type="Rewrite" url="index.php?p={R:1}" />' . "\n";
$xml_rules_block .= '</rule>' . "\n";
} elseif ($permalink_type === 'post') {
$xml_rules_block .= '<rule name="LitaBlog Post Rule" stopProcessing="true">' . "\n";
$xml_rules_block .= '<match url="^post/([0-9]+)$" />' . "\n";
$xml_rules_block .= '<action type="Rewrite" url="index.php?p={R:1}" />' . "\n";
$xml_rules_block .= '</rule>' . "\n";
}

$xml_rules_block .= '<rule name="LitaBlog Index Fallback" stopProcessing="true">' . "\n";
$xml_rules_block .= '<match url="." />' . "\n";
$xml_rules_block .= '<conditions>' . "\n";
$xml_rules_block .= '<add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />' . "\n";
$xml_rules_block .= '<add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />' . "\n";
$xml_rules_block .= '</conditions>' . "\n";
$xml_rules_block .= '<action type="Rewrite" url="index.php" />' . "\n";
$xml_rules_block .= '</rule>' . "\n";
$xml_rules_block .= "{$xml_end}";

$htaccess_ok = false;
if (!file_exists($htaccess_file) || is_writable($htaccess_file)) {
if (file_exists($htaccess_file)) {
$existing_content = file_get_contents($htaccess_file);
$start_pos = strpos($existing_content, $htaccess_start);
$end_pos = strpos($existing_content, $htaccess_end);

if ($start_pos !== false && $end_pos !== false && $end_pos > $start_pos) {
$before = substr($existing_content, 0, $start_pos);
$after = substr($existing_content, $end_pos + strlen($htaccess_end));
$new_content = $before . $htaccess_rules . $after;
} else {
$new_content = rtrim($existing_content) . "\n\n" . $htaccess_rules . "\n";
}
} else {
$new_content = $htaccess_rules . "\n";
}
$htaccess_ok = (file_put_contents($htaccess_file, $new_content, LOCK_EX) !== false);
}

$web_config_ok = false;
if (!file_exists($web_config_file) || is_writable($web_config_file)) {
if (file_exists($web_config_file)) {
$existing_xml = file_get_contents($web_config_file);
$start_pos = strpos($existing_xml, $xml_start);
$end_pos = strpos($existing_xml, $xml_end);

if ($start_pos !== false && $end_pos !== false && $end_pos > $start_pos) {
$before = substr($existing_xml, 0, $start_pos);
$after = substr($existing_xml, $end_pos + strlen($xml_end));
$new_xml = $before . $xml_rules_block . $after;
} else {
$new_xml = $existing_xml;
if (preg_match('/<rules\s*>/i', $new_xml)) {
$new_xml = preg_replace('/<rules\s*\/>/i', '<rules></rules>', $new_xml);
$new_xml = preg_replace('/(<rules\s*>)/i', "$1\n" . $xml_rules_block . "\n", $new_xml, 1);
} elseif (preg_match('/<rewrite\s*>/i', $new_xml)) {
$new_xml = preg_replace('/<rewrite\s*\/>/i', '<rewrite></rewrite>', $new_xml);
$new_xml = preg_replace('/(<rewrite\s*>)/i', "$1\n<rules>\n" . $xml_rules_block . "\n</rules>", $new_xml, 1);
} elseif (preg_match('/<system\.webServer\s*>/i', $new_xml)) {
$new_xml = preg_replace('/<system\.webServer\s*\/>/i', '<system.webServer></system.webServer>', $new_xml);
$new_xml = preg_replace('/(<system\.webServer\s*>)/i', "$1\n<rewrite>\n<rules>\n" . $xml_rules_block . "\n</rules>\n</rewrite>", $new_xml, 1);
} elseif (preg_match('/<configuration\s*>/i', $new_xml)) {
$new_xml = preg_replace('/<configuration\s*\/>/i', '<configuration></configuration>', $new_xml);
$new_xml = preg_replace('/(<configuration\s*>)/i', "$1\n<system.webServer>\n<rewrite>\n<rules>\n" . $xml_rules_block . "\n</rules>\n</rewrite>\n</system.webServer>", $new_xml, 1);
} else {
$new_xml = $existing_xml . "\n" . $xml_rules_block . "\n";
}
}
} else {
$new_xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$new_xml .= '<configuration>' . "\n";
$new_xml .= '<system.webServer>' . "\n";
$new_xml .= '<rewrite>' . "\n";
$new_xml .= '<rules>' . "\n";
$new_xml .= $xml_rules_block . "\n"; 
$new_xml .= '</rules>' . "\n";
$new_xml .= '</rewrite>' . "\n";
$new_xml .= '</system.webServer>' . "\n";
$new_xml .= '</configuration>' . "\n";
}

$web_config_ok = (file_put_contents($web_config_file, $new_xml, LOCK_EX) !== false);
}

return ($htaccess_ok || $web_config_ok);
}

function litablog_purify_html($html) {
if (empty($html)) {
return '';
}

$dom = new DOMDocument();
@$dom->loadHTML(mb_convert_encoding('<div>' . $html . '</div>', 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

$allowed_tags = [
'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'span', 
'a', 'img', 'ul', 'ol', 'li', 'blockquote', 'pre', 'code', 
'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'video', 'audio', 'source',
'figure', 'figcaption',
'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td'
];

$destroy_tags = [
'script', 'style', 'iframe', 'object', 'embed', 
'form', 'input', 'textarea', 'button', 'noscript'
];

$allowed_attributes = [
'a'      => ['href', 'title', 'target', 'class', 'style', 'rel'],
'img'    => ['src', 'alt', 'title', 'class', 'style', 'width', 'height', 'loading', 'decoding'],
'span'   => ['class', 'style'],
'p'      => ['class', 'style', 'align'],
'div'    => ['class', 'style'],
'pre'    => ['class', 'style'],
'code'   => ['class'],
'video'  => ['src', 'controls', 'width', 'height', 'poster', 'preload', 'class', 'playsinline', 'controlslist'],
'audio'  => ['src', 'controls', 'preload', 'class'],
'source' => ['src', 'type']
];

$global_allowed_attributes = ['id', 'class', 'style'];

$root = $dom->getElementsByTagName('div')->item(0);
if (!$root) {
return '';
}

litablog_purify_node($root, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes);

$purified_html = '';
foreach ($root->childNodes as $child) {
$purified_html .= $dom->saveHTML($child);
}

return $purified_html;
}

function litablog_purify_node($node, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes) {
if ($node->hasChildNodes()) {
for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
$child = $node->childNodes->item($i);

if ($child->nodeType === XML_ELEMENT_NODE) {
$tag_name = strtolower($child->nodeName);

if (in_array($tag_name, $destroy_tags)) {
$node->removeChild($child);
continue;
}

if (!in_array($tag_name, $allowed_tags)) {
$textNode = $node->ownerDocument->createTextNode($child->textContent);
$node->replaceChild($textNode, $child);
continue;
}

litablog_purify_node_attributes($child, $tag_name, $allowed_attributes, $global_allowed_attributes);
litablog_purify_node($child, $allowed_tags, $destroy_tags, $allowed_attributes, $global_allowed_attributes);
}
}
}
}

function litablog_purify_node_attributes($element, $tag_name, $allowed_attributes, $global_allowed_attributes) {
if (!$element->hasAttributes()) {
return;
}

$attrs_to_remove = [];
$specific_allowed = $allowed_attributes[$tag_name] ?? [];

foreach ($element->attributes as $attr) {
$attr_name = strtolower($attr->nodeName);
$is_allowed = in_array($attr_name, $global_allowed_attributes) || in_array($attr_name, $specific_allowed);
if (!$is_allowed) {
$attrs_to_remove[] = $attr->nodeName;
continue;
}
/*HTML 净化器对 javascript: URL 的过滤可被空白字符绕过，注释掉待复核
if (in_array($attr_name, ['href', 'src'])) {
$value = trim($attr->nodeValue);
$clean_value = preg_replace('/[\r\n\t]/', '', strtolower($value));

if (preg_match('/^(javascript|vbscript|data|onload|onerror|onmouseover):/i', $clean_value)) {
$attrs_to_remove[] = $attr->nodeName;
continue;
}
}*/
if (in_array($attr_name, ['href', 'src'])) {
    $value = $attr->nodeValue;
    // 剥离所有 ASCII 控制符 + 空白（含 \x00-\x20, \xa0）
    $clean_value = preg_replace('/^[\x00-\x20\xa0]+|[\x00-\x20\xa0]+$/', '', $value);
    $lower = strtolower($clean_value);
    // 改为白名单：仅允许 http(s)://, 相对路径, #, mailto:, tel:, data:image/(png|gif|jpeg|webp)
    // 注意:定界符用 ~(不能用 #,模式内含 # 锚点会截断正则→preg_match 编译失败返回 false)
    $is_safe = preg_match('~^(https?:|mailto:|tel:|/|#|\./|\.\./|data:image/(png|gif|jpeg|webp))~i', $lower)
        || !preg_match('~^[a-z][a-z0-9+.\-]*:~i', $lower); // 无 scheme 也允许
    if (!$is_safe) { $attrs_to_remove[] = $attr->nodeName; continue; }
}

if ($attr_name === 'style') {
$style_value = strtolower(trim($attr->nodeValue));
// Enhanced with -moz-binding protection (Mitigates V-05)
if (preg_match('/(expression|behavior|url\s*\(|javascript:|mocha:|livescript:|-moz-binding)/i', $style_value)) {
$attrs_to_remove[] = $attr->nodeName;
}
}
}

foreach ($attrs_to_remove as $attr_name) {
$element->removeAttribute($attr_name);
}
}

function get_safe_redirect_url($fallback = SITE_URL, $allow_external = false) {
$referer = $_SERVER['HTTP_REFERER'] ?? '';
if (empty($referer)) {
return $fallback;
}

$parsed_referer = parse_url($referer);
$parsed_fallback = parse_url($fallback);

if (empty($parsed_referer['host'])) {
return $fallback;
}

if (!$allow_external) {
$site_host = $parsed_fallback['host'] ?? $_SERVER['HTTP_HOST'] ?? '';
if (empty($site_host)) {
return $fallback;
}

if ($parsed_referer['host'] !== $site_host && 
!preg_match('/\.' . preg_quote($site_host, '/') . '$/', $parsed_referer['host'])) {
return $fallback;
}
}

if (!in_array($parsed_referer['scheme'] ?? '', ['http', 'https'])) {
return $fallback;
}

$safe_url = $parsed_referer['scheme'] . '://' . $parsed_referer['host'];
if (isset($parsed_referer['port'])) {
$safe_url .= ':' . $parsed_referer['port'];
}
if (isset($parsed_referer['path'])) {
$safe_url .= $parsed_referer['path'];
}
if (isset($parsed_referer['query'])) {
$safe_url .= '?' . $parsed_referer['query'];
}
if (isset($parsed_referer['fragment'])) {
$safe_url .= '#' . $parsed_referer['fragment'];
}

return $safe_url;
}

function safe_redirect_from_referer($fallback = SITE_URL, $allow_external = false) {
$url = get_safe_redirect_url($fallback, $allow_external);
header('Location: ' . $url);
exit;
}

add_filter('the_content', 'litablog_purify_html', 9);
?>