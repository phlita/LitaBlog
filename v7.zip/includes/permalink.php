<?php
/**
* 固定链接设置类
*/
if (!defined('CORE')) {
    http_response_code(403);
    exit('Direct access not allowed.');
}
class Permalink {
// 固定链接类型
const TYPE_DEFAULT = 'default';     // 默认 ?p=123
const TYPE_NUMERIC = 'numeric';     // 数字式 123.html
const TYPE_POST = 'post';           // 文章式 post/123

/**
* 获取当前固定链接类型
*/
public static function get_type() {
return get_option('permalink_type', self::TYPE_DEFAULT);
}

/**
* 获取文章链接
*/
public static function get_post_link($post_id) {
$type = self::get_type();
$base_url = rtrim(SITE_URL, '/');

switch($type) {
case self::TYPE_NUMERIC:
return $base_url . '/' . $post_id . '.html';
case self::TYPE_POST:
return $base_url . '/post/' . $post_id;
default:
return $base_url . '/?p=' . $post_id;
}
}

/**
* 获取分类链接
*
* ★2026-09-17（与 v10 同步 ✓）：**URL 一律用数值 id** ✓ —— `?category=3`
*   理由（v10 已定的规则 ✓）：`name` / `slug` 是"**给人看的纯文本**" ✓（多语言原文原样存 ✓），
*   而 URL 是**给机器**用的 ✓ —— 人只看页面上的结果 ✓，不看地址栏 ✓。
*   机器用**唯一数值 id** 最简单 ✓：编码、重名、Unicode 归一化(NFC/NFD)、缓存白名单
*   这些连带问题**统统不存在** ✓（帖子链接早就是这个模型 ✓：`?p=<id>`）。
* ⚠️ **兼容**：传入非数字（尚未改到的旧调用点 ✓）→ 退回旧的 slug 形式 ✓ ——
*   老链接、书签、外部引用照旧能打开 ✓（不制造死链 ✓）。
*/
public static function get_category_link($id) {
$base_url = rtrim(SITE_URL, '/');
if (is_numeric($id)) return $base_url . '/?category=' . (int)$id;
return $base_url . '/?category=' . urlencode((string)$id);
}

/**
* 获取标签链接
*
* ★2026-09-17（与 v10 同步 ✓）：URL 用**数值 id** ✓（`?tag=6`）；非数字退回旧 slug 形式 ✓（兼容 ✓）。
*   ⚠️ 旧主题里是手拼 `?tag=` + `e($slug)` ✗ —— 用 `e()` 当 URL 编码是错的 ✗，
*      名字含 `&` / `#` / 空格就会断开 ✓；改用本方法后由 `urlencode` 负责 ✓。
*/
public static function get_tag_link($id) {
$base_url = rtrim(SITE_URL, '/');
if (is_numeric($id)) return $base_url . '/?tag=' . (int)$id;
return $base_url . '/?tag=' . urlencode((string)$id);
}
}
